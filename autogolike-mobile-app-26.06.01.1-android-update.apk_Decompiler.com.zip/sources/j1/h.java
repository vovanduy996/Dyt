package j1;

import K4.w;

/* JADX INFO: loaded from: classes.dex */
public final class h extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public i f10766o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Object f10767p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public w f10768q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public Object f10769r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public /* synthetic */ Object f10770s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ i f10771t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f10772u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public h(i iVar, M3.c cVar) {
        super(cVar);
        this.f10771t = iVar;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f10770s = obj;
        this.f10772u |= Integer.MIN_VALUE;
        return this.f10771t.b(null, this);
    }
}

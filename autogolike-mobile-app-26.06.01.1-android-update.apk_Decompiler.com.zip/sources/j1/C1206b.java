package j1;

import K4.A;

/* JADX INFO: renamed from: j1.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1206b extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public c f10745o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public A f10746p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f10747q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ c f10748r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f10749s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1206b(c cVar, M3.c cVar2) {
        super(cVar2);
        this.f10748r = cVar;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f10747q = obj;
        this.f10749s |= Integer.MIN_VALUE;
        return c.a(this.f10748r, this);
    }
}

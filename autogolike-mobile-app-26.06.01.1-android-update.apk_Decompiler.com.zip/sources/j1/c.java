package j1;

import K4.s;
import K4.w;
import h1.InterfaceC1056a;

/* JADX INFO: loaded from: classes.dex */
public class c implements InterfaceC1056a {
    public final s a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final w f10750b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final C1205a f10751c;

    public c(s sVar, w wVar) {
        U3.j.f(sVar, "fileSystem");
        U3.j.f(wVar, "path");
        this.a = sVar;
        this.f10750b = wVar;
        this.f10751c = new C1205a();
    }

    /* JADX WARN: Removed duplicated region for block: B:43:0x009b A[Catch: FileNotFoundException -> 0x009f, TRY_ENTER, TryCatch #0 {FileNotFoundException -> 0x009f, blocks: (B:43:0x009b, B:46:0x00a3, B:20:0x0043), top: B:54:0x0043 }] */
    /* JADX WARN: Removed duplicated region for block: B:46:0x00a3 A[Catch: FileNotFoundException -> 0x009f, TRY_LEAVE, TryCatch #0 {FileNotFoundException -> 0x009f, blocks: (B:43:0x009b, B:46:0x00a3, B:20:0x0043), top: B:54:0x0043 }] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00ae  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00b4  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x008a A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:63:0x007a A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0014  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.lang.Object a(j1.c r7, M3.c r8) throws java.lang.Throwable {
        /*
            r0 = 1
            boolean r1 = r8 instanceof j1.C1206b
            if (r1 == 0) goto L14
            r1 = r8
            j1.b r1 = (j1.C1206b) r1
            int r2 = r1.f10749s
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
            r4 = r2 & r3
            if (r4 == 0) goto L14
            int r2 = r2 - r3
            r1.f10749s = r2
            goto L19
        L14:
            j1.b r1 = new j1.b
            r1.<init>(r7, r8)
        L19:
            java.lang.Object r8 = r1.f10747q
            L3.a r2 = L3.a.f4629l
            int r3 = r1.f10749s
            r4 = 0
            if (r3 == 0) goto L36
            if (r3 != r0) goto L2e
            K4.A r7 = r1.f10746p
            j1.c r1 = r1.f10745o
            G3.AbstractC0164a.e(r8)     // Catch: java.lang.Throwable -> L2c
            goto L78
        L2c:
            r8 = move-exception
            goto L88
        L2e:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r8)
            throw r7
        L36:
            G3.AbstractC0164a.e(r8)
            j1.a r8 = r7.f10751c
            java.util.concurrent.atomic.AtomicBoolean r8 = r8.a
            boolean r8 = r8.get()
            if (r8 != 0) goto Lb5
            K4.s r8 = r7.a     // Catch: java.io.FileNotFoundException -> L9f
            K4.w r3 = r7.f10750b     // Catch: java.io.FileNotFoundException -> L9f
            r8.getClass()     // Catch: java.io.FileNotFoundException -> L9f
            java.lang.String r8 = "file"
            U3.j.f(r3, r8)     // Catch: java.io.FileNotFoundException -> L9f
            java.io.File r8 = r3.f()     // Catch: java.io.FileNotFoundException -> L9f
            java.util.logging.Logger r3 = K4.u.a     // Catch: java.io.FileNotFoundException -> L9f
            K4.d r3 = new K4.d     // Catch: java.io.FileNotFoundException -> L9f
            java.io.FileInputStream r5 = new java.io.FileInputStream     // Catch: java.io.FileNotFoundException -> L9f
            r5.<init>(r8)     // Catch: java.io.FileNotFoundException -> L9f
            K4.H r8 = K4.I.f4531d     // Catch: java.io.FileNotFoundException -> L9f
            r3.<init>(r5, r0, r8)     // Catch: java.io.FileNotFoundException -> L9f
            K4.A r8 = E4.l.g0(r3)     // Catch: java.io.FileNotFoundException -> L9f
            l1.e r3 = l1.e.a     // Catch: java.lang.Throwable -> L86
            r1.f10745o = r7     // Catch: java.lang.Throwable -> L86
            r1.f10746p = r8     // Catch: java.lang.Throwable -> L86
            r1.f10749s = r0     // Catch: java.lang.Throwable -> L86
            l1.b r1 = r3.b(r8)     // Catch: java.lang.Throwable -> L86
            if (r1 != r2) goto L74
            return r2
        L74:
            r6 = r1
            r1 = r7
            r7 = r8
            r8 = r6
        L78:
            if (r7 == 0) goto L7f
            r7.close()     // Catch: java.lang.Throwable -> L7e
            goto L7f
        L7e:
            r4 = move-exception
        L7f:
            r7 = r1
            goto L99
        L81:
            r6 = r1
            r1 = r7
            r7 = r8
            r8 = r6
            goto L88
        L86:
            r1 = move-exception
            goto L81
        L88:
            if (r7 == 0) goto L95
            r7.close()     // Catch: java.lang.Throwable -> L8e
            goto L95
        L8e:
            r7 = move-exception
            G3.AbstractC0164a.a(r8, r7)     // Catch: java.io.FileNotFoundException -> L93
            goto L95
        L93:
            r7 = move-exception
            goto La4
        L95:
            r7 = r1
            r6 = r4
            r4 = r8
            r8 = r6
        L99:
            if (r4 != 0) goto La3
            U3.j.c(r8)     // Catch: java.io.FileNotFoundException -> L9f
            goto Lb3
        L9f:
            r8 = move-exception
            r1 = r7
            r7 = r8
            goto La4
        La3:
            throw r4     // Catch: java.io.FileNotFoundException -> L9f
        La4:
            K4.s r8 = r1.a
            K4.w r1 = r1.f10750b
            boolean r8 = r8.a(r1)
            if (r8 != 0) goto Lb4
            l1.b r8 = new l1.b
            r8.<init>(r0)
        Lb3:
            return r8
        Lb4:
            throw r7
        Lb5:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r8 = "This scope has already been closed."
            r7.<init>(r8)
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: j1.c.a(j1.c, M3.c):java.lang.Object");
    }

    @Override // h1.InterfaceC1056a
    public final void close() {
        this.f10751c.a.set(true);
    }
}

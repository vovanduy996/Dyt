package j1;

import K4.m;
import K4.w;
import h1.U;

/* JADX INFO: loaded from: classes.dex */
public final class d extends U3.k implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final d f10752l = new d(2);

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        w wVar = (w) obj;
        U3.j.f(wVar, "path");
        U3.j.f((m) obj2, "<anonymous parameter 1>");
        return new U(n3.b.h(wVar.f4590l.q(), true).f4590l.q());
    }
}

package j1;

import G3.C;
import K4.w;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import e3.C0865A;

/* JADX INFO: loaded from: classes.dex */
public final class e extends U3.k implements T3.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f10753l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ f f10754m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ e(f fVar, int i5) {
        super(0);
        this.f10753l = i5;
        this.f10754m = fVar;
    }

    @Override // T3.a
    public final Object b() {
        switch (this.f10753l) {
            case ConfigBackupDto.$stable /* 0 */:
                f fVar = this.f10754m;
                w wVar = (w) fVar.f10758c.b();
                if (L4.c.a(wVar) != -1) {
                    return n3.b.h(wVar.f4590l.q(), true);
                }
                throw new IllegalStateException(("OkioStorage requires absolute paths, but did not get an absolute path from producePath = " + fVar.f10758c + ", instead got " + wVar).toString());
            default:
                C0865A c0865a = f.f10756f;
                f fVar2 = this.f10754m;
                synchronized (c0865a) {
                    f.f10755e.remove(((w) fVar2.f10759d.getValue()).f4590l.q());
                }
                return C.a;
        }
    }
}

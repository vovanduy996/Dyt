package j1;

/* JADX INFO: loaded from: classes.dex */
public final class g extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public i f10760o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public c f10761p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f10762q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f10763r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ i f10764s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f10765t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public g(i iVar, M3.c cVar) {
        super(cVar);
        this.f10764s = iVar;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f10763r = obj;
        this.f10765t |= Integer.MIN_VALUE;
        return this.f10764s.a(null, this);
    }
}

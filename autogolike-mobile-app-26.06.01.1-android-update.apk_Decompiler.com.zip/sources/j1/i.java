package j1;

import K4.s;
import K4.w;
import h1.InterfaceC1056a;
import h1.U;

/* JADX INFO: loaded from: classes.dex */
public final class i implements InterfaceC1056a {
    public final s a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final w f10773b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final U f10774c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final e f10775d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final C1205a f10776e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final n4.c f10777f;

    public i(s sVar, w wVar, U u5, e eVar) {
        U3.j.f(sVar, "fileSystem");
        U3.j.f(wVar, "path");
        U3.j.f(u5, "coordinator");
        this.a = sVar;
        this.f10773b = wVar;
        this.f10774c = u5;
        this.f10775d = eVar;
        this.f10776e = new C1205a();
        this.f10777f = n4.d.a();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0074  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x007c A[Catch: all -> 0x007d, TRY_ENTER, TRY_LEAVE, TryCatch #3 {all -> 0x007d, blocks: (B:33:0x007c, B:42:0x008d, B:41:0x008a, B:38:0x0085), top: B:57:0x0020, inners: #2 }] */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0097  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Type inference failed for: r0v10, types: [j1.i] */
    /* JADX WARN: Type inference failed for: r0v13 */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v2, types: [j1.g, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v4, types: [j1.i] */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9, types: [j1.i] */
    /* JADX WARN: Type inference failed for: r9v0, types: [h1.W] */
    /* JADX WARN: Type inference failed for: r9v1 */
    /* JADX WARN: Type inference failed for: r9v10 */
    /* JADX WARN: Type inference failed for: r9v11 */
    /* JADX WARN: Type inference failed for: r9v12 */
    /* JADX WARN: Type inference failed for: r9v15, types: [boolean] */
    /* JADX WARN: Type inference failed for: r9v16 */
    /* JADX WARN: Type inference failed for: r9v2 */
    /* JADX WARN: Type inference failed for: r9v6 */
    /* JADX WARN: Type inference failed for: r9v8 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object a(h1.W r9, M3.c r10) throws java.lang.Throwable {
        /*
            r8 = this;
            boolean r0 = r10 instanceof j1.g
            if (r0 == 0) goto L13
            r0 = r10
            j1.g r0 = (j1.g) r0
            int r1 = r0.f10765t
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f10765t = r1
            goto L18
        L13:
            j1.g r0 = new j1.g
            r0.<init>(r8, r10)
        L18:
            java.lang.Object r10 = r0.f10763r
            L3.a r1 = L3.a.f4629l
            int r2 = r0.f10765t
            r3 = 0
            r4 = 1
            if (r2 == 0) goto L38
            if (r2 != r4) goto L30
            boolean r9 = r0.f10762q
            j1.c r1 = r0.f10761p
            j1.i r0 = r0.f10760o
            G3.AbstractC0164a.e(r10)     // Catch: java.lang.Throwable -> L2e
            goto L6c
        L2e:
            r10 = move-exception
            goto L85
        L30:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r10 = "call to 'resume' before 'invoke' with coroutine"
            r9.<init>(r10)
            throw r9
        L38:
            G3.AbstractC0164a.e(r10)
            j1.a r10 = r8.f10776e
            java.util.concurrent.atomic.AtomicBoolean r10 = r10.a
            boolean r10 = r10.get()
            if (r10 != 0) goto L9d
            n4.c r10 = r8.f10777f
            boolean r10 = r10.d(r3)
            j1.c r2 = new j1.c     // Catch: java.lang.Throwable -> L93
            K4.s r5 = r8.a     // Catch: java.lang.Throwable -> L93
            K4.w r6 = r8.f10773b     // Catch: java.lang.Throwable -> L93
            r2.<init>(r5, r6)     // Catch: java.lang.Throwable -> L93
            java.lang.Boolean r5 = java.lang.Boolean.valueOf(r10)     // Catch: java.lang.Throwable -> L7f
            r0.f10760o = r8     // Catch: java.lang.Throwable -> L7f
            r0.f10761p = r2     // Catch: java.lang.Throwable -> L7f
            r0.f10762q = r10     // Catch: java.lang.Throwable -> L7f
            r0.f10765t = r4     // Catch: java.lang.Throwable -> L7f
            java.lang.Object r9 = r9.h(r2, r5, r0)     // Catch: java.lang.Throwable -> L7f
            if (r9 != r1) goto L67
            return r1
        L67:
            r0 = r8
            r1 = r2
            r7 = r10
            r10 = r9
            r9 = r7
        L6c:
            r1.close()     // Catch: java.lang.Throwable -> L71
            r1 = r3
            goto L72
        L71:
            r1 = move-exception
        L72:
            if (r1 != 0) goto L7c
            if (r9 == 0) goto L7b
            n4.c r9 = r0.f10777f
            r9.e(r3)
        L7b:
            return r10
        L7c:
            throw r1     // Catch: java.lang.Throwable -> L7d
        L7d:
            r10 = move-exception
            goto L95
        L7f:
            r9 = move-exception
            r0 = r8
            r1 = r2
            r7 = r10
            r10 = r9
            r9 = r7
        L85:
            r1.close()     // Catch: java.lang.Throwable -> L89
            goto L8d
        L89:
            r1 = move-exception
            G3.AbstractC0164a.a(r10, r1)     // Catch: java.lang.Throwable -> L7d
        L8d:
            throw r10     // Catch: java.lang.Throwable -> L7d
        L8e:
            r0 = r8
            r7 = r10
            r10 = r9
            r9 = r7
            goto L95
        L93:
            r9 = move-exception
            goto L8e
        L95:
            if (r9 == 0) goto L9c
            n4.c r9 = r0.f10777f
            r9.e(r3)
        L9c:
            throw r10
        L9d:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r10 = "StorageConnection has already been disposed."
            r9.<init>(r10)
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: j1.i.a(h1.W, M3.c):java.lang.Object");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:57:0x011a A[Catch: all -> 0x012a, IOException -> 0x012d, TRY_ENTER, TryCatch #9 {IOException -> 0x012d, all -> 0x012a, blocks: (B:57:0x011a, B:59:0x0122, B:67:0x013a, B:74:0x0149, B:73:0x0146, B:70:0x0141), top: B:95:0x0021, inners: #0 }] */
    /* JADX WARN: Removed duplicated region for block: B:67:0x013a A[Catch: all -> 0x012a, IOException -> 0x012d, TRY_ENTER, TRY_LEAVE, TryCatch #9 {IOException -> 0x012d, all -> 0x012a, blocks: (B:57:0x011a, B:59:0x0122, B:67:0x013a, B:74:0x0149, B:73:0x0146, B:70:0x0141), top: B:95:0x0021, inners: #0 }] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Removed duplicated region for block: B:98:0x0155 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11, types: [j1.i] */
    /* JADX WARN: Type inference failed for: r0v12, types: [j1.i] */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v16 */
    /* JADX WARN: Type inference failed for: r0v17 */
    /* JADX WARN: Type inference failed for: r0v2, types: [M3.c, j1.h, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v4, types: [K4.m, K4.s] */
    /* JADX WARN: Type inference failed for: r0v6, types: [K4.s, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r10v20, types: [K4.m, K4.s] */
    /* JADX WARN: Type inference failed for: r10v23, types: [K4.s] */
    /* JADX WARN: Type inference failed for: r10v27 */
    /* JADX WARN: Type inference failed for: r10v31 */
    /* JADX WARN: Type inference failed for: r10v9, types: [T3.e] */
    /* JADX WARN: Type inference failed for: r11v1, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r11v13, types: [java.lang.Object, n4.c] */
    /* JADX WARN: Type inference failed for: r11v16, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r11v2 */
    /* JADX WARN: Type inference failed for: r11v20 */
    /* JADX WARN: Type inference failed for: r11v23 */
    /* JADX WARN: Type inference failed for: r11v3 */
    /* JADX WARN: Type inference failed for: r11v4 */
    /* JADX WARN: Type inference failed for: r1v0, types: [L3.a, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r1v1 */
    /* JADX WARN: Type inference failed for: r1v2 */
    /* JADX WARN: Type inference failed for: r1v3 */
    /* JADX WARN: Type inference failed for: r1v4 */
    /* JADX WARN: Type inference failed for: r1v5, types: [K4.w] */
    /* JADX WARN: Type inference failed for: r1v6, types: [K4.w] */
    /* JADX WARN: Type inference failed for: r1v9 */
    /* JADX WARN: Type inference failed for: r2v0, types: [int] */
    /* JADX WARN: Type inference failed for: r2v1 */
    /* JADX WARN: Type inference failed for: r2v10 */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v15, types: [n4.a] */
    /* JADX WARN: Type inference failed for: r2v16 */
    /* JADX WARN: Type inference failed for: r2v2 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r2v4, types: [K4.w] */
    /* JADX WARN: Type inference failed for: r2v7, types: [K4.w] */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r6v0 */
    /* JADX WARN: Type inference failed for: r6v1, types: [j1.i] */
    /* JADX WARN: Type inference failed for: r6v4 */
    /* JADX WARN: Type inference failed for: r6v5, types: [j1.i] */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r8v6, types: [K4.s] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object b(h1.C1055J r10, M3.c r11) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 372
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: j1.i.b(h1.J, M3.c):java.lang.Object");
    }

    @Override // h1.InterfaceC1056a
    public final void close() {
        this.f10776e.a.set(true);
        this.f10775d.b();
    }
}

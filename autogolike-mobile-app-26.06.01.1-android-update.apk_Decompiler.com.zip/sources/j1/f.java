package j1;

import A.I;
import G3.AbstractC0164a;
import G3.q;
import K4.s;
import e3.C0865A;
import java.util.LinkedHashSet;

/* JADX INFO: loaded from: classes.dex */
public final class f {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final LinkedHashSet f10755e = new LinkedHashSet();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final C0865A f10756f = new C0865A(21);
    public final s a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final T3.e f10757b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final I f10758c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final q f10759d;

    public f(s sVar, I i5) {
        d dVar = d.f10752l;
        U3.j.f(sVar, "fileSystem");
        this.a = sVar;
        this.f10757b = dVar;
        this.f10758c = i5;
        this.f10759d = AbstractC0164a.d(new e(this, 0));
    }
}

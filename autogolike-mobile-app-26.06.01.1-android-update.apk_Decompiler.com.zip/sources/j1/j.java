package j1;

import K4.r;
import K4.y;

/* JADX INFO: loaded from: classes.dex */
public final class j extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public r f10778o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public r f10779p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public y f10780q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f10781r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ k f10782s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f10783t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j(k kVar, M3.c cVar) {
        super(cVar);
        this.f10782s = kVar;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f10781r = obj;
        this.f10783t |= Integer.MIN_VALUE;
        return this.f10782s.b(null, this);
    }
}

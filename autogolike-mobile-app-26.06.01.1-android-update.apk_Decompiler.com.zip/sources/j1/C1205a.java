package j1;

import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: renamed from: j1.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1205a {
    public final AtomicBoolean a;

    public C1205a() {
        this.a = new AtomicBoolean(false);
    }

    public C1205a(boolean z3) {
        this.a = new AtomicBoolean(z3);
    }
}

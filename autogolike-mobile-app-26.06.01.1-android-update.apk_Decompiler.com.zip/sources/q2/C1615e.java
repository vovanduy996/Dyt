package q2;

import P1.k;
import android.os.CancellationSignal;
import androidx.room.t;
import com.autogolike.mobile.core.account.db.AutoGoLikeDatabase_Impl;
import com.autogolike.mobile.core.warmup.template.WarmupTemplateDao;
import com.autogolike.mobile.core.warmup.template.WarmupTemplateEntity;
import i4.InterfaceC1183g;
import java.util.List;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: q2.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1615e implements WarmupTemplateDao {
    public final AutoGoLikeDatabase_Impl a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final P1.e f12685b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final C1614d f12686c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final C1614d f12687d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final P1.f f12688e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final P1.f f12689f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final P1.f f12690g;

    public C1615e(AutoGoLikeDatabase_Impl autoGoLikeDatabase_Impl) {
        this.a = autoGoLikeDatabase_Impl;
        this.f12685b = new P1.e(autoGoLikeDatabase_Impl, 3);
        this.f12686c = new C1614d(autoGoLikeDatabase_Impl, 0);
        this.f12687d = new C1614d(autoGoLikeDatabase_Impl, 1);
        this.f12688e = new P1.f(autoGoLikeDatabase_Impl, 8);
        this.f12689f = new P1.f(autoGoLikeDatabase_Impl, 9);
        this.f12690g = new P1.f(autoGoLikeDatabase_Impl, 10);
    }

    @Override // com.autogolike.mobile.core.warmup.template.WarmupTemplateDao
    public final Object delete(WarmupTemplateEntity warmupTemplateEntity, Continuation continuation) {
        return androidx.room.h.b(this.a, new CallableC1612b(this, warmupTemplateEntity, 2), continuation);
    }

    @Override // com.autogolike.mobile.core.warmup.template.WarmupTemplateDao
    public final Object deleteAllOfKind(String str, String str2, Continuation continuation) {
        return androidx.room.h.b(this.a, new P1.c(4, this, str, str2), continuation);
    }

    @Override // com.autogolike.mobile.core.warmup.template.WarmupTemplateDao
    public final Object deleteById(long j5, Continuation continuation) {
        return androidx.room.h.b(this.a, new P1.h(2, j5, this), continuation);
    }

    @Override // com.autogolike.mobile.core.warmup.template.WarmupTemplateDao
    public final Object insert(WarmupTemplateEntity warmupTemplateEntity, Continuation continuation) {
        return androidx.room.h.b(this.a, new CallableC1612b(this, warmupTemplateEntity, 1), continuation);
    }

    @Override // com.autogolike.mobile.core.warmup.template.WarmupTemplateDao
    public final Object insertAll(List list, Continuation continuation) {
        return androidx.room.h.b(this.a, new P1.d(this, 9, list), continuation);
    }

    @Override // com.autogolike.mobile.core.warmup.template.WarmupTemplateDao
    public final Object markUsed(long j5, long j6, Continuation continuation) {
        return androidx.room.h.b(this.a, new k(this, j6, j5, 1), continuation);
    }

    @Override // com.autogolike.mobile.core.warmup.template.WarmupTemplateDao
    public final InterfaceC1183g observe(String str, String str2) {
        t tVarA = t.a("SELECT * FROM warmup_templates WHERE platform = ? AND kind = ? ORDER BY createdAt DESC", 2);
        tVarA.H(str, 1);
        tVarA.H(str2, 2);
        CallableC1613c callableC1613c = new CallableC1613c(this, tVarA, 0);
        return androidx.room.h.a(this.a, new String[]{"warmup_templates"}, callableC1613c);
    }

    @Override // com.autogolike.mobile.core.warmup.template.WarmupTemplateDao
    public final InterfaceC1183g observeEnabledCount(String str, String str2) {
        t tVarA = t.a("SELECT COUNT(*) FROM warmup_templates WHERE platform = ? AND kind = ? AND enabled = 1", 2);
        tVarA.H(str, 1);
        tVarA.H(str2, 2);
        CallableC1613c callableC1613c = new CallableC1613c(this, tVarA, 2);
        return androidx.room.h.a(this.a, new String[]{"warmup_templates"}, callableC1613c);
    }

    @Override // com.autogolike.mobile.core.warmup.template.WarmupTemplateDao
    public final Object pickLeastRecentlyUsed(String str, String str2, Continuation continuation) {
        t tVarA = t.a("SELECT * FROM warmup_templates WHERE platform = ? AND kind = ? AND enabled = 1 ORDER BY lastUsedAt ASC LIMIT 1", 2);
        tVarA.H(str, 1);
        tVarA.H(str2, 2);
        return androidx.room.h.c(this.a, new CancellationSignal(), new CallableC1613c(this, tVarA, 1), continuation);
    }

    @Override // com.autogolike.mobile.core.warmup.template.WarmupTemplateDao
    public final Object update(WarmupTemplateEntity warmupTemplateEntity, Continuation continuation) {
        return androidx.room.h.b(this.a, new CallableC1612b(this, warmupTemplateEntity, 0), continuation);
    }
}

package q2;

import android.database.Cursor;
import android.os.CancellationSignal;
import androidx.room.t;
import com.autogolike.mobile.core.account.db.AutoGoLikeDatabase_Impl;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import com.autogolike.mobile.core.warmup.template.WarmupTemplateEntity;
import f.C0933a;
import java.util.ArrayList;
import java.util.concurrent.Callable;

/* JADX INFO: renamed from: q2.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class CallableC1613c implements Callable {
    public final /* synthetic */ int a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ t f12682b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ C1615e f12683c;

    public /* synthetic */ CallableC1613c(C1615e c1615e, t tVar, int i5) {
        this.a = i5;
        this.f12683c = c1615e;
        this.f12682b = tVar;
    }

    @Override // java.util.concurrent.Callable
    public final Object call() {
        Cursor cursorQuery;
        switch (this.a) {
            case ConfigBackupDto.$stable /* 0 */:
                cursorQuery = this.f12683c.a.query(this.f12682b, (CancellationSignal) null);
                try {
                    int iS = C0933a.S(cursorQuery, "id");
                    int iS2 = C0933a.S(cursorQuery, "platform");
                    int iS3 = C0933a.S(cursorQuery, "kind");
                    int iS4 = C0933a.S(cursorQuery, "text");
                    int iS5 = C0933a.S(cursorQuery, "enabled");
                    int iS6 = C0933a.S(cursorQuery, "lastUsedAt");
                    int iS7 = C0933a.S(cursorQuery, "createdAt");
                    ArrayList arrayList = new ArrayList(cursorQuery.getCount());
                    while (cursorQuery.moveToNext()) {
                        arrayList.add(new WarmupTemplateEntity(cursorQuery.getLong(iS), cursorQuery.getString(iS2), cursorQuery.getString(iS3), cursorQuery.getString(iS4), cursorQuery.getInt(iS5) != 0, cursorQuery.getLong(iS6), cursorQuery.getLong(iS7)));
                        break;
                    }
                    return arrayList;
                } finally {
                    cursorQuery.close();
                }
            case 1:
                AutoGoLikeDatabase_Impl autoGoLikeDatabase_Impl = this.f12683c.a;
                t tVar = this.f12682b;
                WarmupTemplateEntity warmupTemplateEntity = null;
                Cursor cursorQuery2 = autoGoLikeDatabase_Impl.query(tVar, (CancellationSignal) null);
                try {
                    int iS8 = C0933a.S(cursorQuery2, "id");
                    int iS9 = C0933a.S(cursorQuery2, "platform");
                    int iS10 = C0933a.S(cursorQuery2, "kind");
                    int iS11 = C0933a.S(cursorQuery2, "text");
                    int iS12 = C0933a.S(cursorQuery2, "enabled");
                    int iS13 = C0933a.S(cursorQuery2, "lastUsedAt");
                    int iS14 = C0933a.S(cursorQuery2, "createdAt");
                    if (cursorQuery2.moveToFirst()) {
                        warmupTemplateEntity = new WarmupTemplateEntity(cursorQuery2.getLong(iS8), cursorQuery2.getString(iS9), cursorQuery2.getString(iS10), cursorQuery2.getString(iS11), cursorQuery2.getInt(iS12) != 0, cursorQuery2.getLong(iS13), cursorQuery2.getLong(iS14));
                        break;
                    }
                    return warmupTemplateEntity;
                } finally {
                    cursorQuery2.close();
                    tVar.b();
                }
            default:
                cursorQuery = this.f12683c.a.query(this.f12682b, (CancellationSignal) null);
                try {
                    return cursorQuery.moveToFirst() ? Integer.valueOf(cursorQuery.getInt(0)) : 0;
                } catch (Throwable th) {
                    throw th;
                }
        }
    }

    public void finalize() throws Throwable {
        switch (this.a) {
            case ConfigBackupDto.$stable /* 0 */:
                this.f12682b.b();
                break;
            case 1:
            default:
                super.finalize();
                break;
            case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                this.f12682b.b();
                break;
        }
    }
}

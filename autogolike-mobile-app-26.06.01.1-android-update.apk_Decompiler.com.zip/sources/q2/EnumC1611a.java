package q2;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: q2.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC1611a {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final EnumC1611a f12675m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final EnumC1611a f12676n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final /* synthetic */ EnumC1611a[] f12677o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final /* synthetic */ N3.a f12678p;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final String f12679l;

    static {
        EnumC1611a enumC1611a = new EnumC1611a(0, "Comment", "comment");
        f12675m = enumC1611a;
        EnumC1611a enumC1611a2 = new EnumC1611a(1, "Reply", "reply");
        f12676n = enumC1611a2;
        EnumC1611a[] enumC1611aArr = {enumC1611a, enumC1611a2};
        f12677o = enumC1611aArr;
        f12678p = new N3.a(enumC1611aArr);
    }

    public EnumC1611a(int i5, String str, String str2) {
        this.f12679l = str2;
    }

    public static EnumC1611a valueOf(String str) {
        return (EnumC1611a) Enum.valueOf(EnumC1611a.class, str);
    }

    public static EnumC1611a[] values() {
        return (EnumC1611a[]) f12677o.clone();
    }
}

package q2;

import G3.C;
import com.autogolike.mobile.core.account.db.AutoGoLikeDatabase_Impl;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import com.autogolike.mobile.core.warmup.template.WarmupTemplateEntity;
import java.util.concurrent.Callable;

/* JADX INFO: renamed from: q2.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class CallableC1612b implements Callable {
    public final /* synthetic */ int a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ WarmupTemplateEntity f12680b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ C1615e f12681c;

    public /* synthetic */ CallableC1612b(C1615e c1615e, WarmupTemplateEntity warmupTemplateEntity, int i5) {
        this.a = i5;
        this.f12681c = c1615e;
        this.f12680b = warmupTemplateEntity;
    }

    @Override // java.util.concurrent.Callable
    public final Object call() {
        AutoGoLikeDatabase_Impl autoGoLikeDatabase_Impl;
        switch (this.a) {
            case ConfigBackupDto.$stable /* 0 */:
                C1615e c1615e = this.f12681c;
                autoGoLikeDatabase_Impl = c1615e.a;
                autoGoLikeDatabase_Impl.beginTransaction();
                try {
                    C1614d c1614d = c1615e.f12687d;
                    WarmupTemplateEntity warmupTemplateEntity = this.f12680b;
                    G1.e eVarA = c1614d.a();
                    try {
                        c1614d.d(eVarA, warmupTemplateEntity);
                        eVarA.x();
                        c1614d.c(eVarA);
                        autoGoLikeDatabase_Impl.setTransactionSuccessful();
                        autoGoLikeDatabase_Impl.endTransaction();
                        return C.a;
                    } catch (Throwable th) {
                        c1614d.c(eVarA);
                        throw th;
                    }
                } finally {
                }
            case 1:
                C1615e c1615e2 = this.f12681c;
                autoGoLikeDatabase_Impl = c1615e2.a;
                autoGoLikeDatabase_Impl.beginTransaction();
                try {
                    Long lValueOf = Long.valueOf(c1615e2.f12685b.e(this.f12680b));
                    autoGoLikeDatabase_Impl.setTransactionSuccessful();
                    return lValueOf;
                } finally {
                }
            default:
                C1615e c1615e3 = this.f12681c;
                autoGoLikeDatabase_Impl = c1615e3.a;
                autoGoLikeDatabase_Impl.beginTransaction();
                try {
                    C1614d c1614d2 = c1615e3.f12686c;
                    WarmupTemplateEntity warmupTemplateEntity2 = this.f12680b;
                    G1.e eVarA2 = c1614d2.a();
                    try {
                        c1614d2.d(eVarA2, warmupTemplateEntity2);
                        eVarA2.x();
                        c1614d2.c(eVarA2);
                        autoGoLikeDatabase_Impl.setTransactionSuccessful();
                        autoGoLikeDatabase_Impl.endTransaction();
                        return C.a;
                    } catch (Throwable th2) {
                        c1614d2.c(eVarA2);
                        throw th2;
                    }
                } finally {
                }
        }
    }
}

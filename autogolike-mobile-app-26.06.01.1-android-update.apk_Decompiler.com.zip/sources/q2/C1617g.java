package q2;

/* JADX INFO: renamed from: q2.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1617g extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public Object f12695o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public /* synthetic */ Object f12696p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ C1618h f12697q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f12698r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1617g(C1618h c1618h, M3.c cVar) {
        super(cVar);
        this.f12697q = c1618h;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f12696p = obj;
        this.f12698r |= Integer.MIN_VALUE;
        return this.f12697q.b(null, null, this);
    }
}

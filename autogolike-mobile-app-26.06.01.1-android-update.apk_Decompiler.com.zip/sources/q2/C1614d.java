package q2;

import androidx.room.RoomDatabase;
import androidx.room.j;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import com.autogolike.mobile.core.warmup.template.WarmupTemplateEntity;

/* JADX INFO: renamed from: q2.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1614d extends j {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f12684d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C1614d(RoomDatabase roomDatabase, int i5) {
        super(roomDatabase);
        this.f12684d = i5;
    }

    @Override // androidx.room.v
    public final String b() {
        switch (this.f12684d) {
            case ConfigBackupDto.$stable /* 0 */:
                return "DELETE FROM `warmup_templates` WHERE `id` = ?";
            default:
                return "UPDATE OR ABORT `warmup_templates` SET `id` = ?,`platform` = ?,`kind` = ?,`text` = ?,`enabled` = ?,`lastUsedAt` = ?,`createdAt` = ? WHERE `id` = ?";
        }
    }

    @Override // androidx.room.j
    public final void d(G1.e eVar, Object obj) {
        switch (this.f12684d) {
            case ConfigBackupDto.$stable /* 0 */:
                eVar.S(((WarmupTemplateEntity) obj).getId(), 1);
                break;
            default:
                WarmupTemplateEntity warmupTemplateEntity = (WarmupTemplateEntity) obj;
                eVar.S(warmupTemplateEntity.getId(), 1);
                eVar.H(warmupTemplateEntity.getPlatform(), 2);
                eVar.H(warmupTemplateEntity.getKind(), 3);
                eVar.H(warmupTemplateEntity.getText(), 4);
                eVar.S(warmupTemplateEntity.getEnabled() ? 1L : 0L, 5);
                eVar.S(warmupTemplateEntity.getLastUsedAt(), 6);
                eVar.S(warmupTemplateEntity.getCreatedAt(), 7);
                eVar.S(warmupTemplateEntity.getId(), 8);
                break;
        }
    }
}

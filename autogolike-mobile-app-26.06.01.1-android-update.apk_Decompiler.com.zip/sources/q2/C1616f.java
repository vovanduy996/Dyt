package q2;

import java.util.ArrayList;

/* JADX INFO: renamed from: q2.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1616f extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public ArrayList f12691o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public /* synthetic */ Object f12692p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ C1618h f12693q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f12694r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1616f(C1618h c1618h, M3.c cVar) {
        super(cVar);
        this.f12693q = c1618h;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f12692p = obj;
        this.f12694r |= Integer.MIN_VALUE;
        return this.f12693q.a(null, null, null, this);
    }
}

package q2;

import U3.j;
import com.autogolike.mobile.core.warmup.template.WarmupTemplateDao;

/* JADX INFO: renamed from: q2.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1618h {
    public final WarmupTemplateDao a;

    public C1618h(WarmupTemplateDao warmupTemplateDao) {
        j.f(warmupTemplateDao, "dao");
        this.a = warmupTemplateDao;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object a(java.lang.String r23, q2.EnumC1611a r24, java.lang.String r25, M3.c r26) {
        /*
            Method dump skipped, instruction units count: 203
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: q2.C1618h.a(java.lang.String, q2.a, java.lang.String, M3.c):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:8:0x0014  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object b(java.lang.String r10, q2.EnumC1611a r11, M3.c r12) {
        /*
            r9 = this;
            boolean r0 = r12 instanceof q2.C1617g
            if (r0 == 0) goto L14
            r0 = r12
            q2.g r0 = (q2.C1617g) r0
            int r1 = r0.f12698r
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L14
            int r1 = r1 - r2
            r0.f12698r = r1
        L12:
            r6 = r0
            goto L1a
        L14:
            q2.g r0 = new q2.g
            r0.<init>(r9, r12)
            goto L12
        L1a:
            java.lang.Object r12 = r6.f12696p
            L3.a r0 = L3.a.f4629l
            int r1 = r6.f12698r
            r2 = 2
            r3 = 1
            if (r1 == 0) goto L40
            if (r1 == r3) goto L38
            if (r1 != r2) goto L30
            java.lang.Object r10 = r6.f12695o
            com.autogolike.mobile.core.warmup.template.WarmupTemplateEntity r10 = (com.autogolike.mobile.core.warmup.template.WarmupTemplateEntity) r10
            G3.AbstractC0164a.e(r12)
            goto L72
        L30:
            java.lang.IllegalStateException r10 = new java.lang.IllegalStateException
            java.lang.String r11 = "call to 'resume' before 'invoke' with coroutine"
            r10.<init>(r11)
            throw r10
        L38:
            java.lang.Object r10 = r6.f12695o
            q2.h r10 = (q2.C1618h) r10
            G3.AbstractC0164a.e(r12)
            goto L53
        L40:
            G3.AbstractC0164a.e(r12)
            java.lang.String r11 = r11.f12679l
            r6.f12695o = r9
            r6.f12698r = r3
            com.autogolike.mobile.core.warmup.template.WarmupTemplateDao r12 = r9.a
            java.lang.Object r12 = r12.pickLeastRecentlyUsed(r10, r11, r6)
            if (r12 != r0) goto L52
            return r0
        L52:
            r10 = r9
        L53:
            r11 = r12
            com.autogolike.mobile.core.warmup.template.WarmupTemplateEntity r11 = (com.autogolike.mobile.core.warmup.template.WarmupTemplateEntity) r11
            if (r11 != 0) goto L5a
            r10 = 0
            return r10
        L5a:
            com.autogolike.mobile.core.warmup.template.WarmupTemplateDao r1 = r10.a
            long r3 = r11.getId()
            long r7 = java.lang.System.currentTimeMillis()
            r6.f12695o = r11
            r6.f12698r = r2
            r2 = r3
            r4 = r7
            java.lang.Object r10 = r1.markUsed(r2, r4, r6)
            if (r10 != r0) goto L71
            return r0
        L71:
            r10 = r11
        L72:
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: q2.C1618h.b(java.lang.String, q2.a, M3.c):java.lang.Object");
    }
}

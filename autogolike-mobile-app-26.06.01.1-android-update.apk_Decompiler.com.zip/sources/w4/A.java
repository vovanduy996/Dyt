package w4;

import java.io.Closeable;

/* JADX INFO: loaded from: classes.dex */
public final class A implements Closeable {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final D4.g f15138l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final w f15139m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final String f15140n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final int f15141o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final m f15142p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final n f15143q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final B f15144r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final A f15145s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final A f15146t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final A f15147u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final long f15148v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final long f15149w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final A4.e f15150x;

    public A(D4.g gVar, w wVar, String str, int i5, m mVar, n nVar, B b3, A a, A a5, A a6, long j5, long j6, A4.e eVar) {
        U3.j.f(gVar, "request");
        U3.j.f(wVar, "protocol");
        U3.j.f(str, "message");
        this.f15138l = gVar;
        this.f15139m = wVar;
        this.f15140n = str;
        this.f15141o = i5;
        this.f15142p = mVar;
        this.f15143q = nVar;
        this.f15144r = b3;
        this.f15145s = a;
        this.f15146t = a5;
        this.f15147u = a6;
        this.f15148v = j5;
        this.f15149w = j6;
        this.f15150x = eVar;
    }

    public static String a(String str, A a) {
        a.getClass();
        String strB = a.f15143q.b(str);
        if (strB == null) {
            return null;
        }
        return strB;
    }

    public final boolean b() {
        int i5 = this.f15141o;
        return 200 <= i5 && i5 < 300;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        B b3 = this.f15144r;
        if (b3 == null) {
            throw new IllegalStateException("response is not eligible for a body and must not be closed");
        }
        b3.close();
    }

    public final z f() {
        z zVar = new z();
        zVar.a = this.f15138l;
        zVar.f15317b = this.f15139m;
        zVar.f15318c = this.f15141o;
        zVar.f15319d = this.f15140n;
        zVar.f15320e = this.f15142p;
        zVar.f15321f = this.f15143q.e();
        zVar.f15322g = this.f15144r;
        zVar.f15323h = this.f15145s;
        zVar.f15324i = this.f15146t;
        zVar.f15325j = this.f15147u;
        zVar.f15326k = this.f15148v;
        zVar.f15327l = this.f15149w;
        zVar.f15328m = this.f15150x;
        return zVar;
    }

    public final String toString() {
        return "Response{protocol=" + this.f15139m + ", code=" + this.f15141o + ", message=" + this.f15140n + ", url=" + ((p) this.f15138l.f1094b) + '}';
    }
}

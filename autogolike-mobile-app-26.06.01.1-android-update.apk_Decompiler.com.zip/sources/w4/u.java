package w4;

import A.C0016q;
import e3.C0867C;
import java.util.ArrayList;
import java.util.List;
import javax.net.SocketFactory;

/* JADX INFO: loaded from: classes.dex */
public final class u {
    public final M1.m a = new M1.m(11);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C0867C f15263b = new C0867C(24);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ArrayList f15264c = new ArrayList();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ArrayList f15265d = new ArrayList();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final C0016q f15266e = new C0016q(21);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f15267f = true;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final C2017b f15268g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final boolean f15269h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f15270i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final C2017b f15271j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final C2017b f15272k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final C2017b f15273l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final SocketFactory f15274m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final List f15275n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final List f15276o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final I4.c f15277p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public f f15278q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f15279r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f15280s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f15281t;

    public u() {
        C2017b c2017b = C2017b.a;
        this.f15268g = c2017b;
        this.f15269h = true;
        this.f15270i = true;
        this.f15271j = C2017b.f15169b;
        this.f15272k = C2017b.f15170c;
        this.f15273l = c2017b;
        SocketFactory socketFactory = SocketFactory.getDefault();
        U3.j.e(socketFactory, "getDefault()");
        this.f15274m = socketFactory;
        this.f15275n = v.f15283L;
        this.f15276o = v.f15282K;
        this.f15277p = I4.c.a;
        this.f15278q = f.f15186c;
        this.f15279r = 10000;
        this.f15280s = 10000;
        this.f15281t = 10000;
    }

    public final void a(q qVar) {
        U3.j.f(qVar, "interceptor");
        this.f15264c.add(qVar);
    }
}

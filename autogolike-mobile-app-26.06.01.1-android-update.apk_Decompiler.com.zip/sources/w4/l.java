package w4;

import K4.C0323f;
import K4.InterfaceC0324g;
import java.io.EOFException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import m1.AbstractC1383i;

/* JADX INFO: loaded from: classes.dex */
public final class l extends y {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final r f15227c;
    public final List a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final List f15228b;

    static {
        Pattern pattern = r.f15250d;
        f15227c = AbstractC1383i.F("application/x-www-form-urlencoded");
    }

    public l(ArrayList arrayList, ArrayList arrayList2) {
        U3.j.f(arrayList, "encodedNames");
        U3.j.f(arrayList2, "encodedValues");
        this.a = x4.b.x(arrayList);
        this.f15228b = x4.b.x(arrayList2);
    }

    @Override // w4.y
    public final long a() {
        return d(null, true);
    }

    @Override // w4.y
    public final r b() {
        return f15227c;
    }

    @Override // w4.y
    public final void c(InterfaceC0324g interfaceC0324g) throws EOFException {
        d(interfaceC0324g, false);
    }

    public final long d(InterfaceC0324g interfaceC0324g, boolean z3) throws EOFException {
        C0323f c0323fC;
        if (z3) {
            c0323fC = new C0323f();
        } else {
            U3.j.c(interfaceC0324g);
            c0323fC = interfaceC0324g.c();
        }
        List list = this.a;
        int size = list.size();
        for (int i5 = 0; i5 < size; i5++) {
            if (i5 > 0) {
                c0323fC.e0(38);
            }
            c0323fC.j0((String) list.get(i5));
            c0323fC.e0(61);
            c0323fC.j0((String) this.f15228b.get(i5));
        }
        if (!z3) {
            return 0L;
        }
        long j5 = c0323fC.f4554m;
        c0323fC.a();
        return j5;
    }
}

package w4;

/* JADX INFO: renamed from: w4.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC2019d {
}

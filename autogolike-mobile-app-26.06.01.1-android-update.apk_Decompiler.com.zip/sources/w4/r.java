package w4;

import f.C0933a;
import java.nio.charset.Charset;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: classes.dex */
public final class r {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final Pattern f15250d = Pattern.compile("([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)/([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)");

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final Pattern f15251e = Pattern.compile(";\\s*(?:([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)=(?:([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)|\"([^\"]*)\"))?");
    public final String a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f15252b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String[] f15253c;

    public r(String str, String str2, String[] strArr) {
        this.a = str;
        this.f15252b = str2;
        this.f15253c = strArr;
    }

    public final Charset a(Charset charset) {
        String str;
        String[] strArr = this.f15253c;
        int i5 = 0;
        int iV = C0933a.V(0, strArr.length - 1, 2);
        if (iV < 0) {
            str = null;
            break;
        }
        while (!c4.s.b0(strArr[i5], "charset", true)) {
            if (i5 == iV) {
                str = null;
                break;
            }
            i5 += 2;
        }
        str = strArr[i5 + 1];
        if (str == null) {
            return charset;
        }
        try {
            return Charset.forName(str);
        } catch (IllegalArgumentException unused) {
            return charset;
        }
    }

    public final boolean equals(Object obj) {
        return (obj instanceof r) && U3.j.a(((r) obj).a, this.a);
    }

    public final int hashCode() {
        return this.a.hashCode();
    }

    public final String toString() {
        return this.a;
    }
}

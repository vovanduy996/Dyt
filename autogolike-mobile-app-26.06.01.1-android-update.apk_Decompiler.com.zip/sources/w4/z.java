package w4;

import I.X0;

/* JADX INFO: loaded from: classes.dex */
public final class z {
    public D4.g a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public w f15317b;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public String f15319d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public m f15320e;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public B f15322g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public A f15323h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public A f15324i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public A f15325j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public long f15326k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public long f15327l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public A4.e f15328m;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f15318c = -1;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public X0 f15321f = new X0(4);

    public static void b(String str, A a) {
        if (a != null) {
            if (a.f15144r != null) {
                throw new IllegalArgumentException(str.concat(".body != null").toString());
            }
            if (a.f15145s != null) {
                throw new IllegalArgumentException(str.concat(".networkResponse != null").toString());
            }
            if (a.f15146t != null) {
                throw new IllegalArgumentException(str.concat(".cacheResponse != null").toString());
            }
            if (a.f15147u != null) {
                throw new IllegalArgumentException(str.concat(".priorResponse != null").toString());
            }
        }
    }

    public final A a() {
        int i5 = this.f15318c;
        if (i5 < 0) {
            throw new IllegalStateException(("code < 0: " + this.f15318c).toString());
        }
        D4.g gVar = this.a;
        if (gVar == null) {
            throw new IllegalStateException("request == null");
        }
        w wVar = this.f15317b;
        if (wVar == null) {
            throw new IllegalStateException("protocol == null");
        }
        String str = this.f15319d;
        if (str != null) {
            return new A(gVar, wVar, str, i5, this.f15320e, this.f15321f.d(), this.f15322g, this.f15323h, this.f15324i, this.f15325j, this.f15326k, this.f15327l, this.f15328m);
        }
        throw new IllegalStateException("message == null");
    }
}

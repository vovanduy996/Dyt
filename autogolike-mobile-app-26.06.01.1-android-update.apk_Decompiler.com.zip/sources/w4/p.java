package w4;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: classes.dex */
public final class p {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final char[] f15240k = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
    public final String a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f15241b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f15242c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f15243d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f15244e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final ArrayList f15245f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final ArrayList f15246g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final String f15247h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final String f15248i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final boolean f15249j;

    public p(String str, String str2, String str3, String str4, int i5, ArrayList arrayList, ArrayList arrayList2, String str5, String str6) {
        U3.j.f(str, "scheme");
        U3.j.f(str4, "host");
        this.a = str;
        this.f15241b = str2;
        this.f15242c = str3;
        this.f15243d = str4;
        this.f15244e = i5;
        this.f15245f = arrayList;
        this.f15246g = arrayList2;
        this.f15247h = str5;
        this.f15248i = str6;
        this.f15249j = str.equals("https");
    }

    public final String a() {
        if (this.f15242c.length() == 0) {
            return "";
        }
        int length = this.a.length() + 3;
        String str = this.f15248i;
        String strSubstring = str.substring(c4.l.r0(str, ':', length, false, 4) + 1, c4.l.r0(str, '@', 0, false, 6));
        U3.j.e(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
        return strSubstring;
    }

    public final String b() {
        int length = this.a.length() + 3;
        String str = this.f15248i;
        int iR0 = c4.l.r0(str, '/', length, false, 4);
        String strSubstring = str.substring(iR0, x4.b.f(iR0, str.length(), str, "?#"));
        U3.j.e(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
        return strSubstring;
    }

    public final ArrayList c() {
        int length = this.a.length() + 3;
        String str = this.f15248i;
        int iR0 = c4.l.r0(str, '/', length, false, 4);
        int iF = x4.b.f(iR0, str.length(), str, "?#");
        ArrayList arrayList = new ArrayList();
        while (iR0 < iF) {
            int i5 = iR0 + 1;
            int iG = x4.b.g(str, '/', i5, iF);
            String strSubstring = str.substring(i5, iG);
            U3.j.e(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
            arrayList.add(strSubstring);
            iR0 = iG;
        }
        return arrayList;
    }

    public final String d() {
        if (this.f15246g == null) {
            return null;
        }
        String str = this.f15248i;
        int iR0 = c4.l.r0(str, '?', 0, false, 6) + 1;
        String strSubstring = str.substring(iR0, x4.b.g(str, '#', iR0, str.length()));
        U3.j.e(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
        return strSubstring;
    }

    public final String e() {
        if (this.f15241b.length() == 0) {
            return "";
        }
        int length = this.a.length() + 3;
        String str = this.f15248i;
        String strSubstring = str.substring(length, x4.b.f(length, str.length(), str, ":@"));
        U3.j.e(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
        return strSubstring;
    }

    public final boolean equals(Object obj) {
        return (obj instanceof p) && U3.j.a(((p) obj).f15248i, this.f15248i);
    }

    public final o f(String str) {
        U3.j.f(str, "link");
        try {
            o oVar = new o();
            oVar.c(this, str);
            return oVar;
        } catch (IllegalArgumentException unused) {
            return null;
        }
    }

    public final String g() {
        o oVarF = f("/...");
        U3.j.c(oVarF);
        oVarF.f15233b = C2017b.b("", 0, 0, " \"':;<=>@[]^`{}|/\\?#", false, false, false, false, 251);
        oVarF.f15234c = C2017b.b("", 0, 0, " \"':;<=>@[]^`{}|/\\?#", false, false, false, false, 251);
        return oVarF.a().f15248i;
    }

    public final URI h() {
        String strSubstring;
        String strReplaceAll;
        o oVar = new o();
        String str = this.a;
        oVar.a = str;
        oVar.f15233b = e();
        oVar.f15234c = a();
        oVar.f15235d = this.f15243d;
        U3.j.f(str, "scheme");
        int i5 = str.equals("http") ? 80 : str.equals("https") ? 443 : -1;
        int i6 = this.f15244e;
        oVar.f15236e = i6 != i5 ? i6 : -1;
        ArrayList arrayList = oVar.f15237f;
        arrayList.clear();
        arrayList.addAll(c());
        String strD = d();
        oVar.f15238g = strD != null ? C2017b.f(C2017b.b(strD, 0, 0, " \"'<>#", true, false, true, false, 211)) : null;
        if (this.f15247h == null) {
            strSubstring = null;
        } else {
            String str2 = this.f15248i;
            strSubstring = str2.substring(c4.l.r0(str2, '#', 0, false, 6) + 1);
            U3.j.e(strSubstring, "this as java.lang.String).substring(startIndex)");
        }
        oVar.f15239h = strSubstring;
        String str3 = oVar.f15235d;
        if (str3 != null) {
            Pattern patternCompile = Pattern.compile("[\"<>^`{|}]");
            U3.j.e(patternCompile, "compile(...)");
            strReplaceAll = patternCompile.matcher(str3).replaceAll("");
            U3.j.e(strReplaceAll, "replaceAll(...)");
        } else {
            strReplaceAll = null;
        }
        oVar.f15235d = strReplaceAll;
        int size = arrayList.size();
        for (int i7 = 0; i7 < size; i7++) {
            arrayList.set(i7, C2017b.b((String) arrayList.get(i7), 0, 0, "[]", true, true, false, false, 227));
        }
        ArrayList arrayList2 = oVar.f15238g;
        if (arrayList2 != null) {
            int size2 = arrayList2.size();
            for (int i8 = 0; i8 < size2; i8++) {
                String str4 = (String) arrayList2.get(i8);
                arrayList2.set(i8, str4 != null ? C2017b.b(str4, 0, 0, "\\^`{|}", true, true, true, false, 195) : null);
            }
        }
        String str5 = oVar.f15239h;
        oVar.f15239h = str5 != null ? C2017b.b(str5, 0, 0, " \"#<>\\^`{|}", true, true, false, true, 163) : null;
        String string = oVar.toString();
        try {
            return new URI(string);
        } catch (URISyntaxException e5) {
            try {
                Pattern patternCompile2 = Pattern.compile("[\\u0000-\\u001F\\u007F-\\u009F\\p{javaWhitespace}]");
                U3.j.e(patternCompile2, "compile(...)");
                String strReplaceAll2 = patternCompile2.matcher(string).replaceAll("");
                U3.j.e(strReplaceAll2, "replaceAll(...)");
                URI uriCreate = URI.create(strReplaceAll2);
                U3.j.e(uriCreate, "{\n      // Unlikely edge…Unexpected!\n      }\n    }");
                return uriCreate;
            } catch (Exception unused) {
                throw new RuntimeException(e5);
            }
        }
    }

    public final int hashCode() {
        return this.f15248i.hashCode();
    }

    public final String toString() {
        return this.f15248i;
    }
}

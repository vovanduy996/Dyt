package w4;

/* JADX INFO: loaded from: classes.dex */
public interface q {
    A a(B4.g gVar);
}

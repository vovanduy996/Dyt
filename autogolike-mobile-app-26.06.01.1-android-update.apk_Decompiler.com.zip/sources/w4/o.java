package w4;

import java.util.ArrayList;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public final class o {
    public String a;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public String f15235d;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final ArrayList f15237f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ArrayList f15238g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public String f15239h;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f15233b = "";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public String f15234c = "";

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f15236e = -1;

    public o() {
        ArrayList arrayList = new ArrayList();
        this.f15237f = arrayList;
        arrayList.add("");
    }

    public final p a() {
        ArrayList arrayList;
        String str = this.a;
        if (str == null) {
            throw new IllegalStateException("scheme == null");
        }
        String strE = C2017b.e(this.f15233b, 0, 0, false, 7);
        String strE2 = C2017b.e(this.f15234c, 0, 0, false, 7);
        String str2 = this.f15235d;
        if (str2 == null) {
            throw new IllegalStateException("host == null");
        }
        int iB = b();
        ArrayList arrayList2 = this.f15237f;
        ArrayList arrayList3 = new ArrayList(H3.o.X0(arrayList2, 10));
        Iterator it = arrayList2.iterator();
        while (it.hasNext()) {
            arrayList3.add(C2017b.e((String) it.next(), 0, 0, false, 7));
        }
        ArrayList<String> arrayList4 = this.f15238g;
        if (arrayList4 != null) {
            arrayList = new ArrayList(H3.o.X0(arrayList4, 10));
            for (String str3 : arrayList4) {
                arrayList.add(str3 != null ? C2017b.e(str3, 0, 0, true, 3) : null);
            }
        } else {
            arrayList = null;
        }
        String str4 = this.f15239h;
        return new p(str, strE, strE2, str2, iB, arrayList3, arrayList, str4 != null ? C2017b.e(str4, 0, 0, false, 7) : null, toString());
    }

    public final int b() {
        int i5 = this.f15236e;
        if (i5 != -1) {
            return i5;
        }
        String str = this.a;
        U3.j.c(str);
        if (str.equals("http")) {
            return 80;
        }
        return str.equals("https") ? 443 : -1;
    }

    /* JADX WARN: Removed duplicated region for block: B:4:0x002a  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x013d  */
    /* JADX WARN: Unreachable blocks removed: 1, instructions: 1 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void c(w4.p r33, java.lang.String r34) {
        /*
            Method dump skipped, instruction units count: 1087
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: w4.o.c(w4.p, java.lang.String):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:34:0x008b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.String toString() {
        /*
            Method dump skipped, instruction units count: 280
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: w4.o.toString():java.lang.String");
    }
}

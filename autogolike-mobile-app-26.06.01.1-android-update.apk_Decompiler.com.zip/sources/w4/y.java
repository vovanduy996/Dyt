package w4;

import K4.InterfaceC0324g;

/* JADX INFO: loaded from: classes.dex */
public abstract class y {
    public abstract long a();

    public abstract r b();

    public abstract void c(InterfaceC0324g interfaceC0324g);
}

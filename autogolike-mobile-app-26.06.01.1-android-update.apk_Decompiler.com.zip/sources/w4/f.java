package w4;

import java.util.ArrayList;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class f {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final f f15186c = new f(H3.m.F1(new ArrayList()), null);
    public final Set a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final W3.a f15187b;

    public f(Set set, W3.a aVar) {
        this.a = set;
        this.f15187b = aVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0059  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void a(java.lang.String r16, T3.a r17) throws java.security.NoSuchAlgorithmException, javax.net.ssl.SSLPeerUnverifiedException {
        /*
            Method dump skipped, instruction units count: 411
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: w4.f.a(java.lang.String, T3.a):void");
    }

    public final boolean equals(Object obj) {
        if (obj instanceof f) {
            f fVar = (f) obj;
            if (U3.j.a(fVar.a, this.a) && U3.j.a(fVar.f15187b, this.f15187b)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int iHashCode = (this.a.hashCode() + 1517) * 41;
        W3.a aVar = this.f15187b;
        return iHashCode + (aVar != null ? aVar.hashCode() : 0);
    }
}

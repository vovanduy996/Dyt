package w4;

import G3.AbstractC0164a;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import s.C1703N;

/* JADX INFO: loaded from: classes.dex */
public final class m {
    public final D a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final h f15229b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final List f15230c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final G3.q f15231d;

    public m(D d3, h hVar, List list, T3.a aVar) {
        this.a = d3;
        this.f15229b = hVar;
        this.f15230c = list;
        this.f15231d = AbstractC0164a.d(new C1703N(aVar));
    }

    public final List a() {
        return (List) this.f15231d.getValue();
    }

    public final boolean equals(Object obj) {
        if (obj instanceof m) {
            m mVar = (m) obj;
            if (mVar.a == this.a && U3.j.a(mVar.f15229b, this.f15229b) && U3.j.a(mVar.a(), a()) && U3.j.a(mVar.f15230c, this.f15230c)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.f15230c.hashCode() + ((a().hashCode() + ((this.f15229b.hashCode() + ((this.a.hashCode() + 527) * 31)) * 31)) * 31);
    }

    public final String toString() {
        String type;
        String type2;
        List<Certificate> listA = a();
        ArrayList arrayList = new ArrayList(H3.o.X0(listA, 10));
        for (Certificate certificate : listA) {
            if (certificate instanceof X509Certificate) {
                type2 = ((X509Certificate) certificate).getSubjectDN().toString();
            } else {
                type2 = certificate.getType();
                U3.j.e(type2, "type");
            }
            arrayList.add(type2);
        }
        String string = arrayList.toString();
        StringBuilder sb = new StringBuilder("Handshake{tlsVersion=");
        sb.append(this.a);
        sb.append(" cipherSuite=");
        sb.append(this.f15229b);
        sb.append(" peerCertificates=");
        sb.append(string);
        sb.append(" localCertificates=");
        List<Certificate> list = this.f15230c;
        ArrayList arrayList2 = new ArrayList(H3.o.X0(list, 10));
        for (Certificate certificate2 : list) {
            if (certificate2 instanceof X509Certificate) {
                type = ((X509Certificate) certificate2).getSubjectDN().toString();
            } else {
                type = certificate2.getType();
                U3.j.e(type, "type");
            }
            arrayList2.add(type);
        }
        sb.append(arrayList2);
        sb.append('}');
        return sb.toString();
    }
}

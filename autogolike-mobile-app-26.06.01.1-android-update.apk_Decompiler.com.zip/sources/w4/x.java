package w4;

import K4.InterfaceC0324g;

/* JADX INFO: loaded from: classes.dex */
public final class x extends y {
    public final /* synthetic */ r a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f15314b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ byte[] f15315c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f15316d;

    public x(r rVar, int i5, byte[] bArr, int i6) {
        this.a = rVar;
        this.f15314b = i5;
        this.f15315c = bArr;
        this.f15316d = i6;
    }

    @Override // w4.y
    public final long a() {
        return this.f15314b;
    }

    @Override // w4.y
    public final r b() {
        return this.a;
    }

    @Override // w4.y
    public final void c(InterfaceC0324g interfaceC0324g) {
        interfaceC0324g.g(this.f15315c, this.f15316d, this.f15314b);
    }
}

package w4;

import K4.InterfaceC0325h;
import c4.AbstractC0686a;
import java.io.Closeable;
import java.nio.charset.Charset;
import l3.AbstractC1324b;

/* JADX INFO: loaded from: classes.dex */
public abstract class B implements Closeable {
    public abstract long a();

    public abstract r b();

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        x4.b.d(f());
    }

    public abstract InterfaceC0325h f();

    public final String j() {
        Charset charsetA;
        InterfaceC0325h interfaceC0325hF = f();
        try {
            r rVarB = b();
            if (rVarB == null || (charsetA = rVarB.a(AbstractC0686a.a)) == null) {
                charsetA = AbstractC0686a.a;
            }
            String strW = interfaceC0325hF.W(x4.b.s(interfaceC0325hF, charsetA));
            AbstractC1324b.k(interfaceC0325hF, null);
            return strW;
        } finally {
        }
    }
}

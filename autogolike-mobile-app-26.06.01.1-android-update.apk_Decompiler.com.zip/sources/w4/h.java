package w4;

import java.util.LinkedHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class h {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final C2017b f15188b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final g f15189c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final LinkedHashMap f15190d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final h f15191e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final h f15192f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final h f15193g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final h f15194h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final h f15195i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final h f15196j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final h f15197k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final h f15198l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final h f15199m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final h f15200n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final h f15201o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final h f15202p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final h f15203q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final h f15204r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final h f15205s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final h f15206t;
    public final String a;

    static {
        C2017b c2017b = new C2017b();
        f15188b = c2017b;
        f15189c = new g();
        f15190d = new LinkedHashMap();
        C2017b.a(c2017b, "SSL_RSA_WITH_NULL_MD5");
        C2017b.a(c2017b, "SSL_RSA_WITH_NULL_SHA");
        C2017b.a(c2017b, "SSL_RSA_EXPORT_WITH_RC4_40_MD5");
        C2017b.a(c2017b, "SSL_RSA_WITH_RC4_128_MD5");
        C2017b.a(c2017b, "SSL_RSA_WITH_RC4_128_SHA");
        C2017b.a(c2017b, "SSL_RSA_EXPORT_WITH_DES40_CBC_SHA");
        C2017b.a(c2017b, "SSL_RSA_WITH_DES_CBC_SHA");
        f15191e = C2017b.a(c2017b, "SSL_RSA_WITH_3DES_EDE_CBC_SHA");
        C2017b.a(c2017b, "SSL_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA");
        C2017b.a(c2017b, "SSL_DHE_DSS_WITH_DES_CBC_SHA");
        C2017b.a(c2017b, "SSL_DHE_DSS_WITH_3DES_EDE_CBC_SHA");
        C2017b.a(c2017b, "SSL_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA");
        C2017b.a(c2017b, "SSL_DHE_RSA_WITH_DES_CBC_SHA");
        C2017b.a(c2017b, "SSL_DHE_RSA_WITH_3DES_EDE_CBC_SHA");
        C2017b.a(c2017b, "SSL_DH_anon_EXPORT_WITH_RC4_40_MD5");
        C2017b.a(c2017b, "SSL_DH_anon_WITH_RC4_128_MD5");
        C2017b.a(c2017b, "SSL_DH_anon_EXPORT_WITH_DES40_CBC_SHA");
        C2017b.a(c2017b, "SSL_DH_anon_WITH_DES_CBC_SHA");
        C2017b.a(c2017b, "SSL_DH_anon_WITH_3DES_EDE_CBC_SHA");
        C2017b.a(c2017b, "TLS_KRB5_WITH_DES_CBC_SHA");
        C2017b.a(c2017b, "TLS_KRB5_WITH_3DES_EDE_CBC_SHA");
        C2017b.a(c2017b, "TLS_KRB5_WITH_RC4_128_SHA");
        C2017b.a(c2017b, "TLS_KRB5_WITH_DES_CBC_MD5");
        C2017b.a(c2017b, "TLS_KRB5_WITH_3DES_EDE_CBC_MD5");
        C2017b.a(c2017b, "TLS_KRB5_WITH_RC4_128_MD5");
        C2017b.a(c2017b, "TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA");
        C2017b.a(c2017b, "TLS_KRB5_EXPORT_WITH_RC4_40_SHA");
        C2017b.a(c2017b, "TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5");
        C2017b.a(c2017b, "TLS_KRB5_EXPORT_WITH_RC4_40_MD5");
        f15192f = C2017b.a(c2017b, "TLS_RSA_WITH_AES_128_CBC_SHA");
        C2017b.a(c2017b, "TLS_DHE_DSS_WITH_AES_128_CBC_SHA");
        C2017b.a(c2017b, "TLS_DHE_RSA_WITH_AES_128_CBC_SHA");
        C2017b.a(c2017b, "TLS_DH_anon_WITH_AES_128_CBC_SHA");
        f15193g = C2017b.a(c2017b, "TLS_RSA_WITH_AES_256_CBC_SHA");
        C2017b.a(c2017b, "TLS_DHE_DSS_WITH_AES_256_CBC_SHA");
        C2017b.a(c2017b, "TLS_DHE_RSA_WITH_AES_256_CBC_SHA");
        C2017b.a(c2017b, "TLS_DH_anon_WITH_AES_256_CBC_SHA");
        C2017b.a(c2017b, "TLS_RSA_WITH_NULL_SHA256");
        C2017b.a(c2017b, "TLS_RSA_WITH_AES_128_CBC_SHA256");
        C2017b.a(c2017b, "TLS_RSA_WITH_AES_256_CBC_SHA256");
        C2017b.a(c2017b, "TLS_DHE_DSS_WITH_AES_128_CBC_SHA256");
        C2017b.a(c2017b, "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA");
        C2017b.a(c2017b, "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA");
        C2017b.a(c2017b, "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA");
        C2017b.a(c2017b, "TLS_DHE_RSA_WITH_AES_128_CBC_SHA256");
        C2017b.a(c2017b, "TLS_DHE_DSS_WITH_AES_256_CBC_SHA256");
        C2017b.a(c2017b, "TLS_DHE_RSA_WITH_AES_256_CBC_SHA256");
        C2017b.a(c2017b, "TLS_DH_anon_WITH_AES_128_CBC_SHA256");
        C2017b.a(c2017b, "TLS_DH_anon_WITH_AES_256_CBC_SHA256");
        C2017b.a(c2017b, "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA");
        C2017b.a(c2017b, "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA");
        C2017b.a(c2017b, "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA");
        C2017b.a(c2017b, "TLS_PSK_WITH_RC4_128_SHA");
        C2017b.a(c2017b, "TLS_PSK_WITH_3DES_EDE_CBC_SHA");
        C2017b.a(c2017b, "TLS_PSK_WITH_AES_128_CBC_SHA");
        C2017b.a(c2017b, "TLS_PSK_WITH_AES_256_CBC_SHA");
        C2017b.a(c2017b, "TLS_RSA_WITH_SEED_CBC_SHA");
        f15194h = C2017b.a(c2017b, "TLS_RSA_WITH_AES_128_GCM_SHA256");
        f15195i = C2017b.a(c2017b, "TLS_RSA_WITH_AES_256_GCM_SHA384");
        C2017b.a(c2017b, "TLS_DHE_RSA_WITH_AES_128_GCM_SHA256");
        C2017b.a(c2017b, "TLS_DHE_RSA_WITH_AES_256_GCM_SHA384");
        C2017b.a(c2017b, "TLS_DHE_DSS_WITH_AES_128_GCM_SHA256");
        C2017b.a(c2017b, "TLS_DHE_DSS_WITH_AES_256_GCM_SHA384");
        C2017b.a(c2017b, "TLS_DH_anon_WITH_AES_128_GCM_SHA256");
        C2017b.a(c2017b, "TLS_DH_anon_WITH_AES_256_GCM_SHA384");
        C2017b.a(c2017b, "TLS_EMPTY_RENEGOTIATION_INFO_SCSV");
        C2017b.a(c2017b, "TLS_FALLBACK_SCSV");
        C2017b.a(c2017b, "TLS_ECDH_ECDSA_WITH_NULL_SHA");
        C2017b.a(c2017b, "TLS_ECDH_ECDSA_WITH_RC4_128_SHA");
        C2017b.a(c2017b, "TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA");
        C2017b.a(c2017b, "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA");
        C2017b.a(c2017b, "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA");
        C2017b.a(c2017b, "TLS_ECDHE_ECDSA_WITH_NULL_SHA");
        C2017b.a(c2017b, "TLS_ECDHE_ECDSA_WITH_RC4_128_SHA");
        C2017b.a(c2017b, "TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA");
        C2017b.a(c2017b, "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA");
        C2017b.a(c2017b, "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA");
        C2017b.a(c2017b, "TLS_ECDH_RSA_WITH_NULL_SHA");
        C2017b.a(c2017b, "TLS_ECDH_RSA_WITH_RC4_128_SHA");
        C2017b.a(c2017b, "TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA");
        C2017b.a(c2017b, "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA");
        C2017b.a(c2017b, "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA");
        C2017b.a(c2017b, "TLS_ECDHE_RSA_WITH_NULL_SHA");
        C2017b.a(c2017b, "TLS_ECDHE_RSA_WITH_RC4_128_SHA");
        C2017b.a(c2017b, "TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA");
        f15196j = C2017b.a(c2017b, "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA");
        f15197k = C2017b.a(c2017b, "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA");
        C2017b.a(c2017b, "TLS_ECDH_anon_WITH_NULL_SHA");
        C2017b.a(c2017b, "TLS_ECDH_anon_WITH_RC4_128_SHA");
        C2017b.a(c2017b, "TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA");
        C2017b.a(c2017b, "TLS_ECDH_anon_WITH_AES_128_CBC_SHA");
        C2017b.a(c2017b, "TLS_ECDH_anon_WITH_AES_256_CBC_SHA");
        C2017b.a(c2017b, "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256");
        C2017b.a(c2017b, "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384");
        C2017b.a(c2017b, "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256");
        C2017b.a(c2017b, "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384");
        C2017b.a(c2017b, "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256");
        C2017b.a(c2017b, "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384");
        C2017b.a(c2017b, "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256");
        C2017b.a(c2017b, "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384");
        f15198l = C2017b.a(c2017b, "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256");
        f15199m = C2017b.a(c2017b, "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384");
        C2017b.a(c2017b, "TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256");
        C2017b.a(c2017b, "TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384");
        f15200n = C2017b.a(c2017b, "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256");
        f15201o = C2017b.a(c2017b, "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384");
        C2017b.a(c2017b, "TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256");
        C2017b.a(c2017b, "TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384");
        C2017b.a(c2017b, "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA");
        C2017b.a(c2017b, "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA");
        f15202p = C2017b.a(c2017b, "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256");
        f15203q = C2017b.a(c2017b, "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256");
        C2017b.a(c2017b, "TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256");
        C2017b.a(c2017b, "TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256");
        f15204r = C2017b.a(c2017b, "TLS_AES_128_GCM_SHA256");
        f15205s = C2017b.a(c2017b, "TLS_AES_256_GCM_SHA384");
        f15206t = C2017b.a(c2017b, "TLS_CHACHA20_POLY1305_SHA256");
        C2017b.a(c2017b, "TLS_AES_128_CCM_SHA256");
        C2017b.a(c2017b, "TLS_AES_128_CCM_8_SHA256");
    }

    public h(String str) {
        this.a = str;
    }

    public final String toString() {
        return this.a;
    }
}

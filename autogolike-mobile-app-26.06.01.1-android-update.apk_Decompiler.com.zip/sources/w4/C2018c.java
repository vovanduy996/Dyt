package w4;

import java.util.concurrent.TimeUnit;

/* JADX INFO: renamed from: w4.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C2018c {

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final /* synthetic */ int f15171n = 0;
    public final boolean a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f15172b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f15173c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f15174d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f15175e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f15176f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f15177g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f15178h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f15179i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final boolean f15180j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final boolean f15181k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final boolean f15182l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public String f15183m;

    static {
        TimeUnit timeUnit = TimeUnit.SECONDS;
        U3.j.f(timeUnit, "timeUnit");
        timeUnit.toSeconds(Integer.MAX_VALUE);
    }

    public C2018c(boolean z3, boolean z5, int i5, int i6, boolean z6, boolean z7, boolean z8, int i7, int i8, boolean z9, boolean z10, boolean z11, String str) {
        this.a = z3;
        this.f15172b = z5;
        this.f15173c = i5;
        this.f15174d = i6;
        this.f15175e = z6;
        this.f15176f = z7;
        this.f15177g = z8;
        this.f15178h = i7;
        this.f15179i = i8;
        this.f15180j = z9;
        this.f15181k = z10;
        this.f15182l = z11;
        this.f15183m = str;
    }

    public final String toString() {
        String str = this.f15183m;
        if (str != null) {
            return str;
        }
        StringBuilder sb = new StringBuilder();
        if (this.a) {
            sb.append("no-cache, ");
        }
        if (this.f15172b) {
            sb.append("no-store, ");
        }
        int i5 = this.f15173c;
        if (i5 != -1) {
            sb.append("max-age=");
            sb.append(i5);
            sb.append(", ");
        }
        int i6 = this.f15174d;
        if (i6 != -1) {
            sb.append("s-maxage=");
            sb.append(i6);
            sb.append(", ");
        }
        if (this.f15175e) {
            sb.append("private, ");
        }
        if (this.f15176f) {
            sb.append("public, ");
        }
        if (this.f15177g) {
            sb.append("must-revalidate, ");
        }
        int i7 = this.f15178h;
        if (i7 != -1) {
            sb.append("max-stale=");
            sb.append(i7);
            sb.append(", ");
        }
        int i8 = this.f15179i;
        if (i8 != -1) {
            sb.append("min-fresh=");
            sb.append(i8);
            sb.append(", ");
        }
        if (this.f15180j) {
            sb.append("only-if-cached, ");
        }
        if (this.f15181k) {
            sb.append("no-transform, ");
        }
        if (this.f15182l) {
            sb.append("immutable, ");
        }
        if (sb.length() == 0) {
            return "";
        }
        sb.delete(sb.length() - 2, sb.length());
        String string = sb.toString();
        U3.j.e(string, "StringBuilder().apply(builderAction).toString()");
        this.f15183m = string;
        return string;
    }
}

package w4;

import I.X0;
import f.C0933a;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public final class n implements Iterable, V3.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final String[] f15232l;

    public n(String[] strArr) {
        this.f15232l = strArr;
    }

    public final String b(String str) {
        U3.j.f(str, "name");
        String[] strArr = this.f15232l;
        int length = strArr.length - 2;
        int iV = C0933a.V(length, 0, -2);
        if (iV <= length) {
            while (!c4.s.b0(str, strArr[length], true)) {
                if (length != iV) {
                    length -= 2;
                }
            }
            return strArr[length + 1];
        }
        return null;
    }

    public final String c(int i5) {
        return this.f15232l[i5 * 2];
    }

    public final X0 e() {
        X0 x02 = new X0(4);
        ArrayList arrayList = x02.f3603l;
        U3.j.f(arrayList, "<this>");
        String[] strArr = this.f15232l;
        U3.j.f(strArr, "elements");
        arrayList.addAll(H3.l.X(strArr));
        return x02;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof n) {
            if (Arrays.equals(this.f15232l, ((n) obj).f15232l)) {
                return true;
            }
        }
        return false;
    }

    public final String g(int i5) {
        return this.f15232l[(i5 * 2) + 1];
    }

    public final int hashCode() {
        return Arrays.hashCode(this.f15232l);
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        int size = size();
        G3.l[] lVarArr = new G3.l[size];
        for (int i5 = 0; i5 < size; i5++) {
            lVarArr[i5] = new G3.l(c(i5), g(i5));
        }
        return U3.j.h(lVarArr);
    }

    public final int size() {
        return this.f15232l.length / 2;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        int size = size();
        for (int i5 = 0; i5 < size; i5++) {
            String strC = c(i5);
            String strG = g(i5);
            sb.append(strC);
            sb.append(": ");
            if (x4.b.q(strC)) {
                strG = "██";
            }
            sb.append(strG);
            sb.append("\n");
        }
        String string = sb.toString();
        U3.j.e(string, "StringBuilder().apply(builderAction).toString()");
        return string;
    }
}

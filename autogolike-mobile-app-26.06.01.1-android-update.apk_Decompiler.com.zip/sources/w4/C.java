package w4;

import java.net.InetSocketAddress;
import java.net.Proxy;

/* JADX INFO: loaded from: classes.dex */
public final class C {
    public final C2016a a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Proxy f15151b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final InetSocketAddress f15152c;

    public C(C2016a c2016a, Proxy proxy, InetSocketAddress inetSocketAddress) {
        U3.j.f(inetSocketAddress, "socketAddress");
        this.a = c2016a;
        this.f15151b = proxy;
        this.f15152c = inetSocketAddress;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof C) {
            C c5 = (C) obj;
            if (U3.j.a(c5.a, this.a) && U3.j.a(c5.f15151b, this.f15151b) && U3.j.a(c5.f15152c, this.f15152c)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.f15152c.hashCode() + ((this.f15151b.hashCode() + ((this.a.hashCode() + 527) * 31)) * 31);
    }

    public final String toString() {
        return "Route{" + this.f15152c + '}';
    }
}

package w4;

/* JADX INFO: loaded from: classes.dex */
public enum w {
    f15306m("http/1.0"),
    f15307n("http/1.1"),
    f15308o("spdy/3.1"),
    f15309p("h2"),
    f15310q("h2_prior_knowledge"),
    f15311r("quic");


    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final String f15313l;

    w(String str) {
        this.f15313l = str;
    }

    @Override // java.lang.Enum
    public final String toString() {
        return this.f15313l;
    }
}

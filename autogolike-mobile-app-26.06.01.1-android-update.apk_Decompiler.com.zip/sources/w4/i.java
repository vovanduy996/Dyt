package w4;

import java.util.ArrayList;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class i {
    public boolean a = true;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String[] f15207b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public String[] f15208c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f15209d;

    public final j a() {
        return new j(this.a, this.f15209d, this.f15207b, this.f15208c);
    }

    public final void b(String... strArr) {
        U3.j.f(strArr, "cipherSuites");
        if (!this.a) {
            throw new IllegalArgumentException("no cipher suites for cleartext connections");
        }
        if (strArr.length == 0) {
            throw new IllegalArgumentException("At least one cipher suite is required");
        }
        this.f15207b = (String[]) strArr.clone();
    }

    public final void c(h... hVarArr) {
        U3.j.f(hVarArr, "cipherSuites");
        if (!this.a) {
            throw new IllegalArgumentException("no cipher suites for cleartext connections");
        }
        ArrayList arrayList = new ArrayList(hVarArr.length);
        for (h hVar : hVarArr) {
            arrayList.add(hVar.a);
        }
        String[] strArr = (String[]) arrayList.toArray(new String[0]);
        b((String[]) Arrays.copyOf(strArr, strArr.length));
    }

    public final void d(String... strArr) {
        U3.j.f(strArr, "tlsVersions");
        if (!this.a) {
            throw new IllegalArgumentException("no TLS versions for cleartext connections");
        }
        if (strArr.length == 0) {
            throw new IllegalArgumentException("At least one TLS version is required");
        }
        this.f15208c = (String[]) strArr.clone();
    }

    public final void e(D... dArr) {
        if (!this.a) {
            throw new IllegalArgumentException("no TLS versions for cleartext connections");
        }
        ArrayList arrayList = new ArrayList(dArr.length);
        for (D d3 : dArr) {
            arrayList.add(d3.f15159l);
        }
        String[] strArr = (String[]) arrayList.toArray(new String[0]);
        d((String[]) Arrays.copyOf(strArr, strArr.length));
    }
}

package w4;

/* JADX INFO: loaded from: classes.dex */
public final class s {
    public final n a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final y f15254b;

    public s(n nVar, y yVar) {
        this.a = nVar;
        this.f15254b = yVar;
    }
}

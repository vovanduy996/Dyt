package w4;

/* JADX INFO: loaded from: classes.dex */
public enum D {
    f15153m("TLSv1.3"),
    f15154n("TLSv1.2"),
    f15155o("TLSv1.1"),
    f15156p("TLSv1"),
    f15157q("SSLv3");


    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final String f15159l;

    D(String str) {
        this.f15159l = str;
    }
}

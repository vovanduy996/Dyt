package w4;

import com.google.android.gms.internal.measurement.AbstractC0813y0;
import java.text.DateFormat;
import java.util.Date;
import java.util.regex.Pattern;
import w1.AbstractC1987H;

/* JADX INFO: loaded from: classes.dex */
public final class k {

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final Pattern f15215j = Pattern.compile("(\\d{2,4})[^\\d]*");

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final Pattern f15216k = Pattern.compile("(?i)(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec).*");

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final Pattern f15217l = Pattern.compile("(\\d{1,2})[^\\d]*");

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final Pattern f15218m = Pattern.compile("(\\d{1,2}):(\\d{1,2}):(\\d{1,2})[^\\d]*");
    public final String a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f15219b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f15220c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f15221d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f15222e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f15223f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f15224g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final boolean f15225h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f15226i;

    public k(String str, String str2, long j5, String str3, String str4, boolean z3, boolean z5, boolean z6, boolean z7) {
        this.a = str;
        this.f15219b = str2;
        this.f15220c = j5;
        this.f15221d = str3;
        this.f15222e = str4;
        this.f15223f = z3;
        this.f15224g = z5;
        this.f15225h = z6;
        this.f15226i = z7;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof k) {
            k kVar = (k) obj;
            if (U3.j.a(kVar.a, this.a) && U3.j.a(kVar.f15219b, this.f15219b) && kVar.f15220c == this.f15220c && U3.j.a(kVar.f15221d, this.f15221d) && U3.j.a(kVar.f15222e, this.f15222e) && kVar.f15223f == this.f15223f && kVar.f15224g == this.f15224g && kVar.f15225h == this.f15225h && kVar.f15226i == this.f15226i) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f15226i) + AbstractC0813y0.f(AbstractC0813y0.f(AbstractC0813y0.f(AbstractC1987H.b(AbstractC1987H.b(AbstractC0813y0.e(AbstractC1987H.b(AbstractC1987H.b(527, 31, this.a), 31, this.f15219b), 31, this.f15220c), 31, this.f15221d), 31, this.f15222e), 31, this.f15223f), 31, this.f15224g), 31, this.f15225h);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.a);
        sb.append('=');
        sb.append(this.f15219b);
        if (this.f15225h) {
            long j5 = this.f15220c;
            if (j5 == Long.MIN_VALUE) {
                sb.append("; max-age=0");
            } else {
                sb.append("; expires=");
                String str = ((DateFormat) B4.d.a.get()).format(new Date(j5));
                U3.j.e(str, "STANDARD_DATE_FORMAT.get().format(this)");
                sb.append(str);
            }
        }
        if (!this.f15226i) {
            sb.append("; domain=");
            sb.append(this.f15221d);
        }
        sb.append("; path=");
        sb.append(this.f15222e);
        if (this.f15223f) {
            sb.append("; secure");
        }
        if (this.f15224g) {
            sb.append("; httponly");
        }
        String string = sb.toString();
        U3.j.e(string, "toString()");
        return string;
    }
}

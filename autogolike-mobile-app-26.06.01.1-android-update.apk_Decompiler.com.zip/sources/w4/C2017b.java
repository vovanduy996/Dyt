package w4;

import K4.C0323f;
import java.io.EOFException;
import java.util.ArrayList;
import java.util.LinkedHashMap;

/* JADX INFO: renamed from: w4.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C2017b {
    public static final C2017b a = new C2017b();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final C2017b f15169b = new C2017b();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final C2017b f15170c = new C2017b();

    public static final h a(C2017b c2017b, String str) {
        h hVar = new h(str);
        h.f15190d.put(str, hVar);
        return hVar;
    }

    public static String b(String str, int i5, int i6, String str2, boolean z3, boolean z5, boolean z6, boolean z7, int i7) throws EOFException {
        int i8 = (i7 & 1) != 0 ? 0 : i5;
        int length = (i7 & 2) != 0 ? str.length() : i6;
        boolean z8 = (i7 & 8) != 0 ? false : z3;
        boolean z9 = (i7 & 16) != 0 ? false : z5;
        boolean z10 = (i7 & 32) != 0 ? false : z6;
        boolean z11 = (i7 & 64) == 0 ? z7 : false;
        U3.j.f(str, "<this>");
        int iCharCount = i8;
        while (iCharCount < length) {
            int iCodePointAt = str.codePointAt(iCharCount);
            int i9 = 32;
            int i10 = 128;
            if (iCodePointAt < 32 || iCodePointAt == 127 || ((iCodePointAt >= 128 && !z11) || c4.l.l0(str2, (char) iCodePointAt) || ((iCodePointAt == 37 && (!z8 || (z9 && !d(iCharCount, length, str)))) || (iCodePointAt == 43 && z10)))) {
                C0323f c0323f = new C0323f();
                c0323f.i0(i8, iCharCount, str);
                C0323f c0323f2 = null;
                while (iCharCount < length) {
                    int iCodePointAt2 = str.codePointAt(iCharCount);
                    if (!z8 || (iCodePointAt2 != 9 && iCodePointAt2 != 10 && iCodePointAt2 != 12 && iCodePointAt2 != 13)) {
                        if (iCodePointAt2 == 43 && z10) {
                            c0323f.j0(z8 ? "+" : "%2B");
                        } else if (iCodePointAt2 < i9 || iCodePointAt2 == 127 || ((iCodePointAt2 >= i10 && !z11) || c4.l.l0(str2, (char) iCodePointAt2) || (iCodePointAt2 == 37 && (!z8 || (z9 && !d(iCharCount, length, str)))))) {
                            if (c0323f2 == null) {
                                c0323f2 = new C0323f();
                            }
                            c0323f2.k0(iCodePointAt2);
                            while (!c0323f2.m()) {
                                byte B = c0323f2.B();
                                c0323f.e0(37);
                                char[] cArr = p.f15240k;
                                c0323f.e0(cArr[((B & 255) >> 4) & 15]);
                                c0323f.e0(cArr[B & 15]);
                            }
                        } else {
                            c0323f.k0(iCodePointAt2);
                        }
                    }
                    iCharCount += Character.charCount(iCodePointAt2);
                    i9 = 32;
                    i10 = 128;
                }
                return c0323f.X();
            }
            iCharCount += Character.charCount(iCodePointAt);
        }
        String strSubstring = str.substring(i8, length);
        U3.j.e(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
        return strSubstring;
    }

    public static boolean d(int i5, int i6, String str) {
        int i7 = i5 + 2;
        return i7 < i6 && str.charAt(i5) == '%' && x4.b.r(str.charAt(i5 + 1)) != -1 && x4.b.r(str.charAt(i7)) != -1;
    }

    public static String e(String str, int i5, int i6, boolean z3, int i7) {
        int i8;
        if ((i7 & 1) != 0) {
            i5 = 0;
        }
        if ((i7 & 2) != 0) {
            i6 = str.length();
        }
        if ((i7 & 4) != 0) {
            z3 = false;
        }
        U3.j.f(str, "<this>");
        int iCharCount = i5;
        while (iCharCount < i6) {
            char cCharAt = str.charAt(iCharCount);
            if (cCharAt == '%' || (cCharAt == '+' && z3)) {
                C0323f c0323f = new C0323f();
                c0323f.i0(i5, iCharCount, str);
                while (iCharCount < i6) {
                    int iCodePointAt = str.codePointAt(iCharCount);
                    if (iCodePointAt == 37 && (i8 = iCharCount + 2) < i6) {
                        int iR = x4.b.r(str.charAt(iCharCount + 1));
                        int iR2 = x4.b.r(str.charAt(i8));
                        if (iR == -1 || iR2 == -1) {
                            c0323f.k0(iCodePointAt);
                            iCharCount += Character.charCount(iCodePointAt);
                        } else {
                            c0323f.e0((iR << 4) + iR2);
                            iCharCount = Character.charCount(iCodePointAt) + i8;
                        }
                    } else if (iCodePointAt == 43 && z3) {
                        c0323f.e0(32);
                        iCharCount++;
                    } else {
                        c0323f.k0(iCodePointAt);
                        iCharCount += Character.charCount(iCodePointAt);
                    }
                }
                return c0323f.X();
            }
            iCharCount++;
        }
        String strSubstring = str.substring(i5, i6);
        U3.j.e(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
        return strSubstring;
    }

    public static ArrayList f(String str) {
        ArrayList arrayList = new ArrayList();
        int i5 = 0;
        while (i5 <= str.length()) {
            int iR0 = c4.l.r0(str, '&', i5, false, 4);
            if (iR0 == -1) {
                iR0 = str.length();
            }
            int iR02 = c4.l.r0(str, '=', i5, false, 4);
            if (iR02 == -1 || iR02 > iR0) {
                String strSubstring = str.substring(i5, iR0);
                U3.j.e(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
                arrayList.add(strSubstring);
                arrayList.add(null);
            } else {
                String strSubstring2 = str.substring(i5, iR02);
                U3.j.e(strSubstring2, "this as java.lang.String…ing(startIndex, endIndex)");
                arrayList.add(strSubstring2);
                String strSubstring3 = str.substring(iR02 + 1, iR0);
                U3.j.e(strSubstring3, "this as java.lang.String…ing(startIndex, endIndex)");
                arrayList.add(strSubstring3);
            }
            i5 = iR0 + 1;
        }
        return arrayList;
    }

    public synchronized h c(String str) {
        h hVar;
        String strConcat;
        try {
            U3.j.f(str, "javaName");
            LinkedHashMap linkedHashMap = h.f15190d;
            hVar = (h) linkedHashMap.get(str);
            if (hVar == null) {
                if (c4.s.h0(str, "TLS_", false)) {
                    String strSubstring = str.substring(4);
                    U3.j.e(strSubstring, "this as java.lang.String).substring(startIndex)");
                    strConcat = "SSL_".concat(strSubstring);
                } else if (c4.s.h0(str, "SSL_", false)) {
                    String strSubstring2 = str.substring(4);
                    U3.j.e(strSubstring2, "this as java.lang.String).substring(startIndex)");
                    strConcat = "TLS_".concat(strSubstring2);
                } else {
                    strConcat = str;
                }
                hVar = (h) linkedHashMap.get(strConcat);
                if (hVar == null) {
                    hVar = new h(str);
                }
                linkedHashMap.put(str, hVar);
            }
        } catch (Throwable th) {
            throw th;
        }
        return hVar;
    }
}

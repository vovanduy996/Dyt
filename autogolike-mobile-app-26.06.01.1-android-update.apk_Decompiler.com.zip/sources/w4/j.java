package w4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import javax.net.ssl.SSLSocket;
import m1.AbstractC1393s;

/* JADX INFO: loaded from: classes.dex */
public final class j {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final j f15210e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final j f15211f;
    public final boolean a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f15212b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String[] f15213c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String[] f15214d;

    static {
        h hVar = h.f15204r;
        h hVar2 = h.f15205s;
        h hVar3 = h.f15206t;
        h hVar4 = h.f15198l;
        h hVar5 = h.f15200n;
        h hVar6 = h.f15199m;
        h hVar7 = h.f15201o;
        h hVar8 = h.f15203q;
        h hVar9 = h.f15202p;
        h[] hVarArr = {hVar, hVar2, hVar3, hVar4, hVar5, hVar6, hVar7, hVar8, hVar9, h.f15196j, h.f15197k, h.f15194h, h.f15195i, h.f15192f, h.f15193g, h.f15191e};
        i iVar = new i();
        iVar.c((h[]) Arrays.copyOf(new h[]{hVar, hVar2, hVar3, hVar4, hVar5, hVar6, hVar7, hVar8, hVar9}, 9));
        D d3 = D.f15153m;
        D d5 = D.f15154n;
        iVar.e(d3, d5);
        if (!iVar.a) {
            throw new IllegalArgumentException("no TLS extensions for cleartext connections");
        }
        iVar.f15209d = true;
        iVar.a();
        i iVar2 = new i();
        iVar2.c((h[]) Arrays.copyOf(hVarArr, 16));
        iVar2.e(d3, d5);
        if (!iVar2.a) {
            throw new IllegalArgumentException("no TLS extensions for cleartext connections");
        }
        iVar2.f15209d = true;
        f15210e = iVar2.a();
        i iVar3 = new i();
        iVar3.c((h[]) Arrays.copyOf(hVarArr, 16));
        iVar3.e(d3, d5, D.f15155o, D.f15156p);
        if (!iVar3.a) {
            throw new IllegalArgumentException("no TLS extensions for cleartext connections");
        }
        iVar3.f15209d = true;
        iVar3.a();
        f15211f = new j(false, false, null, null);
    }

    public j(boolean z3, boolean z5, String[] strArr, String[] strArr2) {
        this.a = z3;
        this.f15212b = z5;
        this.f15213c = strArr;
        this.f15214d = strArr2;
    }

    public final List a() {
        String[] strArr = this.f15213c;
        if (strArr == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList(strArr.length);
        for (String str : strArr) {
            arrayList.add(h.f15188b.c(str));
        }
        return H3.m.B1(arrayList);
    }

    public final boolean b(SSLSocket sSLSocket) {
        if (!this.a) {
            return false;
        }
        String[] strArr = this.f15214d;
        if (strArr != null && !x4.b.j(strArr, sSLSocket.getEnabledProtocols(), J3.b.f4395b)) {
            return false;
        }
        String[] strArr2 = this.f15213c;
        return strArr2 == null || x4.b.j(strArr2, sSLSocket.getEnabledCipherSuites(), h.f15189c);
    }

    public final List c() {
        String[] strArr = this.f15214d;
        if (strArr == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList(strArr.length);
        for (String str : strArr) {
            arrayList.add(AbstractC1393s.V(str));
        }
        return H3.m.B1(arrayList);
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof j)) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        j jVar = (j) obj;
        boolean z3 = jVar.a;
        boolean z5 = this.a;
        if (z5 != z3) {
            return false;
        }
        return !z5 || (Arrays.equals(this.f15213c, jVar.f15213c) && Arrays.equals(this.f15214d, jVar.f15214d) && this.f15212b == jVar.f15212b);
    }

    public final int hashCode() {
        if (!this.a) {
            return 17;
        }
        String[] strArr = this.f15213c;
        int iHashCode = (527 + (strArr != null ? Arrays.hashCode(strArr) : 0)) * 31;
        String[] strArr2 = this.f15214d;
        return ((iHashCode + (strArr2 != null ? Arrays.hashCode(strArr2) : 0)) * 31) + (!this.f15212b ? 1 : 0);
    }

    public final String toString() {
        if (!this.a) {
            return "ConnectionSpec()";
        }
        return "ConnectionSpec(cipherSuites=" + Objects.toString(a(), "[all enabled]") + ", tlsVersions=" + Objects.toString(c(), "[all enabled]") + ", supportsTlsExtensions=" + this.f15212b + ')';
    }
}

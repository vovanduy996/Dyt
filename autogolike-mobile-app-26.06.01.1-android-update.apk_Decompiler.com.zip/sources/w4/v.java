package w4;

import A.C0016q;
import e3.C0867C;
import java.net.ProxySelector;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import javax.net.SocketFactory;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;

/* JADX INFO: loaded from: classes.dex */
public final class v implements Cloneable, InterfaceC2019d {

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public static final List f15282K = x4.b.l(w.f15309p, w.f15307n);

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public static final List f15283L = x4.b.l(j.f15210e, j.f15211f);

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final X509TrustManager f15284A;
    public final List B;
    public final List C;
    public final I4.c D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final f f15285E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public final W3.a f15286F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public final int f15287G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public final int f15288H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public final int f15289I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public final C3.c f15290J;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final M1.m f15291l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final C0867C f15292m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final List f15293n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final List f15294o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final C0016q f15295p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final boolean f15296q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final C2017b f15297r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final boolean f15298s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final boolean f15299t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final C2017b f15300u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final C2017b f15301v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final ProxySelector f15302w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final C2017b f15303x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final SocketFactory f15304y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final SSLSocketFactory f15305z;

    public v(u uVar) throws NoSuchAlgorithmException, KeyStoreException {
        this.f15291l = uVar.a;
        this.f15292m = uVar.f15263b;
        this.f15293n = x4.b.x(uVar.f15264c);
        this.f15294o = x4.b.x(uVar.f15265d);
        this.f15295p = uVar.f15266e;
        this.f15296q = uVar.f15267f;
        this.f15297r = uVar.f15268g;
        this.f15298s = uVar.f15269h;
        this.f15299t = uVar.f15270i;
        this.f15300u = uVar.f15271j;
        this.f15301v = uVar.f15272k;
        ProxySelector proxySelector = ProxySelector.getDefault();
        this.f15302w = proxySelector == null ? G4.a.a : proxySelector;
        this.f15303x = uVar.f15273l;
        this.f15304y = uVar.f15274m;
        List list = uVar.f15275n;
        this.B = list;
        this.C = uVar.f15276o;
        this.D = uVar.f15277p;
        this.f15287G = uVar.f15279r;
        this.f15288H = uVar.f15280s;
        this.f15289I = uVar.f15281t;
        this.f15290J = new C3.c(2);
        List list2 = list;
        if ((list2 instanceof Collection) && list2.isEmpty()) {
            this.f15305z = null;
            this.f15286F = null;
            this.f15284A = null;
            this.f15285E = f.f15186c;
        } else {
            Iterator it = list2.iterator();
            while (it.hasNext()) {
                if (((j) it.next()).a) {
                    E4.n nVar = E4.n.a;
                    X509TrustManager x509TrustManagerN = E4.n.a.n();
                    this.f15284A = x509TrustManagerN;
                    this.f15305z = E4.n.a.m(x509TrustManagerN);
                    W3.a aVarB = E4.n.a.b(x509TrustManagerN);
                    this.f15286F = aVarB;
                    f fVar = uVar.f15278q;
                    this.f15285E = U3.j.a(fVar.f15187b, aVarB) ? fVar : new f(fVar.a, aVarB);
                }
            }
            this.f15305z = null;
            this.f15286F = null;
            this.f15284A = null;
            this.f15285E = f.f15186c;
        }
        List list3 = this.f15293n;
        U3.j.d(list3, "null cannot be cast to non-null type kotlin.collections.List<okhttp3.Interceptor?>");
        if (list3.contains(null)) {
            throw new IllegalStateException(("Null interceptor: " + list3).toString());
        }
        List list4 = this.f15294o;
        U3.j.d(list4, "null cannot be cast to non-null type kotlin.collections.List<okhttp3.Interceptor?>");
        if (list4.contains(null)) {
            throw new IllegalStateException(("Null network interceptor: " + list4).toString());
        }
        List list5 = this.B;
        boolean z3 = list5 instanceof Collection;
        X509TrustManager x509TrustManager = this.f15284A;
        W3.a aVar = this.f15286F;
        SSLSocketFactory sSLSocketFactory = this.f15305z;
        if (!z3 || !list5.isEmpty()) {
            Iterator it2 = list5.iterator();
            while (it2.hasNext()) {
                if (((j) it2.next()).a) {
                    if (sSLSocketFactory == null) {
                        throw new IllegalStateException("sslSocketFactory == null");
                    }
                    if (aVar == null) {
                        throw new IllegalStateException("certificateChainCleaner == null");
                    }
                    if (x509TrustManager == null) {
                        throw new IllegalStateException("x509TrustManager == null");
                    }
                    return;
                }
            }
        }
        if (sSLSocketFactory != null) {
            throw new IllegalStateException("Check failed.");
        }
        if (aVar != null) {
            throw new IllegalStateException("Check failed.");
        }
        if (x509TrustManager != null) {
            throw new IllegalStateException("Check failed.");
        }
        if (!U3.j.a(this.f15285E, f.f15186c)) {
            throw new IllegalStateException("Check failed.");
        }
    }

    public final Object clone() {
        return super.clone();
    }
}

package i2;

/* JADX INFO: renamed from: i2.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1148i implements InterfaceC1153n {
    public static final C1148i a = new C1148i();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof C1148i);
    }

    public final int hashCode() {
        return -1816508709;
    }

    public final String toString() {
        return "OpenApp";
    }
}

package i2;

import I.C0234d;
import I.C0258p;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: renamed from: i2.w, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C1162w implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f10535l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Object f10536m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ long f10537n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ boolean f10538o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ int f10539p;

    public /* synthetic */ C1162w(long j5, boolean z3, T3.a aVar, int i5) {
        this.f10535l = 2;
        this.f10537n = j5;
        this.f10538o = z3;
        this.f10536m = aVar;
        this.f10539p = i5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) throws XmlPullParserException, IOException {
        switch (this.f10535l) {
            case ConfigBackupDto.$stable /* 0 */:
                ((Integer) obj2).intValue();
                l0.c.n((String) this.f10536m, this.f10537n, this.f10538o, (C0258p) obj, C0234d.U(this.f10539p | 1));
                break;
            case 1:
                ((Integer) obj2).intValue();
                l0.c.n((String) this.f10536m, this.f10537n, this.f10538o, (C0258p) obj, C0234d.U(this.f10539p | 1));
                break;
            default:
                ((Integer) obj2).intValue();
                l0.c.m(this.f10537n, this.f10538o, (T3.a) this.f10536m, (C0258p) obj, C0234d.U(this.f10539p | 1));
                break;
        }
        return G3.C.a;
    }

    public /* synthetic */ C1162w(String str, long j5, boolean z3, int i5, int i6) {
        this.f10535l = i6;
        this.f10536m = str;
        this.f10537n = j5;
        this.f10538o = z3;
        this.f10539p = i5;
    }
}

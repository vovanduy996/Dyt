package i2;

import a0.C0492c;
import com.autogolike.mobile.core.backup.ConfigBackupDto;

/* JADX INFO: renamed from: i2.A, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C1127A implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f10412l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ T3.e f10413m;

    public /* synthetic */ C1127A(T3.e eVar, int i5) {
        this.f10412l = i5;
        this.f10413m = eVar;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        switch (this.f10412l) {
            case ConfigBackupDto.$stable /* 0 */:
                C0492c c0492c = (C0492c) obj2;
                this.f10413m.i(Float.valueOf(C0492c.d(c0492c.a)), Float.valueOf(C0492c.e(c0492c.a)));
                break;
            case 1:
                String str = (String) obj;
                Long l4 = (Long) obj2;
                l4.longValue();
                U3.j.f(str, "name");
                this.f10413m.i(str, l4);
                break;
            default:
                String str2 = (String) obj;
                Long l5 = (Long) obj2;
                l5.longValue();
                U3.j.f(str2, "name");
                this.f10413m.i(str2, l5);
                break;
        }
        return G3.C.a;
    }
}

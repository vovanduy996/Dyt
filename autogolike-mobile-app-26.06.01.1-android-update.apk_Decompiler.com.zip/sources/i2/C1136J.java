package i2;

import G3.AbstractC0164a;
import N1.n0;
import N1.o0;
import N1.p0;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import com.autogolike.mobile.core.overlay.OverlayService;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: i2.J, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1136J extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public /* synthetic */ Object f10433p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ OverlayService f10434q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1136J(OverlayService overlayService, Continuation continuation) {
        super(2, continuation);
        this.f10434q = overlayService;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        C1136J c1136j = (C1136J) m((p0) obj, (Continuation) obj2);
        G3.C c5 = G3.C.a;
        c1136j.o(c5);
        return c5;
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C1136J c1136j = new C1136J(this.f10434q, continuation);
        c1136j.f10433p = obj;
        return c1136j;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        Object objB;
        AbstractC0164a.e(obj);
        p0 p0Var = (p0) this.f10433p;
        boolean z3 = p0Var instanceof o0;
        G3.C c5 = G3.C.a;
        OverlayService overlayService = this.f10434q;
        if (z3) {
            o0 o0Var = (o0) p0Var;
            Toast.makeText(overlayService, "Đã lưu Downloads/AutoGoLike/" + o0Var.f5258b + " (" + o0Var.f5259c + " nodes)", 1).show();
            Uri uri = o0Var.a;
            C1131E c1131e = OverlayService.Companion;
            overlayService.getClass();
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("text/plain");
            intent.putExtra("android.intent.extra.STREAM", uri);
            intent.putExtra("android.intent.extra.SUBJECT", o0Var.f5258b);
            intent.addFlags(1);
            Intent intentAddFlags = Intent.createChooser(intent, "Chia sẻ UI dump").addFlags(268435456);
            U3.j.e(intentAddFlags, "addFlags(...)");
            try {
                overlayService.startActivity(intentAddFlags);
                objB = c5;
            } catch (Throwable th) {
                objB = AbstractC0164a.b(th);
            }
            Throwable thA = G3.o.a(objB);
            if (thA != null) {
                P4.c cVar = P4.e.a;
                cVar.j("Overlay");
                cVar.h(thA, "share dump failed", new Object[0]);
            }
        } else {
            if (!(p0Var instanceof n0)) {
                throw new G3.f();
            }
            Toast.makeText(overlayService, "Dump lỗi: ".concat(((n0) p0Var).a), 1).show();
        }
        return c5;
    }
}

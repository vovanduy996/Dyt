package i2;

/* JADX INFO: renamed from: i2.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1145f implements InterfaceC1153n {
    public static final C1145f a = new C1145f();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof C1145f);
    }

    public final int hashCode() {
        return -369273039;
    }

    public final String toString() {
        return "FetchNext";
    }
}

package i2;

import G3.AbstractC0164a;
import V1.K1;
import V1.M1;
import com.autogolike.mobile.core.overlay.OverlayService;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: i2.G, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1133G extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f10425p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ OverlayService f10426q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ boolean f10427r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1133G(OverlayService overlayService, boolean z3, Continuation continuation) {
        super(2, continuation);
        this.f10426q = overlayService;
        this.f10427r = z3;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C1133G) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new C1133G(this.f10426q, this.f10427r, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f10425p;
        G3.C c5 = G3.C.a;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            K1 k12 = this.f10426q.f8246r;
            if (k12 == null) {
                U3.j.j("prefs");
                throw null;
            }
            this.f10425p = 1;
            Object objZ = X2.g.z(M1.a(k12.a), new V1.A(k12, this.f10427r, null), this);
            if (objZ != aVar) {
                objZ = c5;
            }
            if (objZ == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return c5;
    }
}

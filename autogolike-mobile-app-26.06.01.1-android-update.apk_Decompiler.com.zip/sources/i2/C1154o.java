package i2;

import i4.N;
import i4.O;
import i4.c0;

/* JADX INFO: renamed from: i2.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1154o {
    public final c0 a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final i4.J f10479b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final N f10480c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final i4.I f10481d;

    public C1154o() {
        c0 c0VarC = O.c(new C1138L());
        this.a = c0VarC;
        this.f10479b = new i4.J(c0VarC);
        N nA = O.a(0, 8, h4.a.f10253m);
        this.f10480c = nA;
        this.f10481d = new i4.I(nA);
    }

    public final void a(T3.c cVar) {
        c0 c0Var = this.a;
        c0Var.l(cVar.invoke(c0Var.getValue()));
    }
}

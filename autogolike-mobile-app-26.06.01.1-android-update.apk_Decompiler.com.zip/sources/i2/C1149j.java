package i2;

/* JADX INFO: renamed from: i2.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1149j implements InterfaceC1153n {
    public static final C1149j a = new C1149j();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof C1149j);
    }

    public final int hashCode() {
        return -476874112;
    }

    public final String toString() {
        return "OpenLink";
    }
}

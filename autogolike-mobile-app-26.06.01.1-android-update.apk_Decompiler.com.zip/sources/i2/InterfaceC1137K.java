package i2;

import com.autogolike.mobile.core.overlay.OverlayService;
import dagger.hilt.InstallIn;
import dagger.hilt.android.components.ServiceComponent;
import dagger.hilt.codegen.OriginatingElement;
import dagger.hilt.internal.GeneratedEntryPoint;

/* JADX INFO: renamed from: i2.K, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
@OriginatingElement(topLevelClass = OverlayService.class)
@GeneratedEntryPoint
@InstallIn({ServiceComponent.class})
public interface InterfaceC1137K {
}

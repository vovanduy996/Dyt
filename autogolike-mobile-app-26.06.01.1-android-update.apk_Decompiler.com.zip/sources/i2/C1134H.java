package i2;

import B2.C0033i;
import B2.C0045v;
import G3.AbstractC0164a;
import I.C0234d;
import I.C0250l;
import I.C0258p;
import I.InterfaceC0233c0;
import I.W;
import N1.C0354a;
import V1.K1;
import android.content.Intent;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import com.autogolike.mobile.core.overlay.OverlayService;
import i4.N;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParserException;
import u0.C1862e0;

/* JADX INFO: renamed from: i2.H, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1134H implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f10428l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ OverlayService f10429m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ C1862e0 f10430n;

    public /* synthetic */ C1134H(OverlayService overlayService, C1862e0 c1862e0, int i5) {
        this.f10428l = i5;
        this.f10429m = overlayService;
        this.f10430n = c1862e0;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) throws XmlPullParserException, IOException {
        switch (this.f10428l) {
            case ConfigBackupDto.$stable /* 0 */:
                C0258p c0258p = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p.x()) {
                    c0258p.L();
                } else {
                    final OverlayService overlayService = this.f10429m;
                    InterfaceC0233c0 interfaceC0233c0V = C0234d.v(overlayService.f().f10479b, c0258p);
                    K1 k12 = overlayService.f8246r;
                    if (k12 == null) {
                        U3.j.j("prefs");
                        throw null;
                    }
                    InterfaceC0233c0 interfaceC0233c0U = C0234d.u(k12.f6345U, Boolean.TRUE, null, c0258p, 48, 2);
                    K1 k13 = overlayService.f8246r;
                    if (k13 == null) {
                        U3.j.j("prefs");
                        throw null;
                    }
                    Boolean bool = Boolean.FALSE;
                    InterfaceC0233c0 interfaceC0233c0U2 = C0234d.u(k13.f6362a1, bool, null, c0258p, 48, 2);
                    InterfaceC0233c0 interfaceC0233c0V2 = C0234d.v(overlayService.f8254z, c0258p);
                    C1862e0 c1862e0 = this.f10430n;
                    boolean z3 = ((Number) interfaceC0233c0V2.getValue()).intValue() + W3.a.O(((float) 28) * overlayService.getResources().getDisplayMetrics().density) > c1862e0.getResources().getDisplayMetrics().widthPixels / 2;
                    c0258p.Q(2064154039);
                    Object objG = c0258p.G();
                    W w5 = C0250l.a;
                    if (objG == w5) {
                        objG = C0234d.K(bool, W.f3598q);
                        c0258p.a0(objG);
                    }
                    InterfaceC0233c0 interfaceC0233c0 = (InterfaceC0233c0) objG;
                    c0258p.p(false);
                    C1138L c1138l = (C1138L) interfaceC0233c0V.getValue();
                    boolean zBooleanValue = ((Boolean) interfaceC0233c0.getValue()).booleanValue();
                    boolean zBooleanValue2 = ((Boolean) interfaceC0233c0U.getValue()).booleanValue();
                    boolean zBooleanValue3 = ((Boolean) interfaceC0233c0U2.getValue()).booleanValue();
                    c0258p.Q(2064167503);
                    Object objG2 = c0258p.G();
                    if (objG2 == w5) {
                        objG2 = new C0033i(interfaceC0233c0, 19);
                        c0258p.a0(objG2);
                    }
                    T3.a aVar = (T3.a) objG2;
                    c0258p.p(false);
                    c0258p.Q(2064169969);
                    boolean zH = c0258p.h(overlayService) | c0258p.h(c1862e0);
                    Object objG3 = c0258p.G();
                    if (zH || objG3 == w5) {
                        objG3 = new C1130D(overlayService, c1862e0);
                        c0258p.a0(objG3);
                    }
                    T3.e eVar = (T3.e) objG3;
                    c0258p.p(false);
                    c0258p.Q(2064184603);
                    boolean zH2 = c0258p.h(overlayService);
                    Object objG4 = c0258p.G();
                    if (zH2 || objG4 == w5) {
                        objG4 = new C0045v(6, overlayService);
                        c0258p.a0(objG4);
                    }
                    T3.c cVar = (T3.c) objG4;
                    c0258p.p(false);
                    c0258p.Q(2064190172);
                    boolean zH3 = c0258p.h(overlayService);
                    Object objG5 = c0258p.G();
                    if (zH3 || objG5 == w5) {
                        final int i5 = 6;
                        objG5 = new T3.a() { // from class: i2.F
                            @Override // T3.a
                            public final Object b() {
                                Object objB;
                                switch (i5) {
                                    case ConfigBackupDto.$stable /* 0 */:
                                        C1154o c1154oF = overlayService.f();
                                        c1154oF.f10480c.c(C1145f.a);
                                        return G3.C.a;
                                    case 1:
                                        OverlayService overlayService2 = overlayService;
                                        C1154o c1154oF2 = overlayService2.f();
                                        c1154oF2.f10480c.c(C1148i.a);
                                        Intent launchIntentForPackage = overlayService2.getPackageManager().getLaunchIntentForPackage(overlayService2.getPackageName());
                                        if (launchIntentForPackage != null) {
                                            launchIntentForPackage.addFlags(268566528);
                                        }
                                        G3.C c5 = G3.C.a;
                                        if (launchIntentForPackage != null) {
                                            try {
                                                overlayService2.startActivity(launchIntentForPackage);
                                                objB = c5;
                                            } catch (Throwable th) {
                                                objB = AbstractC0164a.b(th);
                                            }
                                        } else {
                                            objB = null;
                                        }
                                        Throwable thA = G3.o.a(objB);
                                        if (thA != null) {
                                            P4.c cVar2 = P4.e.a;
                                            cVar2.j("Overlay");
                                            cVar2.h(thA, "bringAppToFront failed", new Object[0]);
                                        }
                                        return c5;
                                    case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                                        C1154o c1154oF3 = overlayService.f();
                                        c1154oF3.f10480c.c(C1149j.a);
                                        return G3.C.a;
                                    case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                                        C1154o c1154oF4 = overlayService.f();
                                        c1154oF4.f10480c.c(C1152m.a);
                                        return G3.C.a;
                                    case k1.h.LONG_FIELD_NUMBER /* 4 */:
                                        C0354a c0354a = overlayService.f8247s;
                                        if (c0354a == null) {
                                            U3.j.j("accessibilityBridge");
                                            throw null;
                                        }
                                        N n5 = c0354a.f5155i;
                                        G3.C c6 = G3.C.a;
                                        n5.c(c6);
                                        return c6;
                                    case k1.h.STRING_FIELD_NUMBER /* 5 */:
                                        C1154o c1154oF5 = overlayService.f();
                                        c1154oF5.f10480c.c(C1150k.a);
                                        return G3.C.a;
                                    case k1.h.STRING_SET_FIELD_NUMBER /* 6 */:
                                        C1154o c1154oF6 = overlayService.f();
                                        c1154oF6.f10480c.c(C1146g.a);
                                        return G3.C.a;
                                    case k1.h.DOUBLE_FIELD_NUMBER /* 7 */:
                                        C1154o c1154oF7 = overlayService.f();
                                        c1154oF7.f10480c.c(C1147h.a);
                                        return G3.C.a;
                                    case 8:
                                        OverlayService overlayService3 = overlayService;
                                        C1154o c1154oF8 = overlayService3.f();
                                        c1154oF8.f10480c.c(C1144e.a);
                                        overlayService3.g();
                                        return G3.C.a;
                                    default:
                                        C1154o c1154oF9 = overlayService.f();
                                        c1154oF9.f10480c.c(C1151l.a);
                                        return G3.C.a;
                                }
                            }
                        };
                        c0258p.a0(objG5);
                    }
                    T3.a aVar2 = (T3.a) objG5;
                    c0258p.p(false);
                    c0258p.Q(2064192796);
                    boolean zH4 = c0258p.h(overlayService);
                    Object objG6 = c0258p.G();
                    if (zH4 || objG6 == w5) {
                        final int i6 = 7;
                        objG6 = new T3.a() { // from class: i2.F
                            @Override // T3.a
                            public final Object b() {
                                Object objB;
                                switch (i6) {
                                    case ConfigBackupDto.$stable /* 0 */:
                                        C1154o c1154oF = overlayService.f();
                                        c1154oF.f10480c.c(C1145f.a);
                                        return G3.C.a;
                                    case 1:
                                        OverlayService overlayService2 = overlayService;
                                        C1154o c1154oF2 = overlayService2.f();
                                        c1154oF2.f10480c.c(C1148i.a);
                                        Intent launchIntentForPackage = overlayService2.getPackageManager().getLaunchIntentForPackage(overlayService2.getPackageName());
                                        if (launchIntentForPackage != null) {
                                            launchIntentForPackage.addFlags(268566528);
                                        }
                                        G3.C c5 = G3.C.a;
                                        if (launchIntentForPackage != null) {
                                            try {
                                                overlayService2.startActivity(launchIntentForPackage);
                                                objB = c5;
                                            } catch (Throwable th) {
                                                objB = AbstractC0164a.b(th);
                                            }
                                        } else {
                                            objB = null;
                                        }
                                        Throwable thA = G3.o.a(objB);
                                        if (thA != null) {
                                            P4.c cVar2 = P4.e.a;
                                            cVar2.j("Overlay");
                                            cVar2.h(thA, "bringAppToFront failed", new Object[0]);
                                        }
                                        return c5;
                                    case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                                        C1154o c1154oF3 = overlayService.f();
                                        c1154oF3.f10480c.c(C1149j.a);
                                        return G3.C.a;
                                    case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                                        C1154o c1154oF4 = overlayService.f();
                                        c1154oF4.f10480c.c(C1152m.a);
                                        return G3.C.a;
                                    case k1.h.LONG_FIELD_NUMBER /* 4 */:
                                        C0354a c0354a = overlayService.f8247s;
                                        if (c0354a == null) {
                                            U3.j.j("accessibilityBridge");
                                            throw null;
                                        }
                                        N n5 = c0354a.f5155i;
                                        G3.C c6 = G3.C.a;
                                        n5.c(c6);
                                        return c6;
                                    case k1.h.STRING_FIELD_NUMBER /* 5 */:
                                        C1154o c1154oF5 = overlayService.f();
                                        c1154oF5.f10480c.c(C1150k.a);
                                        return G3.C.a;
                                    case k1.h.STRING_SET_FIELD_NUMBER /* 6 */:
                                        C1154o c1154oF6 = overlayService.f();
                                        c1154oF6.f10480c.c(C1146g.a);
                                        return G3.C.a;
                                    case k1.h.DOUBLE_FIELD_NUMBER /* 7 */:
                                        C1154o c1154oF7 = overlayService.f();
                                        c1154oF7.f10480c.c(C1147h.a);
                                        return G3.C.a;
                                    case 8:
                                        OverlayService overlayService3 = overlayService;
                                        C1154o c1154oF8 = overlayService3.f();
                                        c1154oF8.f10480c.c(C1144e.a);
                                        overlayService3.g();
                                        return G3.C.a;
                                    default:
                                        C1154o c1154oF9 = overlayService.f();
                                        c1154oF9.f10480c.c(C1151l.a);
                                        return G3.C.a;
                                }
                            }
                        };
                        c0258p.a0(objG6);
                    }
                    T3.a aVar3 = (T3.a) objG6;
                    c0258p.p(false);
                    c0258p.Q(2064217638);
                    boolean zH5 = c0258p.h(overlayService);
                    Object objG7 = c0258p.G();
                    if (zH5 || objG7 == w5) {
                        final int i7 = 8;
                        objG7 = new T3.a() { // from class: i2.F
                            @Override // T3.a
                            public final Object b() {
                                Object objB;
                                switch (i7) {
                                    case ConfigBackupDto.$stable /* 0 */:
                                        C1154o c1154oF = overlayService.f();
                                        c1154oF.f10480c.c(C1145f.a);
                                        return G3.C.a;
                                    case 1:
                                        OverlayService overlayService2 = overlayService;
                                        C1154o c1154oF2 = overlayService2.f();
                                        c1154oF2.f10480c.c(C1148i.a);
                                        Intent launchIntentForPackage = overlayService2.getPackageManager().getLaunchIntentForPackage(overlayService2.getPackageName());
                                        if (launchIntentForPackage != null) {
                                            launchIntentForPackage.addFlags(268566528);
                                        }
                                        G3.C c5 = G3.C.a;
                                        if (launchIntentForPackage != null) {
                                            try {
                                                overlayService2.startActivity(launchIntentForPackage);
                                                objB = c5;
                                            } catch (Throwable th) {
                                                objB = AbstractC0164a.b(th);
                                            }
                                        } else {
                                            objB = null;
                                        }
                                        Throwable thA = G3.o.a(objB);
                                        if (thA != null) {
                                            P4.c cVar2 = P4.e.a;
                                            cVar2.j("Overlay");
                                            cVar2.h(thA, "bringAppToFront failed", new Object[0]);
                                        }
                                        return c5;
                                    case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                                        C1154o c1154oF3 = overlayService.f();
                                        c1154oF3.f10480c.c(C1149j.a);
                                        return G3.C.a;
                                    case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                                        C1154o c1154oF4 = overlayService.f();
                                        c1154oF4.f10480c.c(C1152m.a);
                                        return G3.C.a;
                                    case k1.h.LONG_FIELD_NUMBER /* 4 */:
                                        C0354a c0354a = overlayService.f8247s;
                                        if (c0354a == null) {
                                            U3.j.j("accessibilityBridge");
                                            throw null;
                                        }
                                        N n5 = c0354a.f5155i;
                                        G3.C c6 = G3.C.a;
                                        n5.c(c6);
                                        return c6;
                                    case k1.h.STRING_FIELD_NUMBER /* 5 */:
                                        C1154o c1154oF5 = overlayService.f();
                                        c1154oF5.f10480c.c(C1150k.a);
                                        return G3.C.a;
                                    case k1.h.STRING_SET_FIELD_NUMBER /* 6 */:
                                        C1154o c1154oF6 = overlayService.f();
                                        c1154oF6.f10480c.c(C1146g.a);
                                        return G3.C.a;
                                    case k1.h.DOUBLE_FIELD_NUMBER /* 7 */:
                                        C1154o c1154oF7 = overlayService.f();
                                        c1154oF7.f10480c.c(C1147h.a);
                                        return G3.C.a;
                                    case 8:
                                        OverlayService overlayService3 = overlayService;
                                        C1154o c1154oF8 = overlayService3.f();
                                        c1154oF8.f10480c.c(C1144e.a);
                                        overlayService3.g();
                                        return G3.C.a;
                                    default:
                                        C1154o c1154oF9 = overlayService.f();
                                        c1154oF9.f10480c.c(C1151l.a);
                                        return G3.C.a;
                                }
                            }
                        };
                        c0258p.a0(objG7);
                    }
                    T3.a aVar4 = (T3.a) objG7;
                    c0258p.p(false);
                    c0258p.Q(2064195420);
                    boolean zH6 = c0258p.h(overlayService);
                    Object objG8 = c0258p.G();
                    if (zH6 || objG8 == w5) {
                        final int i8 = 9;
                        objG8 = new T3.a() { // from class: i2.F
                            @Override // T3.a
                            public final Object b() {
                                Object objB;
                                switch (i8) {
                                    case ConfigBackupDto.$stable /* 0 */:
                                        C1154o c1154oF = overlayService.f();
                                        c1154oF.f10480c.c(C1145f.a);
                                        return G3.C.a;
                                    case 1:
                                        OverlayService overlayService2 = overlayService;
                                        C1154o c1154oF2 = overlayService2.f();
                                        c1154oF2.f10480c.c(C1148i.a);
                                        Intent launchIntentForPackage = overlayService2.getPackageManager().getLaunchIntentForPackage(overlayService2.getPackageName());
                                        if (launchIntentForPackage != null) {
                                            launchIntentForPackage.addFlags(268566528);
                                        }
                                        G3.C c5 = G3.C.a;
                                        if (launchIntentForPackage != null) {
                                            try {
                                                overlayService2.startActivity(launchIntentForPackage);
                                                objB = c5;
                                            } catch (Throwable th) {
                                                objB = AbstractC0164a.b(th);
                                            }
                                        } else {
                                            objB = null;
                                        }
                                        Throwable thA = G3.o.a(objB);
                                        if (thA != null) {
                                            P4.c cVar2 = P4.e.a;
                                            cVar2.j("Overlay");
                                            cVar2.h(thA, "bringAppToFront failed", new Object[0]);
                                        }
                                        return c5;
                                    case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                                        C1154o c1154oF3 = overlayService.f();
                                        c1154oF3.f10480c.c(C1149j.a);
                                        return G3.C.a;
                                    case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                                        C1154o c1154oF4 = overlayService.f();
                                        c1154oF4.f10480c.c(C1152m.a);
                                        return G3.C.a;
                                    case k1.h.LONG_FIELD_NUMBER /* 4 */:
                                        C0354a c0354a = overlayService.f8247s;
                                        if (c0354a == null) {
                                            U3.j.j("accessibilityBridge");
                                            throw null;
                                        }
                                        N n5 = c0354a.f5155i;
                                        G3.C c6 = G3.C.a;
                                        n5.c(c6);
                                        return c6;
                                    case k1.h.STRING_FIELD_NUMBER /* 5 */:
                                        C1154o c1154oF5 = overlayService.f();
                                        c1154oF5.f10480c.c(C1150k.a);
                                        return G3.C.a;
                                    case k1.h.STRING_SET_FIELD_NUMBER /* 6 */:
                                        C1154o c1154oF6 = overlayService.f();
                                        c1154oF6.f10480c.c(C1146g.a);
                                        return G3.C.a;
                                    case k1.h.DOUBLE_FIELD_NUMBER /* 7 */:
                                        C1154o c1154oF7 = overlayService.f();
                                        c1154oF7.f10480c.c(C1147h.a);
                                        return G3.C.a;
                                    case 8:
                                        OverlayService overlayService3 = overlayService;
                                        C1154o c1154oF8 = overlayService3.f();
                                        c1154oF8.f10480c.c(C1144e.a);
                                        overlayService3.g();
                                        return G3.C.a;
                                    default:
                                        C1154o c1154oF9 = overlayService.f();
                                        c1154oF9.f10480c.c(C1151l.a);
                                        return G3.C.a;
                                }
                            }
                        };
                        c0258p.a0(objG8);
                    }
                    T3.a aVar5 = (T3.a) objG8;
                    c0258p.p(false);
                    c0258p.Q(2064198077);
                    boolean zH7 = c0258p.h(overlayService);
                    Object objG9 = c0258p.G();
                    if (zH7 || objG9 == w5) {
                        final int i9 = 0;
                        objG9 = new T3.a() { // from class: i2.F
                            @Override // T3.a
                            public final Object b() {
                                Object objB;
                                switch (i9) {
                                    case ConfigBackupDto.$stable /* 0 */:
                                        C1154o c1154oF = overlayService.f();
                                        c1154oF.f10480c.c(C1145f.a);
                                        return G3.C.a;
                                    case 1:
                                        OverlayService overlayService2 = overlayService;
                                        C1154o c1154oF2 = overlayService2.f();
                                        c1154oF2.f10480c.c(C1148i.a);
                                        Intent launchIntentForPackage = overlayService2.getPackageManager().getLaunchIntentForPackage(overlayService2.getPackageName());
                                        if (launchIntentForPackage != null) {
                                            launchIntentForPackage.addFlags(268566528);
                                        }
                                        G3.C c5 = G3.C.a;
                                        if (launchIntentForPackage != null) {
                                            try {
                                                overlayService2.startActivity(launchIntentForPackage);
                                                objB = c5;
                                            } catch (Throwable th) {
                                                objB = AbstractC0164a.b(th);
                                            }
                                        } else {
                                            objB = null;
                                        }
                                        Throwable thA = G3.o.a(objB);
                                        if (thA != null) {
                                            P4.c cVar2 = P4.e.a;
                                            cVar2.j("Overlay");
                                            cVar2.h(thA, "bringAppToFront failed", new Object[0]);
                                        }
                                        return c5;
                                    case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                                        C1154o c1154oF3 = overlayService.f();
                                        c1154oF3.f10480c.c(C1149j.a);
                                        return G3.C.a;
                                    case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                                        C1154o c1154oF4 = overlayService.f();
                                        c1154oF4.f10480c.c(C1152m.a);
                                        return G3.C.a;
                                    case k1.h.LONG_FIELD_NUMBER /* 4 */:
                                        C0354a c0354a = overlayService.f8247s;
                                        if (c0354a == null) {
                                            U3.j.j("accessibilityBridge");
                                            throw null;
                                        }
                                        N n5 = c0354a.f5155i;
                                        G3.C c6 = G3.C.a;
                                        n5.c(c6);
                                        return c6;
                                    case k1.h.STRING_FIELD_NUMBER /* 5 */:
                                        C1154o c1154oF5 = overlayService.f();
                                        c1154oF5.f10480c.c(C1150k.a);
                                        return G3.C.a;
                                    case k1.h.STRING_SET_FIELD_NUMBER /* 6 */:
                                        C1154o c1154oF6 = overlayService.f();
                                        c1154oF6.f10480c.c(C1146g.a);
                                        return G3.C.a;
                                    case k1.h.DOUBLE_FIELD_NUMBER /* 7 */:
                                        C1154o c1154oF7 = overlayService.f();
                                        c1154oF7.f10480c.c(C1147h.a);
                                        return G3.C.a;
                                    case 8:
                                        OverlayService overlayService3 = overlayService;
                                        C1154o c1154oF8 = overlayService3.f();
                                        c1154oF8.f10480c.c(C1144e.a);
                                        overlayService3.g();
                                        return G3.C.a;
                                    default:
                                        C1154o c1154oF9 = overlayService.f();
                                        c1154oF9.f10480c.c(C1151l.a);
                                        return G3.C.a;
                                }
                            }
                        };
                        c0258p.a0(objG9);
                    }
                    T3.a aVar6 = (T3.a) objG9;
                    c0258p.p(false);
                    c0258p.Q(2064206185);
                    boolean zH8 = c0258p.h(overlayService);
                    Object objG10 = c0258p.G();
                    if (zH8 || objG10 == w5) {
                        final int i10 = 1;
                        objG10 = new T3.a() { // from class: i2.F
                            @Override // T3.a
                            public final Object b() {
                                Object objB;
                                switch (i10) {
                                    case ConfigBackupDto.$stable /* 0 */:
                                        C1154o c1154oF = overlayService.f();
                                        c1154oF.f10480c.c(C1145f.a);
                                        return G3.C.a;
                                    case 1:
                                        OverlayService overlayService2 = overlayService;
                                        C1154o c1154oF2 = overlayService2.f();
                                        c1154oF2.f10480c.c(C1148i.a);
                                        Intent launchIntentForPackage = overlayService2.getPackageManager().getLaunchIntentForPackage(overlayService2.getPackageName());
                                        if (launchIntentForPackage != null) {
                                            launchIntentForPackage.addFlags(268566528);
                                        }
                                        G3.C c5 = G3.C.a;
                                        if (launchIntentForPackage != null) {
                                            try {
                                                overlayService2.startActivity(launchIntentForPackage);
                                                objB = c5;
                                            } catch (Throwable th) {
                                                objB = AbstractC0164a.b(th);
                                            }
                                        } else {
                                            objB = null;
                                        }
                                        Throwable thA = G3.o.a(objB);
                                        if (thA != null) {
                                            P4.c cVar2 = P4.e.a;
                                            cVar2.j("Overlay");
                                            cVar2.h(thA, "bringAppToFront failed", new Object[0]);
                                        }
                                        return c5;
                                    case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                                        C1154o c1154oF3 = overlayService.f();
                                        c1154oF3.f10480c.c(C1149j.a);
                                        return G3.C.a;
                                    case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                                        C1154o c1154oF4 = overlayService.f();
                                        c1154oF4.f10480c.c(C1152m.a);
                                        return G3.C.a;
                                    case k1.h.LONG_FIELD_NUMBER /* 4 */:
                                        C0354a c0354a = overlayService.f8247s;
                                        if (c0354a == null) {
                                            U3.j.j("accessibilityBridge");
                                            throw null;
                                        }
                                        N n5 = c0354a.f5155i;
                                        G3.C c6 = G3.C.a;
                                        n5.c(c6);
                                        return c6;
                                    case k1.h.STRING_FIELD_NUMBER /* 5 */:
                                        C1154o c1154oF5 = overlayService.f();
                                        c1154oF5.f10480c.c(C1150k.a);
                                        return G3.C.a;
                                    case k1.h.STRING_SET_FIELD_NUMBER /* 6 */:
                                        C1154o c1154oF6 = overlayService.f();
                                        c1154oF6.f10480c.c(C1146g.a);
                                        return G3.C.a;
                                    case k1.h.DOUBLE_FIELD_NUMBER /* 7 */:
                                        C1154o c1154oF7 = overlayService.f();
                                        c1154oF7.f10480c.c(C1147h.a);
                                        return G3.C.a;
                                    case 8:
                                        OverlayService overlayService3 = overlayService;
                                        C1154o c1154oF8 = overlayService3.f();
                                        c1154oF8.f10480c.c(C1144e.a);
                                        overlayService3.g();
                                        return G3.C.a;
                                    default:
                                        C1154o c1154oF9 = overlayService.f();
                                        c1154oF9.f10480c.c(C1151l.a);
                                        return G3.C.a;
                                }
                            }
                        };
                        c0258p.a0(objG10);
                    }
                    T3.a aVar7 = (T3.a) objG10;
                    c0258p.p(false);
                    c0258p.Q(2064200732);
                    boolean zH9 = c0258p.h(overlayService);
                    Object objG11 = c0258p.G();
                    if (zH9 || objG11 == w5) {
                        final int i11 = 2;
                        objG11 = new T3.a() { // from class: i2.F
                            @Override // T3.a
                            public final Object b() {
                                Object objB;
                                switch (i11) {
                                    case ConfigBackupDto.$stable /* 0 */:
                                        C1154o c1154oF = overlayService.f();
                                        c1154oF.f10480c.c(C1145f.a);
                                        return G3.C.a;
                                    case 1:
                                        OverlayService overlayService2 = overlayService;
                                        C1154o c1154oF2 = overlayService2.f();
                                        c1154oF2.f10480c.c(C1148i.a);
                                        Intent launchIntentForPackage = overlayService2.getPackageManager().getLaunchIntentForPackage(overlayService2.getPackageName());
                                        if (launchIntentForPackage != null) {
                                            launchIntentForPackage.addFlags(268566528);
                                        }
                                        G3.C c5 = G3.C.a;
                                        if (launchIntentForPackage != null) {
                                            try {
                                                overlayService2.startActivity(launchIntentForPackage);
                                                objB = c5;
                                            } catch (Throwable th) {
                                                objB = AbstractC0164a.b(th);
                                            }
                                        } else {
                                            objB = null;
                                        }
                                        Throwable thA = G3.o.a(objB);
                                        if (thA != null) {
                                            P4.c cVar2 = P4.e.a;
                                            cVar2.j("Overlay");
                                            cVar2.h(thA, "bringAppToFront failed", new Object[0]);
                                        }
                                        return c5;
                                    case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                                        C1154o c1154oF3 = overlayService.f();
                                        c1154oF3.f10480c.c(C1149j.a);
                                        return G3.C.a;
                                    case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                                        C1154o c1154oF4 = overlayService.f();
                                        c1154oF4.f10480c.c(C1152m.a);
                                        return G3.C.a;
                                    case k1.h.LONG_FIELD_NUMBER /* 4 */:
                                        C0354a c0354a = overlayService.f8247s;
                                        if (c0354a == null) {
                                            U3.j.j("accessibilityBridge");
                                            throw null;
                                        }
                                        N n5 = c0354a.f5155i;
                                        G3.C c6 = G3.C.a;
                                        n5.c(c6);
                                        return c6;
                                    case k1.h.STRING_FIELD_NUMBER /* 5 */:
                                        C1154o c1154oF5 = overlayService.f();
                                        c1154oF5.f10480c.c(C1150k.a);
                                        return G3.C.a;
                                    case k1.h.STRING_SET_FIELD_NUMBER /* 6 */:
                                        C1154o c1154oF6 = overlayService.f();
                                        c1154oF6.f10480c.c(C1146g.a);
                                        return G3.C.a;
                                    case k1.h.DOUBLE_FIELD_NUMBER /* 7 */:
                                        C1154o c1154oF7 = overlayService.f();
                                        c1154oF7.f10480c.c(C1147h.a);
                                        return G3.C.a;
                                    case 8:
                                        OverlayService overlayService3 = overlayService;
                                        C1154o c1154oF8 = overlayService3.f();
                                        c1154oF8.f10480c.c(C1144e.a);
                                        overlayService3.g();
                                        return G3.C.a;
                                    default:
                                        C1154o c1154oF9 = overlayService.f();
                                        c1154oF9.f10480c.c(C1151l.a);
                                        return G3.C.a;
                                }
                            }
                        };
                        c0258p.a0(objG11);
                    }
                    T3.a aVar8 = (T3.a) objG11;
                    c0258p.p(false);
                    c0258p.Q(2064203422);
                    boolean zH10 = c0258p.h(overlayService);
                    Object objG12 = c0258p.G();
                    if (zH10 || objG12 == w5) {
                        final int i12 = 3;
                        objG12 = new T3.a() { // from class: i2.F
                            @Override // T3.a
                            public final Object b() {
                                Object objB;
                                switch (i12) {
                                    case ConfigBackupDto.$stable /* 0 */:
                                        C1154o c1154oF = overlayService.f();
                                        c1154oF.f10480c.c(C1145f.a);
                                        return G3.C.a;
                                    case 1:
                                        OverlayService overlayService2 = overlayService;
                                        C1154o c1154oF2 = overlayService2.f();
                                        c1154oF2.f10480c.c(C1148i.a);
                                        Intent launchIntentForPackage = overlayService2.getPackageManager().getLaunchIntentForPackage(overlayService2.getPackageName());
                                        if (launchIntentForPackage != null) {
                                            launchIntentForPackage.addFlags(268566528);
                                        }
                                        G3.C c5 = G3.C.a;
                                        if (launchIntentForPackage != null) {
                                            try {
                                                overlayService2.startActivity(launchIntentForPackage);
                                                objB = c5;
                                            } catch (Throwable th) {
                                                objB = AbstractC0164a.b(th);
                                            }
                                        } else {
                                            objB = null;
                                        }
                                        Throwable thA = G3.o.a(objB);
                                        if (thA != null) {
                                            P4.c cVar2 = P4.e.a;
                                            cVar2.j("Overlay");
                                            cVar2.h(thA, "bringAppToFront failed", new Object[0]);
                                        }
                                        return c5;
                                    case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                                        C1154o c1154oF3 = overlayService.f();
                                        c1154oF3.f10480c.c(C1149j.a);
                                        return G3.C.a;
                                    case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                                        C1154o c1154oF4 = overlayService.f();
                                        c1154oF4.f10480c.c(C1152m.a);
                                        return G3.C.a;
                                    case k1.h.LONG_FIELD_NUMBER /* 4 */:
                                        C0354a c0354a = overlayService.f8247s;
                                        if (c0354a == null) {
                                            U3.j.j("accessibilityBridge");
                                            throw null;
                                        }
                                        N n5 = c0354a.f5155i;
                                        G3.C c6 = G3.C.a;
                                        n5.c(c6);
                                        return c6;
                                    case k1.h.STRING_FIELD_NUMBER /* 5 */:
                                        C1154o c1154oF5 = overlayService.f();
                                        c1154oF5.f10480c.c(C1150k.a);
                                        return G3.C.a;
                                    case k1.h.STRING_SET_FIELD_NUMBER /* 6 */:
                                        C1154o c1154oF6 = overlayService.f();
                                        c1154oF6.f10480c.c(C1146g.a);
                                        return G3.C.a;
                                    case k1.h.DOUBLE_FIELD_NUMBER /* 7 */:
                                        C1154o c1154oF7 = overlayService.f();
                                        c1154oF7.f10480c.c(C1147h.a);
                                        return G3.C.a;
                                    case 8:
                                        OverlayService overlayService3 = overlayService;
                                        C1154o c1154oF8 = overlayService3.f();
                                        c1154oF8.f10480c.c(C1144e.a);
                                        overlayService3.g();
                                        return G3.C.a;
                                    default:
                                        C1154o c1154oF9 = overlayService.f();
                                        c1154oF9.f10480c.c(C1151l.a);
                                        return G3.C.a;
                                }
                            }
                        };
                        c0258p.a0(objG12);
                    }
                    T3.a aVar9 = (T3.a) objG12;
                    c0258p.p(false);
                    c0258p.Q(2064212122);
                    boolean zH11 = c0258p.h(overlayService);
                    Object objG13 = c0258p.G();
                    if (zH11 || objG13 == w5) {
                        final int i13 = 4;
                        objG13 = new T3.a() { // from class: i2.F
                            @Override // T3.a
                            public final Object b() {
                                Object objB;
                                switch (i13) {
                                    case ConfigBackupDto.$stable /* 0 */:
                                        C1154o c1154oF = overlayService.f();
                                        c1154oF.f10480c.c(C1145f.a);
                                        return G3.C.a;
                                    case 1:
                                        OverlayService overlayService2 = overlayService;
                                        C1154o c1154oF2 = overlayService2.f();
                                        c1154oF2.f10480c.c(C1148i.a);
                                        Intent launchIntentForPackage = overlayService2.getPackageManager().getLaunchIntentForPackage(overlayService2.getPackageName());
                                        if (launchIntentForPackage != null) {
                                            launchIntentForPackage.addFlags(268566528);
                                        }
                                        G3.C c5 = G3.C.a;
                                        if (launchIntentForPackage != null) {
                                            try {
                                                overlayService2.startActivity(launchIntentForPackage);
                                                objB = c5;
                                            } catch (Throwable th) {
                                                objB = AbstractC0164a.b(th);
                                            }
                                        } else {
                                            objB = null;
                                        }
                                        Throwable thA = G3.o.a(objB);
                                        if (thA != null) {
                                            P4.c cVar2 = P4.e.a;
                                            cVar2.j("Overlay");
                                            cVar2.h(thA, "bringAppToFront failed", new Object[0]);
                                        }
                                        return c5;
                                    case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                                        C1154o c1154oF3 = overlayService.f();
                                        c1154oF3.f10480c.c(C1149j.a);
                                        return G3.C.a;
                                    case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                                        C1154o c1154oF4 = overlayService.f();
                                        c1154oF4.f10480c.c(C1152m.a);
                                        return G3.C.a;
                                    case k1.h.LONG_FIELD_NUMBER /* 4 */:
                                        C0354a c0354a = overlayService.f8247s;
                                        if (c0354a == null) {
                                            U3.j.j("accessibilityBridge");
                                            throw null;
                                        }
                                        N n5 = c0354a.f5155i;
                                        G3.C c6 = G3.C.a;
                                        n5.c(c6);
                                        return c6;
                                    case k1.h.STRING_FIELD_NUMBER /* 5 */:
                                        C1154o c1154oF5 = overlayService.f();
                                        c1154oF5.f10480c.c(C1150k.a);
                                        return G3.C.a;
                                    case k1.h.STRING_SET_FIELD_NUMBER /* 6 */:
                                        C1154o c1154oF6 = overlayService.f();
                                        c1154oF6.f10480c.c(C1146g.a);
                                        return G3.C.a;
                                    case k1.h.DOUBLE_FIELD_NUMBER /* 7 */:
                                        C1154o c1154oF7 = overlayService.f();
                                        c1154oF7.f10480c.c(C1147h.a);
                                        return G3.C.a;
                                    case 8:
                                        OverlayService overlayService3 = overlayService;
                                        C1154o c1154oF8 = overlayService3.f();
                                        c1154oF8.f10480c.c(C1144e.a);
                                        overlayService3.g();
                                        return G3.C.a;
                                    default:
                                        C1154o c1154oF9 = overlayService.f();
                                        c1154oF9.f10480c.c(C1151l.a);
                                        return G3.C.a;
                                }
                            }
                        };
                        c0258p.a0(objG13);
                    }
                    T3.a aVar10 = (T3.a) objG13;
                    c0258p.p(false);
                    c0258p.Q(2064214849);
                    boolean zH12 = c0258p.h(overlayService);
                    Object objG14 = c0258p.G();
                    if (zH12 || objG14 == w5) {
                        final int i14 = 5;
                        objG14 = new T3.a() { // from class: i2.F
                            @Override // T3.a
                            public final Object b() {
                                Object objB;
                                switch (i14) {
                                    case ConfigBackupDto.$stable /* 0 */:
                                        C1154o c1154oF = overlayService.f();
                                        c1154oF.f10480c.c(C1145f.a);
                                        return G3.C.a;
                                    case 1:
                                        OverlayService overlayService2 = overlayService;
                                        C1154o c1154oF2 = overlayService2.f();
                                        c1154oF2.f10480c.c(C1148i.a);
                                        Intent launchIntentForPackage = overlayService2.getPackageManager().getLaunchIntentForPackage(overlayService2.getPackageName());
                                        if (launchIntentForPackage != null) {
                                            launchIntentForPackage.addFlags(268566528);
                                        }
                                        G3.C c5 = G3.C.a;
                                        if (launchIntentForPackage != null) {
                                            try {
                                                overlayService2.startActivity(launchIntentForPackage);
                                                objB = c5;
                                            } catch (Throwable th) {
                                                objB = AbstractC0164a.b(th);
                                            }
                                        } else {
                                            objB = null;
                                        }
                                        Throwable thA = G3.o.a(objB);
                                        if (thA != null) {
                                            P4.c cVar2 = P4.e.a;
                                            cVar2.j("Overlay");
                                            cVar2.h(thA, "bringAppToFront failed", new Object[0]);
                                        }
                                        return c5;
                                    case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                                        C1154o c1154oF3 = overlayService.f();
                                        c1154oF3.f10480c.c(C1149j.a);
                                        return G3.C.a;
                                    case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                                        C1154o c1154oF4 = overlayService.f();
                                        c1154oF4.f10480c.c(C1152m.a);
                                        return G3.C.a;
                                    case k1.h.LONG_FIELD_NUMBER /* 4 */:
                                        C0354a c0354a = overlayService.f8247s;
                                        if (c0354a == null) {
                                            U3.j.j("accessibilityBridge");
                                            throw null;
                                        }
                                        N n5 = c0354a.f5155i;
                                        G3.C c6 = G3.C.a;
                                        n5.c(c6);
                                        return c6;
                                    case k1.h.STRING_FIELD_NUMBER /* 5 */:
                                        C1154o c1154oF5 = overlayService.f();
                                        c1154oF5.f10480c.c(C1150k.a);
                                        return G3.C.a;
                                    case k1.h.STRING_SET_FIELD_NUMBER /* 6 */:
                                        C1154o c1154oF6 = overlayService.f();
                                        c1154oF6.f10480c.c(C1146g.a);
                                        return G3.C.a;
                                    case k1.h.DOUBLE_FIELD_NUMBER /* 7 */:
                                        C1154o c1154oF7 = overlayService.f();
                                        c1154oF7.f10480c.c(C1147h.a);
                                        return G3.C.a;
                                    case 8:
                                        OverlayService overlayService3 = overlayService;
                                        C1154o c1154oF8 = overlayService3.f();
                                        c1154oF8.f10480c.c(C1144e.a);
                                        overlayService3.g();
                                        return G3.C.a;
                                    default:
                                        C1154o c1154oF9 = overlayService.f();
                                        c1154oF9.f10480c.c(C1151l.a);
                                        return G3.C.a;
                                }
                            }
                        };
                        c0258p.a0(objG14);
                    }
                    c0258p.p(false);
                    l0.c.A(c1138l, zBooleanValue, zBooleanValue2, z3, zBooleanValue3, aVar, eVar, cVar, aVar2, aVar3, aVar4, aVar5, aVar6, aVar7, aVar8, aVar9, aVar10, (T3.a) objG14, c0258p, 196616, 0);
                }
                return G3.C.a;
            default:
                C0258p c0258p2 = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p2.x()) {
                    c0258p2.L();
                } else {
                    Y1.h.a(true, Q.f.b(1894254524, new C1134H(this.f10429m, this.f10430n, 0), c0258p2), c0258p2, 54);
                }
                return G3.C.a;
        }
    }
}

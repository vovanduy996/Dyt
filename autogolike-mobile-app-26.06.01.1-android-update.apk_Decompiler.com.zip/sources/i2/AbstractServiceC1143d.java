package i2;

import N1.C0354a;
import V1.K1;
import androidx.lifecycle.AbstractServiceC0579y;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import com.autogolike.mobile.core.overlay.OverlayService;
import com.autogolike.mobile.core.vision.ScreenCaptureService;
import dagger.hilt.android.internal.managers.ServiceComponentManager;
import dagger.hilt.internal.GeneratedComponentManager;
import dagger.hilt.internal.GeneratedComponentManagerHolder;
import dagger.hilt.internal.UnsafeCasts;
import p2.C1567l;
import p2.C1573r;
import p2.InterfaceC1577v;

/* JADX INFO: renamed from: i2.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractServiceC1143d extends AbstractServiceC0579y implements GeneratedComponentManagerHolder {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ int f10475m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public volatile ServiceComponentManager f10476n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final Object f10477o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f10478p;

    public AbstractServiceC1143d(int i5) {
        this.f10475m = i5;
        switch (i5) {
            case 1:
                this.f10477o = new Object();
                this.f10478p = false;
                break;
            default:
                this.f10477o = new Object();
                this.f10478p = false;
                break;
        }
    }

    public final ServiceComponentManager a() {
        switch (this.f10475m) {
            case ConfigBackupDto.$stable /* 0 */:
                if (this.f10476n == null) {
                    synchronized (this.f10477o) {
                        try {
                            if (this.f10476n == null) {
                                this.f10476n = new ServiceComponentManager(this);
                            }
                        } finally {
                        }
                        break;
                    }
                }
                return this.f10476n;
            default:
                if (this.f10476n == null) {
                    synchronized (this.f10477o) {
                        try {
                            if (this.f10476n == null) {
                                this.f10476n = new ServiceComponentManager(this);
                            }
                        } finally {
                        }
                        break;
                    }
                }
                return this.f10476n;
        }
    }

    @Override // dagger.hilt.internal.GeneratedComponentManagerHolder
    public final /* bridge */ /* synthetic */ GeneratedComponentManager componentManager() {
        switch (this.f10475m) {
        }
        return a();
    }

    @Override // dagger.hilt.internal.GeneratedComponentManager
    public final Object generatedComponent() {
        switch (this.f10475m) {
        }
        return a().generatedComponent();
    }

    @Override // androidx.lifecycle.AbstractServiceC0579y, android.app.Service
    public void onCreate() {
        switch (this.f10475m) {
            case ConfigBackupDto.$stable /* 0 */:
                if (!this.f10478p) {
                    this.f10478p = true;
                    InterfaceC1137K interfaceC1137K = (InterfaceC1137K) generatedComponent();
                    OverlayService overlayService = (OverlayService) UnsafeCasts.unsafeCast(this);
                    M1.q qVar = ((M1.o) interfaceC1137K).a;
                    overlayService.f8245q = (C1154o) qVar.f4735W.get();
                    overlayService.f8246r = (K1) qVar.f4744d.get();
                    overlayService.f8247s = (C0354a) qVar.f4771r.get();
                }
                super.onCreate();
                break;
            default:
                if (!this.f10478p) {
                    this.f10478p = true;
                    InterfaceC1577v interfaceC1577v = (InterfaceC1577v) generatedComponent();
                    ScreenCaptureService screenCaptureService = (ScreenCaptureService) UnsafeCasts.unsafeCast(this);
                    M1.q qVar2 = ((M1.o) interfaceC1577v).a;
                    screenCaptureService.f8268q = (C1567l) qVar2.f4779v.get();
                    screenCaptureService.f8269r = (C1573r) qVar2.f4717F0.get();
                }
                super.onCreate();
                break;
        }
    }
}

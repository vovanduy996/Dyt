package i2;

import I.C0234d;
import I.C0258p;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import m.B0;

/* JADX INFO: renamed from: i2.v, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C1161v implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f10530l = 0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ long f10531m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ String f10532n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ int f10533o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ Object f10534p;

    public /* synthetic */ C1161v(long j5, int i5, String str, String str2) {
        this.f10532n = str;
        this.f10534p = str2;
        this.f10531m = j5;
        this.f10533o = i5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        switch (this.f10530l) {
            case ConfigBackupDto.$stable /* 0 */:
                ((Integer) obj2).intValue();
                l0.c.L(this.f10532n, (String) this.f10534p, this.f10531m, (C0258p) obj, C0234d.U(this.f10533o | 1));
                break;
            default:
                ((Integer) obj2).intValue();
                B0.q((X1.h) this.f10534p, this.f10531m, this.f10532n, (C0258p) obj, C0234d.U(this.f10533o | 1));
                break;
        }
        return G3.C.a;
    }

    public /* synthetic */ C1161v(X1.h hVar, long j5, String str, int i5) {
        this.f10534p = hVar;
        this.f10531m = j5;
        this.f10532n = str;
        this.f10533o = i5;
    }
}

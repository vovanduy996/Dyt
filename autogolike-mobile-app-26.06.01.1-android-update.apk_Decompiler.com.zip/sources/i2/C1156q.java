package i2;

import I.C0234d;
import I.C0258p;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import java.io.Serializable;
import java.text.NumberFormat;
import m1.AbstractC1393s;
import z2.AbstractC2143i;

/* JADX INFO: renamed from: i2.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C1156q implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f10500l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ long f10501m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ Serializable f10502n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ int f10503o;

    public /* synthetic */ C1156q(long j5, Serializable serializable, int i5, int i6) {
        this.f10500l = i6;
        this.f10501m = j5;
        this.f10502n = serializable;
        this.f10503o = i5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        int i5 = this.f10500l;
        C0258p c0258p = (C0258p) obj;
        ((Integer) obj2).intValue();
        switch (i5) {
            case ConfigBackupDto.$stable /* 0 */:
                l0.c.N(C0234d.U(this.f10503o | 1), this.f10501m, c0258p, (String) this.f10502n);
                break;
            case 1:
                AbstractC2143i.g(C0234d.U(this.f10503o | 1), this.f10501m, c0258p, (String) this.f10502n);
                break;
            default:
                AbstractC1393s.N(this.f10501m, (NumberFormat) this.f10502n, c0258p, C0234d.U(this.f10503o | 1));
                break;
        }
        return G3.C.a;
    }

    public /* synthetic */ C1156q(long j5, String str, int i5) {
        this.f10500l = 0;
        this.f10502n = str;
        this.f10501m = j5;
        this.f10503o = i5;
    }
}

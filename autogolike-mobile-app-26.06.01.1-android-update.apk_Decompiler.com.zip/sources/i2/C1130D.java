package i2;

import G3.AbstractC0164a;
import android.view.WindowManager;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import com.autogolike.mobile.core.overlay.OverlayService;
import i4.c0;
import u0.C1862e0;

/* JADX INFO: renamed from: i2.D, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C1130D implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f10421l = 0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ OverlayService f10422m;

    public /* synthetic */ C1130D(OverlayService overlayService) {
        this.f10422m = overlayService;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        switch (this.f10421l) {
            case ConfigBackupDto.$stable /* 0 */:
                Integer num = (Integer) obj;
                num.getClass();
                ((Integer) obj2).getClass();
                c0 c0Var = this.f10422m.f8254z;
                c0Var.getClass();
                c0Var.m(null, num);
                break;
            default:
                float fFloatValue = ((Float) obj).floatValue();
                float fFloatValue2 = ((Float) obj2).floatValue();
                OverlayService overlayService = this.f10422m;
                WindowManager.LayoutParams layoutParams = overlayService.f8252x;
                if (layoutParams != null) {
                    layoutParams.x = W3.a.O(fFloatValue) + layoutParams.x;
                    layoutParams.y = W3.a.O(fFloatValue2) + layoutParams.y;
                    Integer numValueOf = Integer.valueOf(layoutParams.x);
                    c0 c0Var2 = overlayService.f8254z;
                    c0Var2.getClass();
                    c0Var2.m(null, numValueOf);
                    try {
                        WindowManager windowManager = overlayService.f8250v;
                        if (windowManager != null) {
                            windowManager.updateViewLayout(overlayService.f8251w, layoutParams);
                        }
                    } catch (Throwable th) {
                        AbstractC0164a.b(th);
                    }
                }
                break;
        }
        return G3.C.a;
    }

    public /* synthetic */ C1130D(OverlayService overlayService, C1862e0 c1862e0) {
        this.f10422m = overlayService;
    }
}

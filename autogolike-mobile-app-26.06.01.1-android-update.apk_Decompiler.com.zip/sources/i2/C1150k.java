package i2;

/* JADX INFO: renamed from: i2.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1150k implements InterfaceC1153n {
    public static final C1150k a = new C1150k();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof C1150k);
    }

    public final int hashCode() {
        return 1925442451;
    }

    public final String toString() {
        return "ReportAnomaly";
    }
}

package i2;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import com.autogolike.mobile.core.overlay.OverlayService;

/* JADX INFO: renamed from: i2.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1141b {
    public final Context a;

    public C1141b(Context context) {
        U3.j.f(context, "ctx");
        this.a = context;
    }

    public final void a() {
        OverlayService.Companion.getClass();
        Context context = this.a;
        U3.j.f(context, "ctx");
        Intent intent = new Intent(context, (Class<?>) OverlayService.class);
        if (Build.VERSION.SDK_INT >= 26) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
    }

    public final void b() {
        OverlayService.Companion.getClass();
        Context context = this.a;
        U3.j.f(context, "ctx");
        Intent intent = new Intent(context, (Class<?>) OverlayService.class);
        intent.setAction("com.autogolike.overlay.STOP");
        context.startService(intent);
    }
}

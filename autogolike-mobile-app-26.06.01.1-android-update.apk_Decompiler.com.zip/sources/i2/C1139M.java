package i2;

import b0.C0603v;
import com.google.android.gms.internal.measurement.AbstractC0813y0;

/* JADX INFO: renamed from: i2.M, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1139M {
    public final String a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C0603v f10457b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final C0603v f10458c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Boolean f10459d;

    public C1139M(String str, C0603v c0603v, C0603v c0603v2, Boolean bool) {
        this.a = str;
        this.f10457b = c0603v;
        this.f10458c = c0603v2;
        this.f10459d = bool;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C1139M)) {
            return false;
        }
        C1139M c1139m = (C1139M) obj;
        return this.a.equals(c1139m.a) && this.f10457b.equals(c1139m.f10457b) && this.f10458c.equals(c1139m.f10458c) && this.f10459d.equals(c1139m.f10459d);
    }

    public final int hashCode() {
        return this.f10459d.hashCode() + AbstractC0813y0.e(AbstractC0813y0.e(this.a.hashCode() * 31, 31, this.f10457b.a), 31, this.f10458c.a);
    }

    public final String toString() {
        return "Quad(a=" + ((Object) this.a) + ", b=" + this.f10457b + ", c=" + this.f10458c + ", d=" + this.f10459d + ")";
    }
}

package i2;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: i2.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC1140a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final EnumC1140a f10460l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final EnumC1140a f10461m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final EnumC1140a f10462n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final EnumC1140a f10463o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final EnumC1140a f10464p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final /* synthetic */ EnumC1140a[] f10465q;

    static {
        EnumC1140a enumC1140a = new EnumC1140a("Hidden", 0);
        f10460l = enumC1140a;
        EnumC1140a enumC1140a2 = new EnumC1140a("Idle", 1);
        f10461m = enumC1140a2;
        EnumC1140a enumC1140a3 = new EnumC1140a("Sending", 2);
        f10462n = enumC1140a3;
        EnumC1140a enumC1140a4 = new EnumC1140a("Sent", 3);
        f10463o = enumC1140a4;
        EnumC1140a enumC1140a5 = new EnumC1140a("Failed", 4);
        f10464p = enumC1140a5;
        f10465q = new EnumC1140a[]{enumC1140a, enumC1140a2, enumC1140a3, enumC1140a4, enumC1140a5};
    }

    public static EnumC1140a valueOf(String str) {
        return (EnumC1140a) Enum.valueOf(EnumC1140a.class, str);
    }

    public static EnumC1140a[] values() {
        return (EnumC1140a[]) f10465q.clone();
    }
}

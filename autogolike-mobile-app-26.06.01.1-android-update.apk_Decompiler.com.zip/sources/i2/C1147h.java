package i2;

/* JADX INFO: renamed from: i2.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1147h implements InterfaceC1153n {
    public static final C1147h a = new C1147h();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof C1147h);
    }

    public final int hashCode() {
        return 274040999;
    }

    public final String toString() {
        return "MarkFail";
    }
}

package i2;

/* JADX INFO: renamed from: i2.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1151l implements InterfaceC1153n {
    public static final C1151l a = new C1151l();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof C1151l);
    }

    public final int hashCode() {
        return -1119013787;
    }

    public final String toString() {
        return "TestLike";
    }
}

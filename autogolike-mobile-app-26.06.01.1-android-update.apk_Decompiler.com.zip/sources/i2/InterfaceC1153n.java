package i2;

/* JADX INFO: renamed from: i2.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC1153n {
}

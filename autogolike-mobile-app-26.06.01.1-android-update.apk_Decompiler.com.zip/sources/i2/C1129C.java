package i2;

import G3.AbstractC0164a;
import I.InterfaceC0233c0;
import f4.AbstractC0952A;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: i2.C, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1129C extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f10417p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ boolean f10418q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ String f10419r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0233c0 f10420s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1129C(boolean z3, String str, InterfaceC0233c0 interfaceC0233c0, Continuation continuation) {
        super(2, continuation);
        this.f10418q = z3;
        this.f10419r = str;
        this.f10420s = interfaceC0233c0;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C1129C) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new C1129C(this.f10418q, this.f10419r, this.f10420s, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        String str;
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f10417p;
        InterfaceC0233c0 interfaceC0233c0 = this.f10420s;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            if (!this.f10418q || (str = this.f10419r) == null || c4.l.u0(str)) {
                interfaceC0233c0.setValue(Boolean.FALSE);
                return G3.C.a;
            }
            interfaceC0233c0.setValue(Boolean.TRUE);
            this.f10417p = 1;
            if (AbstractC0952A.g(3000L, this) == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        interfaceC0233c0.setValue(Boolean.FALSE);
        return G3.C.a;
    }
}

package i2;

import G3.AbstractC0164a;
import V1.K1;
import com.autogolike.mobile.core.overlay.OverlayService;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: i2.I, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1135I extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f10431p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ OverlayService f10432q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1135I(OverlayService overlayService, Continuation continuation) {
        super(2, continuation);
        this.f10432q = overlayService;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C1135I) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new C1135I(this.f10432q, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f10431p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            OverlayService overlayService = this.f10432q;
            K1 k12 = overlayService.f8246r;
            if (k12 == null) {
                U3.j.j("prefs");
                throw null;
            }
            F2.k kVar = new F2.k(6, overlayService);
            this.f10431p = 1;
            if (k12.f6336R.d(kVar, this) == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return G3.C.a;
    }
}

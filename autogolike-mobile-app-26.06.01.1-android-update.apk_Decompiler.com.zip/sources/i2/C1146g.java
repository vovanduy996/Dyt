package i2;

/* JADX INFO: renamed from: i2.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1146g implements InterfaceC1153n {
    public static final C1146g a = new C1146g();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof C1146g);
    }

    public final int hashCode() {
        return 273995019;
    }

    public final String toString() {
        return "MarkDone";
    }
}

package i2;

/* JADX INFO: renamed from: i2.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1152m implements InterfaceC1153n {
    public static final C1152m a = new C1152m();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof C1152m);
    }

    public final int hashCode() {
        return 294572351;
    }

    public final String toString() {
        return "ToggleAuto";
    }
}

package i2;

import A.e0;
import A.g0;
import G3.AbstractC0164a;
import kotlin.coroutines.Continuation;
import m1.AbstractC1388n;
import n0.C1434C;
import o.C1473A;
import o.C1484e;
import o.C1525z;

/* JADX INFO: renamed from: i2.B, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1128B extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f10414p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f10415q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ T3.e f10416r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1128B(T3.e eVar, Continuation continuation) {
        super(2, continuation);
        this.f10416r = eVar;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C1128B) m((C1434C) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C1128B c1128b = new C1128B(this.f10416r, continuation);
        c1128b.f10415q = obj;
        return c1128b;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f10414p;
        G3.C c5 = G3.C.a;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            C1434C c1434c = (C1434C) this.f10415q;
            C1127A c1127a = new C1127A(this.f10416r, 0);
            this.f10414p = 1;
            float f5 = o.D.a;
            C1484e c1484e = C1484e.f12269n;
            C1525z c1525z = C1525z.f12396m;
            C1525z c1525z2 = C1525z.f12397n;
            Object objV = AbstractC1388n.v(c1434c, new C1473A(C1525z.f12398o, new U3.t(), null, new g0(2, c1484e), c1127a, c1525z2, new e0(c1525z, 1), null), this);
            if (objV != aVar) {
                objV = c5;
            }
            if (objV != aVar) {
                objV = c5;
            }
            if (objV == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return c5;
    }
}

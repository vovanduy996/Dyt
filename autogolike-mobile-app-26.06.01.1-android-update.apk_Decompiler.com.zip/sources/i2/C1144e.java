package i2;

/* JADX INFO: renamed from: i2.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1144e implements InterfaceC1153n {
    public static final C1144e a = new C1144e();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof C1144e);
    }

    public final int hashCode() {
        return -160567716;
    }

    public final String toString() {
        return "Close";
    }
}

package i2;

import com.google.android.gms.internal.measurement.AbstractC0813y0;
import java.util.List;
import l.AbstractC1297i;
import w1.AbstractC1987H;

/* JADX INFO: renamed from: i2.L, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1138L {
    public final X1.o a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f10435b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Long f10436c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f10437d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f10438e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f10439f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f10440g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f10441h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final String f10442i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final boolean f10443j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final String f10444k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final boolean f10445l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final List f10446m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final boolean f10447n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final EnumC1140a f10448o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final boolean f10449p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final int f10450q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final int f10451r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final int f10452s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final boolean f10453t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final String f10454u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final boolean f10455v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final boolean f10456w;

    public C1138L(X1.o oVar, String str, Long l4, String str2, int i5, int i6, int i7, int i8, String str3, boolean z3, String str4, boolean z5, List list, boolean z6, EnumC1140a enumC1140a, boolean z7, int i9, int i10, int i11, boolean z8, String str5, boolean z9, boolean z10) {
        U3.j.f(oVar, "platform");
        U3.j.f(str3, "status");
        U3.j.f(list, "candidates");
        U3.j.f(enumC1140a, "anomalyState");
        U3.j.f(str5, "accountSwitchStatus");
        this.a = oVar;
        this.f10435b = str;
        this.f10436c = l4;
        this.f10437d = str2;
        this.f10438e = i5;
        this.f10439f = i6;
        this.f10440g = i7;
        this.f10441h = i8;
        this.f10442i = str3;
        this.f10443j = z3;
        this.f10444k = str4;
        this.f10445l = z5;
        this.f10446m = list;
        this.f10447n = z6;
        this.f10448o = enumC1140a;
        this.f10449p = z7;
        this.f10450q = i9;
        this.f10451r = i10;
        this.f10452s = i11;
        this.f10453t = z8;
        this.f10454u = str5;
        this.f10455v = z9;
        this.f10456w = z10;
    }

    public static C1138L a(C1138L c1138l, X1.o oVar, String str, Long l4, String str2, int i5, int i6, int i7, int i8, String str3, boolean z3, String str4, boolean z5, List list, boolean z6, EnumC1140a enumC1140a, boolean z7, int i9, int i10, int i11, boolean z8, String str5, boolean z9, boolean z10, int i12) {
        X1.o oVar2 = (i12 & 1) != 0 ? c1138l.a : oVar;
        String str6 = (i12 & 2) != 0 ? c1138l.f10435b : str;
        Long l5 = (i12 & 4) != 0 ? c1138l.f10436c : l4;
        String str7 = (i12 & 8) != 0 ? c1138l.f10437d : str2;
        int i13 = (i12 & 16) != 0 ? c1138l.f10438e : i5;
        int i14 = (i12 & 32) != 0 ? c1138l.f10439f : i6;
        int i15 = (i12 & 64) != 0 ? c1138l.f10440g : i7;
        int i16 = (i12 & 128) != 0 ? c1138l.f10441h : i8;
        String str8 = (i12 & 256) != 0 ? c1138l.f10442i : str3;
        boolean z11 = (i12 & 512) != 0 ? c1138l.f10443j : z3;
        String str9 = (i12 & 1024) != 0 ? c1138l.f10444k : str4;
        boolean z12 = (i12 & 2048) != 0 ? c1138l.f10445l : z5;
        List list2 = (i12 & 4096) != 0 ? c1138l.f10446m : list;
        boolean z13 = (i12 & 8192) != 0 ? c1138l.f10447n : z6;
        EnumC1140a enumC1140a2 = (i12 & 16384) != 0 ? c1138l.f10448o : enumC1140a;
        boolean z14 = z12;
        boolean z15 = (i12 & 32768) != 0 ? c1138l.f10449p : z7;
        int i17 = (i12 & 65536) != 0 ? c1138l.f10450q : i9;
        int i18 = (i12 & 131072) != 0 ? c1138l.f10451r : i10;
        int i19 = (i12 & 262144) != 0 ? c1138l.f10452s : i11;
        boolean z16 = (i12 & 524288) != 0 ? c1138l.f10453t : z8;
        String str10 = (i12 & 1048576) != 0 ? c1138l.f10454u : str5;
        String str11 = str9;
        boolean z17 = (i12 & 2097152) != 0 ? c1138l.f10455v : z9;
        boolean z18 = (i12 & 4194304) != 0 ? c1138l.f10456w : z10;
        c1138l.getClass();
        U3.j.f(oVar2, "platform");
        U3.j.f(str8, "status");
        U3.j.f(list2, "candidates");
        U3.j.f(enumC1140a2, "anomalyState");
        U3.j.f(str10, "accountSwitchStatus");
        return new C1138L(oVar2, str6, l5, str7, i13, i14, i15, i16, str8, z11, str11, z14, list2, z13, enumC1140a2, z15, i17, i18, i19, z16, str10, z17, z18);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C1138L)) {
            return false;
        }
        C1138L c1138l = (C1138L) obj;
        return this.a == c1138l.a && U3.j.a(this.f10435b, c1138l.f10435b) && U3.j.a(this.f10436c, c1138l.f10436c) && U3.j.a(this.f10437d, c1138l.f10437d) && this.f10438e == c1138l.f10438e && this.f10439f == c1138l.f10439f && this.f10440g == c1138l.f10440g && this.f10441h == c1138l.f10441h && U3.j.a(this.f10442i, c1138l.f10442i) && this.f10443j == c1138l.f10443j && U3.j.a(this.f10444k, c1138l.f10444k) && this.f10445l == c1138l.f10445l && U3.j.a(this.f10446m, c1138l.f10446m) && this.f10447n == c1138l.f10447n && this.f10448o == c1138l.f10448o && this.f10449p == c1138l.f10449p && this.f10450q == c1138l.f10450q && this.f10451r == c1138l.f10451r && this.f10452s == c1138l.f10452s && this.f10453t == c1138l.f10453t && U3.j.a(this.f10454u, c1138l.f10454u) && this.f10455v == c1138l.f10455v && this.f10456w == c1138l.f10456w;
    }

    public final int hashCode() {
        int iHashCode = this.a.hashCode() * 31;
        String str = this.f10435b;
        int iHashCode2 = (iHashCode + (str == null ? 0 : str.hashCode())) * 31;
        Long l4 = this.f10436c;
        int iHashCode3 = (iHashCode2 + (l4 == null ? 0 : l4.hashCode())) * 31;
        String str2 = this.f10437d;
        int iF = AbstractC0813y0.f(AbstractC1987H.b(AbstractC1297i.b(this.f10441h, AbstractC1297i.b(this.f10440g, AbstractC1297i.b(this.f10439f, AbstractC1297i.b(this.f10438e, (iHashCode3 + (str2 == null ? 0 : str2.hashCode())) * 31, 31), 31), 31), 31), 31, this.f10442i), 31, this.f10443j);
        String str3 = this.f10444k;
        return Boolean.hashCode(this.f10456w) + AbstractC0813y0.f(AbstractC1987H.b(AbstractC0813y0.f(AbstractC1297i.b(this.f10452s, AbstractC1297i.b(this.f10451r, AbstractC1297i.b(this.f10450q, AbstractC0813y0.f((this.f10448o.hashCode() + AbstractC0813y0.f(AbstractC0813y0.g(this.f10446m, AbstractC0813y0.f((iF + (str3 != null ? str3.hashCode() : 0)) * 31, 31, this.f10445l), 31), 31, this.f10447n)) * 31, 31, this.f10449p), 31), 31), 31), 31, this.f10453t), 31, this.f10454u), 31, this.f10455v);
    }

    public final String toString() {
        return "OverlaySnapshot(platform=" + this.a + ", accountLabel=" + this.f10435b + ", jobId=" + this.f10436c + ", jobType=" + this.f10437d + ", coin=" + this.f10438e + ", totalDone=" + this.f10439f + ", totalFail=" + this.f10440g + ", totalCoin=" + this.f10441h + ", status=" + this.f10442i + ", isWorking=" + this.f10443j + ", launchedUrl=" + this.f10444k + ", isAutoMode=" + this.f10445l + ", candidates=" + this.f10446m + ", canManualMarkDone=" + this.f10447n + ", anomalyState=" + this.f10448o + ", isWarmupMode=" + this.f10449p + ", warmupRemainingSec=" + this.f10450q + ", warmupLikeCount=" + this.f10451r + ", warmupSwipeCount=" + this.f10452s + ", isAccountSwitchMode=" + this.f10453t + ", accountSwitchStatus=" + this.f10454u + ", accountSwitchDone=" + this.f10455v + ", accountSwitchSuccess=" + this.f10456w + ")";
    }

    public /* synthetic */ C1138L() {
        this(X1.o.f6994o, null, null, null, 0, 0, 0, 0, "Đang chờ…", false, null, false, H3.w.f3464l, false, EnumC1140a.f10460l, false, 0, 0, 0, false, "", false, false);
    }
}

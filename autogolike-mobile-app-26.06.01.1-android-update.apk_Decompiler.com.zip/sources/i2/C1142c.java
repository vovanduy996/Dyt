package i2;

import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.FrameLayout;
import androidx.lifecycle.AbstractServiceC0579y;

/* JADX INFO: renamed from: i2.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1142c extends FrameLayout {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final WindowManager f10466l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final WindowManager.LayoutParams f10467m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final T3.e f10468n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final int f10469o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public float f10470p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public float f10471q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f10472r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f10473s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f10474t;

    public C1142c(AbstractServiceC0579y abstractServiceC0579y, WindowManager windowManager, WindowManager.LayoutParams layoutParams, T3.e eVar) {
        super(abstractServiceC0579y);
        this.f10466l = windowManager;
        this.f10467m = layoutParams;
        this.f10468n = eVar;
        this.f10469o = ViewConfiguration.get(abstractServiceC0579y).getScaledTouchSlop();
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        U3.j.f(motionEvent, "ev");
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f10470p = motionEvent.getRawX();
            this.f10471q = motionEvent.getRawY();
            WindowManager.LayoutParams layoutParams = this.f10467m;
            this.f10472r = layoutParams.x;
            this.f10473s = layoutParams.y;
            this.f10474t = false;
        } else if (actionMasked == 2 && !this.f10474t) {
            float rawX = motionEvent.getRawX() - this.f10470p;
            float rawY = motionEvent.getRawY() - this.f10471q;
            float fAbs = Math.abs(rawX);
            float f5 = this.f10469o;
            if (fAbs > f5 || Math.abs(rawY) > f5) {
                this.f10474t = true;
                return true;
            }
        }
        return false;
    }

    /* JADX WARN: Code restructure failed: missing block: B:7:0x0011, code lost:
    
        if (r0 != 3) goto L8;
     */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean onTouchEvent(android.view.MotionEvent r5) {
        /*
            r4 = this;
            java.lang.String r0 = "ev"
            U3.j.f(r5, r0)
            int r0 = r5.getActionMasked()
            r1 = 1
            r2 = 0
            if (r0 == r1) goto L5b
            r3 = 2
            if (r0 == r3) goto L15
            r5 = 3
            if (r0 == r5) goto L5b
        L13:
            r1 = r2
            goto L5f
        L15:
            boolean r0 = r4.f10474t
            if (r0 == 0) goto L13
            int r0 = r4.f10472r
            float r2 = r5.getRawX()
            float r3 = r4.f10470p
            float r2 = r2 - r3
            int r2 = W3.a.O(r2)
            int r2 = r2 + r0
            int r0 = r4.f10473s
            float r5 = r5.getRawY()
            float r3 = r4.f10471q
            float r5 = r5 - r3
            int r5 = W3.a.O(r5)
            int r5 = r5 + r0
            android.view.WindowManager$LayoutParams r0 = r4.f10467m
            int r3 = r0.x
            if (r3 != r2) goto L3f
            int r3 = r0.y
            if (r3 == r5) goto L5f
        L3f:
            r0.x = r2
            r0.y = r5
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)
            T3.e r3 = r4.f10468n
            r3.i(r2, r5)
            android.view.WindowManager r5 = r4.f10466l     // Catch: java.lang.Throwable -> L56
            r5.updateViewLayout(r4, r0)     // Catch: java.lang.Throwable -> L56
            goto L5f
        L56:
            r5 = move-exception
            G3.AbstractC0164a.b(r5)
            goto L5f
        L5b:
            boolean r1 = r4.f10474t
            r4.f10474t = r2
        L5f:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: i2.C1142c.onTouchEvent(android.view.MotionEvent):boolean");
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z3) {
    }
}

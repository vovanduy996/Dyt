package I2;

import N1.C0379o;
import N1.InterfaceC0384u;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import i2.C1144e;
import i2.InterfaceC1153n;
import i4.InterfaceC1184h;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: I2.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0301m implements InterfaceC1184h {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f4176l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ C0313z f4177m;

    public /* synthetic */ C0301m(C0313z c0313z, int i5) {
        this.f4176l = i5;
        this.f4177m = c0313z;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r24v0 */
    /* JADX WARN: Type inference failed for: r24v1 */
    /* JADX WARN: Type inference failed for: r24v2 */
    /* JADX WARN: Type inference failed for: r3v13 */
    /* JADX WARN: Type inference failed for: r3v14 */
    /* JADX WARN: Type inference failed for: r3v4 */
    /* JADX WARN: Type inference failed for: r3v5, types: [int] */
    /* JADX WARN: Type inference failed for: r3v6 */
    /* JADX WARN: Type inference failed for: r3v7, types: [int] */
    @Override // i4.InterfaceC1184h
    public final Object k(Object obj, Continuation continuation) {
        switch (this.f4176l) {
            case ConfigBackupDto.$stable /* 0 */:
                InterfaceC0384u interfaceC0384u = (InterfaceC0384u) obj;
                if (interfaceC0384u instanceof C0379o) {
                    String str = ((C0379o) interfaceC0384u).a;
                    boolean z3 = true;
                    boolean zK0 = c4.l.k0(str, "thả tim", true);
                    boolean zK02 = c4.l.k0(str, "lướt", true);
                    String str2 = "Đang xem bình luận";
                    boolean z5 = false;
                    boolean zH0 = c4.s.h0(str, "Đang xem bình luận", false);
                    String str3 = "Đang xem ";
                    ?? r24 = !zH0 && c4.s.h0(str, "Đang xem ", false);
                    boolean zK03 = c4.l.k0(str, "đã sao chép liên kết", true);
                    boolean zEquals = str.equals("Đã đăng bình luận");
                    boolean zEquals2 = str.equals("Đã trả lời bình luận");
                    i4.c0 c0Var = this.f4177m.f4280l;
                    while (true) {
                        Object value = c0Var.getValue();
                        C0300l c0300l = (C0300l) value;
                        String str4 = c0300l.f4167m;
                        if (str4 == null) {
                            str4 = "";
                        }
                        boolean zH02 = c4.s.h0(str4, str2, z5);
                        boolean z6 = (zH02 || !c4.s.h0(str4, str3, z5)) ? z5 : z3;
                        i4.c0 c0Var2 = c0Var;
                        String str5 = str3;
                        boolean z7 = z5;
                        String str6 = str2;
                        boolean z8 = z3;
                        if (!c0Var2.j(value, C0300l.a(c0300l, 0L, 0, false, c0300l.f4160f + ((!r24 == true || z6) ? z5 : z3), c0300l.f4161g + (zK0 ? 1 : 0), c0300l.f4162h + (zK02 ? 1 : 0), c0300l.f4163i + ((!zH0 || zH02) ? z5 : z3), c0300l.f4164j + (zK03 ? 1 : 0), c0300l.f4165k + (zEquals ? 1 : 0), c0300l.f4166l + (zEquals2 ? 1 : 0), str, null, null, 0, false, null, 516127))) {
                            c0Var = c0Var2;
                            str3 = str5;
                            z5 = z7;
                            str2 = str6;
                            z3 = z8;
                        }
                    }
                }
                break;
            case 1:
                C0313z c0313z = this.f4177m;
                c0313z.f4274f.a(new A2.h((C0300l) obj, 4, c0313z));
                break;
            default:
                if (U3.j.a((InterfaceC1153n) obj, C1144e.a)) {
                    this.f4177m.e();
                }
                break;
        }
        return G3.C.a;
    }
}

package I2;

import F.A1;
import F.E0;
import F.H1;
import I.C0234d;
import I.C0258p;
import I.InterfaceC0233c0;
import I.InterfaceC0255n0;
import I.Z0;
import com.google.android.gms.internal.measurement.AbstractC0813y0;
import q.AbstractC1587c;
import q.AbstractC1594j;
import q.C1586b;
import q.C1591g;
import q.C1603t;
import t0.C1802i;
import t0.C1803j;
import t0.C1804k;
import t0.InterfaceC1805l;

/* JADX INFO: loaded from: classes.dex */
public final class c0 implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ boolean f4067l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ T3.c f4068m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ Y1.b f4069n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ int f4070o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ int f4071p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ int f4072q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ int f4073r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0233c0 f4074s;

    public c0(boolean z3, T3.c cVar, Y1.b bVar, int i5, int i6, int i7, int i8, InterfaceC0233c0 interfaceC0233c0) {
        this.f4067l = z3;
        this.f4068m = cVar;
        this.f4069n = bVar;
        this.f4070o = i5;
        this.f4071p = i6;
        this.f4072q = i7;
        this.f4073r = i8;
        this.f4074s = interfaceC0233c0;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        C0258p c0258p = (C0258p) obj;
        if ((((Number) obj2).intValue() & 3) == 2 && c0258p.x()) {
            c0258p.L();
        } else {
            C1586b c1586b = AbstractC1594j.a;
            c0258p.Q(-633634936);
            Y1.e eVar = (Y1.e) c0258p.k(Y1.k.a);
            c0258p.p(false);
            C1591g c1591gG = AbstractC1594j.g(eVar.f7107c);
            U.n nVar = U.n.a;
            U.g gVar = U.b.f6119x;
            C1603t c1603tA = q.r.a(c1591gG, gVar, c0258p, 0);
            int i5 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            U.q qVarD = U.a.d(c0258p, nVar);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C1802i c1802i = C1804k.f13645f;
            C0234d.R(c0258p, c1802i, c1603tA);
            C1802i c1802i2 = C1804k.f13644e;
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M);
            C1802i c1802i3 = C1804k.f13646g;
            if (c0258p.f3668O || !U3.j.a(c0258p.G(), Integer.valueOf(i5))) {
                AbstractC0813y0.r(i5, c0258p, i5, c1802i3);
            }
            C1802i c1802i4 = C1804k.f13643d;
            C0234d.R(c0258p, c1802i4, qVarD);
            q.b0 b0VarB = q.a0.b(AbstractC1594j.a, U.b.f6117v, c0258p, 48);
            int i6 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M2 = c0258p.m();
            U.q qVarD2 = U.a.d(c0258p, nVar);
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, c1802i, b0VarB);
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M2);
            if (c0258p.f3668O || !U3.j.a(c0258p.G(), Integer.valueOf(i6))) {
                AbstractC0813y0.r(i6, c0258p, i6, c1802i3);
            }
            C0234d.R(c0258p, c1802i4, qVarD2);
            U.q qVarA = q.c0.a(1.0f);
            C1603t c1603tA2 = q.r.a(AbstractC1594j.f12606c, gVar, c0258p, 0);
            int i7 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M3 = c0258p.m();
            U.q qVarD3 = U.a.d(c0258p, qVarA);
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, c1802i, c1603tA2);
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M3);
            if (c0258p.f3668O || !U3.j.a(c0258p.G(), Integer.valueOf(i7))) {
                AbstractC0813y0.r(i7, c0258p, i7, c1802i3);
            }
            C0234d.R(c0258p, c1802i4, qVarD3);
            Y1.b bVar = this.f4069n;
            long j5 = bVar.f7049h;
            c0258p.Q(258792282);
            Z0 z02 = Y1.l.f7129c;
            Y1.f fVar = (Y1.f) c0258p.k(z02);
            c0258p.p(false);
            H1.b("Xem bình luận", null, j5, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar.f7117f, c0258p, 6, 0, 65530);
            c0258p.Q(258792282);
            Y1.f fVar2 = (Y1.f) c0258p.k(z02);
            c0258p.p(false);
            H1.b("Cứ vài video lại mở phần bình luận đọc thử rồi đóng.", null, bVar.f7052k, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar2.f7118g, c0258p, 6, 0, 65530);
            c0258p.p(true);
            A1 a1G = E0.g(bVar.f7055n, bVar.f7053l, bVar.f7052k, bVar.f7045d, c0258p);
            boolean z3 = this.f4067l;
            androidx.compose.material3.a.a(z3, this.f4068m, null, null, false, a1G, null, c0258p, 0);
            c0258p.p(true);
            c0258p.Q(599674490);
            if (z3) {
                AbstractC1587c.a(c0258p, androidx.compose.foundation.layout.c.d(nVar, 2));
                E4.l.t(Q.f.b(1313057589, new Y(bVar, this.f4070o, this.f4071p, this.f4072q, this.f4073r, this.f4074s), c0258p), c0258p, 6);
            }
            c0258p.p(false);
            c0258p.p(true);
        }
        return G3.C.a;
    }
}

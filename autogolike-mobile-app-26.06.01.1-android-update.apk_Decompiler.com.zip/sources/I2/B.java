package I2;

import com.autogolike.mobile.core.backup.ConfigBackupDto;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class B implements T3.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f3899l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ boolean f3900m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ T3.a f3901n;

    public /* synthetic */ B(int i5, T3.a aVar, boolean z3) {
        this.f3899l = i5;
        this.f3900m = z3;
        this.f3901n = aVar;
    }

    @Override // T3.a
    public final Object b() {
        switch (this.f3899l) {
            case ConfigBackupDto.$stable /* 0 */:
                if (this.f3900m) {
                    this.f3901n.b();
                }
                break;
            case 1:
                if (this.f3900m) {
                    this.f3901n.b();
                }
                break;
            case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                if (this.f3900m) {
                    this.f3901n.b();
                }
                break;
            case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                if (this.f3900m) {
                    this.f3901n.b();
                }
                break;
            default:
                if (!this.f3900m) {
                    this.f3901n.b();
                }
                break;
        }
        return G3.C.a;
    }
}

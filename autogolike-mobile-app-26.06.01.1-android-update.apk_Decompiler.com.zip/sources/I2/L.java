package I2;

import I.C0234d;
import I.C0258p;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import m1.AbstractC1383i;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class L implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f3982l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Q.a f3983m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ int f3984n;

    public /* synthetic */ L(Q.a aVar, int i5, int i6) {
        this.f3982l = i6;
        this.f3983m = aVar;
        this.f3984n = i5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        int i5 = this.f3982l;
        C0258p c0258p = (C0258p) obj;
        ((Integer) obj2).getClass();
        switch (i5) {
            case ConfigBackupDto.$stable /* 0 */:
                E4.l.t(this.f3983m, c0258p, C0234d.U(this.f3984n | 1));
                break;
            case 1:
                l0.c.a(this.f3983m, c0258p, C0234d.U(this.f3984n | 1));
                break;
            default:
                AbstractC1383i.A(this.f3983m, c0258p, C0234d.U(this.f3984n | 1));
                break;
        }
        return G3.C.a;
    }
}

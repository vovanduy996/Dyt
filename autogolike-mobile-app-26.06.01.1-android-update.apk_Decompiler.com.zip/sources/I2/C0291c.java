package I2;

import F.H1;
import I.C0258p;
import com.autogolike.mobile.core.backup.ConfigBackupDto;

/* JADX INFO: renamed from: I2.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0291c implements T3.f {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final C0291c f4064m = new C0291c(0);

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final C0291c f4065n = new C0291c(1);

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f4066l;

    public /* synthetic */ C0291c(int i5) {
        this.f4066l = i5;
    }

    @Override // T3.f
    public final Object h(Object obj, Object obj2, Object obj3) {
        switch (this.f4066l) {
            case ConfigBackupDto.$stable /* 0 */:
                C0258p c0258p = (C0258p) obj2;
                int iIntValue = ((Number) obj3).intValue();
                U3.j.f((q.c0) obj, "$this$TextButton");
                if ((iIntValue & 17) == 16 && c0258p.x()) {
                    c0258p.L();
                } else {
                    H1.b("OK", null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, 6, 0, 131070);
                }
                break;
            default:
                C0258p c0258p2 = (C0258p) obj2;
                int iIntValue2 = ((Number) obj3).intValue();
                U3.j.f((q.c0) obj, "$this$TextButton");
                if ((iIntValue2 & 17) == 16 && c0258p2.x()) {
                    c0258p2.L();
                } else {
                    H1.b("Hủy", null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p2, 6, 0, 131070);
                }
                break;
        }
        return G3.C.a;
    }
}

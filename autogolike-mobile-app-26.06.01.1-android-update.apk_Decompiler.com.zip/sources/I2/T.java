package I2;

import F.AbstractC0121o0;
import F.H1;
import I.C0234d;
import I.C0258p;
import I.InterfaceC0255n0;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import com.google.android.gms.internal.measurement.AbstractC0813y0;
import q.AbstractC1594j;
import q.C1591g;
import q.C1603t;
import t0.C1802i;
import t0.C1803j;
import t0.C1804k;
import t0.InterfaceC1805l;

/* JADX INFO: loaded from: classes.dex */
public final class T implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f4012l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ String f4013m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ T3.c f4014n;

    public /* synthetic */ T(int i5, String str, T3.c cVar) {
        this.f4012l = i5;
        this.f4013m = str;
        this.f4014n = cVar;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        switch (this.f4012l) {
            case ConfigBackupDto.$stable /* 0 */:
                C0258p c0258p = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p.x()) {
                    c0258p.L();
                } else {
                    C1591g c1591gG = AbstractC1594j.g(8);
                    U.n nVar = U.n.a;
                    C1603t c1603tA = q.r.a(c1591gG, U.b.f6119x, c0258p, 6);
                    int i5 = c0258p.f3669P;
                    InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
                    U.q qVarD = U.a.d(c0258p, nVar);
                    InterfaceC1805l.f13649k.getClass();
                    C1803j c1803j = C1804k.f13641b;
                    c0258p.U();
                    if (c0258p.f3668O) {
                        c0258p.l(c1803j);
                    } else {
                        c0258p.d0();
                    }
                    C0234d.R(c0258p, C1804k.f13645f, c1603tA);
                    C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
                    C1802i c1802i = C1804k.f13646g;
                    if (c0258p.f3668O || !U3.j.a(c0258p.G(), Integer.valueOf(i5))) {
                        AbstractC0813y0.r(i5, c0258p, i5, c1802i);
                    }
                    C0234d.R(c0258p, C1804k.f13643d, qVarD);
                    c0258p.Q(258792282);
                    Y1.f fVar = (Y1.f) c0258p.k(Y1.l.f7129c);
                    c0258p.p(false);
                    H1.b("Nhập từ 1 đến 999 phút.", null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar.f7118g, c0258p, 0, 0, 65534);
                    AbstractC0121o0.a(this.f4013m, this.f4014n, null, false, false, null, null, AbstractC0292d.f4077d, null, null, null, null, null, false, null, new w.Q(3, 123), null, true, 0, 0, null, null, null, c0258p, 12582912, 12779520, 0, 8224636);
                    c0258p.p(true);
                }
                break;
            default:
                C0258p c0258p2 = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p2.x()) {
                    c0258p2.L();
                } else {
                    C1591g c1591gG2 = AbstractC1594j.g(8);
                    U.n nVar2 = U.n.a;
                    C1603t c1603tA2 = q.r.a(c1591gG2, U.b.f6119x, c0258p2, 6);
                    int i6 = c0258p2.f3669P;
                    InterfaceC0255n0 interfaceC0255n0M2 = c0258p2.m();
                    U.q qVarD2 = U.a.d(c0258p2, nVar2);
                    InterfaceC1805l.f13649k.getClass();
                    C1803j c1803j2 = C1804k.f13641b;
                    c0258p2.U();
                    if (c0258p2.f3668O) {
                        c0258p2.l(c1803j2);
                    } else {
                        c0258p2.d0();
                    }
                    C0234d.R(c0258p2, C1804k.f13645f, c1603tA2);
                    C0234d.R(c0258p2, C1804k.f13644e, interfaceC0255n0M2);
                    C1802i c1802i2 = C1804k.f13646g;
                    if (c0258p2.f3668O || !U3.j.a(c0258p2.G(), Integer.valueOf(i6))) {
                        AbstractC0813y0.r(i6, c0258p2, i6, c1802i2);
                    }
                    C0234d.R(c0258p2, C1804k.f13643d, qVarD2);
                    c0258p2.Q(258792282);
                    Y1.f fVar2 = (Y1.f) c0258p2.k(Y1.l.f7129c);
                    c0258p2.p(false);
                    H1.b("Mỗi dòng = 1 mẫu. Dòng trống và trùng lặp sẽ tự bỏ qua.", null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar2.f7118g, c0258p2, 6, 0, 65534);
                    AbstractC0121o0.a(this.f4013m, this.f4014n, androidx.compose.foundation.layout.c.d(androidx.compose.foundation.layout.c.c(nVar2, 1.0f), 200), false, false, null, null, K2.c.f4450e, null, null, null, null, null, false, null, null, null, false, 0, 0, null, null, null, c0258p2, 12583296, 0, 0, 8388472);
                    c0258p2.p(true);
                }
                break;
        }
        return G3.C.a;
    }
}

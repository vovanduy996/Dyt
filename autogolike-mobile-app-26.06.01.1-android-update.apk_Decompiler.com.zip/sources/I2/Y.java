package I2;

import B2.C0033i;
import F.H1;
import I.C0234d;
import I.C0250l;
import I.C0258p;
import I.InterfaceC0233c0;
import I.InterfaceC0255n0;
import I.Z0;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import com.google.android.gms.internal.measurement.AbstractC0813y0;
import q.AbstractC1594j;
import q.C1586b;
import q.C1591g;
import q.C1603t;
import t0.C1802i;
import t0.C1803j;
import t0.C1804k;
import t0.InterfaceC1805l;

/* JADX INFO: loaded from: classes.dex */
public final class Y implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f4028l = 1;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Y1.b f4029m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ int f4030n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ int f4031o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ int f4032p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ int f4033q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0233c0 f4034r;

    public Y(Y1.b bVar, int i5, int i6, int i7, int i8, InterfaceC0233c0 interfaceC0233c0) {
        this.f4029m = bVar;
        this.f4030n = i5;
        this.f4031o = i6;
        this.f4032p = i7;
        this.f4033q = i8;
        this.f4034r = interfaceC0233c0;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        G3.C c5 = G3.C.a;
        switch (this.f4028l) {
            case ConfigBackupDto.$stable /* 0 */:
                C0258p c0258p = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p.x()) {
                    c0258p.L();
                } else {
                    C1586b c1586b = AbstractC1594j.a;
                    c0258p.Q(-633634936);
                    Y1.e eVar = (Y1.e) c0258p.k(Y1.k.a);
                    c0258p.p(false);
                    C1591g c1591gG = AbstractC1594j.g(eVar.f7107c);
                    U.n nVar = U.n.a;
                    C1603t c1603tA = q.r.a(c1591gG, U.b.f6119x, c0258p, 0);
                    int i5 = c0258p.f3669P;
                    InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
                    U.q qVarD = U.a.d(c0258p, nVar);
                    InterfaceC1805l.f13649k.getClass();
                    C1803j c1803j = C1804k.f13641b;
                    c0258p.U();
                    if (c0258p.f3668O) {
                        c0258p.l(c1803j);
                    } else {
                        c0258p.d0();
                    }
                    C0234d.R(c0258p, C1804k.f13645f, c1603tA);
                    C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
                    C1802i c1802i = C1804k.f13646g;
                    if (c0258p.f3668O || !U3.j.a(c0258p.G(), Integer.valueOf(i5))) {
                        AbstractC0813y0.r(i5, c0258p, i5, c1802i);
                    }
                    C0234d.R(c0258p, C1804k.f13643d, qVarD);
                    Y1.b bVar = this.f4029m;
                    long j5 = bVar.f7049h;
                    c0258p.Q(258792282);
                    Z0 z02 = Y1.l.f7129c;
                    Y1.f fVar = (Y1.f) c0258p.k(z02);
                    c0258p.p(false);
                    H1.b("Nhịp độ", null, j5, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar.f7117f, c0258p, 6, 0, 65530);
                    c0258p.Q(258792282);
                    Y1.f fVar2 = (Y1.f) c0258p.k(z02);
                    c0258p.p(false);
                    H1.b("Random trong khoảng để engine không bấm máy móc.", null, bVar.f7052k, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar2.f7118g, c0258p, 6, 0, 65530);
                    int i6 = this.f4030n;
                    int i7 = this.f4031o;
                    InterfaceC0233c0 interfaceC0233c0 = this.f4034r;
                    E4.l.t(Q.f.b(-352978119, new P(i6, i7, 1, interfaceC0233c0, bVar), c0258p), c0258p, 6);
                    E4.l.t(Q.f.b(1022447714, new P(this.f4032p, this.f4033q, 2, interfaceC0233c0, bVar), c0258p), c0258p, 6);
                    c0258p.p(true);
                }
                break;
            default:
                C0258p c0258p2 = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p2.x()) {
                    c0258p2.L();
                } else {
                    Y1.b bVar2 = this.f4029m;
                    long j6 = bVar2.f7050i;
                    c0258p2.Q(258792282);
                    Z0 z03 = Y1.l.f7129c;
                    Y1.f fVar3 = (Y1.f) c0258p2.k(z03);
                    c0258p2.p(false);
                    H1.b("Cứ", null, j6, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar3.f7116e, c0258p2, 6, 0, 65530);
                    String strS0 = E4.l.s0(this.f4030n, this.f4031o, "");
                    c0258p2.Q(-430548339);
                    Object objG = c0258p2.G();
                    I.W w5 = C0250l.a;
                    InterfaceC0233c0 interfaceC0233c02 = this.f4034r;
                    if (objG == w5) {
                        objG = new C0033i(interfaceC0233c02, 14);
                        c0258p2.a0(objG);
                    }
                    c0258p2.p(false);
                    E4.l.X(strS0, (T3.a) objG, c0258p2, 48);
                    c0258p2.Q(258792282);
                    Y1.f fVar4 = (Y1.f) c0258p2.k(z03);
                    c0258p2.p(false);
                    H1.b("video, xem", null, bVar2.f7050i, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar4.f7116e, c0258p2, 6, 0, 65530);
                    String strS02 = E4.l.s0(this.f4032p, this.f4033q, "s");
                    c0258p2.Q(-430538832);
                    Object objG2 = c0258p2.G();
                    if (objG2 == w5) {
                        objG2 = new C0033i(interfaceC0233c02, 15);
                        c0258p2.a0(objG2);
                    }
                    c0258p2.p(false);
                    E4.l.X(strS02, (T3.a) objG2, c0258p2, 48);
                }
                break;
        }
        return c5;
    }

    public Y(Y1.b bVar, int i5, int i6, InterfaceC0233c0 interfaceC0233c0, int i7, int i8) {
        this.f4029m = bVar;
        this.f4030n = i5;
        this.f4031o = i6;
        this.f4034r = interfaceC0233c0;
        this.f4032p = i7;
        this.f4033q = i8;
    }
}

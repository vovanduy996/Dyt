package I2;

import F.E0;
import I.C0258p;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import n2.AbstractC1455b;

/* JADX INFO: loaded from: classes.dex */
public final class S implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f4010l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ T3.a f4011m;

    public /* synthetic */ S(T3.a aVar, int i5) {
        this.f4010l = i5;
        this.f4011m = aVar;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        switch (this.f4010l) {
            case ConfigBackupDto.$stable /* 0 */:
                C0258p c0258p = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p.x()) {
                    c0258p.L();
                } else {
                    E0.e(this.f4011m, null, false, null, null, null, null, null, null, AbstractC0292d.f4075b, c0258p, 805306368, 510);
                }
                break;
            case 1:
                C0258p c0258p2 = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p2.x()) {
                    c0258p2.L();
                } else {
                    E0.e(this.f4011m, null, false, null, null, null, null, null, null, K2.c.f4448c, c0258p2, 805306368, 510);
                }
                break;
            case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                C0258p c0258p3 = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p3.x()) {
                    c0258p3.L();
                } else {
                    E0.b(this.f4011m, null, false, null, null, null, null, null, null, AbstractC1455b.f12000b, c0258p3, 805306368, 510);
                }
                break;
            default:
                C0258p c0258p4 = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p4.x()) {
                    c0258p4.L();
                } else {
                    E0.e(this.f4011m, null, false, null, null, null, null, null, null, AbstractC1455b.f12001c, c0258p4, 805306368, 510);
                }
                break;
        }
        return G3.C.a;
    }
}

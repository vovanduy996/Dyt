package I2;

import I.C0258p;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import r.C1624d;

/* JADX INFO: loaded from: classes.dex */
public final class d0 implements T3.f {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f4078l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ g0 f4079m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ T3.c f4080n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ T3.e f4081o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ T3.a f4082p;

    public /* synthetic */ d0(g0 g0Var, T3.c cVar, T3.e eVar, T3.a aVar, int i5) {
        this.f4078l = i5;
        this.f4079m = g0Var;
        this.f4080n = cVar;
        this.f4081o = eVar;
        this.f4082p = aVar;
    }

    @Override // T3.f
    public final Object h(Object obj, Object obj2, Object obj3) {
        switch (this.f4078l) {
            case ConfigBackupDto.$stable /* 0 */:
                C0258p c0258p = (C0258p) obj2;
                int iIntValue = ((Number) obj3).intValue();
                U3.j.f((C1624d) obj, "$this$item");
                if ((iIntValue & 17) == 16 && c0258p.x()) {
                    c0258p.L();
                } else {
                    g0 g0Var = this.f4079m;
                    E4.l.Q("Đăng bình luận", "Thỉnh thoảng tự đăng 1 bình luận (random từ mẫu bạn nhập).", g0Var.f4114v, g0Var.f4115w, g0Var.f4116x, g0Var.f4117y, this.f4080n, this.f4081o, this.f4082p, "Quản lý mẫu bình luận", c0258p, 805306422);
                }
                break;
            default:
                C0258p c0258p2 = (C0258p) obj2;
                int iIntValue2 = ((Number) obj3).intValue();
                U3.j.f((C1624d) obj, "$this$item");
                if ((iIntValue2 & 17) == 16 && c0258p2.x()) {
                    c0258p2.L();
                } else {
                    g0 g0Var2 = this.f4079m;
                    E4.l.Q("Trả lời bình luận", "Trả lời 1 bình luận có sẵn (random từ mẫu trả lời).", g0Var2.f4118z, g0Var2.f4093A, g0Var2.B, g0Var2.C, this.f4080n, this.f4081o, this.f4082p, "Quản lý mẫu trả lời", c0258p2, 805306422);
                }
                break;
        }
        return G3.C.a;
    }
}

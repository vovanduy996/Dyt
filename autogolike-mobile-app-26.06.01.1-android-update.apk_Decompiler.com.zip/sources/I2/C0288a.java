package I2;

import F.H1;
import I.C0258p;
import com.autogolike.mobile.core.backup.ConfigBackupDto;

/* JADX INFO: renamed from: I2.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0288a implements T3.e {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final C0288a f4042m = new C0288a(0);

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final C0288a f4043n = new C0288a(1);

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final C0288a f4044o = new C0288a(2);

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final C0288a f4045p = new C0288a(3);

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f4046l;

    public /* synthetic */ C0288a(int i5) {
        this.f4046l = i5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        switch (this.f4046l) {
            case ConfigBackupDto.$stable /* 0 */:
                C0258p c0258p = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p.x()) {
                    c0258p.L();
                } else {
                    c0258p.Q(258792282);
                    Y1.f fVar = (Y1.f) c0258p.k(Y1.l.f7129c);
                    c0258p.p(false);
                    H1.b("DỪNG PHIÊN", null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar.f7114c, c0258p, 6, 0, 65534);
                }
                break;
            case 1:
                C0258p c0258p2 = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p2.x()) {
                    c0258p2.L();
                } else {
                    c0258p2.Q(258792282);
                    Y1.f fVar2 = (Y1.f) c0258p2.k(Y1.l.f7129c);
                    c0258p2.p(false);
                    H1.b("XONG", null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar2.f7114c, c0258p2, 6, 0, 65534);
                }
                break;
            case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                C0258p c0258p3 = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p3.x()) {
                    c0258p3.L();
                } else {
                    H1.b("Số phút mỗi acc", null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p3, 6, 0, 131070);
                }
                break;
            default:
                C0258p c0258p4 = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p4.x()) {
                    c0258p4.L();
                } else {
                    H1.b("vd: 20", null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p4, 6, 0, 131070);
                }
                break;
        }
        return G3.C.a;
    }
}

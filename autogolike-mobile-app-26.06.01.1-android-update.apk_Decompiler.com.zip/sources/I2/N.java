package I2;

import C0.C0052g;
import I.InterfaceC0233c0;
import android.content.Context;
import android.widget.Toast;
import com.autogolike.mobile.core.account.LocalSocialAccount;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import f4.AbstractC0952A;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import m1.AbstractC1383i;
import n2.C1464k;
import n2.C1468o;
import u0.C1867h;
import u0.InterfaceC1858c0;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class N implements T3.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f3988l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Object f3989m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ Object f3990n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ Object f3991o;

    public /* synthetic */ N(T3.e eVar, InterfaceC0233c0 interfaceC0233c0, InterfaceC0233c0 interfaceC0233c02) {
        this.f3988l = 3;
        this.f3989m = eVar;
        this.f3991o = interfaceC0233c0;
        this.f3990n = interfaceC0233c02;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v2, types: [H3.w] */
    /* JADX WARN: Type inference failed for: r2v3, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r2v8, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r3v2 */
    @Override // T3.a
    public final Object b() {
        ?? arrayList;
        switch (this.f3988l) {
            case ConfigBackupDto.$stable /* 0 */:
                A0 a02 = (A0) this.f3989m;
                g0 g0Var = (g0) a02.f3897f.getValue();
                if (U3.j.a(g0Var.a, "tt")) {
                    List list = g0Var.f4102j;
                    ArrayList arrayList2 = new ArrayList(H3.o.X0(list, 10));
                    Iterator it = list.iterator();
                    while (it.hasNext()) {
                        arrayList2.add(((LocalSocialAccount) it.next()).getUsername());
                    }
                    arrayList = new ArrayList();
                    for (Object obj : arrayList2) {
                        if (g0Var.f4103k.contains((String) obj)) {
                            arrayList.add(obj);
                        }
                    }
                } else {
                    arrayList = H3.w.f3464l;
                }
                AbstractC0952A.s(androidx.lifecycle.U.k(a02), null, null, new m0(a02, arrayList, null), 3);
                InterfaceC0233c0 interfaceC0233c0 = (InterfaceC0233c0) this.f3991o;
                ((T3.f) this.f3990n).h(((g0) interfaceC0233c0.getValue()).a, Integer.valueOf(((g0) interfaceC0233c0.getValue()).f4094b), H3.m.o1((Iterable) arrayList, ",", null, null, null, 62));
                break;
            case 1:
                String strO1 = H3.m.o1((List) this.f3989m, "\n\n", null, null, new S1.a(8), 30);
                if (strO1.length() > 0) {
                    ((C1867h) ((InterfaceC1858c0) this.f3990n)).a(new C0052g(6, strO1, null));
                    Toast.makeText((Context) this.f3991o, "Đã copy log", 0).show();
                }
                break;
            case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                AbstractC1383i.I((Context) this.f3989m, ((C1468o) this.f3990n).f12029b);
                C1464k c1464k = (C1464k) this.f3991o;
                Boolean bool = Boolean.TRUE;
                i4.c0 c0Var = c1464k.f12025d;
                c0Var.getClass();
                c0Var.m(null, bool);
                break;
            default:
                ((T3.e) this.f3989m).i((String) ((InterfaceC0233c0) this.f3991o).getValue(), Long.valueOf(((Number) ((InterfaceC0233c0) this.f3990n).getValue()).longValue()));
                break;
        }
        return G3.C.a;
    }

    public /* synthetic */ N(Object obj, Object obj2, Object obj3, int i5) {
        this.f3988l = i5;
        this.f3989m = obj;
        this.f3990n = obj2;
        this.f3991o = obj3;
    }
}

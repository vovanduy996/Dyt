package I2;

import f4.InterfaceC0991y;
import java.util.Set;
import kotlin.coroutines.Continuation;

/* JADX INFO: loaded from: classes.dex */
public final class h0 extends M3.i implements T3.e {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public int f4122A;
    public int B;
    public int C;
    public float D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public Set f4123E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public boolean f4124F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public boolean f4125G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public boolean f4126H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public boolean f4127I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public int f4128J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public final /* synthetic */ A0 f4129K;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f4130p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f4131q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f4132r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f4133s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f4134t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f4135u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f4136v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f4137w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f4138x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f4139y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public int f4140z;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public h0(A0 a02, Continuation continuation) {
        super(2, continuation);
        this.f4129K = a02;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((h0) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new h0(this.f4129K, continuation);
    }

    /* JADX WARN: Removed duplicated region for block: B:100:0x077e  */
    /* JADX WARN: Removed duplicated region for block: B:103:0x07e7 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:104:0x07e8  */
    /* JADX WARN: Removed duplicated region for block: B:107:0x0852 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:108:0x0853  */
    /* JADX WARN: Removed duplicated region for block: B:114:0x08e7 A[LOOP:0: B:110:0x087c->B:114:0x08e7, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:115:0x08e4 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:33:0x03b0 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:36:0x03c8 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:37:0x03c9  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x03e7 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:41:0x03e8  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x0409 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:45:0x040a  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x042c A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x042d  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x0454 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0455  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x047f A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:59:0x04a7 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:60:0x04a8  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x04d6 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:64:0x04d7  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x050e A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:68:0x050f  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x0541 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:72:0x0542  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x0581 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:76:0x0582  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x05c0 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:80:0x05c1  */
    /* JADX WARN: Removed duplicated region for block: B:83:0x0612 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:84:0x0613  */
    /* JADX WARN: Removed duplicated region for block: B:87:0x065c A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:88:0x065d  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x06b9 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:92:0x06ba  */
    /* JADX WARN: Removed duplicated region for block: B:95:0x071a A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:96:0x071b  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x077d A[RETURN] */
    @Override // M3.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object o(java.lang.Object r59) {
        /*
            Method dump skipped, instruction units count: 2332
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: I2.h0.o(java.lang.Object):java.lang.Object");
    }
}

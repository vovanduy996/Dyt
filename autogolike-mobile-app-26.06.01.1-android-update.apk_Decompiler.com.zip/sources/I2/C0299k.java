package I2;

import G3.AbstractC0164a;
import f4.AbstractC0952A;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: I2.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0299k extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ C0313z f4153p;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0299k(C0313z c0313z, Continuation continuation) {
        super(2, continuation);
        this.f4153p = c0313z;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        C0299k c0299k = (C0299k) m((InterfaceC0991y) obj, (Continuation) obj2);
        G3.C c5 = G3.C.a;
        c0299k.o(c5);
        return c5;
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new C0299k(this.f4153p, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        Object value;
        Object value2;
        AbstractC0164a.e(obj);
        C0313z c0313z = this.f4153p;
        i4.c0 c0Var = c0313z.f4280l;
        if (!((C0300l) c0Var.getValue()).f4159e) {
            if (c0313z.f4272d.a()) {
                do {
                    value = c0Var.getValue();
                } while (!c0Var.j(value, C0300l.a((C0300l) value, 0L, 0, true, 0, 0, 0, 0, 0, 0, 0, null, null, null, 0, false, null, 507887)));
                f4.p0 p0VarS = AbstractC0952A.s(androidx.lifecycle.U.k(c0313z), null, null, new C0308u(c0313z, null), 3);
                c0313z.f4282n = p0VarS;
                p0VarS.O(new A2.h(c0313z, 3, p0VarS));
            } else {
                do {
                    value2 = c0Var.getValue();
                } while (!c0Var.j(value2, C0300l.a((C0300l) value2, 0L, 0, false, 0, 0, 0, 0, 0, 0, 0, null, "Chưa bật Accessibility", null, 0, false, null, 507903)));
            }
        }
        return G3.C.a;
    }
}

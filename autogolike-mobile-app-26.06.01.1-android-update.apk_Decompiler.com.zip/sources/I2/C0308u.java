package I2;

import G3.AbstractC0164a;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: I2.u, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0308u extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f4235p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ C0313z f4236q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0308u(C0313z c0313z, Continuation continuation) {
        super(2, continuation);
        this.f4236q = c0313z;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C0308u) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new C0308u(this.f4236q, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f4235p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            this.f4235p = 1;
            if (C0313z.a(this.f4236q, this) == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return G3.C.a;
    }
}

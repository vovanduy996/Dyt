package I2;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: I2.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC0294f {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final EnumC0294f f4087l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final EnumC0294f f4088m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final /* synthetic */ EnumC0294f[] f4089n;

    static {
        EnumC0294f enumC0294f = new EnumC0294f("Every", 0);
        f4087l = enumC0294f;
        EnumC0294f enumC0294f2 = new EnumC0294f("Duration", 1);
        f4088m = enumC0294f2;
        f4089n = new EnumC0294f[]{enumC0294f, enumC0294f2};
    }

    public static EnumC0294f valueOf(String str) {
        return (EnumC0294f) Enum.valueOf(EnumC0294f.class, str);
    }

    public static EnumC0294f[] values() {
        return (EnumC0294f[]) f4089n.clone();
    }
}

package I2;

import G3.AbstractC0164a;
import V1.C0433c0;
import V1.K1;
import V1.M1;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: loaded from: classes.dex */
public final class x0 extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f4258p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ A0 f4259q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ boolean f4260r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public x0(A0 a02, boolean z3, Continuation continuation) {
        super(2, continuation);
        this.f4259q = a02;
        this.f4260r = z3;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((x0) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new x0(this.f4259q, this.f4260r, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f4258p;
        G3.C c5 = G3.C.a;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            K1 k12 = this.f4259q.a;
            this.f4258p = 1;
            Object objZ = X2.g.z(M1.a(k12.a), new C0433c0(k12, this.f4260r, null), this);
            if (objZ != aVar) {
                objZ = c5;
            }
            if (objZ == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return c5;
    }
}

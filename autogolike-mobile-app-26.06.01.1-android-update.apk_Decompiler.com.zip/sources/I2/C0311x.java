package I2;

import N1.InterfaceC0384u;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: I2.x, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0311x extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public /* synthetic */ Object f4255p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ String f4256q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ String f4257r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0311x(String str, String str2, Continuation continuation) {
        super(2, continuation);
        this.f4256q = str;
        this.f4257r = str2;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C0311x) m((InterfaceC0384u) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C0311x c0311x = new C0311x(this.f4256q, this.f4257r, continuation);
        c0311x.f4255p = obj;
        return c0311x;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0031  */
    @Override // M3.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object o(java.lang.Object r5) {
        /*
            r4 = this;
            G3.AbstractC0164a.e(r5)
            java.lang.Object r5 = r4.f4255p
            N1.u r5 = (N1.InterfaceC0384u) r5
            boolean r0 = r5 instanceof N1.C0378n
            java.lang.String r1 = r4.f4256q
            r2 = 1
            if (r0 == 0) goto L17
            N1.n r5 = (N1.C0378n) r5
            java.lang.String r5 = r5.f5257b
            boolean r2 = c4.s.b0(r5, r1, r2)
            goto L32
        L17:
            boolean r0 = r5 instanceof N1.C0377m
            r3 = 0
            if (r0 == 0) goto L31
            N1.m r5 = (N1.C0377m) r5
            java.lang.String r0 = r5.a
            boolean r0 = c4.s.b0(r0, r1, r2)
            if (r0 != 0) goto L32
            java.lang.String r5 = r5.a
            java.lang.String r0 = r4.f4257r
            boolean r5 = c4.s.b0(r5, r0, r2)
            if (r5 == 0) goto L31
            goto L32
        L31:
            r2 = r3
        L32:
            java.lang.Boolean r5 = java.lang.Boolean.valueOf(r2)
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: I2.C0311x.o(java.lang.Object):java.lang.Object");
    }
}

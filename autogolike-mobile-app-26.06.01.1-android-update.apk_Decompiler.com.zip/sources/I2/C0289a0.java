package I2;

import B2.C0033i;
import F.H1;
import I.C0250l;
import I.C0258p;
import I.InterfaceC0233c0;

/* JADX INFO: renamed from: I2.a0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0289a0 implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ Y1.b f4047l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ int f4048m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ int f4049n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ int f4050o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0233c0 f4051p;

    public C0289a0(int i5, int i6, int i7, InterfaceC0233c0 interfaceC0233c0, Y1.b bVar) {
        this.f4047l = bVar;
        this.f4048m = i5;
        this.f4049n = i6;
        this.f4050o = i7;
        this.f4051p = interfaceC0233c0;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        C0258p c0258p = (C0258p) obj;
        if ((((Number) obj2).intValue() & 3) == 2 && c0258p.x()) {
            c0258p.L();
        } else {
            Y1.b bVar = this.f4047l;
            H1.b("Cứ", null, bVar.f7050i, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, X2.g.L(c0258p).f7116e, c0258p, 6, 0, 65530);
            String strS0 = E4.l.s0(this.f4048m, this.f4049n, "");
            c0258p.Q(360390370);
            Object objG = c0258p.G();
            if (objG == C0250l.a) {
                objG = new C0033i(this.f4051p, 13);
                c0258p.a0(objG);
            }
            c0258p.p(false);
            E4.l.X(strS0, (T3.a) objG, c0258p, 48);
            H1.b("video làm 1 lần", null, bVar.f7050i, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, X2.g.L(c0258p).f7116e, c0258p, 6, 0, 65530);
            int i5 = this.f4050o;
            if (i5 > 0) {
                H1.b("·", null, bVar.f7052k, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, X2.g.L(c0258p).f7116e, c0258p, 6, 0, 65530);
                H1.b(i5 + " mẫu", null, bVar.f7052k, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, X2.g.L(c0258p).f7118g, c0258p, 0, 0, 65530);
            }
        }
        return G3.C.a;
    }
}

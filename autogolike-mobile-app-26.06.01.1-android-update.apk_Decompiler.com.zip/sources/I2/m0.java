package I2;

import G3.AbstractC0164a;
import V1.K1;
import V1.M1;
import f4.InterfaceC0991y;
import java.util.List;
import kotlin.coroutines.Continuation;

/* JADX INFO: loaded from: classes.dex */
public final class m0 extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f4178p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ A0 f4179q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ Object f4180r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public m0(A0 a02, List list, Continuation continuation) {
        super(2, continuation);
        this.f4179q = a02;
        this.f4180r = list;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((m0) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [java.lang.Object, java.util.List] */
    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new m0(this.f4179q, this.f4180r, continuation);
    }

    /* JADX WARN: Type inference failed for: r4v0, types: [java.lang.Object, java.util.List] */
    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f4178p;
        G3.C c5 = G3.C.a;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            A0 a02 = this.f4179q;
            this.f4178p = 1;
            K1 k12 = a02.a;
            Object objZ = X2.g.z(M1.a(k12.a), new V1.T(k12, this.f4180r, null), this);
            if (objZ != aVar) {
                objZ = c5;
            }
            if (objZ == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return c5;
    }
}

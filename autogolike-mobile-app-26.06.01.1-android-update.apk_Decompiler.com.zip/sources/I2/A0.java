package I2;

import N1.C0362e;
import O1.C0396g;
import V1.K1;
import androidx.room.RoomDatabase;
import f4.AbstractC0952A;
import q2.C1618h;

/* JADX INFO: loaded from: classes.dex */
public final class A0 extends androidx.lifecycle.a0 {
    public final K1 a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C0362e f3893b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final C0396g f3894c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final C1618h f3895d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f3896e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final i4.c0 f3897f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final i4.J f3898g;

    public A0(K1 k12, C0362e c0362e, C0396g c0396g, C1618h c1618h, androidx.lifecycle.Q q5) {
        U3.j.f(k12, "prefs");
        U3.j.f(c0362e, "accessibilityHelper");
        U3.j.f(c0396g, "tiktokAccountRepo");
        U3.j.f(c1618h, "templateRepo");
        U3.j.f(q5, "savedStateHandle");
        this.a = k12;
        this.f3893b = c0362e;
        this.f3894c = c0396g;
        this.f3895d = c1618h;
        String str = (String) q5.b("platform");
        str = str == null ? "tt" : str;
        this.f3896e = str;
        i4.c0 c0VarC = i4.O.c(new g0(str, (536870910 & 2) != 0 ? 15 : 0, H3.n.S0(5, 15, 30, 60), 15, 6, 22, 2, 3, false, (536870910 & 512) != 0 ? H3.w.f3464l : null, (536870910 & 1024) != 0 ? H3.y.f3466l : null, false, "", false, 5, 10, 8, 20, false, 15, 30, false, 25, 50, 0, false, 30, 60, 0));
        this.f3897f = c0VarC;
        this.f3898g = new i4.J(c0VarC);
        AbstractC0952A.s(androidx.lifecycle.U.k(this), null, null, new h0(this, null), 3);
        if (str.equals("tt")) {
            AbstractC0952A.s(androidx.lifecycle.U.k(this), null, null, new j0(this, null), 3);
            AbstractC0952A.s(androidx.lifecycle.U.k(this), null, null, new k0(this, null), 3);
        }
        if (str.equals("tt")) {
            AbstractC0952A.s(androidx.lifecycle.U.k(this), null, null, new l0(this, null), 3);
        }
    }

    public final void a(int i5) {
        A0 a02 = this;
        int iO0 = E4.l.o0(i5, 1, RoomDatabase.MAX_BIND_PARAMETER_CNT);
        while (true) {
            i4.c0 c0Var = a02.f3897f;
            Object value = c0Var.getValue();
            if (c0Var.j(value, g0.a((g0) value, iO0, 0, 0, 0, 0, 0, false, null, null, false, null, false, 0, 0, 0, 0, false, 0, 0, false, 0, 0, 0, false, 0, 0, 0, 536870909))) {
                AbstractC0952A.s(androidx.lifecycle.U.k(this), null, null, new n0(this, iO0, null), 3);
                return;
            }
            a02 = this;
        }
    }
}

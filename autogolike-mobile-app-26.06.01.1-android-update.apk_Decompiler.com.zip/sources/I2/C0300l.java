package I2;

import com.google.android.gms.internal.measurement.AbstractC0813y0;
import java.util.List;
import l.AbstractC1297i;
import z1.AbstractC2128a;

/* JADX INFO: renamed from: I2.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0300l {
    public final X1.o a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f4156b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f4157c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f4158d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f4159e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f4160f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f4161g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f4162h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f4163i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final int f4164j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final int f4165k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final int f4166l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final String f4167m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final boolean f4168n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final String f4169o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final List f4170p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final int f4171q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final boolean f4172r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final String f4173s;

    public C0300l(X1.o oVar, int i5, long j5, int i6, boolean z3, int i7, int i8, int i9, int i10, int i11, int i12, int i13, String str, boolean z5, String str2, List list, int i14, boolean z6, String str3) {
        U3.j.f(oVar, "platform");
        U3.j.f(list, "accountQueue");
        this.a = oVar;
        this.f4156b = i5;
        this.f4157c = j5;
        this.f4158d = i6;
        this.f4159e = z3;
        this.f4160f = i7;
        this.f4161g = i8;
        this.f4162h = i9;
        this.f4163i = i10;
        this.f4164j = i11;
        this.f4165k = i12;
        this.f4166l = i13;
        this.f4167m = str;
        this.f4168n = z5;
        this.f4169o = str2;
        this.f4170p = list;
        this.f4171q = i14;
        this.f4172r = z6;
        this.f4173s = str3;
    }

    public static C0300l a(C0300l c0300l, long j5, int i5, boolean z3, int i6, int i7, int i8, int i9, int i10, int i11, int i12, String str, String str2, List list, int i13, boolean z5, String str3, int i14) {
        X1.o oVar = c0300l.a;
        int i15 = c0300l.f4156b;
        long j6 = (i14 & 4) != 0 ? c0300l.f4157c : j5;
        int i16 = (i14 & 8) != 0 ? c0300l.f4158d : i5;
        boolean z6 = (i14 & 16) != 0 ? c0300l.f4159e : z3;
        int i17 = (i14 & 32) != 0 ? c0300l.f4160f : i6;
        int i18 = (i14 & 64) != 0 ? c0300l.f4161g : i7;
        int i19 = (i14 & 128) != 0 ? c0300l.f4162h : i8;
        int i20 = (i14 & 256) != 0 ? c0300l.f4163i : i9;
        int i21 = (i14 & 512) != 0 ? c0300l.f4164j : i10;
        int i22 = (i14 & 1024) != 0 ? c0300l.f4165k : i11;
        int i23 = (i14 & 2048) != 0 ? c0300l.f4166l : i12;
        String str4 = (i14 & 4096) != 0 ? c0300l.f4167m : str;
        boolean z7 = c0300l.f4168n;
        String str5 = (i14 & 16384) != 0 ? c0300l.f4169o : str2;
        List list2 = (32768 & i14) != 0 ? c0300l.f4170p : list;
        int i24 = i23;
        int i25 = (i14 & 65536) != 0 ? c0300l.f4171q : i13;
        boolean z8 = (131072 & i14) != 0 ? c0300l.f4172r : z5;
        String str6 = (i14 & 262144) != 0 ? c0300l.f4173s : str3;
        c0300l.getClass();
        U3.j.f(oVar, "platform");
        U3.j.f(list2, "accountQueue");
        return new C0300l(oVar, i15, j6, i16, z6, i17, i18, i19, i20, i21, i22, i24, str4, z7, str5, list2, i25, z8, str6);
    }

    public final String b() {
        List list = this.f4170p;
        if (list.isEmpty()) {
            return null;
        }
        return AbstractC0813y0.k(this.f4171q + 1, list.size(), "Acc ", "/");
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0300l)) {
            return false;
        }
        C0300l c0300l = (C0300l) obj;
        return this.a == c0300l.a && this.f4156b == c0300l.f4156b && this.f4157c == c0300l.f4157c && this.f4158d == c0300l.f4158d && this.f4159e == c0300l.f4159e && this.f4160f == c0300l.f4160f && this.f4161g == c0300l.f4161g && this.f4162h == c0300l.f4162h && this.f4163i == c0300l.f4163i && this.f4164j == c0300l.f4164j && this.f4165k == c0300l.f4165k && this.f4166l == c0300l.f4166l && U3.j.a(this.f4167m, c0300l.f4167m) && this.f4168n == c0300l.f4168n && U3.j.a(this.f4169o, c0300l.f4169o) && U3.j.a(this.f4170p, c0300l.f4170p) && this.f4171q == c0300l.f4171q && this.f4172r == c0300l.f4172r && U3.j.a(this.f4173s, c0300l.f4173s);
    }

    public final int hashCode() {
        int iB = AbstractC1297i.b(this.f4166l, AbstractC1297i.b(this.f4165k, AbstractC1297i.b(this.f4164j, AbstractC1297i.b(this.f4163i, AbstractC1297i.b(this.f4162h, AbstractC1297i.b(this.f4161g, AbstractC1297i.b(this.f4160f, AbstractC0813y0.f(AbstractC1297i.b(this.f4158d, AbstractC0813y0.e(AbstractC1297i.b(this.f4156b, this.a.hashCode() * 31, 31), 31, this.f4157c), 31), 31, this.f4159e), 31), 31), 31), 31), 31), 31), 31);
        String str = this.f4167m;
        int iF = AbstractC0813y0.f((iB + (str == null ? 0 : str.hashCode())) * 31, 31, this.f4168n);
        String str2 = this.f4169o;
        int iF2 = AbstractC0813y0.f(AbstractC1297i.b(this.f4171q, AbstractC0813y0.g(this.f4170p, (iF + (str2 == null ? 0 : str2.hashCode())) * 31, 31), 31), 31, this.f4172r);
        String str3 = this.f4173s;
        return iF2 + (str3 != null ? str3.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("WarmupRunnerUiState(platform=");
        sb.append(this.a);
        sb.append(", durationMin=");
        sb.append(this.f4156b);
        sb.append(", endAtMs=");
        sb.append(this.f4157c);
        sb.append(", remainingSec=");
        sb.append(this.f4158d);
        sb.append(", isRunning=");
        sb.append(this.f4159e);
        sb.append(", watchCount=");
        sb.append(this.f4160f);
        sb.append(", likeCount=");
        sb.append(this.f4161g);
        sb.append(", swipeCount=");
        sb.append(this.f4162h);
        sb.append(", viewCommentCount=");
        sb.append(this.f4163i);
        sb.append(", copyLinkCount=");
        sb.append(this.f4164j);
        sb.append(", postCommentCount=");
        sb.append(this.f4165k);
        sb.append(", replyCommentCount=");
        sb.append(this.f4166l);
        sb.append(", lastEvent=");
        sb.append(this.f4167m);
        sb.append(", accessibilityEnabled=");
        sb.append(this.f4168n);
        sb.append(", errorMessage=");
        sb.append(this.f4169o);
        sb.append(", accountQueue=");
        sb.append(this.f4170p);
        sb.append(", currentAccountIndex=");
        sb.append(this.f4171q);
        sb.append(", isSwitchingAccount=");
        sb.append(this.f4172r);
        sb.append(", switchingTo=");
        return AbstractC2128a.k(sb, this.f4173s, ")");
    }
}

package I2;

/* JADX INFO: renamed from: I2.v, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0309v extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public C0313z f4240o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public String f4241p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f4242q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ C0313z f4243r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f4244s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0309v(C0313z c0313z, M3.c cVar) {
        super(cVar);
        this.f4243r = c0313z;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f4242q = obj;
        this.f4244s |= Integer.MIN_VALUE;
        return this.f4243r.f(null, this);
    }
}

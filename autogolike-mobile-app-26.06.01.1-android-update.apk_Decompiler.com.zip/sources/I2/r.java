package I2;

/* JADX INFO: loaded from: classes.dex */
public final class r extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public String f4201o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public /* synthetic */ Object f4202p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ C0313z f4203q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f4204r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public r(C0313z c0313z, M3.c cVar) {
        super(cVar);
        this.f4203q = c0313z;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f4202p = obj;
        this.f4204r |= Integer.MIN_VALUE;
        return this.f4203q.c(this);
    }
}

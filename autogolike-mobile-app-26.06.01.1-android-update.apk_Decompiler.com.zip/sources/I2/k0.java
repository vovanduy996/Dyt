package I2;

import G3.AbstractC0164a;
import f4.InterfaceC0991y;
import i4.InterfaceC1183g;
import kotlin.coroutines.Continuation;
import q2.C1618h;
import q2.EnumC1611a;

/* JADX INFO: loaded from: classes.dex */
public final class k0 extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f4154p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ A0 f4155q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public k0(A0 a02, Continuation continuation) {
        super(2, continuation);
        this.f4155q = a02;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((k0) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new k0(this.f4155q, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        int i5 = 1;
        L3.a aVar = L3.a.f4629l;
        int i6 = this.f4154p;
        if (i6 == 0) {
            AbstractC0164a.e(obj);
            A0 a02 = this.f4155q;
            C1618h c1618h = a02.f3895d;
            EnumC1611a enumC1611a = EnumC1611a.f12675m;
            c1618h.getClass();
            String str = a02.f3896e;
            U3.j.f(str, "platform");
            InterfaceC1183g interfaceC1183gObserveEnabledCount = c1618h.a.observeEnabledCount(str, "reply");
            i0 i0Var = new i0(a02, i5);
            this.f4154p = 1;
            if (interfaceC1183gObserveEnabledCount.d(i0Var, this) == aVar) {
                return aVar;
            }
        } else {
            if (i6 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return G3.C.a;
    }
}

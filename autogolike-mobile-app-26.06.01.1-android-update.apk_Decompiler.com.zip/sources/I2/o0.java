package I2;

import G3.AbstractC0164a;
import V1.K1;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: loaded from: classes.dex */
public final class o0 extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f4188p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ A0 f4189q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ int f4190r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ int f4191s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o0(A0 a02, int i5, int i6, Continuation continuation) {
        super(2, continuation);
        this.f4189q = a02;
        this.f4190r = i5;
        this.f4191s = i6;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((o0) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new o0(this.f4189q, this.f4190r, this.f4191s, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f4188p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            K1 k12 = this.f4189q.a;
            this.f4188p = 1;
            if (k12.U(this.f4190r, this.f4191s, this) == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return G3.C.a;
    }
}

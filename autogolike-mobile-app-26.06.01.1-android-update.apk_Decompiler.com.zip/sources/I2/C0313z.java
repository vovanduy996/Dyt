package I2;

import N1.C0354a;
import N1.C0362e;
import N1.C0368h;
import O1.C0396g;
import V1.K1;
import f4.AbstractC0952A;
import i2.C1138L;
import i2.C1141b;
import i2.C1154o;

/* JADX INFO: renamed from: I2.z, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0313z extends androidx.lifecycle.a0 {
    public static final C0305q Companion = new C0305q();
    public final C0354a a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final K1 f4270b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Z1.j f4271c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final C0362e f4272d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final C1141b f4273e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final C1154o f4274f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final C0396g f4275g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final String f4276h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f4277i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final String f4278j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final X1.o f4279k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final i4.c0 f4280l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final i4.J f4281m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public f4.p0 f4282n;

    public C0313z(C0354a c0354a, K1 k12, Z1.j jVar, C0362e c0362e, C1141b c1141b, C1154o c1154o, C0396g c0396g, androidx.lifecycle.Q q5) {
        Object next;
        U3.j.f(c0354a, "bridge");
        U3.j.f(k12, "prefs");
        U3.j.f(jVar, "socialLauncher");
        U3.j.f(c0362e, "accessibilityHelper");
        U3.j.f(c1141b, "overlayController");
        U3.j.f(c1154o, "overlayBridge");
        U3.j.f(c0396g, "tiktokAccountRepo");
        U3.j.f(q5, "savedStateHandle");
        this.a = c0354a;
        this.f4270b = k12;
        this.f4271c = jVar;
        this.f4272d = c0362e;
        this.f4273e = c1141b;
        this.f4274f = c1154o;
        this.f4275g = c0396g;
        String str = (String) q5.b("platform");
        this.f4276h = str == null ? "tt" : str;
        Integer num = (Integer) q5.b("durationMin");
        this.f4277i = num != null ? num.intValue() : 15;
        String str2 = (String) q5.b("accountKeysCsv");
        this.f4278j = str2 == null ? "-" : str2;
        N3.a aVar = X1.o.f7001v;
        aVar.getClass();
        G3.t tVar = new G3.t(4, aVar);
        while (true) {
            if (!tVar.hasNext()) {
                next = null;
                break;
            } else {
                next = tVar.next();
                if (((X1.o) next).f7002l.equals(this.f4276h)) {
                    break;
                }
            }
        }
        X1.o oVar = (X1.o) next;
        X1.o oVar2 = oVar == null ? X1.o.f6995p : oVar;
        this.f4279k = oVar2;
        int i5 = this.f4277i;
        i4.c0 c0VarC = i4.O.c(new C0300l(oVar2, i5, 0L, i5 * 60, false, 0, 0, 0, 0, 0, 0, 0, null, (516084 & 8192) != 0 ? false : this.f4272d.a(), null, H3.w.f3464l, 0, false, null));
        this.f4280l = c0VarC;
        this.f4281m = new i4.J(c0VarC);
        AbstractC0952A.s(androidx.lifecycle.U.k(this), null, null, new C0302n(this, null), 3);
        AbstractC0952A.s(androidx.lifecycle.U.k(this), null, null, new C0303o(this, null), 3);
        AbstractC0952A.s(androidx.lifecycle.U.k(this), null, null, new C0304p(this, null), 3);
    }

    /* JADX WARN: Path cross not found for [B:140:0x0606, B:143:0x0612], limit reached: 199 */
    /* JADX WARN: Path cross not found for [B:143:0x0612, B:140:0x0606], limit reached: 199 */
    /* JADX WARN: Removed duplicated region for block: B:103:0x04af  */
    /* JADX WARN: Removed duplicated region for block: B:110:0x0505  */
    /* JADX WARN: Removed duplicated region for block: B:113:0x0515  */
    /* JADX WARN: Removed duplicated region for block: B:114:0x0517  */
    /* JADX WARN: Removed duplicated region for block: B:116:0x0525  */
    /* JADX WARN: Removed duplicated region for block: B:122:0x055a  */
    /* JADX WARN: Removed duplicated region for block: B:131:0x05bf  */
    /* JADX WARN: Removed duplicated region for block: B:132:0x05c1  */
    /* JADX WARN: Removed duplicated region for block: B:134:0x05d0  */
    /* JADX WARN: Removed duplicated region for block: B:140:0x0606  */
    /* JADX WARN: Removed duplicated region for block: B:146:0x061d A[LOOP:2: B:146:0x061d->B:196:?, LOOP_START] */
    /* JADX WARN: Removed duplicated region for block: B:149:0x064d A[LOOP:3: B:149:0x064d->B:191:0x0846, LOOP_START, PHI: r2
      0x064d: PHI (r2v3 I2.s) = (r2v2 I2.s), (r2v9 I2.s) binds: [B:145:0x061b, B:191:0x0846] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:157:0x06ab  */
    /* JADX WARN: Removed duplicated region for block: B:177:0x077a  */
    /* JADX WARN: Removed duplicated region for block: B:178:0x0782  */
    /* JADX WARN: Removed duplicated region for block: B:182:0x07e2  */
    /* JADX WARN: Removed duplicated region for block: B:201:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:202:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:203:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:204:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:205:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:207:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:208:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:209:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:210:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:212:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:213:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:215:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:216:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:218:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:219:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0279  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x029a  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x02da  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x0309  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x0354  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x0382  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x03cb  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x03ce  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x03dd  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /* JADX WARN: Removed duplicated region for block: B:84:0x040d  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x045e  */
    /* JADX WARN: Removed duplicated region for block: B:94:0x046e  */
    /* JADX WARN: Removed duplicated region for block: B:95:0x0470  */
    /* JADX WARN: Removed duplicated region for block: B:97:0x047d  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:177:0x077a -> B:184:0x07f4). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:181:0x07e0 -> B:183:0x07e5). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final java.lang.Object a(I2.C0313z r41, M3.c r42) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 2174
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: I2.C0313z.a(I2.z, M3.c):java.lang.Object");
    }

    public static String b(X1.o oVar) {
        int iOrdinal = oVar.ordinal();
        if (iOrdinal == 0) {
            return "https://m.facebook.com/";
        }
        if (iOrdinal == 1) {
            return "https://www.tiktok.com/";
        }
        if (iOrdinal == 2) {
            return "https://www.instagram.com/";
        }
        if (iOrdinal == 3) {
            return "https://www.snapchat.com/";
        }
        if (iOrdinal == 4) {
            return "https://www.threads.net/";
        }
        if (iOrdinal == 5) {
            return "https://www.linkedin.com/feed/";
        }
        throw new G3.f();
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0015  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object c(M3.c r10) {
        /*
            Method dump skipped, instruction units count: 391
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: I2.C0313z.c(M3.c):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0017  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object d(float r32, int r33, int r34, int r35, int r36, N1.J0 r37, N1.D0 r38, N1.F0 r39, N1.H0 r40, M3.c r41) {
        /*
            Method dump skipped, instruction units count: 280
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: I2.C0313z.d(float, int, int, int, int, N1.J0, N1.D0, N1.F0, N1.H0, M3.c):java.lang.Object");
    }

    public final void e() {
        i4.c0 c0Var;
        Object value;
        f4.p0 p0Var = this.f4282n;
        if (p0Var != null) {
            p0Var.a(null);
        }
        this.f4282n = null;
        this.a.a(C0368h.a);
        this.f4273e.b();
        i4.c0 c0Var2 = this.f4274f.a;
        C1138L c1138l = (C1138L) c0Var2.getValue();
        U3.j.f(c1138l, "it");
        c0Var2.l(C1138L.a(c1138l, null, null, null, null, 0, 0, 0, 0, null, false, null, false, null, false, null, false, 0, 0, 0, false, null, false, false, 8289791));
        do {
            c0Var = this.f4280l;
            value = c0Var.getValue();
        } while (!c0Var.j(value, C0300l.a((C0300l) value, 0L, 0, false, 0, 0, 0, 0, 0, 0, 0, null, null, null, 0, false, null, 131047)));
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x00ff  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0113  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x011c  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object f(java.lang.String r30, M3.c r31) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 378
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: I2.C0313z.f(java.lang.String, M3.c):java.lang.Object");
    }
}

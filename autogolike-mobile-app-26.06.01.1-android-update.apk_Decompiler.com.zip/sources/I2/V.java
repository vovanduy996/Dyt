package I2;

import F.H1;
import I.C0234d;
import I.C0258p;
import I.InterfaceC0255n0;
import I.Z0;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import com.google.android.gms.internal.measurement.AbstractC0813y0;
import q.AbstractC1594j;
import q.C1591g;
import q.C1603t;
import t0.C1802i;
import t0.C1803j;
import t0.C1804k;
import t0.InterfaceC1805l;

/* JADX INFO: loaded from: classes.dex */
public final class V implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f4021l = 1;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ X1.o f4022m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ Y1.b f4023n;

    public V(X1.o oVar, Y1.b bVar) {
        this.f4022m = oVar;
        this.f4023n = bVar;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        switch (this.f4021l) {
            case ConfigBackupDto.$stable /* 0 */:
                C0258p c0258p = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p.x()) {
                    c0258p.L();
                } else {
                    C1591g c1591gG = AbstractC1594j.g(4);
                    U.n nVar = U.n.a;
                    C1603t c1603tA = q.r.a(c1591gG, U.b.f6119x, c0258p, 6);
                    int i5 = c0258p.f3669P;
                    InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
                    U.q qVarD = U.a.d(c0258p, nVar);
                    InterfaceC1805l.f13649k.getClass();
                    C1803j c1803j = C1804k.f13641b;
                    c0258p.U();
                    if (c0258p.f3668O) {
                        c0258p.l(c1803j);
                    } else {
                        c0258p.d0();
                    }
                    C0234d.R(c0258p, C1804k.f13645f, c1603tA);
                    C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
                    C1802i c1802i = C1804k.f13646g;
                    if (c0258p.f3668O || !U3.j.a(c0258p.G(), Integer.valueOf(i5))) {
                        AbstractC0813y0.r(i5, c0258p, i5, c1802i);
                    }
                    C0234d.R(c0258p, C1804k.f13643d, qVarD);
                    Y1.b bVar = this.f4023n;
                    long j5 = bVar.f7049h;
                    c0258p.Q(258792282);
                    Z0 z02 = Y1.l.f7129c;
                    Y1.f fVar = (Y1.f) c0258p.k(z02);
                    c0258p.p(false);
                    H1.b("Phiên này làm gì?", null, j5, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar.f7117f, c0258p, 6, 0, 65530);
                    String str = "• Mở " + this.f4022m.f7003m + " (cần tự đăng nhập)\n• Lướt reel + xem video theo khoảng thời gian bạn đặt\n• Thả tim ngẫu nhiên theo tỉ lệ trên\n• Bật thêm xem bình luận / sao chép liên kết (tùy chọn)\n• Hết giờ tự chuyển sang acc kế (nếu chọn nhiều acc)\n• KHÔNG nhận coin (đây là nuôi nick, không phải job)";
                    c0258p.Q(258792282);
                    Y1.f fVar2 = (Y1.f) c0258p.k(z02);
                    c0258p.p(false);
                    H1.b(str, null, bVar.f7051j, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar2.f7118g, c0258p, 0, 0, 65530);
                    c0258p.p(true);
                }
                break;
            default:
                C0258p c0258p2 = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p2.x()) {
                    c0258p2.L();
                } else {
                    String str2 = this.f4022m.f7003m;
                    long j6 = this.f4023n.f7059r;
                    c0258p2.Q(258792282);
                    Y1.f fVar3 = (Y1.f) c0258p2.k(Y1.l.f7129c);
                    c0258p2.p(false);
                    H1.b("Chưa có tài khoản " + str2 + " nào enabled. Thêm ở tab Tài khoản > " + str2 + " trước.", null, j6, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar3.f7116e, c0258p2, 0, 0, 65530);
                }
                break;
        }
        return G3.C.a;
    }

    public V(Y1.b bVar, X1.o oVar) {
        this.f4023n = bVar;
        this.f4022m = oVar;
    }
}

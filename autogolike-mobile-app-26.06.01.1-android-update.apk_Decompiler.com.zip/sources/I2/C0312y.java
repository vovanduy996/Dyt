package I2;

import G3.AbstractC0164a;
import N1.C0372j;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: I2.y, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0312y extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f4261p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ C0313z f4262q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ C0372j f4263r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ String f4264s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ String f4265t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0312y(C0313z c0313z, C0372j c0372j, String str, String str2, Continuation continuation) {
        super(2, continuation);
        this.f4262q = c0313z;
        this.f4263r = c0372j;
        this.f4264s = str;
        this.f4265t = str2;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C0312y) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new C0312y(this.f4262q, this.f4263r, this.f4264s, this.f4265t, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f4261p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            C0313z c0313z = this.f4262q;
            i4.h0 h0Var = new i4.h0(c0313z.a.f5152f, new C0310w(c0313z, this.f4263r, null));
            C0311x c0311x = new C0311x(this.f4264s, this.f4265t, null);
            this.f4261p = 1;
            obj = i4.O.l(h0Var, c0311x, this);
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return obj;
    }
}

package I2;

/* JADX INFO: renamed from: I2.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0292d {
    public static final Q.a a = new Q.a(1635815362, C0291c.f4064m, false);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Q.a f4075b = new Q.a(-764818048, C0291c.f4065n, false);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Q.a f4076c = new Q.a(181365595, C0288a.f4044o, false);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final Q.a f4077d = new Q.a(847752683, C0288a.f4045p, false);
}

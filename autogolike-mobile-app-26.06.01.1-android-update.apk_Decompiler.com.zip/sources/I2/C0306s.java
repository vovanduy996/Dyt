package I2;

import N1.D0;
import N1.F0;
import N1.H0;
import N1.J0;
import java.util.List;

/* JADX INFO: renamed from: I2.s, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0306s extends M3.c {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public int f4208A;
    public int B;
    public long C;
    public /* synthetic */ Object D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final /* synthetic */ C0313z f4209E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public int f4210F;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public C0313z f4211o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public J0 f4212p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public D0 f4213q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public F0 f4214r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public H0 f4215s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public List f4216t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public float f4217u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f4218v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f4219w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f4220x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f4221y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public int f4222z;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0306s(C0313z c0313z, M3.c cVar) {
        super(cVar);
        this.f4209E = c0313z;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.D = obj;
        this.f4210F |= Integer.MIN_VALUE;
        return C0313z.a(this.f4209E, this);
    }
}

package I2;

import I.C0234d;
import I.C0258p;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import m.H0;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class G implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f3944l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ X1.o f3945m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ int f3946n;

    public /* synthetic */ G(X1.o oVar, int i5, int i6) {
        this.f3944l = i6;
        this.f3945m = oVar;
        this.f3946n = i5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        int i5 = this.f3944l;
        C0258p c0258p = (C0258p) obj;
        ((Integer) obj2).intValue();
        switch (i5) {
            case ConfigBackupDto.$stable /* 0 */:
                E4.l.s(this.f3945m, c0258p, C0234d.U(this.f3946n | 1));
                break;
            default:
                H0.s(this.f3945m, c0258p, C0234d.U(this.f3946n | 1));
                break;
        }
        return G3.C.a;
    }
}

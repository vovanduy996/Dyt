package I2;

/* JADX INFO: renamed from: I2.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0307t extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public C0313z f4226o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public long f4227p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f4228q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ C0313z f4229r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f4230s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0307t(C0313z c0313z, M3.c cVar) {
        super(cVar);
        this.f4229r = c0313z;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f4228q = obj;
        this.f4230s |= Integer.MIN_VALUE;
        return this.f4229r.d(0.0f, 0, 0, 0, 0, null, null, null, null, this);
    }
}

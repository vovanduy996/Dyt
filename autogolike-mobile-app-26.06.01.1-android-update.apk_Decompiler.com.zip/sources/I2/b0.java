package I2;

import F.A1;
import F.E0;
import F.H1;
import I.C0234d;
import I.C0258p;
import I.InterfaceC0233c0;
import I.InterfaceC0255n0;
import com.google.android.gms.internal.measurement.AbstractC0813y0;
import q.AbstractC1587c;
import q.AbstractC1594j;
import q.C1586b;
import q.C1591g;
import q.C1603t;
import t0.C1802i;
import t0.C1803j;
import t0.C1804k;
import t0.InterfaceC1805l;
import z1.AbstractC2128a;

/* JADX INFO: loaded from: classes.dex */
public final class b0 implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ boolean f4053l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ int f4054m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ String f4055n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ Y1.b f4056o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ T3.a f4057p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ T3.c f4058q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ String f4059r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ String f4060s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f4061t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ int f4062u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0233c0 f4063v;

    public b0(boolean z3, int i5, String str, Y1.b bVar, T3.a aVar, T3.c cVar, String str2, String str3, int i6, int i7, InterfaceC0233c0 interfaceC0233c0) {
        this.f4053l = z3;
        this.f4054m = i5;
        this.f4055n = str;
        this.f4056o = bVar;
        this.f4057p = aVar;
        this.f4058q = cVar;
        this.f4059r = str2;
        this.f4060s = str3;
        this.f4061t = i6;
        this.f4062u = i7;
        this.f4063v = interfaceC0233c0;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        C0258p c0258p;
        boolean z3;
        String str;
        int i5;
        Y1.b bVar;
        C0258p c0258p2 = (C0258p) obj;
        if ((((Number) obj2).intValue() & 3) == 2 && c0258p2.x()) {
            c0258p2.L();
        } else {
            C1586b c1586b = AbstractC1594j.a;
            C1591g c1591gG = AbstractC1594j.g(X2.g.I(c0258p2).f7107c);
            U.n nVar = U.n.a;
            U.g gVar = U.b.f6119x;
            C1603t c1603tA = q.r.a(c1591gG, gVar, c0258p2, 0);
            int i6 = c0258p2.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p2.m();
            U.q qVarD = U.a.d(c0258p2, nVar);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p2.U();
            if (c0258p2.f3668O) {
                c0258p2.l(c1803j);
            } else {
                c0258p2.d0();
            }
            C1802i c1802i = C1804k.f13645f;
            C0234d.R(c0258p2, c1802i, c1603tA);
            C1802i c1802i2 = C1804k.f13644e;
            C0234d.R(c0258p2, c1802i2, interfaceC0255n0M);
            C1802i c1802i3 = C1804k.f13646g;
            if (c0258p2.f3668O || !U3.j.a(c0258p2.G(), Integer.valueOf(i6))) {
                AbstractC0813y0.r(i6, c0258p2, i6, c1802i3);
            }
            C1802i c1802i4 = C1804k.f13643d;
            C0234d.R(c0258p2, c1802i4, qVarD);
            q.b0 b0VarB = q.a0.b(AbstractC1594j.a, U.b.f6117v, c0258p2, 48);
            int i7 = c0258p2.f3669P;
            InterfaceC0255n0 interfaceC0255n0M2 = c0258p2.m();
            U.q qVarD2 = U.a.d(c0258p2, nVar);
            c0258p2.U();
            if (c0258p2.f3668O) {
                c0258p2.l(c1803j);
            } else {
                c0258p2.d0();
            }
            C0234d.R(c0258p2, c1802i, b0VarB);
            C0234d.R(c0258p2, c1802i2, interfaceC0255n0M2);
            if (c0258p2.f3668O || !U3.j.a(c0258p2.G(), Integer.valueOf(i7))) {
                AbstractC0813y0.r(i7, c0258p2, i7, c1802i3);
            }
            C0234d.R(c0258p2, c1802i4, qVarD2);
            U.q qVarA = q.c0.a(1.0f);
            C1603t c1603tA2 = q.r.a(AbstractC1594j.f12606c, gVar, c0258p2, 0);
            int i8 = c0258p2.f3669P;
            InterfaceC0255n0 interfaceC0255n0M3 = c0258p2.m();
            U.q qVarD3 = U.a.d(c0258p2, qVarA);
            c0258p2.U();
            if (c0258p2.f3668O) {
                c0258p2.l(c1803j);
            } else {
                c0258p2.d0();
            }
            C0234d.R(c0258p2, c1802i, c1603tA2);
            C0234d.R(c0258p2, c1802i2, interfaceC0255n0M3);
            if (c0258p2.f3668O || !U3.j.a(c0258p2.G(), Integer.valueOf(i8))) {
                AbstractC0813y0.r(i8, c0258p2, i8, c1802i3);
            }
            C0234d.R(c0258p2, c1802i4, qVarD3);
            Y1.b bVar2 = this.f4056o;
            H1.b(this.f4059r, null, bVar2.f7049h, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, X2.g.L(c0258p2).f7117f, c0258p2, 0, 0, 65530);
            H1.b(this.f4060s, null, bVar2.f7052k, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, X2.g.L(c0258p2).f7118g, c0258p2, 0, 0, 65530);
            c0258p2.p(true);
            A1 a1G = E0.g(bVar2.f7055n, bVar2.f7053l, bVar2.f7052k, bVar2.f7045d, c0258p2);
            boolean z5 = this.f4053l;
            androidx.compose.material3.a.a(z5, this.f4058q, null, null, false, a1G, null, c0258p2, 0);
            c0258p2.p(true);
            c0258p2.Q(610387732);
            if (z5) {
                AbstractC1587c.a(c0258p2, androidx.compose.foundation.layout.c.d(nVar, 2));
                c0258p2.Q(610389209);
                String str2 = this.f4055n;
                int i9 = this.f4054m;
                if (i9 == 0) {
                    i5 = i9;
                    bVar = bVar2;
                    str = str2;
                    H1.b(AbstractC2128a.g("Chưa có mẫu nào — engine sẽ bỏ qua hành động này. Bấm \"", str2, "\" để nhập mẫu."), null, bVar2.f7059r, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, X2.g.L(c0258p2).f7118g, c0258p2, 0, 0, 65530);
                    c0258p = c0258p2;
                } else {
                    str = str2;
                    i5 = i9;
                    bVar = bVar2;
                    c0258p = c0258p2;
                }
                z3 = false;
                c0258p.p(false);
                E4.l.t(Q.f.b(1794352879, new C0289a0(this.f4061t, this.f4062u, i5, this.f4063v, bVar), c0258p), c0258p, 6);
                X2.g.a(this.f4057p, null, X1.f.f6928n, X1.e.f6923l, false, Q.f.b(-1792099313, new B2.I(str, bVar, 10), c0258p), c0258p, 200064, 18);
            } else {
                c0258p = c0258p2;
                z3 = false;
            }
            c0258p.p(z3);
            c0258p.p(true);
        }
        return G3.C.a;
    }
}

package I2;

import F.H1;
import F.r1;
import I.C0234d;
import I.C0250l;
import I.C0258p;
import I.InterfaceC0255n0;
import I.Z0;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import com.google.android.gms.internal.measurement.AbstractC0813y0;
import q.AbstractC1594j;
import q.AbstractC1598n;
import q.C1591g;
import q.C1603t;
import r0.InterfaceC1642G;
import t0.C1802i;
import t0.C1803j;
import t0.C1804k;
import t0.InterfaceC1805l;
import v.AbstractC1921e;
import z1.AbstractC2128a;

/* JADX INFO: renamed from: I2.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0298j implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f4147l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ int f4148m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ Y1.b f4149n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ Object f4150o;

    public /* synthetic */ C0298j(int i5, Y1.b bVar, Object obj, int i6) {
        this.f4147l = i6;
        this.f4148m = i5;
        this.f4149n = bVar;
        this.f4150o = obj;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        Object objValueOf;
        switch (this.f4147l) {
            case ConfigBackupDto.$stable /* 0 */:
                C0258p c0258p = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p.x()) {
                    c0258p.L();
                } else {
                    U.g gVar = U.b.f6120y;
                    U.n nVar = U.n.a;
                    C1603t c1603tA = q.r.a(AbstractC1594j.f12606c, gVar, c0258p, 48);
                    int i5 = c0258p.f3669P;
                    InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
                    U.q qVarD = U.a.d(c0258p, nVar);
                    InterfaceC1805l.f13649k.getClass();
                    C1803j c1803j = C1804k.f13641b;
                    c0258p.U();
                    if (c0258p.f3668O) {
                        c0258p.l(c1803j);
                    } else {
                        c0258p.d0();
                    }
                    C0234d.R(c0258p, C1804k.f13645f, c1603tA);
                    C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
                    C1802i c1802i = C1804k.f13646g;
                    if (c0258p.f3668O || !U3.j.a(c0258p.G(), Integer.valueOf(i5))) {
                        AbstractC0813y0.r(i5, c0258p, i5, c1802i);
                    }
                    C0234d.R(c0258p, C1804k.f13643d, qVarD);
                    String strValueOf = String.valueOf(this.f4148m);
                    Y1.b bVar = this.f4149n;
                    long j5 = bVar.f7049h;
                    c0258p.Q(258792282);
                    Z0 z02 = Y1.l.f7129c;
                    Y1.f fVar = (Y1.f) c0258p.k(z02);
                    c0258p.p(false);
                    H1.b(strValueOf, null, j5, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, C0.L.a(fVar.f7113b, 0L, 0L, H0.z.f2959s, null, 0L, null, 0L, null, null, 16777211), c0258p, 0, 0, 65530);
                    c0258p.Q(258792282);
                    Y1.f fVar2 = (Y1.f) c0258p.k(z02);
                    c0258p.p(false);
                    H1.b((String) this.f4150o, null, bVar.f7052k, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar2.f7118g, c0258p, 0, 0, 65530);
                    c0258p.p(true);
                }
                break;
            case 1:
                C0258p c0258p2 = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p2.x()) {
                    c0258p2.L();
                } else {
                    C1591g c1591gG = AbstractC1594j.g(4);
                    U.n nVar2 = U.n.a;
                    C1603t c1603tA2 = q.r.a(c1591gG, U.b.f6119x, c0258p2, 6);
                    int i6 = c0258p2.f3669P;
                    InterfaceC0255n0 interfaceC0255n0M2 = c0258p2.m();
                    U.q qVarD2 = U.a.d(c0258p2, nVar2);
                    InterfaceC1805l.f13649k.getClass();
                    C1803j c1803j2 = C1804k.f13641b;
                    c0258p2.U();
                    if (c0258p2.f3668O) {
                        c0258p2.l(c1803j2);
                    } else {
                        c0258p2.d0();
                    }
                    C1802i c1802i2 = C1804k.f13645f;
                    C0234d.R(c0258p2, c1802i2, c1603tA2);
                    C1802i c1802i3 = C1804k.f13644e;
                    C0234d.R(c0258p2, c1802i3, interfaceC0255n0M2);
                    C1802i c1802i4 = C1804k.f13646g;
                    if (c0258p2.f3668O || !U3.j.a(c0258p2.G(), Integer.valueOf(i6))) {
                        AbstractC0813y0.r(i6, c0258p2, i6, c1802i4);
                    }
                    C1802i c1802i5 = C1804k.f13643d;
                    C0234d.R(c0258p2, c1802i5, qVarD2);
                    q.b0 b0VarB = q.a0.b(AbstractC1594j.a, U.b.f6117v, c0258p2, 48);
                    int i7 = c0258p2.f3669P;
                    InterfaceC0255n0 interfaceC0255n0M3 = c0258p2.m();
                    U.q qVarD3 = U.a.d(c0258p2, nVar2);
                    c0258p2.U();
                    if (c0258p2.f3668O) {
                        c0258p2.l(c1803j2);
                    } else {
                        c0258p2.d0();
                    }
                    C0234d.R(c0258p2, c1802i2, b0VarB);
                    C0234d.R(c0258p2, c1802i3, interfaceC0255n0M3);
                    if (c0258p2.f3668O || !U3.j.a(c0258p2.G(), Integer.valueOf(i7))) {
                        AbstractC0813y0.r(i7, c0258p2, i7, c1802i4);
                    }
                    C0234d.R(c0258p2, c1802i5, qVarD3);
                    Y1.b bVar2 = this.f4149n;
                    long j6 = bVar2.f7049h;
                    c0258p2.Q(258792282);
                    Z0 z03 = Y1.l.f7129c;
                    Y1.f fVar3 = (Y1.f) c0258p2.k(z03);
                    c0258p2.p(false);
                    H1.b("Tỉ lệ thả tim", q.c0.a(1.0f), j6, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar3.f7117f, c0258p2, 6, 0, 65528);
                    U.q qVarH = androidx.compose.foundation.layout.b.h(androidx.compose.foundation.a.b(nVar2, bVar2.f7054m, AbstractC1921e.b(6)), 8, 3);
                    InterfaceC1642G interfaceC1642GE = AbstractC1598n.e(U.b.f6107l, false);
                    int i8 = c0258p2.f3669P;
                    InterfaceC0255n0 interfaceC0255n0M4 = c0258p2.m();
                    U.q qVarD4 = U.a.d(c0258p2, qVarH);
                    c0258p2.U();
                    if (c0258p2.f3668O) {
                        c0258p2.l(c1803j2);
                    } else {
                        c0258p2.d0();
                    }
                    C0234d.R(c0258p2, c1802i2, interfaceC1642GE);
                    C0234d.R(c0258p2, c1802i3, interfaceC0255n0M4);
                    if (c0258p2.f3668O || !U3.j.a(c0258p2.G(), Integer.valueOf(i8))) {
                        AbstractC0813y0.r(i8, c0258p2, i8, c1802i4);
                    }
                    C0234d.R(c0258p2, c1802i5, qVarD4);
                    StringBuilder sb = new StringBuilder();
                    int i9 = this.f4148m;
                    sb.append(i9);
                    sb.append("%");
                    String string = sb.toString();
                    c0258p2.Q(258792282);
                    Y1.f fVar4 = (Y1.f) c0258p2.k(z03);
                    c0258p2.p(false);
                    H1.b(string, null, bVar2.f7053l, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, C0.L.a(fVar4.f7121j, 0L, 0L, H0.z.f2959s, null, 0L, null, 0L, null, null, 16777211), c0258p2, 0, 0, 65530);
                    c0258p2.p(true);
                    c0258p2.p(true);
                    if (i9 == 0) {
                        objValueOf = "—";
                    } else {
                        objValueOf = Integer.valueOf(100 / (i9 < 1 ? 1 : i9));
                    }
                    String str = "Cứ ~" + objValueOf + " reel lại thả tim 1 lần. 10–20% tự nhiên nhất.";
                    c0258p2.Q(258792282);
                    Y1.f fVar5 = (Y1.f) c0258p2.k(z03);
                    c0258p2.p(false);
                    H1.b(str, null, bVar2.f7052k, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar5.f7118g, c0258p2, 0, 0, 65530);
                    float f5 = i9;
                    c0258p2.Q(1709126759);
                    T3.c cVar = (T3.c) this.f4150o;
                    boolean zF = c0258p2.f(cVar);
                    Object objG = c0258p2.G();
                    if (zF || objG == C0250l.a) {
                        objG = new X(0, cVar);
                        c0258p2.a0(objG);
                    }
                    c0258p2.p(false);
                    r1.f(f5, (T3.c) objG, null, false, new Z3.a(0.0f, 50.0f), 0, null, null, null, c0258p2, 0, 492);
                    c0258p2.p(true);
                }
                break;
            default:
                C0258p c0258p3 = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p3.x()) {
                    c0258p3.L();
                } else {
                    String strI = ((t2.p) this.f4150o).f13793o ? "Đang lưu…" : AbstractC2128a.i(new StringBuilder("Lưu "), this.f4148m, " tài khoản");
                    long j7 = this.f4149n.f7055n;
                    c0258p3.Q(258792282);
                    Y1.f fVar6 = (Y1.f) c0258p3.k(Y1.l.f7129c);
                    c0258p3.p(false);
                    H1.b(strI, null, j7, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar6.f7114c, c0258p3, 0, 0, 65530);
                }
                break;
        }
        return G3.C.a;
    }

    public C0298j(t2.p pVar, int i5, Y1.b bVar) {
        this.f4147l = 2;
        this.f4150o = pVar;
        this.f4148m = i5;
        this.f4149n = bVar;
    }
}

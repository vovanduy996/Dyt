package I2;

import com.google.android.gms.internal.measurement.AbstractC0813y0;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import l.AbstractC1297i;
import w1.AbstractC1987H;
import z1.AbstractC2128a;

/* JADX INFO: loaded from: classes.dex */
public final class g0 {
    public static final f0 Companion = new f0();

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final int f4093A;
    public final int B;
    public final int C;
    public final String a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f4094b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final List f4095c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f4096d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f4097e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f4098f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f4099g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f4100h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f4101i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final List f4102j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final Set f4103k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final boolean f4104l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final String f4105m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final boolean f4106n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final int f4107o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final int f4108p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final int f4109q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final int f4110r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final boolean f4111s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final int f4112t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final int f4113u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final boolean f4114v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f4115w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final int f4116x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final int f4117y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final boolean f4118z;

    public g0(String str, int i5, List list, int i6, int i7, int i8, int i9, int i10, boolean z3, List list2, Set set, boolean z5, String str2, boolean z6, int i11, int i12, int i13, int i14, boolean z7, int i15, int i16, boolean z8, int i17, int i18, int i19, boolean z9, int i20, int i21, int i22) {
        U3.j.f(str, "platformCode");
        U3.j.f(list, "presets");
        U3.j.f(list2, "availableAccounts");
        U3.j.f(set, "selectedAccountKeys");
        U3.j.f(str2, "customDialogInput");
        this.a = str;
        this.f4094b = i5;
        this.f4095c = list;
        this.f4096d = i6;
        this.f4097e = i7;
        this.f4098f = i8;
        this.f4099g = i9;
        this.f4100h = i10;
        this.f4101i = z3;
        this.f4102j = list2;
        this.f4103k = set;
        this.f4104l = z5;
        this.f4105m = str2;
        this.f4106n = z6;
        this.f4107o = i11;
        this.f4108p = i12;
        this.f4109q = i13;
        this.f4110r = i14;
        this.f4111s = z7;
        this.f4112t = i15;
        this.f4113u = i16;
        this.f4114v = z8;
        this.f4115w = i17;
        this.f4116x = i18;
        this.f4117y = i19;
        this.f4118z = z9;
        this.f4093A = i20;
        this.B = i21;
        this.C = i22;
    }

    public static g0 a(g0 g0Var, int i5, int i6, int i7, int i8, int i9, int i10, boolean z3, ArrayList arrayList, Set set, boolean z5, String str, boolean z6, int i11, int i12, int i13, int i14, boolean z7, int i15, int i16, boolean z8, int i17, int i18, int i19, boolean z9, int i20, int i21, int i22, int i23) {
        String str2 = g0Var.a;
        int i24 = (i23 & 2) != 0 ? g0Var.f4094b : i5;
        List list = g0Var.f4095c;
        int i25 = (i23 & 8) != 0 ? g0Var.f4096d : i6;
        int i26 = (i23 & 16) != 0 ? g0Var.f4097e : i7;
        int i27 = (i23 & 32) != 0 ? g0Var.f4098f : i8;
        int i28 = (i23 & 64) != 0 ? g0Var.f4099g : i9;
        int i29 = (i23 & 128) != 0 ? g0Var.f4100h : i10;
        boolean z10 = (i23 & 256) != 0 ? g0Var.f4101i : z3;
        List list2 = (i23 & 512) != 0 ? g0Var.f4102j : arrayList;
        Set set2 = (i23 & 1024) != 0 ? g0Var.f4103k : set;
        boolean z11 = (i23 & 2048) != 0 ? g0Var.f4104l : z5;
        String str3 = (i23 & 4096) != 0 ? g0Var.f4105m : str;
        boolean z12 = (i23 & 8192) != 0 ? g0Var.f4106n : z6;
        int i30 = (i23 & 16384) != 0 ? g0Var.f4107o : i11;
        int i31 = (i23 & 32768) != 0 ? g0Var.f4108p : i12;
        int i32 = (65536 & i23) != 0 ? g0Var.f4109q : i13;
        int i33 = (131072 & i23) != 0 ? g0Var.f4110r : i14;
        boolean z13 = (262144 & i23) != 0 ? g0Var.f4111s : z7;
        int i34 = (524288 & i23) != 0 ? g0Var.f4112t : i15;
        int i35 = (1048576 & i23) != 0 ? g0Var.f4113u : i16;
        boolean z14 = (2097152 & i23) != 0 ? g0Var.f4114v : z8;
        int i36 = (4194304 & i23) != 0 ? g0Var.f4115w : i17;
        int i37 = (8388608 & i23) != 0 ? g0Var.f4116x : i18;
        int i38 = (16777216 & i23) != 0 ? g0Var.f4117y : i19;
        boolean z15 = (33554432 & i23) != 0 ? g0Var.f4118z : z9;
        int i39 = (67108864 & i23) != 0 ? g0Var.f4093A : i20;
        int i40 = (134217728 & i23) != 0 ? g0Var.B : i21;
        int i41 = (i23 & 268435456) != 0 ? g0Var.C : i22;
        g0Var.getClass();
        U3.j.f(str2, "platformCode");
        U3.j.f(list, "presets");
        U3.j.f(list2, "availableAccounts");
        U3.j.f(set2, "selectedAccountKeys");
        U3.j.f(str3, "customDialogInput");
        return new g0(str2, i24, list, i25, i26, i27, i28, i29, z10, list2, set2, z11, str3, z12, i30, i31, i32, i33, z13, i34, i35, z14, i36, i37, i38, z15, i39, i40, i41);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof g0)) {
            return false;
        }
        g0 g0Var = (g0) obj;
        return U3.j.a(this.a, g0Var.a) && this.f4094b == g0Var.f4094b && U3.j.a(this.f4095c, g0Var.f4095c) && this.f4096d == g0Var.f4096d && this.f4097e == g0Var.f4097e && this.f4098f == g0Var.f4098f && this.f4099g == g0Var.f4099g && this.f4100h == g0Var.f4100h && this.f4101i == g0Var.f4101i && U3.j.a(this.f4102j, g0Var.f4102j) && U3.j.a(this.f4103k, g0Var.f4103k) && this.f4104l == g0Var.f4104l && U3.j.a(this.f4105m, g0Var.f4105m) && this.f4106n == g0Var.f4106n && this.f4107o == g0Var.f4107o && this.f4108p == g0Var.f4108p && this.f4109q == g0Var.f4109q && this.f4110r == g0Var.f4110r && this.f4111s == g0Var.f4111s && this.f4112t == g0Var.f4112t && this.f4113u == g0Var.f4113u && this.f4114v == g0Var.f4114v && this.f4115w == g0Var.f4115w && this.f4116x == g0Var.f4116x && this.f4117y == g0Var.f4117y && this.f4118z == g0Var.f4118z && this.f4093A == g0Var.f4093A && this.B == g0Var.B && this.C == g0Var.C;
    }

    public final int hashCode() {
        return Integer.hashCode(this.C) + AbstractC1297i.b(this.B, AbstractC1297i.b(this.f4093A, AbstractC0813y0.f(AbstractC1297i.b(this.f4117y, AbstractC1297i.b(this.f4116x, AbstractC1297i.b(this.f4115w, AbstractC0813y0.f(AbstractC1297i.b(this.f4113u, AbstractC1297i.b(this.f4112t, AbstractC0813y0.f(AbstractC1297i.b(this.f4110r, AbstractC1297i.b(this.f4109q, AbstractC1297i.b(this.f4108p, AbstractC1297i.b(this.f4107o, AbstractC0813y0.f(AbstractC1987H.b(AbstractC0813y0.f((this.f4103k.hashCode() + AbstractC0813y0.g(this.f4102j, AbstractC0813y0.f(AbstractC1297i.b(this.f4100h, AbstractC1297i.b(this.f4099g, AbstractC1297i.b(this.f4098f, AbstractC1297i.b(this.f4097e, AbstractC1297i.b(this.f4096d, AbstractC0813y0.g(this.f4095c, AbstractC1297i.b(this.f4094b, this.a.hashCode() * 31, 31), 31), 31), 31), 31), 31), 31), 31, this.f4101i), 31)) * 31, 31, this.f4104l), 31, this.f4105m), 31, this.f4106n), 31), 31), 31), 31), 31, this.f4111s), 31), 31), 31, this.f4114v), 31), 31), 31), 31, this.f4118z), 31), 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("WarmupSetupUiState(platformCode=");
        sb.append(this.a);
        sb.append(", durationMin=");
        sb.append(this.f4094b);
        sb.append(", presets=");
        sb.append(this.f4095c);
        sb.append(", likeProbabilityPct=");
        sb.append(this.f4096d);
        sb.append(", watchMinSec=");
        sb.append(this.f4097e);
        sb.append(", watchMaxSec=");
        sb.append(this.f4098f);
        sb.append(", actionDelayMinSec=");
        sb.append(this.f4099g);
        sb.append(", actionDelayMaxSec=");
        sb.append(this.f4100h);
        sb.append(", accessibilityEnabled=");
        sb.append(this.f4101i);
        sb.append(", availableAccounts=");
        sb.append(this.f4102j);
        sb.append(", selectedAccountKeys=");
        sb.append(this.f4103k);
        sb.append(", customDialogOpen=");
        sb.append(this.f4104l);
        sb.append(", customDialogInput=");
        sb.append(this.f4105m);
        sb.append(", viewCommentEnabled=");
        sb.append(this.f4106n);
        sb.append(", viewCommentEveryMin=");
        sb.append(this.f4107o);
        sb.append(", viewCommentEveryMax=");
        sb.append(this.f4108p);
        sb.append(", viewCommentDurationMinSec=");
        sb.append(this.f4109q);
        sb.append(", viewCommentDurationMaxSec=");
        sb.append(this.f4110r);
        sb.append(", copyLinkEnabled=");
        sb.append(this.f4111s);
        sb.append(", copyLinkEveryMin=");
        sb.append(this.f4112t);
        sb.append(", copyLinkEveryMax=");
        sb.append(this.f4113u);
        sb.append(", postCommentEnabled=");
        sb.append(this.f4114v);
        sb.append(", postCommentEveryMin=");
        sb.append(this.f4115w);
        sb.append(", postCommentEveryMax=");
        sb.append(this.f4116x);
        sb.append(", postCommentTemplateCount=");
        sb.append(this.f4117y);
        sb.append(", replyCommentEnabled=");
        sb.append(this.f4118z);
        sb.append(", replyCommentEveryMin=");
        sb.append(this.f4093A);
        sb.append(", replyCommentEveryMax=");
        sb.append(this.B);
        sb.append(", replyCommentTemplateCount=");
        return AbstractC2128a.i(sb, this.C, ")");
    }
}

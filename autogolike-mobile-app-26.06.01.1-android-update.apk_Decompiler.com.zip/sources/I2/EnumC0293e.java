package I2;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: I2.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC0293e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final EnumC0293e f4083l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final EnumC0293e f4084m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final /* synthetic */ EnumC0293e[] f4085n;

    static {
        EnumC0293e enumC0293e = new EnumC0293e("Watch", 0);
        f4083l = enumC0293e;
        EnumC0293e enumC0293e2 = new EnumC0293e("ActionDelay", 1);
        f4084m = enumC0293e2;
        f4085n = new EnumC0293e[]{enumC0293e, enumC0293e2};
    }

    public static EnumC0293e valueOf(String str) {
        return (EnumC0293e) Enum.valueOf(EnumC0293e.class, str);
    }

    public static EnumC0293e[] values() {
        return (EnumC0293e[]) f4085n.clone();
    }
}

package I2;

import I.C0234d;
import I.C0258p;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import f.C0933a;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class F implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f3938l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ String f3939m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ T3.c f3940n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ T3.a f3941o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ T3.a f3942p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ int f3943q;

    public /* synthetic */ F(String str, T3.c cVar, T3.a aVar, T3.a aVar2, int i5, int i6) {
        this.f3938l = i6;
        this.f3939m = str;
        this.f3940n = cVar;
        this.f3941o = aVar;
        this.f3942p = aVar2;
        this.f3943q = i5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        switch (this.f3938l) {
            case ConfigBackupDto.$stable /* 0 */:
                ((Integer) obj2).intValue();
                E4.l.j(this.f3939m, this.f3940n, this.f3941o, this.f3942p, (C0258p) obj, C0234d.U(this.f3943q | 1));
                break;
            default:
                ((Integer) obj2).intValue();
                C0933a.h(this.f3939m, this.f3940n, this.f3941o, this.f3942p, (C0258p) obj, C0234d.U(this.f3943q | 1));
                break;
        }
        return G3.C.a;
    }
}

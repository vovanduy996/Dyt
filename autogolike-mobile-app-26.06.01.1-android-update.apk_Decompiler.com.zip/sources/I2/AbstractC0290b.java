package I2;

/* JADX INFO: renamed from: I2.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0290b {
    public static final Q.a a = new Q.a(-926480849, C0288a.f4042m, false);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Q.a f4052b = new Q.a(-1838563400, C0288a.f4043n, false);
}

package I2;

import F.AbstractC0121o0;
import F.H1;
import I.C0234d;
import I.C0250l;
import I.C0258p;
import I.InterfaceC0233c0;
import I.InterfaceC0255n0;
import com.google.android.gms.internal.measurement.AbstractC0813y0;
import q.AbstractC1587c;
import q.AbstractC1594j;
import q.C1603t;
import t0.C1802i;
import t0.C1803j;
import t0.C1804k;
import t0.InterfaceC1805l;

/* JADX INFO: loaded from: classes.dex */
public final class Z implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ boolean f4035l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ int f4036m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ int f4037n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ Y1.b f4038o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0233c0 f4039p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ String f4040q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0233c0 f4041r;

    public Z(boolean z3, int i5, int i6, Y1.b bVar, InterfaceC0233c0 interfaceC0233c0, String str, InterfaceC0233c0 interfaceC0233c02) {
        this.f4035l = z3;
        this.f4036m = i5;
        this.f4037n = i6;
        this.f4038o = bVar;
        this.f4039p = interfaceC0233c0;
        this.f4040q = str;
        this.f4041r = interfaceC0233c02;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        String strK;
        C0258p c0258p = (C0258p) obj;
        if ((((Number) obj2).intValue() & 3) == 2 && c0258p.x()) {
            c0258p.L();
        } else {
            U.n nVar = U.n.a;
            C1603t c1603tA = q.r.a(AbstractC1594j.f12606c, U.b.f6119x, c0258p, 0);
            int i5 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            U.q qVarD = U.a.d(c0258p, nVar);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C1802i c1802i = C1804k.f13645f;
            C0234d.R(c0258p, c1802i, c1603tA);
            C1802i c1802i2 = C1804k.f13644e;
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M);
            C1802i c1802i3 = C1804k.f13646g;
            if (c0258p.f3668O || !U3.j.a(c0258p.G(), Integer.valueOf(i5))) {
                AbstractC0813y0.r(i5, c0258p, i5, c1802i3);
            }
            C1802i c1802i4 = C1804k.f13643d;
            C0234d.R(c0258p, c1802i4, qVarD);
            q.b0 b0VarB = q.a0.b(AbstractC1594j.g(8), U.b.f6116u, c0258p, 6);
            int i6 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M2 = c0258p.m();
            U.q qVarD2 = U.a.d(c0258p, nVar);
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, c1802i, b0VarB);
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M2);
            if (c0258p.f3668O || !U3.j.a(c0258p.G(), Integer.valueOf(i6))) {
                AbstractC0813y0.r(i6, c0258p, i6, c1802i3);
            }
            C0234d.R(c0258p, c1802i4, qVarD2);
            InterfaceC0233c0 interfaceC0233c0 = this.f4039p;
            String str = (String) interfaceC0233c0.getValue();
            w.Q q5 = new w.Q(3, 123);
            U.q qVarA = q.c0.a(1.0f);
            c0258p.Q(-1941441500);
            Object objG = c0258p.G();
            I.W w5 = C0250l.a;
            if (objG == w5) {
                objG = new A2.e(interfaceC0233c0, 11);
                c0258p.a0(objG);
            }
            c0258p.p(false);
            String str2 = this.f4040q;
            Y1.b bVar = this.f4038o;
            AbstractC0121o0.a(str, (T3.c) objG, qVarA, false, false, null, Q.f.b(1592592949, new B2.I(str2, bVar, 8), c0258p), null, null, null, null, null, null, false, null, q5, null, true, 0, 0, null, null, null, c0258p, 1572912, 12779520, 0, 8224696);
            InterfaceC0233c0 interfaceC0233c02 = this.f4041r;
            String str3 = (String) interfaceC0233c02.getValue();
            w.Q q6 = new w.Q(3, 123);
            U.q qVarA2 = q.c0.a(1.0f);
            c0258p.Q(-1941425436);
            Object objG2 = c0258p.G();
            if (objG2 == w5) {
                objG2 = new A2.e(interfaceC0233c02, 12);
                c0258p.a0(objG2);
            }
            c0258p.p(false);
            AbstractC0121o0.a(str3, (T3.c) objG2, qVarA2, false, false, null, Q.f.b(-979432866, new B2.I(str2, bVar, 9), c0258p), null, null, null, null, null, null, false, null, q6, null, true, 0, 0, null, null, null, c0258p, 1572912, 12779520, 0, 8224696);
            c0258p.p(true);
            AbstractC1587c.a(c0258p, androidx.compose.foundation.layout.c.d(nVar, 6));
            boolean z3 = this.f4035l;
            int i7 = this.f4036m;
            int i8 = this.f4037n;
            if (z3) {
                strK = AbstractC0813y0.k(i7, i8, "Giá trị ", "–");
            } else {
                strK = "Giá trị " + i7 + "–" + i8 + ", Tối đa ≥ Tối thiểu";
            }
            long j5 = !z3 ? bVar.f7056o : bVar.f7052k;
            c0258p.Q(258792282);
            Y1.f fVar = (Y1.f) c0258p.k(Y1.l.f7129c);
            c0258p.p(false);
            H1.b(strK, null, j5, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar.f7118g, c0258p, 0, 0, 65530);
            c0258p.p(true);
        }
        return G3.C.a;
    }
}

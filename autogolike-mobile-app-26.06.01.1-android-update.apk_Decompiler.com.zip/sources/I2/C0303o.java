package I2;

import G3.AbstractC0164a;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: I2.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0303o extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f4186p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ C0313z f4187q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0303o(C0313z c0313z, Continuation continuation) {
        super(2, continuation);
        this.f4187q = c0313z;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) throws Throwable {
        ((C0303o) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
        return L3.a.f4629l;
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new C0303o(this.f4187q, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) throws Throwable {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f4186p;
        if (i5 != 0) {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
            throw new G3.f();
        }
        AbstractC0164a.e(obj);
        C0313z c0313z = this.f4187q;
        i4.J j5 = c0313z.f4281m;
        C0301m c0301m = new C0301m(c0313z, 1);
        this.f4186p = 1;
        ((i4.c0) j5.f10592l).d(c0301m, this);
        return aVar;
    }
}

package I2;

import G3.AbstractC0164a;
import N1.C0372j;
import i4.InterfaceC1184h;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: I2.w, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0310w extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ C0313z f4249p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ C0372j f4250q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0310w(C0313z c0313z, C0372j c0372j, Continuation continuation) {
        super(2, continuation);
        this.f4249p = c0313z;
        this.f4250q = c0372j;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        C0310w c0310w = (C0310w) m((InterfaceC1184h) obj, (Continuation) obj2);
        G3.C c5 = G3.C.a;
        c0310w.o(c5);
        return c5;
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new C0310w(this.f4249p, this.f4250q, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        AbstractC0164a.e(obj);
        this.f4249p.a.a(this.f4250q);
        return G3.C.a;
    }
}

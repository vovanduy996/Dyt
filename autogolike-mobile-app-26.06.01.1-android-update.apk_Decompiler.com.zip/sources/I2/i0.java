package I2;

import com.autogolike.mobile.core.account.LocalSocialAccount;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import i4.InterfaceC1184h;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import kotlin.coroutines.Continuation;

/* JADX INFO: loaded from: classes.dex */
public final class i0 implements InterfaceC1184h {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f4145l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ A0 f4146m;

    public /* synthetic */ i0(A0 a02, int i5) {
        this.f4145l = i5;
        this.f4146m = a02;
    }

    @Override // i4.InterfaceC1184h
    public final Object k(Object obj, Continuation continuation) {
        switch (this.f4145l) {
            case ConfigBackupDto.$stable /* 0 */:
                int iIntValue = ((Number) obj).intValue();
                i4.c0 c0Var = this.f4146m.f3897f;
                while (true) {
                    Object value = c0Var.getValue();
                    i4.c0 c0Var2 = c0Var;
                    if (!c0Var2.j(value, g0.a((g0) value, 0, 0, 0, 0, 0, 0, false, null, null, false, null, false, 0, 0, 0, 0, false, 0, 0, false, 0, 0, iIntValue, false, 0, 0, 0, 520093695))) {
                        c0Var = c0Var2;
                    }
                    break;
                }
                break;
            case 1:
                int iIntValue2 = ((Number) obj).intValue();
                i4.c0 c0Var3 = this.f4146m.f3897f;
                while (true) {
                    Object value2 = c0Var3.getValue();
                    i4.c0 c0Var4 = c0Var3;
                    if (!c0Var4.j(value2, g0.a((g0) value2, 0, 0, 0, 0, 0, 0, false, null, null, false, null, false, 0, 0, 0, 0, false, 0, 0, false, 0, 0, 0, false, 0, 0, iIntValue2, 268435455))) {
                        c0Var3 = c0Var4;
                    }
                    break;
                }
                break;
            default:
                ArrayList arrayList = new ArrayList();
                for (Object obj2 : (List) obj) {
                    if (((LocalSocialAccount) obj2).getEnabled()) {
                        arrayList.add(obj2);
                    }
                }
                i4.c0 c0Var5 = this.f4146m.f3897f;
                while (true) {
                    Object value3 = c0Var5.getValue();
                    g0 g0Var = (g0) value3;
                    Set set = g0Var.f4103k;
                    ArrayList arrayList2 = new ArrayList(H3.o.X0(arrayList, 10));
                    Iterator it = arrayList.iterator();
                    while (it.hasNext()) {
                        arrayList2.add(((LocalSocialAccount) it.next()).getUsername());
                    }
                    Set setL1 = H3.m.l1(set, H3.m.F1(arrayList2));
                    if (setL1.isEmpty() && g0Var.f4103k.isEmpty()) {
                        ArrayList arrayList3 = new ArrayList(H3.o.X0(arrayList, 10));
                        Iterator it2 = arrayList.iterator();
                        while (it2.hasNext()) {
                            arrayList3.add(((LocalSocialAccount) it2.next()).getUsername());
                        }
                        setL1 = H3.m.F1(arrayList3);
                    }
                    ArrayList arrayList4 = arrayList;
                    if (!c0Var5.j(value3, g0.a(g0Var, 0, 0, 0, 0, 0, 0, false, arrayList, setL1, false, null, false, 0, 0, 0, 0, false, 0, 0, false, 0, 0, 0, false, 0, 0, 0, 536869375))) {
                        arrayList = arrayList4;
                    }
                    break;
                }
                break;
        }
        return G3.C.a;
    }
}

package I2;

import F.H1;
import I.C0234d;
import I.C0250l;
import I.C0258p;
import I.InterfaceC0255n0;
import com.google.android.gms.internal.measurement.AbstractC0813y0;
import java.util.Iterator;
import java.util.List;
import q.AbstractC1594j;
import q.C1586b;
import q.C1591g;
import q.C1603t;
import t0.C1802i;
import t0.C1803j;
import t0.C1804k;
import t0.InterfaceC1805l;

/* JADX INFO: loaded from: classes.dex */
public final class U implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ Y1.b f4015l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ List f4016m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ boolean f4017n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ int f4018o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ T3.a f4019p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ T3.c f4020q;

    public U(Y1.b bVar, List list, boolean z3, int i5, T3.a aVar, T3.c cVar) {
        this.f4015l = bVar;
        this.f4016m = list;
        this.f4017n = z3;
        this.f4018o = i5;
        this.f4019p = aVar;
        this.f4020q = cVar;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        boolean z3;
        int i5;
        C0258p c0258p = (C0258p) obj;
        if ((((Number) obj2).intValue() & 3) == 2 && c0258p.x()) {
            c0258p.L();
        } else {
            C1586b c1586b = AbstractC1594j.a;
            C1591g c1591gG = AbstractC1594j.g(X2.g.I(c0258p).f7107c);
            U.n nVar = U.n.a;
            C1603t c1603tA = q.r.a(c1591gG, U.b.f6119x, c0258p, 0);
            int i6 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            U.q qVarD = U.a.d(c0258p, nVar);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C1802i c1802i = C1804k.f13645f;
            C0234d.R(c0258p, c1802i, c1603tA);
            C1802i c1802i2 = C1804k.f13644e;
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M);
            C1802i c1802i3 = C1804k.f13646g;
            if (c0258p.f3668O || !U3.j.a(c0258p.G(), Integer.valueOf(i6))) {
                AbstractC0813y0.r(i6, c0258p, i6, c1802i3);
            }
            C1802i c1802i4 = C1804k.f13643d;
            C0234d.R(c0258p, c1802i4, qVarD);
            Y1.b bVar = this.f4015l;
            H1.b("Thời lượng / mỗi acc", null, bVar.f7049h, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, X2.g.L(c0258p).f7117f, c0258p, 6, 0, 65530);
            H1.b("Mỗi tài khoản nuôi đủ số phút này rồi tự chuyển sang acc kế tiếp.", null, bVar.f7052k, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, X2.g.L(c0258p).f7118g, c0258p, 6, 0, 65530);
            C1591g c1591gG2 = AbstractC1594j.g(X2.g.I(c0258p).f7107c);
            U.q qVarC = androidx.compose.foundation.layout.c.c(nVar, 1.0f);
            q.b0 b0VarB = q.a0.b(c1591gG2, U.b.f6116u, c0258p, 0);
            int i7 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M2 = c0258p.m();
            U.q qVarD2 = U.a.d(c0258p, qVarC);
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, c1802i, b0VarB);
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M2);
            if (c0258p.f3668O || !U3.j.a(c0258p.G(), Integer.valueOf(i7))) {
                AbstractC0813y0.r(i7, c0258p, i7, c1802i3);
            }
            C0234d.R(c0258p, c1802i4, qVarD2);
            c0258p.Q(1832029450);
            Iterator it = this.f4016m.iterator();
            while (true) {
                boolean zHasNext = it.hasNext();
                z3 = this.f4017n;
                i5 = this.f4018o;
                if (!zHasNext) {
                    break;
                }
                int iIntValue = ((Number) it.next()).intValue();
                String strValueOf = String.valueOf(iIntValue);
                boolean z5 = !z3 && iIntValue == i5;
                U.q qVarA = q.c0.a(1.0f);
                c0258p.Q(-1650104594);
                T3.c cVar = this.f4020q;
                boolean zF = c0258p.f(cVar) | c0258p.d(iIntValue);
                Object objG = c0258p.G();
                if (zF || objG == C0250l.a) {
                    objG = new B2.K(iIntValue, 2, cVar);
                    c0258p.a0(objG);
                }
                c0258p.p(false);
                E4.l.o(strValueOf, "phút", z5, qVarA, (T3.a) objG, c0258p, 48);
            }
            c0258p.p(false);
            E4.l.o(z3 ? String.valueOf(i5) : "—", z3 ? "phút" : "Khác", z3, q.c0.a(1.0f), this.f4019p, c0258p, 0);
            c0258p.p(true);
            c0258p.p(true);
        }
        return G3.C.a;
    }
}

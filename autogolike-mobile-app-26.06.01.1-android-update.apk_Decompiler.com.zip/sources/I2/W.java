package I2;

import F.H1;
import I.C0258p;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import m.AbstractC1340a0;
import m.H0;
import r.C1624d;

/* JADX INFO: loaded from: classes.dex */
public final class W implements T3.f {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f4024l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Object f4025m;

    public /* synthetic */ W(int i5, Object obj) {
        this.f4024l = i5;
        this.f4025m = obj;
    }

    @Override // T3.f
    public final Object h(Object obj, Object obj2, Object obj3) {
        switch (this.f4024l) {
            case ConfigBackupDto.$stable /* 0 */:
                C0258p c0258p = (C0258p) obj2;
                int iIntValue = ((Number) obj3).intValue();
                U3.j.f((q.M) obj, "$this$FlowRow");
                if ((iIntValue & 17) == 16 && c0258p.x()) {
                    c0258p.L();
                } else {
                    ((Q.a) this.f4025m).i(c0258p, 0);
                }
                break;
            case 1:
                C0258p c0258p2 = (C0258p) obj2;
                int iIntValue2 = ((Number) obj3).intValue();
                U3.j.f((C1624d) obj, "$this$item");
                if ((iIntValue2 & 17) == 16 && c0258p2.x()) {
                    c0258p2.L();
                } else {
                    E4.l.s((X1.o) this.f4025m, c0258p2, 0);
                }
                break;
            case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                C0258p c0258p3 = (C0258p) obj2;
                int iIntValue3 = ((Number) obj3).intValue();
                U3.j.f((C1624d) obj, "$this$item");
                if ((iIntValue3 & 17) == 16 && c0258p3.x()) {
                    c0258p3.L();
                } else {
                    H0.u(((t2.p) this.f4025m).f13791m, c0258p3, 0);
                }
                break;
            case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                C0258p c0258p4 = (C0258p) obj2;
                int iIntValue4 = ((Number) obj3).intValue();
                U3.j.f((C1624d) obj, "$this$item");
                if ((iIntValue4 & 17) == 16 && c0258p4.x()) {
                    c0258p4.L();
                } else {
                    AbstractC1340a0.A(((u2.k) this.f4025m).f14283b, c0258p4, 0);
                }
                break;
            default:
                C0258p c0258p5 = (C0258p) obj2;
                int iIntValue5 = ((Number) obj3).intValue();
                U3.j.f((C1624d) obj, "$this$item");
                if ((iIntValue5 & 17) == 16 && c0258p5.x()) {
                    c0258p5.L();
                } else {
                    String str = "→ " + ((String) this.f4025m);
                    c0258p5.Q(-1101863115);
                    Y1.b bVar = (Y1.b) c0258p5.k(Y1.i.a);
                    c0258p5.p(false);
                    long j5 = bVar.f7052k;
                    c0258p5.Q(258792282);
                    Y1.f fVar = (Y1.f) c0258p5.k(Y1.l.f7129c);
                    c0258p5.p(false);
                    H1.b(str, null, j5, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar.f7122k, c0258p5, 0, 0, 65530);
                }
                break;
        }
        return G3.C.a;
    }
}

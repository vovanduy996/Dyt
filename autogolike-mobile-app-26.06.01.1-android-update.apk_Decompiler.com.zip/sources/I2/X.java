package I2;

import com.autogolike.mobile.core.backup.ConfigBackupDto;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class X implements T3.c {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f4026l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ T3.c f4027m;

    public /* synthetic */ X(int i5, T3.c cVar) {
        this.f4026l = i5;
        this.f4027m = cVar;
    }

    @Override // T3.c
    public final Object invoke(Object obj) {
        switch (this.f4026l) {
            case ConfigBackupDto.$stable /* 0 */:
                this.f4027m.invoke(Integer.valueOf((int) ((Float) obj).floatValue()));
                break;
            case 1:
                String str = (String) obj;
                U3.j.f(str, "v");
                if (str.length() > 0) {
                    this.f4027m.invoke(c4.l.O0(str, 1));
                }
                break;
            default:
                String str2 = (String) obj;
                U3.j.f(str2, "v");
                if (str2.length() > 0) {
                    this.f4027m.invoke(c4.l.O0(str2, 1));
                }
                break;
        }
        return G3.C.a;
    }
}

package I2;

import G3.AbstractC0164a;
import O1.C0405p;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: loaded from: classes.dex */
public final class l0 extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f4174p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ A0 f4175q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public l0(A0 a02, Continuation continuation) {
        super(2, continuation);
        this.f4175q = a02;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((l0) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new l0(this.f4175q, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f4174p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            A0 a02 = this.f4175q;
            C0405p c0405p = a02.f3894c.f5428b;
            i0 i0Var = new i0(a02, 2);
            this.f4174p = 1;
            if (c0405p.d(i0Var, this) == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return G3.C.a;
    }
}

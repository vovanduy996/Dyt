package I2;

/* JADX INFO: renamed from: I2.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0305q {
}

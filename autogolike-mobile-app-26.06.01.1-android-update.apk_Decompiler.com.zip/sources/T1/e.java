package T1;

/* JADX INFO: loaded from: classes.dex */
public final class e implements g {
    public static final e a = new e();

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof e);
    }

    public final int hashCode() {
        return 2110344606;
    }

    public final String toString() {
        return "Loading";
    }
}

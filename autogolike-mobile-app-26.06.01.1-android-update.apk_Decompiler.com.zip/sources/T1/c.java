package T1;

import com.google.android.gms.internal.measurement.AbstractC0813y0;
import l.AbstractC1297i;
import z1.AbstractC2128a;

/* JADX INFO: loaded from: classes.dex */
public final class c {
    public final int a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f6085b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f6086c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f6087d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f6088e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f6089f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f6090g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f6091h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f6092i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final int f6093j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final int f6094k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final int f6095l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final boolean f6096m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final int f6097n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final boolean f6098o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final int f6099p;

    public /* synthetic */ c(int i5, int i6) {
        this((i6 & 1) != 0 ? 5 : i5, true, 2, 5, 8, 20, 30, 60, true, 50, 60, 120, true, 500, true, 20);
    }

    public static c a(c cVar, int i5, boolean z3, int i6, int i7, int i8, int i9, int i10, int i11, boolean z5, int i12, int i13, int i14, boolean z6, int i15, boolean z7, int i16, int i17) {
        int i18 = (i17 & 1) != 0 ? cVar.a : i5;
        boolean z8 = (i17 & 2) != 0 ? cVar.f6085b : z3;
        int i19 = (i17 & 4) != 0 ? cVar.f6086c : i6;
        int i20 = (i17 & 8) != 0 ? cVar.f6087d : i7;
        int i21 = (i17 & 16) != 0 ? cVar.f6088e : i8;
        int i22 = (i17 & 32) != 0 ? cVar.f6089f : i9;
        int i23 = (i17 & 64) != 0 ? cVar.f6090g : i10;
        int i24 = (i17 & 128) != 0 ? cVar.f6091h : i11;
        boolean z9 = (i17 & 256) != 0 ? cVar.f6092i : z5;
        int i25 = (i17 & 512) != 0 ? cVar.f6093j : i12;
        int i26 = (i17 & 1024) != 0 ? cVar.f6094k : i13;
        int i27 = (i17 & 2048) != 0 ? cVar.f6095l : i14;
        boolean z10 = (i17 & 4096) != 0 ? cVar.f6096m : z6;
        int i28 = (i17 & 8192) != 0 ? cVar.f6097n : i15;
        boolean z11 = (i17 & 16384) != 0 ? cVar.f6098o : z7;
        int i29 = (i17 & 32768) != 0 ? cVar.f6099p : i16;
        cVar.getClass();
        return new c(i18, z8, i19, i20, i21, i22, i23, i24, z9, i25, i26, i27, z10, i28, z11, i29);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return this.a == cVar.a && this.f6085b == cVar.f6085b && this.f6086c == cVar.f6086c && this.f6087d == cVar.f6087d && this.f6088e == cVar.f6088e && this.f6089f == cVar.f6089f && this.f6090g == cVar.f6090g && this.f6091h == cVar.f6091h && this.f6092i == cVar.f6092i && this.f6093j == cVar.f6093j && this.f6094k == cVar.f6094k && this.f6095l == cVar.f6095l && this.f6096m == cVar.f6096m && this.f6097n == cVar.f6097n && this.f6098o == cVar.f6098o && this.f6099p == cVar.f6099p;
    }

    public final int hashCode() {
        return Integer.hashCode(this.f6099p) + AbstractC0813y0.f(AbstractC1297i.b(this.f6097n, AbstractC0813y0.f(AbstractC1297i.b(this.f6095l, AbstractC1297i.b(this.f6094k, AbstractC1297i.b(this.f6093j, AbstractC0813y0.f(AbstractC1297i.b(this.f6091h, AbstractC1297i.b(this.f6090g, AbstractC1297i.b(this.f6089f, AbstractC1297i.b(this.f6088e, AbstractC1297i.b(this.f6087d, AbstractC1297i.b(this.f6086c, AbstractC0813y0.f(Integer.hashCode(this.a) * 31, 31, this.f6085b), 31), 31), 31), 31), 31), 31), 31, this.f6092i), 31), 31), 31), 31, this.f6096m), 31), 31, this.f6098o);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("TokenRunSettings(threads=");
        sb.append(this.a);
        sb.append(", usePerAccountProxy=");
        sb.append(this.f6085b);
        sb.append(", stepDelayMin=");
        sb.append(this.f6086c);
        sb.append(", stepDelayMax=");
        sb.append(this.f6087d);
        sb.append(", taskDelayMin=");
        sb.append(this.f6088e);
        sb.append(", taskDelayMax=");
        sb.append(this.f6089f);
        sb.append(", noJobDelayMin=");
        sb.append(this.f6090g);
        sb.append(", noJobDelayMax=");
        sb.append(this.f6091h);
        sb.append(", breakEnabled=");
        sb.append(this.f6092i);
        sb.append(", breakAfterJobs=");
        sb.append(this.f6093j);
        sb.append(", breakMinSec=");
        sb.append(this.f6094k);
        sb.append(", breakMaxSec=");
        sb.append(this.f6095l);
        sb.append(", stopOnSuccessEnabled=");
        sb.append(this.f6096m);
        sb.append(", stopOnSuccess=");
        sb.append(this.f6097n);
        sb.append(", stopOnFailEnabled=");
        sb.append(this.f6098o);
        sb.append(", stopOnFail=");
        return AbstractC2128a.i(sb, this.f6099p, ")");
    }

    public c(int i5, boolean z3, int i6, int i7, int i8, int i9, int i10, int i11, boolean z5, int i12, int i13, int i14, boolean z6, int i15, boolean z7, int i16) {
        this.a = i5;
        this.f6085b = z3;
        this.f6086c = i6;
        this.f6087d = i7;
        this.f6088e = i8;
        this.f6089f = i9;
        this.f6090g = i10;
        this.f6091h = i11;
        this.f6092i = z5;
        this.f6093j = i12;
        this.f6094k = i13;
        this.f6095l = i14;
        this.f6096m = z6;
        this.f6097n = i15;
        this.f6098o = z7;
        this.f6099p = i16;
    }
}

package T1;

import H3.y;
import U3.j;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class b {
    public final String a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Set f6083b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final c f6084c;

    public b(String str, Set set, c cVar) {
        j.f(set, "selectedAccountIds");
        this.a = str;
        this.f6083b = set;
        this.f6084c = cVar;
    }

    public static b a(b bVar, String str, Set set, c cVar, int i5) {
        if ((i5 & 1) != 0) {
            str = bVar.a;
        }
        if ((i5 & 2) != 0) {
            set = bVar.f6083b;
        }
        if ((i5 & 4) != 0) {
            cVar = bVar.f6084c;
        }
        bVar.getClass();
        j.f(set, "selectedAccountIds");
        return new b(str, set, cVar);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return j.a(this.a, bVar.a) && j.a(this.f6083b, bVar.f6083b) && j.a(this.f6084c, bVar.f6084c);
    }

    public final int hashCode() {
        String str = this.a;
        int iHashCode = (this.f6083b.hashCode() + ((str == null ? 0 : str.hashCode()) * 31)) * 31;
        c cVar = this.f6084c;
        return iHashCode + (cVar != null ? cVar.hashCode() : 0);
    }

    public final String toString() {
        return "SessionDraft(platformCode=" + this.a + ", selectedAccountIds=" + this.f6083b + ", tokenRunSettings=" + this.f6084c + ")";
    }

    public /* synthetic */ b() {
        this(null, y.f3466l, null);
    }
}

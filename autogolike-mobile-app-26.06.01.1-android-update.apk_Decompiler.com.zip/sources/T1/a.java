package T1;

import i4.J;
import i4.O;
import i4.c0;

/* JADX INFO: loaded from: classes.dex */
public final class a {
    public final c0 a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final J f6082b;

    public a() {
        c0 c0VarC = O.c(new b());
        this.a = c0VarC;
        this.f6082b = new J(c0VarC);
    }
}

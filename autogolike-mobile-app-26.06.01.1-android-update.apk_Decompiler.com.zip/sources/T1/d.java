package T1;

/* JADX INFO: loaded from: classes.dex */
public final class d implements g {
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof d)) {
            return false;
        }
        ((d) obj).getClass();
        return true;
    }

    public final int hashCode() {
        return -237592589;
    }

    public final String toString() {
        return "Error(message=Không tải được trang chủ)";
    }
}

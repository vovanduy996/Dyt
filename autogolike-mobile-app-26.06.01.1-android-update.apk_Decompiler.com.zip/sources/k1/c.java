package k1;

import androidx.datastore.preferences.protobuf.F0;
import androidx.datastore.preferences.protobuf.O;

/* JADX INFO: loaded from: classes.dex */
public abstract class c {
    public static final O a = new O(F0.f7536n, F0.f7538p, h.x());
}

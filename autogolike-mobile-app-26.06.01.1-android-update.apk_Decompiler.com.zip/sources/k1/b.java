package k1;

import androidx.datastore.preferences.protobuf.AbstractC0552w;

/* JADX INFO: loaded from: classes.dex */
public final class b extends AbstractC0552w {
}

package k1;

import androidx.datastore.preferences.protobuf.AbstractC0552w;

/* JADX INFO: loaded from: classes.dex */
public final class e extends AbstractC0552w {
}

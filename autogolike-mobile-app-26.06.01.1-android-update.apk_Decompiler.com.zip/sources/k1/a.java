package k1;

import f4.InterfaceC0991y;
import l1.C1321d;

/* JADX INFO: loaded from: classes.dex */
public final class a {
    public final T3.c a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final InterfaceC0991y f11000b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f11001c = new Object();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public volatile C1321d f11002d;

    public a(T3.c cVar, InterfaceC0991y interfaceC0991y) {
        this.a = cVar;
        this.f11000b = interfaceC0991y;
    }
}

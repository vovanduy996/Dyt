package k1;

import androidx.datastore.preferences.protobuf.A;
import androidx.datastore.preferences.protobuf.AbstractC0526b;
import androidx.datastore.preferences.protobuf.AbstractC0552w;
import androidx.datastore.preferences.protobuf.AbstractC0554y;
import androidx.datastore.preferences.protobuf.B;
import androidx.datastore.preferences.protobuf.C0529c0;
import androidx.datastore.preferences.protobuf.C0531d0;
import androidx.datastore.preferences.protobuf.C0538h;
import androidx.datastore.preferences.protobuf.C0553x;
import androidx.datastore.preferences.protobuf.G;
import androidx.datastore.preferences.protobuf.InterfaceC0525a0;
import androidx.datastore.preferences.protobuf.Z;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import l.AbstractC1297i;

/* JADX INFO: loaded from: classes.dex */
public final class f extends AbstractC0554y {
    private static final f DEFAULT_INSTANCE;
    private static volatile Z PARSER = null;
    public static final int STRINGS_FIELD_NUMBER = 1;
    private A strings_ = C0529c0.f7582o;

    static {
        f fVar = new f();
        DEFAULT_INSTANCE = fVar;
        AbstractC0554y.l(f.class, fVar);
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$PrimitiveArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public static void n(f fVar, Iterable iterable) {
        A a = fVar.strings_;
        if (!((AbstractC0526b) a).f7578l) {
            int size = a.size();
            fVar.strings_ = a.l(size == 0 ? 10 : size * 2);
        }
        List list = fVar.strings_;
        Charset charset = B.a;
        iterable.getClass();
        if (iterable instanceof G) {
            List listM = ((G) iterable).m();
            G g3 = (G) list;
            int size2 = list.size();
            for (Object obj : listM) {
                if (obj == null) {
                    String str = "Element at index " + (g3.size() - size2) + " is null.";
                    for (int size3 = g3.size() - 1; size3 >= size2; size3--) {
                        g3.remove(size3);
                    }
                    throw new NullPointerException(str);
                }
                if (obj instanceof C0538h) {
                    g3.p((C0538h) obj);
                } else {
                    g3.add((String) obj);
                }
            }
            return;
        }
        if (iterable instanceof InterfaceC0525a0) {
            list.addAll((Collection) iterable);
            return;
        }
        if ((list instanceof ArrayList) && (iterable instanceof Collection)) {
            ((ArrayList) list).ensureCapacity(((Collection) iterable).size() + list.size());
        }
        int size4 = list.size();
        for (Object obj2 : iterable) {
            if (obj2 == null) {
                String str2 = "Element at index " + (list.size() - size4) + " is null.";
                for (int size5 = list.size() - 1; size5 >= size4; size5--) {
                    list.remove(size5);
                }
                throw new NullPointerException(str2);
            }
            list.add(obj2);
        }
    }

    public static f o() {
        return DEFAULT_INSTANCE;
    }

    public static e q() {
        return (e) ((AbstractC0552w) DEFAULT_INSTANCE.e(5));
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC0554y
    public final Object e(int i5) {
        switch (AbstractC1297i.c(i5)) {
            case ConfigBackupDto.$stable /* 0 */:
                return (byte) 1;
            case 1:
                return null;
            case h.FLOAT_FIELD_NUMBER /* 2 */:
                return new C0531d0(DEFAULT_INSTANCE, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001a", new Object[]{"strings_"});
            case h.INTEGER_FIELD_NUMBER /* 3 */:
                return new f();
            case h.LONG_FIELD_NUMBER /* 4 */:
                return new e(DEFAULT_INSTANCE);
            case h.STRING_FIELD_NUMBER /* 5 */:
                return DEFAULT_INSTANCE;
            case h.STRING_SET_FIELD_NUMBER /* 6 */:
                Z c0553x = PARSER;
                if (c0553x == null) {
                    synchronized (f.class) {
                        try {
                            c0553x = PARSER;
                            if (c0553x == null) {
                                c0553x = new C0553x();
                                PARSER = c0553x;
                            }
                        } finally {
                        }
                        break;
                    }
                }
                return c0553x;
            default:
                throw new UnsupportedOperationException();
        }
    }

    public final A p() {
        return this.strings_;
    }
}

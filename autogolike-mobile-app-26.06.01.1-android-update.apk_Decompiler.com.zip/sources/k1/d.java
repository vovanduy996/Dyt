package k1;

import A.C0013n;
import androidx.datastore.preferences.protobuf.AbstractC0552w;
import androidx.datastore.preferences.protobuf.AbstractC0554y;
import androidx.datastore.preferences.protobuf.C0527b0;
import androidx.datastore.preferences.protobuf.C0531d0;
import androidx.datastore.preferences.protobuf.C0540j;
import androidx.datastore.preferences.protobuf.C0546p;
import androidx.datastore.preferences.protobuf.C0553x;
import androidx.datastore.preferences.protobuf.D;
import androidx.datastore.preferences.protobuf.InterfaceC0533e0;
import androidx.datastore.preferences.protobuf.P;
import androidx.datastore.preferences.protobuf.Z;
import androidx.datastore.preferences.protobuf.n0;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.Map;
import l.AbstractC1297i;

/* JADX INFO: loaded from: classes.dex */
public final class d extends AbstractC0554y {
    private static final d DEFAULT_INSTANCE;
    private static volatile Z PARSER = null;
    public static final int PREFERENCES_FIELD_NUMBER = 1;
    private P preferences_ = P.f7557m;

    static {
        d dVar = new d();
        DEFAULT_INSTANCE = dVar;
        AbstractC0554y.l(d.class, dVar);
    }

    public static P n(d dVar) {
        P p4 = dVar.preferences_;
        if (!p4.f7558l) {
            dVar.preferences_ = p4.c();
        }
        return dVar.preferences_;
    }

    public static b p() {
        return (b) ((AbstractC0552w) DEFAULT_INSTANCE.e(5));
    }

    public static d q(InputStream inputStream) {
        d dVar = DEFAULT_INSTANCE;
        C0540j c0540j = new C0540j(inputStream);
        C0546p c0546pA = C0546p.a();
        AbstractC0554y abstractC0554yK = dVar.k();
        try {
            C0527b0 c0527b0 = C0527b0.f7579c;
            c0527b0.getClass();
            InterfaceC0533e0 interfaceC0533e0A = c0527b0.a(abstractC0554yK.getClass());
            C0013n c0013n = (C0013n) c0540j.f7624b;
            if (c0013n == null) {
                c0013n = new C0013n(c0540j);
            }
            interfaceC0533e0A.e(abstractC0554yK, c0013n, c0546pA);
            interfaceC0533e0A.h(abstractC0554yK);
            if (AbstractC0554y.h(abstractC0554yK, true)) {
                return (d) abstractC0554yK;
            }
            throw new D(new n0().getMessage());
        } catch (D e5) {
            if (e5.f7523l) {
                throw new D(e5.getMessage(), e5);
            }
            throw e5;
        } catch (n0 e6) {
            throw new D(e6.getMessage());
        } catch (IOException e7) {
            if (e7.getCause() instanceof D) {
                throw ((D) e7.getCause());
            }
            throw new D(e7.getMessage(), e7);
        } catch (RuntimeException e8) {
            if (e8.getCause() instanceof D) {
                throw ((D) e8.getCause());
            }
            throw e8;
        }
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC0554y
    public final Object e(int i5) {
        switch (AbstractC1297i.c(i5)) {
            case ConfigBackupDto.$stable /* 0 */:
                return (byte) 1;
            case 1:
                return null;
            case h.FLOAT_FIELD_NUMBER /* 2 */:
                return new C0531d0(DEFAULT_INSTANCE, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0001\u0000\u0000\u00012", new Object[]{"preferences_", c.a});
            case h.INTEGER_FIELD_NUMBER /* 3 */:
                return new d();
            case h.LONG_FIELD_NUMBER /* 4 */:
                return new b(DEFAULT_INSTANCE);
            case h.STRING_FIELD_NUMBER /* 5 */:
                return DEFAULT_INSTANCE;
            case h.STRING_SET_FIELD_NUMBER /* 6 */:
                Z c0553x = PARSER;
                if (c0553x == null) {
                    synchronized (d.class) {
                        try {
                            c0553x = PARSER;
                            if (c0553x == null) {
                                c0553x = new C0553x();
                                PARSER = c0553x;
                            }
                        } finally {
                        }
                        break;
                    }
                }
                return c0553x;
            default:
                throw new UnsupportedOperationException();
        }
    }

    public final Map o() {
        return Collections.unmodifiableMap(this.preferences_);
    }
}

package n3;

import C1.d;
import H0.B;
import H0.F;
import H0.v;
import H0.z;
import K3.g;
import K4.C0323f;
import K4.C0326i;
import K4.w;
import L4.c;
import U3.j;
import X2.e;
import android.graphics.Typeface;
import android.util.Log;
import com.google.android.gms.internal.measurement.C0707c3;
import com.google.android.gms.internal.measurement.C0717e3;
import com.google.android.gms.internal.measurement.C0732h3;
import com.google.android.gms.internal.measurement.C0742j3;
import com.google.android.gms.internal.measurement.C0762n3;
import com.google.android.gms.internal.measurement.C0772p3;
import com.google.android.gms.internal.measurement.G3;
import com.google.android.gms.internal.measurement.I3;
import com.google.android.gms.internal.measurement.L3;
import com.google.android.gms.internal.measurement.N3;
import com.google.android.gms.internal.measurement.W2;
import com.google.android.gms.internal.measurement.Y2;
import com.google.android.gms.internal.measurement.d4;
import com.google.android.gms.internal.measurement.f4;
import com.google.android.gms.internal.measurement.j4;
import com.google.android.gms.internal.measurement.l4;
import com.google.firebase.components.ComponentRegistrar;
import e3.D;
import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import k1.h;
import l3.AbstractC1324b;
import t1.InterfaceC1820b;

/* JADX INFO: loaded from: classes.dex */
public final class b implements InterfaceC1471a, d, F, e, InterfaceC1820b, g, D {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static volatile b f12031m;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f12032l;

    public /* synthetic */ b(int i5) {
        this.f12032l = i5;
    }

    public static final float d(float f5, float[] fArr, float[] fArr2) {
        float f6;
        float f7;
        float f8;
        float f9;
        float fMax;
        float fAbs = Math.abs(f5);
        float fSignum = Math.signum(f5);
        int iBinarySearch = Arrays.binarySearch(fArr, fAbs);
        if (iBinarySearch >= 0) {
            fMax = fSignum * fArr2[iBinarySearch];
        } else {
            int i5 = -(iBinarySearch + 1);
            int i6 = i5 - 1;
            if (i6 >= fArr.length - 1) {
                float f10 = fArr[fArr.length - 1];
                float f11 = fArr2[fArr.length - 1];
                if (f10 == 0.0f) {
                    return 0.0f;
                }
                return (f11 / f10) * f5;
            }
            if (i6 == -1) {
                float f12 = fArr[0];
                f8 = fArr2[0];
                f9 = f12;
                f7 = 0.0f;
                f6 = 0.0f;
            } else {
                float f13 = fArr[i6];
                float f14 = fArr[i5];
                f6 = fArr2[i6];
                f7 = f13;
                f8 = fArr2[i5];
                f9 = f14;
            }
            fMax = fSignum * (((f8 - f6) * Math.max(0.0f, Math.min(1.0f, f7 == f9 ? 0.0f : (fAbs - f7) / (f9 - f7)))) + f6);
        }
        return fMax;
    }

    public static Typeface f(String str, z zVar, int i5) {
        if (v.a(i5, 0) && j.a(zVar, z.f2956p) && (str == null || str.length() == 0)) {
            return Typeface.DEFAULT;
        }
        int iT = AbstractC1324b.t(i5, zVar);
        return (str == null || str.length() == 0) ? Typeface.defaultFromStyle(iT) : Typeface.create(str, iT);
    }

    public static w h(String str, boolean z3) {
        j.f(str, "<this>");
        C0326i c0326i = c.a;
        C0323f c0323f = new C0323f();
        c0323f.j0(str);
        return c.d(c0323f, z3);
    }

    public static w i(File file) {
        String str = w.f4589m;
        String string = file.toString();
        j.e(string, "toString(...)");
        return h(string, false);
    }

    @Override // e3.D
    public Object a() {
        switch (this.f12032l) {
            case 11:
                W2.f8455m.get();
                Long l4 = (Long) Y2.a.a();
                l4.getClass();
                return l4;
            case 12:
                d4.f8559m.get();
                Boolean bool = (Boolean) f4.f8585j.a();
                bool.getClass();
                return bool;
            case 13:
                d4.f8559m.get();
                Boolean bool2 = (Boolean) f4.f8584i.a();
                bool2.getClass();
                return bool2;
            case 14:
                d4.f8559m.get();
                Boolean bool3 = (Boolean) f4.f8586k.a();
                bool3.getClass();
                return bool3;
            case 15:
                j4.f8613m.get();
                Boolean bool4 = (Boolean) l4.a.a();
                bool4.getClass();
                return bool4;
            case 16:
                C0762n3.f8649m.get();
                Boolean bool5 = (Boolean) C0772p3.f8669c.a();
                bool5.getClass();
                return bool5;
            case 17:
                L3.f8413m.get();
                Boolean bool6 = (Boolean) N3.a.a();
                bool6.getClass();
                return bool6;
            case 18:
                W2.f8455m.get();
                return Integer.valueOf((int) ((Long) Y2.f8482V.a()).longValue());
            case 19:
                C0732h3.f8600m.get();
                Boolean bool7 = (Boolean) C0742j3.a.a();
                bool7.getClass();
                return bool7;
            case 20:
                G3.f8396m.get();
                Boolean bool8 = (Boolean) I3.a.a();
                bool8.getClass();
                return bool8;
            case 21:
                d4.f8559m.get();
                Boolean bool9 = (Boolean) f4.f8581f.a();
                bool9.getClass();
                return bool9;
            case 22:
                W2.f8455m.get();
                return Integer.valueOf((int) ((Long) Y2.f8479S.a()).longValue());
            case 23:
                W2.f8455m.get();
                return Integer.valueOf((int) ((Long) Y2.f8485Y.a()).longValue());
            case 24:
                W2.f8455m.get();
                Long l5 = (Long) Y2.f8493d0.a();
                l5.getClass();
                return l5;
            case 25:
                C0707c3.f8542m.get();
                Boolean bool10 = (Boolean) C0717e3.f8567b.a();
                bool10.getClass();
                return bool10;
            case 26:
                W2.f8455m.get();
                Long l6 = (Long) Y2.f8514x.a();
                l6.getClass();
                return l6;
            case 27:
                W2.f8455m.get();
                Long l7 = (Long) Y2.f8513w.a();
                l7.getClass();
                return l7;
            case 28:
                C0707c3.f8542m.get();
                Boolean bool11 = (Boolean) C0717e3.f8568c.a();
                bool11.getClass();
                return bool11;
            default:
                W2.f8455m.get();
                return Integer.valueOf((int) ((Long) Y2.f8487a0.a()).longValue());
        }
    }

    @Override // C1.d
    public void b(int i5, Serializable serializable) {
        String str;
        switch (i5) {
            case 1:
                str = "RESULT_INSTALL_SUCCESS";
                break;
            case h.FLOAT_FIELD_NUMBER /* 2 */:
                str = "RESULT_ALREADY_INSTALLED";
                break;
            case h.INTEGER_FIELD_NUMBER /* 3 */:
                str = "RESULT_UNSUPPORTED_ART_VERSION";
                break;
            case h.LONG_FIELD_NUMBER /* 4 */:
                str = "RESULT_NOT_WRITABLE";
                break;
            case h.STRING_FIELD_NUMBER /* 5 */:
                str = "RESULT_DESIRED_FORMAT_UNSUPPORTED";
                break;
            case h.STRING_SET_FIELD_NUMBER /* 6 */:
                str = "RESULT_BASELINE_PROFILE_NOT_FOUND";
                break;
            case h.DOUBLE_FIELD_NUMBER /* 7 */:
                str = "RESULT_IO_EXCEPTION";
                break;
            case 8:
                str = "RESULT_PARSE_EXCEPTION";
                break;
            case 9:
            default:
                str = "";
                break;
            case 10:
                str = "RESULT_INSTALL_SKIP_FILE_SUCCESS";
                break;
            case 11:
                str = "RESULT_DELETE_SKIP_FILE_SUCCESS";
                break;
        }
        if (i5 == 6 || i5 == 7 || i5 == 8) {
            Log.e("ProfileInstaller", str, (Throwable) serializable);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x001b A[PHI: r4
      0x001b: PHI (r4v2 int) = (r4v1 int), (r4v3 int) binds: [B:3:0x0014, B:5:0x0017] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // X2.e
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public X2.d c(android.content.Context r3, java.lang.String r4, X2.c r5) {
        /*
            r2 = this;
            X2.d r0 = new X2.d
            r0.<init>()
            int r1 = r5.c(r3, r4)
            r0.a = r1
            r1 = 1
            int r3 = r5.h(r3, r4, r1)
            r0.f7005b = r3
            int r4 = r0.a
            if (r4 != 0) goto L1b
            r4 = 0
            if (r3 != 0) goto L1b
            r1 = r4
            goto L1e
        L1b:
            if (r4 < r3) goto L1e
            r1 = -1
        L1e:
            r0.f7006c = r1
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: n3.b.c(android.content.Context, java.lang.String, X2.c):X2.d");
    }

    @Override // H0.F
    public Typeface e(B b3, z zVar, int i5) {
        String strConcat = b3.f2889o;
        int i6 = zVar.f2961l / 100;
        if (i6 >= 0 && i6 < 2) {
            strConcat = strConcat.concat("-thin");
        } else if (2 <= i6 && i6 < 4) {
            strConcat = strConcat.concat("-light");
        } else if (i6 != 4) {
            if (i6 == 5) {
                strConcat = strConcat.concat("-medium");
            } else if ((6 > i6 || i6 >= 8) && 8 <= i6 && i6 < 11) {
                strConcat = strConcat.concat("-black");
            }
        }
        Typeface typeface = null;
        if (strConcat.length() != 0) {
            Typeface typefaceF = f(strConcat, zVar, i5);
            if (!j.a(typefaceF, Typeface.create(Typeface.DEFAULT, AbstractC1324b.t(i5, zVar))) && !j.a(typefaceF, f(null, zVar, i5))) {
                typeface = typefaceF;
            }
        }
        return typeface == null ? f(b3.f2889o, zVar, i5) : typeface;
    }

    @Override // H0.F
    public Typeface g(int i5, z zVar) {
        return f(null, zVar, i5);
    }

    public List j(ComponentRegistrar componentRegistrar) {
        ArrayList arrayList = new ArrayList();
        for (q3.b bVar : componentRegistrar.getComponents()) {
            String str = bVar.a;
            if (str != null) {
                C3.d dVar = new C3.d(str, bVar, 1);
                bVar = new q3.b(str, bVar.f12705b, bVar.f12706c, bVar.f12707d, bVar.f12708e, dVar, bVar.f12710g);
            }
            arrayList.add(bVar);
        }
        return arrayList;
    }
}

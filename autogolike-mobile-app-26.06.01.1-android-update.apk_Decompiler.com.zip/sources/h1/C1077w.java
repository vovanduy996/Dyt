package h1;

/* JADX INFO: renamed from: h1.w, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1077w extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public K f10221o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f10222p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f10223q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ K f10224r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f10225s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1077w(K k5, M3.c cVar) {
        super(cVar);
        this.f10224r = k5;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f10223q = obj;
        this.f10225s |= Integer.MIN_VALUE;
        return this.f10224r.g(this);
    }
}

package h1;

import n4.InterfaceC1472a;

/* JADX INFO: loaded from: classes.dex */
public final class O extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public M1.m f10127o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public InterfaceC1472a f10128p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f10129q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ M1.m f10130r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f10131s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public O(M1.m mVar, M3.c cVar) {
        super(cVar);
        this.f10130r = mVar;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f10129q = obj;
        this.f10131s |= Integer.MIN_VALUE;
        return this.f10130r.s(this);
    }
}

package h1;

import i4.InterfaceC1184h;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1070o implements InterfaceC1184h {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final C1070o f10199l = new C1070o();

    @Override // i4.InterfaceC1184h
    public final /* bridge */ /* synthetic */ Object k(Object obj, Continuation continuation) {
        return G3.C.a;
    }
}

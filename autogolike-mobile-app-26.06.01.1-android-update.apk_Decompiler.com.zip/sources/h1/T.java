package h1;

import G3.AbstractC0164a;
import i4.InterfaceC1184h;
import kotlin.coroutines.Continuation;

/* JADX INFO: loaded from: classes.dex */
public final class T extends M3.i implements T3.e {
    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        T t5 = (T) m((InterfaceC1184h) obj, (Continuation) obj2);
        G3.C c5 = G3.C.a;
        t5.o(c5);
        return c5;
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new T(2, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        AbstractC0164a.e(obj);
        return G3.C.a;
    }
}

package h1;

import f4.C0984q;

/* JADX INFO: loaded from: classes.dex */
public final class M {
    public final M3.i a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C0984q f10123b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final V f10124c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final K3.h f10125d;

    /* JADX WARN: Multi-variable type inference failed */
    public M(T3.e eVar, C0984q c0984q, V v5, K3.h hVar) {
        U3.j.f(hVar, "callerContext");
        this.a = (M3.i) eVar;
        this.f10123b = c0984q;
        this.f10124c = v5;
        this.f10125d = hVar;
    }
}

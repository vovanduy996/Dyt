package h1;

/* JADX INFO: renamed from: h1.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1058c extends V {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f10153b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f10154c;

    public C1058c(int i5, int i6, Object obj) {
        super(i6);
        this.f10153b = obj;
        this.f10154c = i5;
    }
}

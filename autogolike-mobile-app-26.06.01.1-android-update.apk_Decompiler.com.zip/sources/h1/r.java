package h1;

import f4.C0984q;

/* JADX INFO: loaded from: classes.dex */
public final class r extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public Object f10205o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public K f10206p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public C0984q f10207q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f10208r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ K f10209s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f10210t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public r(K k5, M3.c cVar) {
        super(cVar);
        this.f10209s = k5;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f10208r = obj;
        this.f10210t |= Integer.MIN_VALUE;
        return K.c(this.f10209s, null, this);
    }
}

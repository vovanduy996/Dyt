package h1;

/* JADX INFO: loaded from: classes.dex */
public final class X extends V {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final X f10149b = new X(-1);
}

package h1;

import i4.InterfaceC1184h;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.v, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1076v extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public C1058c f10217p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f10218q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f10219r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ K f10220s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1076v(K k5, Continuation continuation) {
        super(2, continuation);
        this.f10220s = k5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C1076v) m((InterfaceC1184h) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C1076v c1076v = new C1076v(this.f10220s, continuation);
        c1076v.f10219r = obj;
        return c1076v;
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x009c  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00c0  */
    @Override // M3.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object o(java.lang.Object r10) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 210
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: h1.C1076v.o(java.lang.Object):java.lang.Object");
    }
}

package h1;

import G3.AbstractC0164a;
import f4.p0;
import i4.InterfaceC1184h;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1069n extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ p0 f10198p;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1069n(p0 p0Var, Continuation continuation) {
        super(2, continuation);
        this.f10198p = p0Var;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        C1069n c1069n = (C1069n) m((InterfaceC1184h) obj, (Continuation) obj2);
        G3.C c5 = G3.C.a;
        c1069n.o(c5);
        return c5;
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new C1069n(this.f10198p, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        AbstractC0164a.e(obj);
        this.f10198p.o();
        return G3.C.a;
    }
}

package h1;

import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.u, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1075u extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public /* synthetic */ Object f10214o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f10215p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ O1.A f10216q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1075u(O1.A a, Continuation continuation) {
        super(continuation);
        this.f10216q = a;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f10214o = obj;
        this.f10215p |= Integer.MIN_VALUE;
        return this.f10216q.k(null, this);
    }
}

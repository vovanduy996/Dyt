package h1;

import n4.InterfaceC1472a;

/* JADX INFO: renamed from: h1.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1066k {
    public final /* synthetic */ InterfaceC1472a a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ U3.q f10184b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ U3.u f10185c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ K f10186d;

    public C1066k(InterfaceC1472a interfaceC1472a, U3.q qVar, U3.u uVar, K k5) {
        this.a = interfaceC1472a;
        this.f10184b = qVar;
        this.f10185c = uVar;
        this.f10186d = k5;
    }

    /* JADX WARN: Removed duplicated region for block: B:38:0x00b6 A[Catch: all -> 0x0054, TRY_LEAVE, TryCatch #0 {all -> 0x0054, blocks: (B:21:0x0050, B:36:0x00ae, B:38:0x00b6), top: B:53:0x0050 }] */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00cd  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object a(h1.C1062g r11, M3.c r12) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 231
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: h1.C1066k.a(h1.g, M3.c):java.lang.Object");
    }
}

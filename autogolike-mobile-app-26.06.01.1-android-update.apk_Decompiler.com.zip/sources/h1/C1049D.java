package h1;

import G3.AbstractC0164a;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.D, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1049D extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f10088p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ M3.i f10089q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ C1058c f10090r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public C1049D(T3.e eVar, C1058c c1058c, Continuation continuation) {
        super(2, continuation);
        this.f10089q = (M3.i) eVar;
        this.f10090r = c1058c;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C1049D) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [M3.i, T3.e] */
    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new C1049D(this.f10089q, this.f10090r, continuation);
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [M3.i, T3.e] */
    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f10088p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            Object obj2 = this.f10090r.f10153b;
            this.f10088p = 1;
            obj = this.f10089q.i(obj2, this);
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return obj;
    }
}

package h1;

import java.io.Serializable;
import java.util.Iterator;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1067l extends M3.i implements T3.c {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Object f10187p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public Serializable f10188q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public Object f10189r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public Object f10190s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public Iterator f10191t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f10192u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f10193v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ K f10194w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final /* synthetic */ M1.m f10195x;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1067l(K k5, M1.m mVar, Continuation continuation) {
        super(1, continuation);
        this.f10194w = k5;
        this.f10195x = mVar;
    }

    @Override // T3.c
    public final Object invoke(Object obj) {
        return new C1067l(this.f10194w, this.f10195x, (Continuation) obj).o(G3.C.a);
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x00a7  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x00da A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:30:0x00db  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00e8  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00ed  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0102 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0103  */
    @Override // M3.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object o(java.lang.Object r14) {
        /*
            Method dump skipped, instruction units count: 280
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: h1.C1067l.o(java.lang.Object):java.lang.Object");
    }
}

package h1;

import G3.AbstractC0164a;
import kotlin.coroutines.Continuation;

/* JADX INFO: loaded from: classes.dex */
public final class W extends M3.i implements T3.f {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f10147p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ j1.c f10148q;

    @Override // T3.f
    public final Object h(Object obj, Object obj2, Object obj3) {
        ((Boolean) obj2).getClass();
        W w5 = new W(3, (Continuation) obj3);
        w5.f10148q = (j1.c) obj;
        return w5.o(G3.C.a);
    }

    @Override // M3.a
    public final Object o(Object obj) throws Throwable {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f10147p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            j1.c cVar = this.f10148q;
            this.f10147p = 1;
            cVar.getClass();
            obj = j1.c.a(cVar, this);
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return obj;
    }
}

package h1;

import com.autogolike.mobile.core.backup.ConfigBackupDto;
import kotlin.coroutines.Continuation;
import l.C1288d0;
import l.v0;

/* JADX INFO: renamed from: h1.B, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1047B extends M3.i implements T3.c {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ int f10080p = 0;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f10081q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ Object f10082r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public Object f10083s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ Object f10084t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ Object f10085u;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1047B(U3.u uVar, K k5, U3.s sVar, Continuation continuation) {
        super(1, continuation);
        this.f10084t = uVar;
        this.f10082r = k5;
        this.f10085u = sVar;
    }

    /* JADX WARN: Type inference failed for: r1v3, types: [M3.i, T3.e] */
    @Override // T3.c
    public final Object invoke(Object obj) {
        switch (this.f10080p) {
            case ConfigBackupDto.$stable /* 0 */:
                return new C1047B((U3.u) this.f10084t, (K) this.f10082r, (U3.s) this.f10085u, (Continuation) obj).o(G3.C.a);
            case 1:
                ?? r12 = (M3.i) this.f10085u;
                return new C1047B((K) this.f10082r, (K3.h) this.f10084t, (T3.e) r12, (Continuation) obj).o(G3.C.a);
            default:
                return new C1047B(this.f10082r, (Continuation) obj, (l.C) this.f10085u, (C1288d0) this.f10084t, (v0) this.f10083s).o(G3.C.a);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00a6  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00ab  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00c0  */
    /* JADX WARN: Type inference failed for: r6v3, types: [M3.i, T3.e] */
    @Override // M3.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object o(java.lang.Object r10) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 340
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: h1.C1047B.o(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public C1047B(K k5, K3.h hVar, T3.e eVar, Continuation continuation) {
        super(1, continuation);
        this.f10082r = k5;
        this.f10084t = hVar;
        this.f10085u = (M3.i) eVar;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1047B(Object obj, Continuation continuation, l.C c5, C1288d0 c1288d0, v0 v0Var) {
        super(1, continuation);
        this.f10083s = v0Var;
        this.f10084t = c1288d0;
        this.f10082r = obj;
        this.f10085u = c5;
    }
}

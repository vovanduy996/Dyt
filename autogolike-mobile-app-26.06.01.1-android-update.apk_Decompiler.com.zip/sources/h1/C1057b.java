package h1;

import java.io.IOException;

/* JADX INFO: renamed from: h1.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1057b extends IOException {
}

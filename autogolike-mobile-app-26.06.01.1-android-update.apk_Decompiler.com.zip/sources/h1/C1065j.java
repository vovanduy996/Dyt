package h1;

/* JADX INFO: renamed from: h1.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1065j extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public Object f10176o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Object f10177p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public Object f10178q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public U3.u f10179r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public K f10180s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public /* synthetic */ Object f10181t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ C1066k f10182u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f10183v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1065j(C1066k c1066k, M3.c cVar) {
        super(cVar);
        this.f10182u = c1066k;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f10181t = obj;
        this.f10183v |= Integer.MIN_VALUE;
        return this.f10182u.a(null, this);
    }
}

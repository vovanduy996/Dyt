package h1;

import G3.AbstractC0164a;
import f4.C0984q;
import i4.InterfaceC1183g;
import i4.InterfaceC1184h;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.E, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1050E extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f10091p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ K f10092q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1050E(K k5, Continuation continuation) {
        super(2, continuation);
        this.f10092q = k5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C1050E) m((InterfaceC1184h) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new C1050E(this.f10092q, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) throws Throwable {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f10091p;
        G3.C c5 = G3.C.a;
        K k5 = this.f10092q;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            M1.m mVar = k5.f10118h;
            this.f10091p = 1;
            Object objL0 = ((C0984q) mVar.f4705m).l0(this);
            if (objL0 != aVar) {
                objL0 = c5;
            }
            if (objL0 == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                if (i5 == 2) {
                    AbstractC0164a.e(obj);
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        InterfaceC1183g interfaceC1183gF = i4.O.f(k5.f().f10146c, -1);
        F2.k kVar = new F2.k(5, k5);
        this.f10091p = 2;
        return interfaceC1183gF.d(kVar, this) == aVar ? aVar : c5;
    }
}

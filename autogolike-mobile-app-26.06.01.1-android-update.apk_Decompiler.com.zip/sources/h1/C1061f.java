package h1;

import G3.AbstractC0164a;
import V1.L1;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1061f extends M3.i implements T3.c {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ int f10162p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f10163q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ Object f10164r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C1061f(int i5, Object obj, Continuation continuation) {
        super(1, continuation);
        this.f10162p = i5;
        this.f10164r = obj;
    }

    @Override // T3.c
    public final Object invoke(Object obj) {
        Continuation continuation = (Continuation) obj;
        switch (this.f10162p) {
            case ConfigBackupDto.$stable /* 0 */:
                return new C1061f(0, (L1) this.f10164r, continuation).o(G3.C.a);
            default:
                return new C1061f(1, (C1047B) this.f10164r, continuation).o(G3.C.a);
        }
    }

    @Override // M3.a
    public final Object o(Object obj) {
        switch (this.f10162p) {
            case ConfigBackupDto.$stable /* 0 */:
                L3.a aVar = L3.a.f4629l;
                int i5 = this.f10163q;
                G3.C c5 = G3.C.a;
                if (i5 == 0) {
                    AbstractC0164a.e(obj);
                    this.f10163q = 1;
                    ((L1) this.f10164r).getClass();
                    if (c5 == aVar) {
                        return aVar;
                    }
                } else {
                    if (i5 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0164a.e(obj);
                }
                return c5;
            default:
                L3.a aVar2 = L3.a.f4629l;
                int i6 = this.f10163q;
                if (i6 == 0) {
                    AbstractC0164a.e(obj);
                    this.f10163q = 1;
                    obj = ((C1047B) this.f10164r).invoke(this);
                    if (obj == aVar2) {
                        return aVar2;
                    }
                } else {
                    if (i6 != 1) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0164a.e(obj);
                }
                return obj;
        }
    }
}

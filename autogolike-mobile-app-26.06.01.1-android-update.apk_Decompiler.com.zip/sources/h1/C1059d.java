package h1;

import G3.AbstractC0164a;
import java.util.List;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1059d extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f10155p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f10156q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ List f10157r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1059d(List list, Continuation continuation) {
        super(2, continuation);
        this.f10157r = list;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C1059d) m((C1066k) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C1059d c1059d = new C1059d(this.f10157r, continuation);
        c1059d.f10156q = obj;
        return c1059d;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f10155p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            C1066k c1066k = (C1066k) this.f10156q;
            this.f10155p = 1;
            if (V2.a.l(this.f10157r, c1066k, this) == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return G3.C.a;
    }
}

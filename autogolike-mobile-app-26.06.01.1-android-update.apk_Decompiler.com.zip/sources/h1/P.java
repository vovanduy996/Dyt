package h1;

import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: loaded from: classes.dex */
public final class P extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public T3.e f10132p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f10133q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ M1.m f10134r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public P(M1.m mVar, Continuation continuation) {
        super(2, continuation);
        this.f10134r = mVar;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((P) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new P(this.f10134r, continuation);
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x004f A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:17:0x005b A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:20:0x006a  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:16:0x0059 -> B:18:0x005c). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    @Override // M3.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object o(java.lang.Object r7) {
        /*
            r6 = this;
            L3.a r0 = L3.a.f4629l
            int r1 = r6.f10133q
            r2 = 2
            r3 = 1
            M1.m r4 = r6.f10134r
            if (r1 == 0) goto L20
            if (r1 == r3) goto L1a
            if (r1 != r2) goto L12
            G3.AbstractC0164a.e(r7)
            goto L5c
        L12:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r0)
            throw r7
        L1a:
            T3.e r1 = r6.f10132p
            G3.AbstractC0164a.e(r7)
            goto L50
        L20:
            G3.AbstractC0164a.e(r7)
            java.lang.Object r7 = r4.f4707o
            e3.C r7 = (e3.C0867C) r7
            java.lang.Object r7 = r7.f8994m
            java.util.concurrent.atomic.AtomicInteger r7 = (java.util.concurrent.atomic.AtomicInteger) r7
            int r7 = r7.get()
            if (r7 <= 0) goto L6d
        L31:
            java.lang.Object r7 = r4.f4704l
            f4.y r7 = (f4.InterfaceC0991y) r7
            K3.h r7 = r7.w()
            f4.AbstractC0952A.h(r7)
            java.lang.Object r7 = r4.f4705m
            r1 = r7
            h1.H r1 = (h1.C1053H) r1
            r6.f10132p = r1
            r6.f10133q = r3
            java.lang.Object r7 = r4.f4706n
            h4.g r7 = (h4.g) r7
            java.lang.Object r7 = r7.h(r6)
            if (r7 != r0) goto L50
            return r0
        L50:
            r5 = 0
            r6.f10132p = r5
            r6.f10133q = r2
            java.lang.Object r7 = r1.i(r7, r6)
            if (r7 != r0) goto L5c
            return r0
        L5c:
            java.lang.Object r7 = r4.f4707o
            e3.C r7 = (e3.C0867C) r7
            java.lang.Object r7 = r7.f8994m
            java.util.concurrent.atomic.AtomicInteger r7 = (java.util.concurrent.atomic.AtomicInteger) r7
            int r7 = r7.decrementAndGet()
            if (r7 != 0) goto L31
            G3.C r7 = G3.C.a
            return r7
        L6d:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r0 = "Check failed."
            r7.<init>(r0)
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: h1.P.o(java.lang.Object):java.lang.Object");
    }
}

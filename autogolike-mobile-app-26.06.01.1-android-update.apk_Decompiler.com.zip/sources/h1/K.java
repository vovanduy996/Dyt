package h1;

import A.C0021w;
import G3.AbstractC0164a;
import b0.C0590h;
import d4.C0832a;
import d4.EnumC0834c;
import e3.C0867C;
import e3.C0928y;
import f.C0933a;
import f4.AbstractC0952A;
import f4.AbstractC0967a;
import f4.C0984q;
import f4.C0988v;
import f4.EnumC0992z;
import f4.InterfaceC0991y;
import f4.b0;
import f4.j0;
import f4.p0;
import i4.C1175C;
import i4.C1179c;
import i4.InterfaceC1183g;
import java.util.List;
import k4.C1275t;
import kotlin.coroutines.Continuation;

/* JADX INFO: loaded from: classes.dex */
public final class K implements InterfaceC1063h {
    public final j1.f a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C0928y f10112b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final InterfaceC0991y f10113c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final i4.I f10114d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final O1.B f10115e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final C1179c f10116f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final C0867C f10117g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final M1.m f10118h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final G3.q f10119i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final G3.q f10120j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final M1.m f10121k;

    public K(j1.f fVar, List list, C0928y c0928y, InterfaceC0991y interfaceC0991y) {
        int i5 = 0;
        int i6 = 1;
        U3.j.f(interfaceC0991y, "scope");
        this.a = fVar;
        this.f10112b = c0928y;
        this.f10113c = interfaceC0991y;
        O1.B b3 = new O1.B(new C1050E(this, null));
        int i7 = C0832a.f8765o;
        int i8 = ((int) 0) & 1;
        i4.Z z3 = new i4.Z((i8 != 1 || C0832a.d(0L)) ? C0832a.f(0L, EnumC0834c.MILLISECONDS) : 0L, (i8 != 1 || C0832a.d(0L)) ? C0832a.f(0L, EnumC0834c.MILLISECONDS) : 0L);
        C0590h c0590hI = i4.O.i(b3, 0);
        i4.N nA = i4.O.a(0, c0590hI.a, (h4.a) c0590hI.f7960c);
        C1275t c1275t = i4.O.a;
        InterfaceC1183g interfaceC1183g = (InterfaceC1183g) c0590hI.f7959b;
        EnumC0992z enumC0992z = z3.equals(i4.S.a) ? EnumC0992z.f9856l : EnumC0992z.f9859o;
        C1175C c1175c = new C1175C(z3, interfaceC1183g, nA, c1275t, null);
        K3.h hVarT = AbstractC0952A.t(interfaceC0991y, (K3.h) c0590hI.f7961d);
        AbstractC0967a j0Var = enumC0992z == EnumC0992z.f9857m ? new j0(hVarT, c1175c) : new p0(hVarT, true);
        j0Var.n0(enumC0992z, j0Var, c1175c);
        this.f10114d = new i4.I(nA);
        this.f10115e = new O1.B(new C1076v(this, null));
        this.f10116f = new C1179c(new C1072q(this, null), K3.i.f4514l, -2, h4.a.f10252l);
        this.f10117g = new C0867C(8);
        M1.m mVar = new M1.m();
        mVar.f4707o = this;
        mVar.f4704l = n4.d.a();
        C0984q c0984q = new C0984q(true);
        c0984q.V(null);
        mVar.f4705m = c0984q;
        mVar.f4706n = H3.m.B1(list);
        this.f10118h = mVar;
        this.f10119i = AbstractC0164a.d(new C1068m(this, i6));
        this.f10120j = AbstractC0164a.d(new C1068m(this, i5));
        A0.k kVar = new A0.k(15, this);
        C1053H c1053h = new C1053H(this, null);
        U3.j.f(interfaceC0991y, "scope");
        M1.m mVar2 = new M1.m();
        mVar2.f4704l = interfaceC0991y;
        mVar2.f4705m = c1053h;
        mVar2.f4706n = C0933a.i(Integer.MAX_VALUE, 6, null);
        mVar2.f4707o = new C0867C(7);
        b0 b0Var = (b0) interfaceC0991y.w().m(C0988v.f9848m);
        if (b0Var != null) {
            b0Var.O(new C0021w(kVar, 21, mVar2));
        }
        this.f10121k = mVar2;
    }

    /* JADX WARN: Can't wrap try/catch for region: R(14:0|2|(2:4|(1:6)(1:7))(0)|8|(7:73|(1:(1:(1:13)(2:18|19))(3:20|21|22))(1:23)|14|63|(1:65)(1:66)|67|68)(4:24|74|25|(9:27|71|28|(1:76)|31|63|(0)(0)|67|68)(3:38|(1:40)(1:41)|(2:43|(2:45|(2:47|75))(2:54|55))(2:56|(2:58|59)(2:60|61))))|48|69|49|(1:77)|31|63|(0)(0)|67|68) */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x00c1, code lost:
    
        r9 = th;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:65:0x00e8  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x00ec  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0016  */
    /* JADX WARN: Type inference failed for: r2v3, types: [M3.i, T3.e] */
    /* JADX WARN: Type inference failed for: r2v9, types: [M3.i, T3.e] */
    /* JADX WARN: Type inference failed for: r9v0, types: [h1.K, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r9v12 */
    /* JADX WARN: Type inference failed for: r9v13 */
    /* JADX WARN: Type inference failed for: r9v15 */
    /* JADX WARN: Type inference failed for: r9v18 */
    /* JADX WARN: Type inference failed for: r9v26 */
    /* JADX WARN: Type inference failed for: r9v27 */
    /* JADX WARN: Type inference failed for: r9v28 */
    /* JADX WARN: Type inference failed for: r9v5 */
    /* JADX WARN: Type inference failed for: r9v9, types: [h1.K] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final java.lang.Object c(h1.K r9, h1.M r10, M3.c r11) {
        /*
            Method dump skipped, instruction units count: 251
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: h1.K.c(h1.K, h1.M, M3.c):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:45:0x00c9  */
    /* JADX WARN: Removed duplicated region for block: B:50:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0016  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final java.lang.Object d(h1.K r8, boolean r9, kotlin.coroutines.Continuation r10) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 215
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: h1.K.d(h1.K, boolean, kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:27:0x008e  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x00eb A[Catch: b -> 0x00ac, TryCatch #0 {b -> 0x00ac, blocks: (B:35:0x00a7, B:69:0x0145, B:40:0x00b5, B:66:0x0128, B:48:0x00d2, B:56:0x00eb, B:57:0x00ef, B:52:0x00db, B:63:0x0116), top: B:74:0x0023 }] */
    /* JADX WARN: Removed duplicated region for block: B:60:0x0105  */
    /* JADX WARN: Removed duplicated region for block: B:68:0x0144  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0016  */
    /* JADX WARN: Removed duplicated region for block: B:86:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final java.lang.Object e(h1.K r8, boolean r9, M3.c r10) {
        /*
            Method dump skipped, instruction units count: 368
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: h1.K.e(h1.K, boolean, M3.c):java.lang.Object");
    }

    @Override // h1.InterfaceC1063h
    public final Object a(T3.e eVar, Continuation continuation) {
        Z z3 = (Z) continuation.g().m(Y.f10150l);
        if (z3 != null) {
            z3.c(this);
        }
        return AbstractC0952A.B(new Z(z3, this), new C1051F(this, eVar, null), continuation);
    }

    @Override // h1.InterfaceC1063h
    public final InterfaceC1183g b() {
        return this.f10116f;
    }

    public final U f() {
        return (U) this.f10120j.getValue();
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object g(M3.c r6) throws java.lang.Throwable {
        /*
            r5 = this;
            boolean r0 = r6 instanceof h1.C1077w
            if (r0 == 0) goto L13
            r0 = r6
            h1.w r0 = (h1.C1077w) r0
            int r1 = r0.f10225s
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f10225s = r1
            goto L18
        L13:
            h1.w r0 = new h1.w
            r0.<init>(r5, r6)
        L18:
            java.lang.Object r6 = r0.f10223q
            L3.a r1 = L3.a.f4629l
            int r2 = r0.f10225s
            r3 = 2
            r4 = 1
            if (r2 == 0) goto L3e
            if (r2 == r4) goto L38
            if (r2 != r3) goto L30
            int r1 = r0.f10222p
            h1.K r0 = r0.f10221o
            G3.AbstractC0164a.e(r6)     // Catch: java.lang.Throwable -> L2e
            goto L66
        L2e:
            r6 = move-exception
            goto L6f
        L30:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r0)
            throw r6
        L38:
            h1.K r2 = r0.f10221o
            G3.AbstractC0164a.e(r6)
            goto L51
        L3e:
            G3.AbstractC0164a.e(r6)
            h1.U r6 = r5.f()
            r0.f10221o = r5
            r0.f10225s = r4
            java.lang.Integer r6 = r6.a()
            if (r6 != r1) goto L50
            return r1
        L50:
            r2 = r5
        L51:
            java.lang.Number r6 = (java.lang.Number) r6
            int r6 = r6.intValue()
            M1.m r4 = r2.f10118h     // Catch: java.lang.Throwable -> L6d
            r0.f10221o = r2     // Catch: java.lang.Throwable -> L6d
            r0.f10222p = r6     // Catch: java.lang.Throwable -> L6d
            r0.f10225s = r3     // Catch: java.lang.Throwable -> L6d
            java.lang.Object r6 = r4.s(r0)     // Catch: java.lang.Throwable -> L6d
            if (r6 != r1) goto L66
            return r1
        L66:
            G3.C r6 = G3.C.a
            return r6
        L69:
            r1 = r6
            r6 = r0
            r0 = r2
            goto L6f
        L6d:
            r0 = move-exception
            goto L69
        L6f:
            e3.C r0 = r0.f10117g
            h1.N r2 = new h1.N
            r2.<init>(r1, r6)
            r0.r(r2)
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: h1.K.g(M3.c):java.lang.Object");
    }

    public final Object h(M3.c cVar) {
        return ((j1.i) this.f10119i.getValue()).a(new W(3, null), cVar);
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object i(java.lang.Object r12, boolean r13, M3.c r14) {
        /*
            r11 = this;
            boolean r0 = r14 instanceof h1.C1054I
            if (r0 == 0) goto L13
            r0 = r14
            h1.I r0 = (h1.C1054I) r0
            int r1 = r0.f10104r
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f10104r = r1
            goto L18
        L13:
            h1.I r0 = new h1.I
            r0.<init>(r11, r14)
        L18:
            java.lang.Object r14 = r0.f10102p
            L3.a r1 = L3.a.f4629l
            int r2 = r0.f10104r
            r3 = 1
            if (r2 == 0) goto L31
            if (r2 != r3) goto L29
            U3.s r12 = r0.f10101o
            G3.AbstractC0164a.e(r14)
            goto L58
        L29:
            java.lang.IllegalStateException r12 = new java.lang.IllegalStateException
            java.lang.String r13 = "call to 'resume' before 'invoke' with coroutine"
            r12.<init>(r13)
            throw r12
        L31:
            G3.AbstractC0164a.e(r14)
            U3.s r14 = new U3.s
            r14.<init>()
            G3.q r2 = r11.f10119i
            java.lang.Object r2 = r2.getValue()
            j1.i r2 = (j1.i) r2
            h1.J r10 = new h1.J
            r9 = 0
            r4 = r10
            r5 = r14
            r6 = r11
            r7 = r12
            r8 = r13
            r4.<init>(r5, r6, r7, r8, r9)
            r0.f10101o = r14
            r0.f10104r = r3
            java.lang.Object r12 = r2.b(r10, r0)
            if (r12 != r1) goto L57
            return r1
        L57:
            r12 = r14
        L58:
            int r12 = r12.f6190l
            java.lang.Integer r13 = new java.lang.Integer
            r13.<init>(r12)
            return r13
        */
        throw new UnsupportedOperationException("Method not decompiled: h1.K.i(java.lang.Object, boolean, M3.c):java.lang.Object");
    }
}

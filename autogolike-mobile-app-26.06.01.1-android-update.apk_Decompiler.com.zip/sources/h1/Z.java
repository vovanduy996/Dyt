package h1;

/* JADX INFO: loaded from: classes.dex */
public final class Z implements K3.f {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final Z f10151l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final K f10152m;

    public Z(Z z3, K k5) {
        U3.j.f(k5, "instance");
        this.f10151l = z3;
        this.f10152m = k5;
    }

    @Override // K3.h
    public final Object B(Object obj, T3.e eVar) {
        return eVar.i(obj, this);
    }

    @Override // K3.h
    public final K3.h F(K3.h hVar) {
        return l0.c.q0(this, hVar);
    }

    public final void c(K k5) {
        if (this.f10152m == k5) {
            throw new IllegalStateException("Calling updateData inside updateData on the same DataStore instance is not supported\nsince updates made in the parent updateData call will not be visible to the nested\nupdateData call. See https://issuetracker.google.com/issues/241760537 for details.");
        }
        Z z3 = this.f10151l;
        if (z3 != null) {
            z3.c(k5);
        }
    }

    @Override // K3.f
    public final K3.g getKey() {
        return Y.f10150l;
    }

    @Override // K3.h
    public final K3.f m(K3.g gVar) {
        return l0.c.h0(this, gVar);
    }

    @Override // K3.h
    public final K3.h u(K3.g gVar) {
        return l0.c.p0(this, gVar);
    }
}

package h1;

import V1.L1;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1062g extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Iterator f10165p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public L1 f10166q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public Object f10167r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f10168s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public /* synthetic */ Object f10169t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ List f10170u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ ArrayList f10171v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1062g(List list, ArrayList arrayList, Continuation continuation) {
        super(2, continuation);
        this.f10170u = list;
        this.f10171v = arrayList;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C1062g) m(obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C1062g c1062g = new C1062g(this.f10170u, this.f10171v, continuation);
        c1062g.f10169t = obj;
        return c1062g;
    }

    /* JADX WARN: Code restructure failed: missing block: B:23:0x008f, code lost:
    
        r7 = true;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Path cross not found for [B:18:0x006f, B:17:0x006d], limit reached: 44 */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0046  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x00a4  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00e8  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00ea A[RETURN] */
    /* JADX WARN: Type inference failed for: r13v0, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r13v1, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r13v11 */
    /* JADX WARN: Type inference failed for: r13v2 */
    /* JADX WARN: Type inference failed for: r13v5 */
    /* JADX WARN: Type inference failed for: r13v7, types: [l1.b] */
    /* JADX WARN: Type inference failed for: r13v8, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r13v9 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v17 */
    /* JADX WARN: Type inference failed for: r1v4 */
    /* JADX WARN: Type inference failed for: r7v4 */
    @Override // M3.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object o(java.lang.Object r13) {
        /*
            Method dump skipped, instruction units count: 235
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: h1.C1062g.o(java.lang.Object):java.lang.Object");
    }
}

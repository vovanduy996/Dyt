package h1;

import G3.AbstractC0164a;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.H, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1053H extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f10098p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f10099q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ K f10100r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1053H(K k5, Continuation continuation) {
        super(2, continuation);
        this.f10100r = k5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C1053H) m((M) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C1053H c1053h = new C1053H(this.f10100r, continuation);
        c1053h.f10099q = obj;
        return c1053h;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f10098p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            M m5 = (M) this.f10099q;
            this.f10098p = 1;
            if (K.c(this.f10100r, m5, this) == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return G3.C.a;
    }
}

package h1;

import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.J, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1055J extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public U3.s f10105p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f10106q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f10107r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ U3.s f10108s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ K f10109t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ Object f10110u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ boolean f10111v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1055J(U3.s sVar, K k5, Object obj, boolean z3, Continuation continuation) {
        super(2, continuation);
        this.f10108s = sVar;
        this.f10109t = k5;
        this.f10110u = obj;
        this.f10111v = z3;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C1055J) m((j1.k) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C1055J c1055j = new C1055J(this.f10108s, this.f10109t, this.f10110u, this.f10111v, continuation);
        c1055j.f10107r = obj;
        return c1055j;
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x0069  */
    @Override // M3.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object o(java.lang.Object r9) {
        /*
            r8 = this;
            L3.a r0 = L3.a.f4629l
            int r1 = r8.f10106q
            U3.s r2 = r8.f10108s
            java.lang.Object r3 = r8.f10110u
            h1.K r4 = r8.f10109t
            r5 = 2
            r6 = 1
            if (r1 == 0) goto L28
            if (r1 == r6) goto L1e
            if (r1 != r5) goto L16
            G3.AbstractC0164a.e(r9)
            goto L65
        L16:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r9.<init>(r0)
            throw r9
        L1e:
            U3.s r1 = r8.f10105p
            java.lang.Object r6 = r8.f10107r
            j1.k r6 = (j1.k) r6
            G3.AbstractC0164a.e(r9)
            goto L4f
        L28:
            G3.AbstractC0164a.e(r9)
            java.lang.Object r9 = r8.f10107r
            j1.k r9 = (j1.k) r9
            h1.U r1 = r4.f()
            r8.f10107r = r9
            r8.f10105p = r2
            r8.f10106q = r6
            e3.C r1 = r1.f10145b
            java.lang.Object r1 = r1.f8994m
            java.util.concurrent.atomic.AtomicInteger r1 = (java.util.concurrent.atomic.AtomicInteger) r1
            int r1 = r1.incrementAndGet()
            java.lang.Integer r6 = new java.lang.Integer
            r6.<init>(r1)
            if (r6 != r0) goto L4b
            return r0
        L4b:
            r1 = r2
            r7 = r6
            r6 = r9
            r9 = r7
        L4f:
            java.lang.Number r9 = (java.lang.Number) r9
            int r9 = r9.intValue()
            r1.f6190l = r9
            r9 = 0
            r8.f10107r = r9
            r8.f10105p = r9
            r8.f10106q = r5
            java.lang.Object r9 = r6.b(r3, r8)
            if (r9 != r0) goto L65
            return r0
        L65:
            boolean r9 = r8.f10111v
            if (r9 == 0) goto L7d
            e3.C r9 = r4.f10117g
            h1.c r0 = new h1.c
            if (r3 == 0) goto L74
            int r1 = r3.hashCode()
            goto L75
        L74:
            r1 = 0
        L75:
            int r2 = r2.f6190l
            r0.<init>(r1, r2, r3)
            r9.r(r0)
        L7d:
            G3.C r9 = G3.C.a
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: h1.C1055J.o(java.lang.Object):java.lang.Object");
    }
}

package h1;

import G3.AbstractC0164a;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.y, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1079y extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Throwable f10232p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f10233q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ boolean f10234r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ K f10235s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f10236t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1079y(K k5, int i5, Continuation continuation) {
        super(2, continuation);
        this.f10235s = k5;
        this.f10236t = i5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        Boolean bool = (Boolean) obj;
        bool.booleanValue();
        return ((C1079y) m(bool, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C1079y c1079y = new C1079y(this.f10235s, this.f10236t, continuation);
        c1079y.f10234r = ((Boolean) obj).booleanValue();
        return c1079y;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v2 */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v5 */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r1v0, types: [int] */
    /* JADX WARN: Type inference failed for: r1v1, types: [boolean] */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v13 */
    /* JADX WARN: Type inference failed for: r1v14 */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v4, types: [boolean] */
    /* JADX WARN: Type inference failed for: r1v7 */
    /* JADX WARN: Type inference failed for: r5v0 */
    @Override // M3.a
    public final Object o(Object obj) {
        Throwable th;
        int iIntValue;
        ?? r02;
        ?? r03;
        V v5;
        ?? r12;
        L3.a aVar = L3.a.f4629l;
        ?? r13 = this.f10233q;
        K k5 = this.f10235s;
        try {
        } catch (Throwable th2) {
            if (r13 == 0) {
                ?? r5 = r13;
                th = th2;
                iIntValue = this.f10236t;
                r02 = r5 == true ? 1 : 0;
                N n5 = new N(iIntValue, th);
                r12 = r02;
                v5 = n5;
                return new G3.l(v5, Boolean.valueOf((boolean) r12));
            }
            U uF = k5.f();
            this.f10232p = th2;
            this.f10234r = r13;
            this.f10233q = 2;
            Integer numA = uF.a();
            if (numA == aVar) {
                return aVar;
            }
            r03 = r13;
            th = th2;
            obj = numA;
        }
        if (r13 == 0) {
            AbstractC0164a.e(obj);
            boolean z3 = this.f10234r;
            this.f10234r = z3;
            this.f10233q = 1;
            obj = K.e(k5, z3, this);
            r13 = z3;
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (r13 != 1) {
                if (r13 != 2) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                boolean z5 = this.f10234r;
                th = this.f10232p;
                AbstractC0164a.e(obj);
                r03 = z5;
                iIntValue = ((Number) obj).intValue();
                r02 = r03;
                N n52 = new N(iIntValue, th);
                r12 = r02;
                v5 = n52;
                return new G3.l(v5, Boolean.valueOf((boolean) r12));
            }
            boolean z6 = this.f10234r;
            AbstractC0164a.e(obj);
            r13 = z6;
        }
        v5 = (V) obj;
        r12 = r13;
        return new G3.l(v5, Boolean.valueOf((boolean) r12));
    }
}

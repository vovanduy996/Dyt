package h1;

/* JADX INFO: loaded from: classes.dex */
public final class Y implements K3.g {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final Y f10150l = new Y();
}

package h1;

import F.C0098g1;
import G3.AbstractC0164a;
import f4.AbstractC0952A;
import f4.EnumC0992z;
import f4.p0;
import i4.C1189m;
import i4.C1191o;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1072q extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f10202p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f10203q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ K f10204r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1072q(K k5, Continuation continuation) {
        super(2, continuation);
        this.f10204r = k5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C1072q) m((h4.s) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C1072q c1072q = new C1072q(this.f10204r, continuation);
        c1072q.f10203q = obj;
        return c1072q;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f10202p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            h4.s sVar = (h4.s) this.f10203q;
            EnumC0992z enumC0992z = EnumC0992z.f9857m;
            K k5 = this.f10204r;
            p0 p0VarS = AbstractC0952A.s(sVar, null, enumC0992z, new C1071p(k5, null), 1);
            C1189m c1189m = new C1189m(new C1191o(new C1069n(p0VarS, null), k5.f10115e), new C0098g1(2, p0VarS, null));
            F2.k kVar = new F2.k(4, sVar);
            this.f10202p = 1;
            if (c1189m.d(kVar, this) == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return G3.C.a;
    }
}

package h1;

import e3.C0867C;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: loaded from: classes.dex */
public final class U {
    public final n4.c a = n4.d.a();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C0867C f10145b = new C0867C(7);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final O1.B f10146c = new O1.B(new T(2, null));

    public U(String str) {
    }

    public final Integer a() {
        return new Integer(((AtomicInteger) this.f10145b.f8994m).get());
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object b(T3.c r8, M3.c r9) {
        /*
            r7 = this;
            boolean r0 = r9 instanceof h1.Q
            if (r0 == 0) goto L13
            r0 = r9
            h1.Q r0 = (h1.Q) r0
            int r1 = r0.f10139s
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f10139s = r1
            goto L18
        L13:
            h1.Q r0 = new h1.Q
            r0.<init>(r7, r9)
        L18:
            java.lang.Object r9 = r0.f10137q
            L3.a r1 = L3.a.f4629l
            int r2 = r0.f10139s
            r3 = 2
            r4 = 1
            r5 = 0
            if (r2 == 0) goto L45
            if (r2 == r4) goto L39
            if (r2 != r3) goto L31
            java.lang.Object r8 = r0.f10135o
            n4.a r8 = (n4.InterfaceC1472a) r8
            G3.AbstractC0164a.e(r9)     // Catch: java.lang.Throwable -> L2f
            goto L67
        L2f:
            r9 = move-exception
            goto L71
        L31:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r9 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r9)
            throw r8
        L39:
            n4.c r8 = r0.f10136p
            java.lang.Object r2 = r0.f10135o
            T3.c r2 = (T3.c) r2
            G3.AbstractC0164a.e(r9)
            r9 = r8
            r8 = r2
            goto L57
        L45:
            G3.AbstractC0164a.e(r9)
            r0.f10135o = r8
            n4.c r9 = r7.a
            r0.f10136p = r9
            r0.f10139s = r4
            java.lang.Object r2 = r9.c(r5, r0)
            if (r2 != r1) goto L57
            return r1
        L57:
            r0.f10135o = r9     // Catch: java.lang.Throwable -> L6d
            r0.f10136p = r5     // Catch: java.lang.Throwable -> L6d
            r0.f10139s = r3     // Catch: java.lang.Throwable -> L6d
            java.lang.Object r8 = r8.invoke(r0)     // Catch: java.lang.Throwable -> L6d
            if (r8 != r1) goto L64
            return r1
        L64:
            r6 = r9
            r9 = r8
            r8 = r6
        L67:
            n4.c r8 = (n4.c) r8
            r8.e(r5)
            return r9
        L6d:
            r8 = move-exception
            r6 = r9
            r9 = r8
            r8 = r6
        L71:
            n4.c r8 = (n4.c) r8
            r8.e(r5)
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: h1.U.b(T3.c, M3.c):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:24:0x0055  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x005f  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object c(T3.e r7, M3.c r8) throws java.lang.Throwable {
        /*
            r6 = this;
            boolean r0 = r8 instanceof h1.S
            if (r0 == 0) goto L13
            r0 = r8
            h1.S r0 = (h1.S) r0
            int r1 = r0.f10144s
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f10144s = r1
            goto L18
        L13:
            h1.S r0 = new h1.S
            r0.<init>(r6, r8)
        L18:
            java.lang.Object r8 = r0.f10142q
            L3.a r1 = L3.a.f4629l
            int r2 = r0.f10144s
            r3 = 1
            r4 = 0
            if (r2 == 0) goto L36
            if (r2 != r3) goto L2e
            boolean r7 = r0.f10141p
            n4.c r0 = r0.f10140o
            G3.AbstractC0164a.e(r8)     // Catch: java.lang.Throwable -> L2c
            goto L53
        L2c:
            r8 = move-exception
            goto L5d
        L2e:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r8)
            throw r7
        L36:
            G3.AbstractC0164a.e(r8)
            n4.c r8 = r6.a
            boolean r2 = r8.d(r4)
            java.lang.Boolean r5 = java.lang.Boolean.valueOf(r2)     // Catch: java.lang.Throwable -> L59
            r0.f10140o = r8     // Catch: java.lang.Throwable -> L59
            r0.f10141p = r2     // Catch: java.lang.Throwable -> L59
            r0.f10144s = r3     // Catch: java.lang.Throwable -> L59
            java.lang.Object r7 = r7.i(r5, r0)     // Catch: java.lang.Throwable -> L59
            if (r7 != r1) goto L50
            return r1
        L50:
            r0 = r8
            r8 = r7
            r7 = r2
        L53:
            if (r7 == 0) goto L58
            r0.e(r4)
        L58:
            return r8
        L59:
            r7 = move-exception
            r0 = r8
            r8 = r7
            r7 = r2
        L5d:
            if (r7 == 0) goto L62
            r0.e(r4)
        L62:
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: h1.U.c(T3.e, M3.c):java.lang.Object");
    }
}

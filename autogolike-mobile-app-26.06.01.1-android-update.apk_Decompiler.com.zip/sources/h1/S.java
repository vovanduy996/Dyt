package h1;

/* JADX INFO: loaded from: classes.dex */
public final class S extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public n4.c f10140o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f10141p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f10142q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ U f10143r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f10144s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public S(U u5, M3.c cVar) {
        super(cVar);
        this.f10143r = u5;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f10142q = obj;
        this.f10144s |= Integer.MIN_VALUE;
        return this.f10143r.c(null, this);
    }
}

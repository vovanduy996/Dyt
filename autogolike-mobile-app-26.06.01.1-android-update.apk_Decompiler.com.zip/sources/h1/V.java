package h1;

/* JADX INFO: loaded from: classes.dex */
public abstract class V {
    public final int a;

    public V(int i5) {
        this.a = i5;
    }
}

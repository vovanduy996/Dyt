package h1;

import G3.AbstractC0164a;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1074t extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public /* synthetic */ Object f10212p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ V f10213q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1074t(V v5, Continuation continuation) {
        super(2, continuation);
        this.f10213q = v5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C1074t) m((V) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C1074t c1074t = new C1074t(this.f10213q, continuation);
        c1074t.f10212p = obj;
        return c1074t;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        AbstractC0164a.e(obj);
        V v5 = (V) this.f10212p;
        return Boolean.valueOf((v5 instanceof C1058c) && v5.a <= this.f10213q.a);
    }
}

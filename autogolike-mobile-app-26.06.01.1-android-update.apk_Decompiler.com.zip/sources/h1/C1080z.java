package h1;

import java.io.Serializable;

/* JADX INFO: renamed from: h1.z, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1080z extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public Object f10237o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Object f10238p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public Serializable f10239q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public U3.u f10240r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f10241s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f10242t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public /* synthetic */ Object f10243u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ K f10244v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f10245w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1080z(K k5, M3.c cVar) {
        super(cVar);
        this.f10244v = k5;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f10243u = obj;
        this.f10245w |= Integer.MIN_VALUE;
        return K.e(this.f10244v, false, this);
    }
}

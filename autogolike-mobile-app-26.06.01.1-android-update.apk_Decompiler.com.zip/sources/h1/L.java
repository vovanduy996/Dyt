package h1;

/* JADX INFO: loaded from: classes.dex */
public final class L extends V {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Throwable f10122b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public L(Throwable th) {
        super(Integer.MAX_VALUE);
        U3.j.f(th, "finalException");
        this.f10122b = th;
    }
}

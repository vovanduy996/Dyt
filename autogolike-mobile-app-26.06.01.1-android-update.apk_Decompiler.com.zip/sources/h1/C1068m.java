package h1;

import com.autogolike.mobile.core.backup.ConfigBackupDto;
import java.util.LinkedHashSet;

/* JADX INFO: renamed from: h1.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1068m extends U3.k implements T3.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f10196l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ K f10197m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C1068m(K k5, int i5) {
        super(0);
        this.f10196l = i5;
        this.f10197m = k5;
    }

    @Override // T3.a
    public final Object b() {
        switch (this.f10196l) {
            case ConfigBackupDto.$stable /* 0 */:
                return ((j1.i) this.f10197m.f10119i.getValue()).f10774c;
            default:
                j1.f fVar = this.f10197m.a;
                String strQ = ((K4.w) fVar.f10759d.getValue()).f4590l.q();
                synchronized (j1.f.f10756f) {
                    LinkedHashSet linkedHashSet = j1.f.f10755e;
                    if (linkedHashSet.contains(strQ)) {
                        throw new IllegalStateException(("There are multiple DataStores active for the same file: " + strQ + ". You should either maintain your DataStore as a singleton or confirm that there is no two DataStore's active on the same file (by confirming that the scope is cancelled).").toString());
                    }
                    linkedHashSet.add(strQ);
                }
                return new j1.i(fVar.a, (K4.w) fVar.f10759d.getValue(), (U) fVar.f10757b.i((K4.w) fVar.f10759d.getValue(), fVar.a), new j1.e(fVar, 1));
        }
    }
}

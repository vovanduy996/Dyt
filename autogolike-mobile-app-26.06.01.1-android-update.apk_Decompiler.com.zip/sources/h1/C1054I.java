package h1;

/* JADX INFO: renamed from: h1.I, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1054I extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public U3.s f10101o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public /* synthetic */ Object f10102p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ K f10103q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f10104r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1054I(K k5, M3.c cVar) {
        super(cVar);
        this.f10103q = k5;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f10102p = obj;
        this.f10104r |= Integer.MIN_VALUE;
        return this.f10103q.i(null, false, this);
    }
}

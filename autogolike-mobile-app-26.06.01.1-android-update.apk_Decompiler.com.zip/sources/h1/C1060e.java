package h1;

import java.io.Serializable;
import java.util.Iterator;

/* JADX INFO: renamed from: h1.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1060e extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public Serializable f10158o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Iterator f10159p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f10160q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f10161r;

    @Override // M3.a
    public final Object o(Object obj) {
        this.f10160q = obj;
        this.f10161r |= Integer.MIN_VALUE;
        return V2.a.l(null, null, this);
    }
}

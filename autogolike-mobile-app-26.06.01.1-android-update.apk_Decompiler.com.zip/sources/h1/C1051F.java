package h1;

import G3.AbstractC0164a;
import e3.C0867C;
import f4.AbstractC0952A;
import f4.C0984q;
import f4.InterfaceC0991y;
import h3.C1081a;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.F, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1051F extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f10093p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f10094q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ K f10095r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ M3.i f10096s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public C1051F(K k5, T3.e eVar, Continuation continuation) {
        super(2, continuation);
        this.f10095r = k5;
        this.f10096s = (M3.i) eVar;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C1051F) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [M3.i, T3.e] */
    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C1051F c1051f = new C1051F(this.f10095r, this.f10096s, continuation);
        c1051f.f10094q = obj;
        return c1051f;
    }

    /* JADX WARN: Type inference failed for: r7v0, types: [M3.i, T3.e] */
    @Override // M3.a
    public final Object o(Object obj) throws Throwable {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f10093p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            InterfaceC0991y interfaceC0991y = (InterfaceC0991y) this.f10094q;
            C0984q c0984q = new C0984q(true);
            c0984q.V(null);
            K k5 = this.f10095r;
            M m5 = new M(this.f10096s, c0984q, k5.f10117g.o(), interfaceC0991y.w());
            M1.m mVar = k5.f10121k;
            Object objN = ((h4.g) mVar.f4706n).n(m5);
            if (objN instanceof h4.l) {
                h4.l lVar = objN instanceof h4.l ? (h4.l) objN : null;
                Throwable th = lVar != null ? lVar.a : null;
                if (th == null) {
                    throw new C1081a("Channel was closed normally");
                }
                throw th;
            }
            if (objN instanceof h4.m) {
                throw new IllegalStateException("Check failed.");
            }
            if (((AtomicInteger) ((C0867C) mVar.f4707o).f8994m).getAndIncrement() == 0) {
                AbstractC0952A.s((InterfaceC0991y) mVar.f4704l, null, null, new P(mVar, null), 3);
            }
            this.f10093p = 1;
            obj = c0984q.l0(this);
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return obj;
    }
}

package h1;

/* JADX INFO: renamed from: h1.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1064i extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public M1.m f10172o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public /* synthetic */ Object f10173p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ M1.m f10174q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f10175r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1064i(M1.m mVar, M3.c cVar) {
        super(cVar);
        this.f10174q = mVar;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f10173p = obj;
        this.f10175r |= Integer.MIN_VALUE;
        return this.f10174q.n(this);
    }
}

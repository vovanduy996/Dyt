package h1;

import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.x, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1078x extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public K f10226o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public V f10227p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f10228q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f10229r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ K f10230s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f10231t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1078x(K k5, Continuation continuation) {
        super(continuation);
        this.f10230s = k5;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f10229r = obj;
        this.f10231t |= Integer.MIN_VALUE;
        return K.d(this.f10230s, false, this);
    }
}

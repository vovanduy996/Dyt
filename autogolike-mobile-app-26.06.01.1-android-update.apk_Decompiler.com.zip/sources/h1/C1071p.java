package h1;

import G3.AbstractC0164a;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1071p extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f10200p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ K f10201q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1071p(K k5, Continuation continuation) {
        super(2, continuation);
        this.f10201q = k5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        ((C1071p) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
        return L3.a.f4629l;
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new C1071p(this.f10201q, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f10200p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            i4.I i6 = this.f10201q.f10114d;
            C1070o c1070o = C1070o.f10199l;
            this.f10200p = 1;
            if (i6.f10591l.d(c1070o, this) == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        throw new G3.f();
    }
}

package h1;

import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.A, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1046A extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Object f10075p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f10076q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ boolean f10077r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ K f10078s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f10079t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1046A(K k5, int i5, Continuation continuation) {
        super(2, continuation);
        this.f10078s = k5;
        this.f10079t = i5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        Boolean bool = (Boolean) obj;
        bool.booleanValue();
        return ((C1046A) m(bool, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C1046A c1046a = new C1046A(this.f10078s, this.f10079t, continuation);
        c1046a.f10077r = ((Boolean) obj).booleanValue();
        return c1046a;
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x0055  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x005a  */
    @Override // M3.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object o(java.lang.Object r7) {
        /*
            r6 = this;
            L3.a r0 = L3.a.f4629l
            int r1 = r6.f10076q
            h1.K r2 = r6.f10078s
            r3 = 2
            r4 = 1
            if (r1 == 0) goto L22
            if (r1 == r4) goto L1c
            if (r1 != r3) goto L14
            java.lang.Object r0 = r6.f10075p
            G3.AbstractC0164a.e(r7)
            goto L45
        L14:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r0)
            throw r7
        L1c:
            boolean r1 = r6.f10077r
            G3.AbstractC0164a.e(r7)
            goto L32
        L22:
            G3.AbstractC0164a.e(r7)
            boolean r1 = r6.f10077r
            r6.f10077r = r1
            r6.f10076q = r4
            java.lang.Object r7 = r2.h(r6)
            if (r7 != r0) goto L32
            return r0
        L32:
            if (r1 == 0) goto L4c
            h1.U r1 = r2.f()
            r6.f10075p = r7
            r6.f10076q = r3
            java.lang.Integer r1 = r1.a()
            if (r1 != r0) goto L43
            return r0
        L43:
            r0 = r7
            r7 = r1
        L45:
            java.lang.Number r7 = (java.lang.Number) r7
            int r7 = r7.intValue()
            goto L51
        L4c:
            int r0 = r6.f10079t
            r5 = r0
            r0 = r7
            r7 = r5
        L51:
            h1.c r1 = new h1.c
            if (r0 == 0) goto L5a
            int r2 = r0.hashCode()
            goto L5b
        L5a:
            r2 = 0
        L5b:
            r1.<init>(r2, r7, r0)
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: h1.C1046A.o(java.lang.Object):java.lang.Object");
    }
}

package h1;

import i4.InterfaceC1183g;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC1063h {
    Object a(T3.e eVar, Continuation continuation);

    InterfaceC1183g b();
}

package h1;

import G3.AbstractC0164a;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.s, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1073s extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public /* synthetic */ Object f10211p;

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C1073s) m((V) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C1073s c1073s = new C1073s(2, continuation);
        c1073s.f10211p = obj;
        return c1073s;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        AbstractC0164a.e(obj);
        return Boolean.valueOf(!(((V) this.f10211p) instanceof L));
    }
}

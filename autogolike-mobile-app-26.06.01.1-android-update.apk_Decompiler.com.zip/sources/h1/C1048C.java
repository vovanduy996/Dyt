package h1;

import G3.AbstractC0164a;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: h1.C, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1048C extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f10086p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ K f10087q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1048C(K k5, Continuation continuation) {
        super(2, continuation);
        this.f10087q = k5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C1048C) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new C1048C(this.f10087q, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) throws Throwable {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f10086p;
        K k5 = this.f10087q;
        try {
            if (i5 == 0) {
                AbstractC0164a.e(obj);
                if (k5.f10117g.o() instanceof L) {
                    return k5.f10117g.o();
                }
                this.f10086p = 1;
                if (k5.g(this) == aVar) {
                    return aVar;
                }
            } else {
                if (i5 != 1) {
                    if (i5 != 2) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    AbstractC0164a.e(obj);
                    return (V) obj;
                }
                AbstractC0164a.e(obj);
            }
            this.f10086p = 2;
            obj = K.d(k5, false, this);
            if (obj == aVar) {
                return aVar;
            }
            return (V) obj;
        } catch (Throwable th) {
            return new N(-1, th);
        }
    }
}

package h1;

import f4.C0985s;
import java.util.concurrent.CancellationException;

/* JADX INFO: renamed from: h1.G, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1052G extends U3.k implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final C1052G f10097l = new C1052G(2);

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        M m5 = (M) obj;
        Throwable cancellationException = (Throwable) obj2;
        U3.j.f(m5, "msg");
        if (cancellationException == null) {
            cancellationException = new CancellationException("DataStore scope was cancelled before updateData could complete");
        }
        m5.f10123b.Y(new C0985s(cancellationException, false));
        return G3.C.a;
    }
}

package h1;

/* JADX INFO: loaded from: classes.dex */
public final class N extends V {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Throwable f10126b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public N(int i5, Throwable th) {
        super(i5);
        U3.j.f(th, "readException");
        this.f10126b = th;
    }
}

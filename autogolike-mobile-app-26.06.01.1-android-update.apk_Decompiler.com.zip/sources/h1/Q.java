package h1;

/* JADX INFO: loaded from: classes.dex */
public final class Q extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public Object f10135o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public n4.c f10136p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f10137q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ U f10138r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f10139s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Q(U u5, M3.c cVar) {
        super(cVar);
        this.f10138r = u5;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f10137q = obj;
        this.f10139s |= Integer.MIN_VALUE;
        return this.f10138r.b(null, this);
    }
}

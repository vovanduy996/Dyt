package u1;

import I.C0258p;
import I.C0277z;
import I.W;
import android.view.View;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import androidx.lifecycle.U;
import androidx.lifecycle.h0;

/* JADX INFO: renamed from: u1.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1906b {
    public static final C0277z a = new C0277z(W.f3598q, C1905a.f14258l);

    public static h0 a(C0258p c0258p) {
        c0258p.R(-584162872);
        h0 h0VarH = (h0) c0258p.k(a);
        if (h0VarH == null) {
            c0258p.R(1382572291);
            h0VarH = U.h((View) c0258p.k(AndroidCompositionLocals_androidKt.f7505f));
            c0258p.p(false);
        }
        c0258p.p(false);
        return h0VarH;
    }
}

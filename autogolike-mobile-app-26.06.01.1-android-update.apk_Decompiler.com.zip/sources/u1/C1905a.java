package u1;

import U3.k;

/* JADX INFO: renamed from: u1.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1905a extends k implements T3.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final C1905a f14258l = new C1905a(0);

    @Override // T3.a
    public final /* bridge */ /* synthetic */ Object b() {
        return null;
    }
}

package c1;

import android.view.KeyEvent;
import android.view.View;

/* JADX INFO: renamed from: c1.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class ViewOnUnhandledKeyEventListenerC0676n implements View.OnUnhandledKeyEventListener {
    @Override // android.view.View.OnUnhandledKeyEventListener
    public final boolean onUnhandledKeyEvent(View view, KeyEvent keyEvent) {
        throw null;
    }
}

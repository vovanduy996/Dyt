package c1;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class y extends AnimatorListenerAdapter {
    public final /* synthetic */ C0653E a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ View f8153b;

    public y(View view, C0653E c0653e) {
        this.a = c0653e;
        this.f8153b = view;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        C0653E c0653e = this.a;
        c0653e.a.c(1.0f);
        C0649A.d(this.f8153b, c0653e);
    }
}

package c1;

import android.animation.ValueAnimator;
import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import java.util.Objects;
import k3.RunnableC1254a;

/* JADX INFO: loaded from: classes.dex */
public final class z implements View.OnApplyWindowInsetsListener {
    public final q.O a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public T f8154b;

    public z(View view, q.O o3) {
        T tB;
        this.a = o3;
        int i5 = AbstractC0680s.a;
        T tA = AbstractC0675m.a(view);
        if (tA != null) {
            int i6 = Build.VERSION.SDK_INT;
            tB = (i6 >= 30 ? new C0657I(tA) : i6 >= 29 ? new C0656H(tA) : new C0655G(tA)).b();
        } else {
            tB = null;
        }
        this.f8154b = tB;
    }

    @Override // android.view.View.OnApplyWindowInsetsListener
    public final WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
        P p4;
        if (!view.isLaidOut()) {
            this.f8154b = T.b(view, windowInsets);
            return C0649A.h(view, windowInsets);
        }
        T tB = T.b(view, windowInsets);
        if (this.f8154b == null) {
            int i5 = AbstractC0680s.a;
            this.f8154b = AbstractC0675m.a(view);
        }
        if (this.f8154b == null) {
            this.f8154b = tB;
            return C0649A.h(view, windowInsets);
        }
        q.O oI = C0649A.i(view);
        if (oI != null && Objects.equals(oI.f12561l, windowInsets)) {
            return C0649A.h(view, windowInsets);
        }
        T t5 = this.f8154b;
        int i6 = 1;
        int i7 = 0;
        while (true) {
            p4 = tB.a;
            if (i6 > 256) {
                break;
            }
            if (!p4.f(i6).equals(t5.a.f(i6))) {
                i7 |= i6;
            }
            i6 <<= 1;
        }
        if (i7 == 0) {
            return C0649A.h(view, windowInsets);
        }
        T t6 = this.f8154b;
        C0653E c0653e = new C0653E(i7, (i7 & 8) != 0 ? p4.f(8).f6884d > t6.a.f(8).f6884d ? C0649A.f8101d : C0649A.f8102e : C0649A.f8103f, 160L);
        c0653e.a.c(0.0f);
        ValueAnimator duration = ValueAnimator.ofFloat(0.0f, 1.0f).setDuration(c0653e.a.a());
        X0.c cVarF = p4.f(i7);
        X0.c cVarF2 = t6.a.f(i7);
        int iMin = Math.min(cVarF.a, cVarF2.a);
        int i8 = cVarF.f6882b;
        int i9 = cVarF2.f6882b;
        int iMin2 = Math.min(i8, i9);
        int i10 = cVarF.f6883c;
        int i11 = cVarF2.f6883c;
        int iMin3 = Math.min(i10, i11);
        int i12 = cVarF.f6884d;
        int i13 = i7;
        int i14 = cVarF2.f6884d;
        y.t tVar = new y.t(X0.c.b(iMin, iMin2, iMin3, Math.min(i12, i14)), 12, X0.c.b(Math.max(cVarF.a, cVarF2.a), Math.max(i8, i9), Math.max(i10, i11), Math.max(i12, i14)));
        C0649A.e(view, windowInsets, false);
        duration.addUpdateListener(new x(c0653e, tB, t6, i13, view));
        duration.addListener(new y(view, c0653e));
        RunnableC1254a runnableC1254a = new RunnableC1254a(view, c0653e, tVar, duration);
        if (view == null) {
            throw new NullPointerException("view == null");
        }
        ViewTreeObserverOnPreDrawListenerC0669g viewTreeObserverOnPreDrawListenerC0669g = new ViewTreeObserverOnPreDrawListenerC0669g(view, runnableC1254a);
        view.getViewTreeObserver().addOnPreDrawListener(viewTreeObserverOnPreDrawListenerC0669g);
        view.addOnAttachStateChangeListener(viewTreeObserverOnPreDrawListenerC0669g);
        this.f8154b = tB;
        return C0649A.h(view, windowInsets);
    }
}

package c1;

import android.os.Build;
import android.view.View;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public class P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final T f8135b;
    public final T a;

    static {
        int i5 = Build.VERSION.SDK_INT;
        f8135b = (i5 >= 30 ? new C0657I() : i5 >= 29 ? new C0656H() : new C0655G()).b().a.a().a.b().a.c();
    }

    public P(T t5) {
        this.a = t5;
    }

    public T a() {
        return this.a;
    }

    public T b() {
        return this.a;
    }

    public T c() {
        return this.a;
    }

    public C0667e e() {
        return null;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof P)) {
            return false;
        }
        P p4 = (P) obj;
        return n() == p4.n() && m() == p4.m() && Objects.equals(k(), p4.k()) && Objects.equals(i(), p4.i()) && Objects.equals(e(), p4.e());
    }

    public X0.c f(int i5) {
        return X0.c.f6881e;
    }

    public X0.c g(int i5) {
        if ((i5 & 8) == 0) {
            return X0.c.f6881e;
        }
        throw new IllegalArgumentException("Unable to query the maximum insets for IME");
    }

    public X0.c h() {
        return k();
    }

    public int hashCode() {
        return Objects.hash(Boolean.valueOf(n()), Boolean.valueOf(m()), k(), i(), e());
    }

    public X0.c i() {
        return X0.c.f6881e;
    }

    public X0.c j() {
        return k();
    }

    public X0.c k() {
        return X0.c.f6881e;
    }

    public X0.c l() {
        return k();
    }

    public boolean m() {
        return false;
    }

    public boolean n() {
        return false;
    }

    public boolean o(int i5) {
        return true;
    }

    public void d(View view) {
    }

    public void p(X0.c[] cVarArr) {
    }

    public void q(T t5) {
    }

    public void r(X0.c cVar) {
    }
}

package c1;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public final class T {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final T f8136b;
    public final P a;

    static {
        if (Build.VERSION.SDK_INT >= 30) {
            f8136b = O.f8134q;
        } else {
            f8136b = P.f8135b;
        }
    }

    public T(WindowInsets windowInsets) {
        int i5 = Build.VERSION.SDK_INT;
        if (i5 >= 30) {
            this.a = new O(this, windowInsets);
            return;
        }
        if (i5 >= 29) {
            this.a = new C0662N(this, windowInsets);
        } else if (i5 >= 28) {
            this.a = new C0661M(this, windowInsets);
        } else {
            this.a = new C0660L(this, windowInsets);
        }
    }

    public static T b(View view, WindowInsets windowInsets) {
        windowInsets.getClass();
        T t5 = new T(windowInsets);
        if (view != null && view.isAttachedToWindow()) {
            int i5 = AbstractC0680s.a;
            T tA = AbstractC0675m.a(view);
            P p4 = t5.a;
            p4.q(tA);
            p4.d(view.getRootView());
        }
        return t5;
    }

    public final WindowInsets a() {
        P p4 = this.a;
        if (p4 instanceof AbstractC0659K) {
            return ((AbstractC0659K) p4).f8125c;
        }
        return null;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof T)) {
            return false;
        }
        return Objects.equals(this.a, ((T) obj).a);
    }

    public final int hashCode() {
        P p4 = this.a;
        if (p4 == null) {
            return 0;
        }
        return p4.hashCode();
    }

    public T() {
        this.a = new P(this);
    }
}

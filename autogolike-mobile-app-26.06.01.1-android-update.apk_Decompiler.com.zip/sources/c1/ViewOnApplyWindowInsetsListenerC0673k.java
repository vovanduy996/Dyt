package c1;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;

/* JADX INFO: renamed from: c1.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class ViewOnApplyWindowInsetsListenerC0673k implements View.OnApplyWindowInsetsListener {
    public T a = null;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ View f8143b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0668f f8144c;

    public ViewOnApplyWindowInsetsListenerC0673k(View view, InterfaceC0668f interfaceC0668f) {
        this.f8143b = view;
        this.f8144c = interfaceC0668f;
    }

    @Override // android.view.View.OnApplyWindowInsetsListener
    public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
        T tB = T.b(view, windowInsets);
        int i5 = Build.VERSION.SDK_INT;
        InterfaceC0668f interfaceC0668f = this.f8144c;
        if (i5 < 30) {
            AbstractC0674l.a(windowInsets, this.f8143b);
            if (tB.equals(this.a)) {
                return ((q.O) interfaceC0668f).a(view, tB).a();
            }
        }
        this.a = tB;
        T tA = ((q.O) interfaceC0668f).a(view, tB);
        if (i5 >= 30) {
            return tA.a();
        }
        int i6 = AbstractC0680s.a;
        AbstractC0672j.c(view);
        return tA.a();
    }
}

package c1;

import android.view.View;
import com.google.android.gms.internal.measurement.K1;

/* JADX INFO: renamed from: c1.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0664b {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final View.AccessibilityDelegate f8137c = new View.AccessibilityDelegate();
    public final View.AccessibilityDelegate a = f8137c;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C0663a f8138b = new C0663a(this);

    public abstract K1 a(View view);
}

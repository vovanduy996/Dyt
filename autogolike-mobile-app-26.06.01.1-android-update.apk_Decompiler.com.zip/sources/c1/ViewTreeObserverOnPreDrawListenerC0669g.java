package c1;

import android.view.View;
import android.view.ViewTreeObserver;

/* JADX INFO: renamed from: c1.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class ViewTreeObserverOnPreDrawListenerC0669g implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final View f8139l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public ViewTreeObserver f8140m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Runnable f8141n;

    public ViewTreeObserverOnPreDrawListenerC0669g(View view, Runnable runnable) {
        this.f8139l = view;
        this.f8140m = view.getViewTreeObserver();
        this.f8141n = runnable;
    }

    @Override // android.view.ViewTreeObserver.OnPreDrawListener
    public final boolean onPreDraw() {
        boolean zIsAlive = this.f8140m.isAlive();
        View view = this.f8139l;
        if (zIsAlive) {
            this.f8140m.removeOnPreDrawListener(this);
        } else {
            view.getViewTreeObserver().removeOnPreDrawListener(this);
        }
        view.removeOnAttachStateChangeListener(this);
        this.f8141n.run();
        return true;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
        this.f8140m = view.getViewTreeObserver();
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
        boolean zIsAlive = this.f8140m.isAlive();
        View view2 = this.f8139l;
        if (zIsAlive) {
            this.f8140m.removeOnPreDrawListener(this);
        } else {
            view2.getViewTreeObserver().removeOnPreDrawListener(this);
        }
        view2.removeOnAttachStateChangeListener(this);
    }
}

package c1;

import l3.AbstractC1324b;

/* JADX INFO: renamed from: c1.J, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0658J {
    public final T a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public X0.c[] f8119b;

    public AbstractC0658J() {
        this(new T());
    }

    public final void a() {
        X0.c[] cVarArr = this.f8119b;
        if (cVarArr != null) {
            X0.c cVarF = cVarArr[0];
            X0.c cVarF2 = cVarArr[1];
            T t5 = this.a;
            if (cVarF2 == null) {
                cVarF2 = t5.a.f(2);
            }
            if (cVarF == null) {
                cVarF = t5.a.f(1);
            }
            g(X0.c.a(cVarF, cVarF2));
            X0.c cVar = this.f8119b[AbstractC1324b.B(16)];
            if (cVar != null) {
                f(cVar);
            }
            X0.c cVar2 = this.f8119b[AbstractC1324b.B(32)];
            if (cVar2 != null) {
                d(cVar2);
            }
            X0.c cVar3 = this.f8119b[AbstractC1324b.B(64)];
            if (cVar3 != null) {
                h(cVar3);
            }
        }
    }

    public abstract T b();

    public void c(int i5, X0.c cVar) {
        if (this.f8119b == null) {
            this.f8119b = new X0.c[9];
        }
        for (int i6 = 1; i6 <= 256; i6 <<= 1) {
            if ((i5 & i6) != 0) {
                this.f8119b[AbstractC1324b.B(i6)] = cVar;
            }
        }
    }

    public abstract void e(X0.c cVar);

    public abstract void g(X0.c cVar);

    public AbstractC0658J(T t5) {
        this.a = t5;
    }

    public void d(X0.c cVar) {
    }

    public void f(X0.c cVar) {
    }

    public void h(X0.c cVar) {
    }
}

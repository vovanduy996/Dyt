package c1;

import android.view.View;
import android.view.WindowInsets;

/* JADX INFO: loaded from: classes.dex */
public final class O extends C0662N {

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final T f8134q = T.b(null, WindowInsets.CONSUMED);

    public O(T t5, WindowInsets windowInsets) {
        super(t5, windowInsets);
    }

    @Override // c1.AbstractC0659K, c1.P
    public X0.c f(int i5) {
        return X0.c.c(this.f8125c.getInsets(S.a(i5)));
    }

    @Override // c1.AbstractC0659K, c1.P
    public X0.c g(int i5) {
        return X0.c.c(this.f8125c.getInsetsIgnoringVisibility(S.a(i5)));
    }

    @Override // c1.AbstractC0659K, c1.P
    public boolean o(int i5) {
        return this.f8125c.isVisible(S.a(i5));
    }

    @Override // c1.AbstractC0659K, c1.P
    public final void d(View view) {
    }
}

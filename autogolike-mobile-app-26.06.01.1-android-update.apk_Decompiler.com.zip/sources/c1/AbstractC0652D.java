package c1;

import android.view.animation.Interpolator;

/* JADX INFO: renamed from: c1.D, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0652D {
    public float a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Interpolator f8107b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f8108c;

    public AbstractC0652D(Interpolator interpolator, long j5) {
        this.f8107b = interpolator;
        this.f8108c = j5;
    }

    public long a() {
        return this.f8108c;
    }

    public float b() {
        Interpolator interpolator = this.f8107b;
        return interpolator != null ? interpolator.getInterpolation(this.a) : this.a;
    }

    public void c(float f5) {
        this.a = f5;
    }
}

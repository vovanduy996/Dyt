package c1;

import android.view.WindowInsetsAnimation;

/* JADX INFO: renamed from: c1.C, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0651C extends AbstractC0652D {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final WindowInsetsAnimation f8106d;

    public C0651C(WindowInsetsAnimation windowInsetsAnimation) {
        super(null, 0L);
        this.f8106d = windowInsetsAnimation;
    }

    @Override // c1.AbstractC0652D
    public final long a() {
        return this.f8106d.getDurationMillis();
    }

    @Override // c1.AbstractC0652D
    public final float b() {
        return this.f8106d.getInterpolatedFraction();
    }

    @Override // c1.AbstractC0652D
    public final void c(float f5) {
        this.f8106d.setFraction(f5);
    }
}

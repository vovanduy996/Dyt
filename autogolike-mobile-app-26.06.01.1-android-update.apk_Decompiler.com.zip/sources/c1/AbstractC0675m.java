package c1;

import android.view.View;
import android.view.WindowInsets;

/* JADX INFO: renamed from: c1.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0675m {
    public static T a(View view) {
        WindowInsets rootWindowInsets = view.getRootWindowInsets();
        if (rootWindowInsets == null) {
            return null;
        }
        T tB = T.b(null, rootWindowInsets);
        P p4 = tB.a;
        p4.q(tB);
        p4.d(view.getRootView());
        return tB;
    }

    public static int b(View view) {
        return view.getScrollIndicators();
    }

    public static void c(View view, int i5) {
        view.setScrollIndicators(i5);
    }

    public static void d(View view, int i5, int i6) {
        view.setScrollIndicators(i5, i6);
    }
}

package c1;

import android.view.WindowInsets;

/* JADX INFO: renamed from: c1.N, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C0662N extends C0661M {

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public X0.c f8131n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public X0.c f8132o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public X0.c f8133p;

    public C0662N(T t5, WindowInsets windowInsets) {
        super(t5, windowInsets);
        this.f8131n = null;
        this.f8132o = null;
        this.f8133p = null;
    }

    @Override // c1.P
    public X0.c h() {
        if (this.f8132o == null) {
            this.f8132o = X0.c.c(this.f8125c.getMandatorySystemGestureInsets());
        }
        return this.f8132o;
    }

    @Override // c1.P
    public X0.c j() {
        if (this.f8131n == null) {
            this.f8131n = X0.c.c(this.f8125c.getSystemGestureInsets());
        }
        return this.f8131n;
    }

    @Override // c1.P
    public X0.c l() {
        if (this.f8133p == null) {
            this.f8133p = X0.c.c(this.f8125c.getTappableElementInsets());
        }
        return this.f8133p;
    }

    @Override // c1.C0660L, c1.P
    public void r(X0.c cVar) {
    }
}

package c1;

import android.os.Build;
import android.view.WindowInsets;
import android.view.WindowInsetsAnimation;
import android.view.WindowInsetsAnimation$Callback;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import q.j0;

/* JADX INFO: renamed from: c1.B, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0650B extends WindowInsetsAnimation$Callback {
    public final q.O a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ArrayList f8104b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final HashMap f8105c;

    public C0650B(q.O o3) {
        super(o3.f12562m);
        this.f8105c = new HashMap();
        this.a = o3;
    }

    public final C0653E a(WindowInsetsAnimation windowInsetsAnimation) {
        C0653E c0653e = (C0653E) this.f8105c.get(windowInsetsAnimation);
        if (c0653e == null) {
            c0653e = new C0653E(0, null, 0L);
            if (Build.VERSION.SDK_INT >= 30) {
                c0653e.a = new C0651C(windowInsetsAnimation);
            }
            this.f8105c.put(windowInsetsAnimation, c0653e);
        }
        return c0653e;
    }

    public final void onEnd(WindowInsetsAnimation windowInsetsAnimation) {
        this.a.b(a(windowInsetsAnimation));
        this.f8105c.remove(windowInsetsAnimation);
    }

    public final void onPrepare(WindowInsetsAnimation windowInsetsAnimation) {
        q.O o3 = this.a;
        a(windowInsetsAnimation);
        o3.f12564o = true;
        o3.f12565p = true;
    }

    public final WindowInsets onProgress(WindowInsets windowInsets, List list) {
        ArrayList arrayList = this.f8104b;
        if (arrayList == null) {
            ArrayList arrayList2 = new ArrayList(list.size());
            this.f8104b = arrayList2;
            Collections.unmodifiableList(arrayList2);
        } else {
            arrayList.clear();
        }
        for (int size = list.size() - 1; size >= 0; size--) {
            WindowInsetsAnimation windowInsetsAnimationI = D0.k.i(list.get(size));
            C0653E c0653eA = a(windowInsetsAnimationI);
            c0653eA.a.c(windowInsetsAnimationI.getFraction());
            this.f8104b.add(c0653eA);
        }
        q.O o3 = this.a;
        T tB = T.b(null, windowInsets);
        j0 j0Var = o3.f12563n;
        j0.a(j0Var, tB);
        if (j0Var.f12627s) {
            tB = T.f8136b;
        }
        return tB.a();
    }

    public final WindowInsetsAnimation.Bounds onStart(WindowInsetsAnimation windowInsetsAnimation, WindowInsetsAnimation.Bounds bounds) {
        q.O o3 = this.a;
        a(windowInsetsAnimation);
        X0.c cVarC = X0.c.c(bounds.getLowerBound());
        X0.c cVarC2 = X0.c.c(bounds.getUpperBound());
        o3.f12564o = false;
        D0.k.l();
        return D0.k.g(cVarC.d(), cVarC2.d());
    }
}

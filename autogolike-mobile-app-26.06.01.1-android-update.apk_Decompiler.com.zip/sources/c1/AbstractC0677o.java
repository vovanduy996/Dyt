package c1;

import android.view.View;
import dagger.hilt.android.R;
import e1.AbstractC0849a;
import i.C1096H;
import java.util.Objects;

/* JADX INFO: renamed from: c1.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0677o {
    public static void a(View view, InterfaceC0679q interfaceC0679q) {
        C1096H c1096h = (C1096H) view.getTag(R.id.tag_unhandled_key_listeners);
        if (c1096h == null) {
            c1096h = new C1096H(0);
            view.setTag(R.id.tag_unhandled_key_listeners, c1096h);
        }
        Objects.requireNonNull(interfaceC0679q);
        View.OnUnhandledKeyEventListener viewOnUnhandledKeyEventListenerC0676n = new ViewOnUnhandledKeyEventListenerC0676n();
        c1096h.put(interfaceC0679q, viewOnUnhandledKeyEventListenerC0676n);
        view.addOnUnhandledKeyEventListener(viewOnUnhandledKeyEventListenerC0676n);
    }

    public static CharSequence b(View view) {
        return view.getAccessibilityPaneTitle();
    }

    public static boolean c(View view) {
        return view.isAccessibilityHeading();
    }

    public static boolean d(View view) {
        return view.isScreenReaderFocusable();
    }

    public static void e(View view, InterfaceC0679q interfaceC0679q) {
        View.OnUnhandledKeyEventListener onUnhandledKeyEventListener;
        C1096H c1096h = (C1096H) view.getTag(R.id.tag_unhandled_key_listeners);
        if (c1096h == null || (onUnhandledKeyEventListener = (View.OnUnhandledKeyEventListener) c1096h.get(interfaceC0679q)) == null) {
            return;
        }
        view.removeOnUnhandledKeyEventListener(onUnhandledKeyEventListener);
    }

    public static <T> T f(View view, int i5) {
        return (T) view.requireViewById(i5);
    }

    public static void g(View view, boolean z3) {
        view.setAccessibilityHeading(z3);
    }

    public static void h(View view, CharSequence charSequence) {
        view.setAccessibilityPaneTitle(charSequence);
    }

    public static void i(View view, AbstractC0849a abstractC0849a) {
        view.setAutofillId(null);
    }

    public static void j(View view, boolean z3) {
        view.setScreenReaderFocusable(z3);
    }
}

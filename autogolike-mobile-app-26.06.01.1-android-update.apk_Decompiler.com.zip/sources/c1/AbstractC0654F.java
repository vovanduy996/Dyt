package c1;

import android.util.Log;
import android.view.View;
import java.lang.reflect.Field;

/* JADX INFO: renamed from: c1.F, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0654F {
    public static final Field a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Field f8109b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Field f8110c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final boolean f8111d;

    static {
        try {
            Field declaredField = View.class.getDeclaredField("mAttachInfo");
            a = declaredField;
            declaredField.setAccessible(true);
            Class<?> cls = Class.forName("android.view.View$AttachInfo");
            Field declaredField2 = cls.getDeclaredField("mStableInsets");
            f8109b = declaredField2;
            declaredField2.setAccessible(true);
            Field declaredField3 = cls.getDeclaredField("mContentInsets");
            f8110c = declaredField3;
            declaredField3.setAccessible(true);
            f8111d = true;
        } catch (ReflectiveOperationException e5) {
            Log.w("WindowInsetsCompat", "Failed to get visible insets from AttachInfo " + e5.getMessage(), e5);
        }
    }
}

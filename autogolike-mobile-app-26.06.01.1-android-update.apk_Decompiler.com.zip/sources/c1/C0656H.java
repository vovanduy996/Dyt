package c1;

import android.view.WindowInsets;
import b0.AbstractC0601t;

/* JADX INFO: renamed from: c1.H, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C0656H extends AbstractC0658J {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final WindowInsets.Builder f8118c;

    public C0656H() {
        this.f8118c = AbstractC0601t.b();
    }

    @Override // c1.AbstractC0658J
    public T b() {
        a();
        T tB = T.b(null, this.f8118c.build());
        tB.a.p(this.f8119b);
        return tB;
    }

    @Override // c1.AbstractC0658J
    public void d(X0.c cVar) {
        this.f8118c.setMandatorySystemGestureInsets(cVar.d());
    }

    @Override // c1.AbstractC0658J
    public void e(X0.c cVar) {
        this.f8118c.setStableInsets(cVar.d());
    }

    @Override // c1.AbstractC0658J
    public void f(X0.c cVar) {
        this.f8118c.setSystemGestureInsets(cVar.d());
    }

    @Override // c1.AbstractC0658J
    public void g(X0.c cVar) {
        this.f8118c.setSystemWindowInsets(cVar.d());
    }

    @Override // c1.AbstractC0658J
    public void h(X0.c cVar) {
        this.f8118c.setTappableElementInsets(cVar.d());
    }

    public C0656H(T t5) {
        WindowInsets.Builder builderB;
        super(t5);
        WindowInsets windowInsetsA = t5.a();
        if (windowInsetsA != null) {
            builderB = AbstractC0601t.c(windowInsetsA);
        } else {
            builderB = AbstractC0601t.b();
        }
        this.f8118c = builderB;
    }
}

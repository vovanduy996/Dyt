package c1;

/* JADX INFO: renamed from: c1.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0679q {
}

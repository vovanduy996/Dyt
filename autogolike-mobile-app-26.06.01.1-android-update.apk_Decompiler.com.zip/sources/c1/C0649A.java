package c1;

import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.PathInterpolator;
import dagger.hilt.android.R;
import q.j0;
import q1.InterpolatorC1610a;

/* JADX INFO: renamed from: c1.A, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0649A extends AbstractC0652D {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final PathInterpolator f8101d = new PathInterpolator(0.0f, 1.1f, 0.0f, 1.0f);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final InterpolatorC1610a f8102e = new InterpolatorC1610a(InterpolatorC1610a.f12673c);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final DecelerateInterpolator f8103f = new DecelerateInterpolator();

    public static void d(View view, C0653E c0653e) {
        q.O oI = i(view);
        if (oI != null) {
            oI.b(c0653e);
            if (oI.f12562m == 0) {
                return;
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i5 = 0; i5 < viewGroup.getChildCount(); i5++) {
                d(viewGroup.getChildAt(i5), c0653e);
            }
        }
    }

    public static void e(View view, WindowInsets windowInsets, boolean z3) {
        q.O oI = i(view);
        if (oI != null) {
            oI.f12561l = windowInsets;
            if (!z3) {
                z3 = true;
                oI.f12564o = true;
                oI.f12565p = true;
                if (oI.f12562m != 0) {
                    z3 = false;
                }
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i5 = 0; i5 < viewGroup.getChildCount(); i5++) {
                e(viewGroup.getChildAt(i5), windowInsets, z3);
            }
        }
    }

    public static void f(View view, T t5) {
        q.O oI = i(view);
        if (oI != null) {
            j0 j0Var = oI.f12563n;
            j0.a(j0Var, t5);
            if (j0Var.f12627s) {
                t5 = T.f8136b;
            }
            if (oI.f12562m == 0) {
                return;
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i5 = 0; i5 < viewGroup.getChildCount(); i5++) {
                f(viewGroup.getChildAt(i5), t5);
            }
        }
    }

    public static void g(View view) {
        q.O oI = i(view);
        if (oI != null) {
            oI.f12564o = false;
            if (oI.f12562m == 0) {
                return;
            }
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i5 = 0; i5 < viewGroup.getChildCount(); i5++) {
                g(viewGroup.getChildAt(i5));
            }
        }
    }

    public static WindowInsets h(View view, WindowInsets windowInsets) {
        return view.getTag(R.id.tag_on_apply_window_listener) != null ? windowInsets : view.onApplyWindowInsets(windowInsets);
    }

    public static q.O i(View view) {
        Object tag = view.getTag(R.id.tag_window_insets_animation_callback);
        if (tag instanceof z) {
            return ((z) tag).a;
        }
        return null;
    }
}

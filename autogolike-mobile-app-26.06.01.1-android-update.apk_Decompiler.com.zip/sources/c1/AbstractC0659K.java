package c1;

import android.annotation.SuppressLint;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;
import l3.AbstractC1324b;

/* JADX INFO: renamed from: c1.K, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0659K extends P {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static boolean f8120h = false;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static Method f8121i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static Class f8122j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static Field f8123k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static Field f8124l;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final WindowInsets f8125c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public X0.c[] f8126d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public X0.c f8127e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public T f8128f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public X0.c f8129g;

    public AbstractC0659K(T t5, WindowInsets windowInsets) {
        super(t5);
        this.f8127e = null;
        this.f8125c = windowInsets;
    }

    @SuppressLint({"WrongConstant"})
    private X0.c s(int i5, boolean z3) {
        X0.c cVarA = X0.c.f6881e;
        for (int i6 = 1; i6 <= 256; i6 <<= 1) {
            if ((i5 & i6) != 0) {
                cVarA = X0.c.a(cVarA, t(i6, z3));
            }
        }
        return cVarA;
    }

    private X0.c u() {
        T t5 = this.f8128f;
        return t5 != null ? t5.a.i() : X0.c.f6881e;
    }

    private X0.c v(View view) {
        if (Build.VERSION.SDK_INT >= 30) {
            throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
        }
        if (!f8120h) {
            x();
        }
        Method method = f8121i;
        if (method != null && f8122j != null && f8123k != null) {
            try {
                Object objInvoke = method.invoke(view, null);
                if (objInvoke == null) {
                    Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
                    return null;
                }
                Rect rect = (Rect) f8123k.get(f8124l.get(objInvoke));
                if (rect != null) {
                    return X0.c.b(rect.left, rect.top, rect.right, rect.bottom);
                }
                return null;
            } catch (ReflectiveOperationException e5) {
                Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e5.getMessage(), e5);
            }
        }
        return null;
    }

    @SuppressLint({"PrivateApi"})
    private static void x() {
        try {
            f8121i = View.class.getDeclaredMethod("getViewRootImpl", null);
            Class<?> cls = Class.forName("android.view.View$AttachInfo");
            f8122j = cls;
            f8123k = cls.getDeclaredField("mVisibleInsets");
            f8124l = Class.forName("android.view.ViewRootImpl").getDeclaredField("mAttachInfo");
            f8123k.setAccessible(true);
            f8124l.setAccessible(true);
        } catch (ReflectiveOperationException e5) {
            Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e5.getMessage(), e5);
        }
        f8120h = true;
    }

    @Override // c1.P
    public void d(View view) {
        X0.c cVarV = v(view);
        if (cVarV == null) {
            cVarV = X0.c.f6881e;
        }
        y(cVarV);
    }

    @Override // c1.P
    public boolean equals(Object obj) {
        if (super.equals(obj)) {
            return Objects.equals(this.f8129g, ((AbstractC0659K) obj).f8129g);
        }
        return false;
    }

    @Override // c1.P
    public X0.c f(int i5) {
        return s(i5, false);
    }

    @Override // c1.P
    public X0.c g(int i5) {
        return s(i5, true);
    }

    @Override // c1.P
    public final X0.c k() {
        if (this.f8127e == null) {
            WindowInsets windowInsets = this.f8125c;
            this.f8127e = X0.c.b(windowInsets.getSystemWindowInsetLeft(), windowInsets.getSystemWindowInsetTop(), windowInsets.getSystemWindowInsetRight(), windowInsets.getSystemWindowInsetBottom());
        }
        return this.f8127e;
    }

    @Override // c1.P
    public boolean n() {
        return this.f8125c.isRound();
    }

    @Override // c1.P
    @SuppressLint({"WrongConstant"})
    public boolean o(int i5) {
        for (int i6 = 1; i6 <= 256; i6 <<= 1) {
            if ((i5 & i6) != 0 && !w(i6)) {
                return false;
            }
        }
        return true;
    }

    @Override // c1.P
    public void p(X0.c[] cVarArr) {
        this.f8126d = cVarArr;
    }

    @Override // c1.P
    public void q(T t5) {
        this.f8128f = t5;
    }

    public X0.c t(int i5, boolean z3) {
        X0.c cVarI;
        int i6;
        if (i5 == 1) {
            return z3 ? X0.c.b(0, Math.max(u().f6882b, k().f6882b), 0, 0) : X0.c.b(0, k().f6882b, 0, 0);
        }
        if (i5 == 2) {
            if (z3) {
                X0.c cVarU = u();
                X0.c cVarI2 = i();
                return X0.c.b(Math.max(cVarU.a, cVarI2.a), 0, Math.max(cVarU.f6883c, cVarI2.f6883c), Math.max(cVarU.f6884d, cVarI2.f6884d));
            }
            X0.c cVarK = k();
            T t5 = this.f8128f;
            cVarI = t5 != null ? t5.a.i() : null;
            int iMin = cVarK.f6884d;
            if (cVarI != null) {
                iMin = Math.min(iMin, cVarI.f6884d);
            }
            return X0.c.b(cVarK.a, 0, cVarK.f6883c, iMin);
        }
        X0.c cVar = X0.c.f6881e;
        if (i5 == 8) {
            X0.c[] cVarArr = this.f8126d;
            cVarI = cVarArr != null ? cVarArr[AbstractC1324b.B(8)] : null;
            if (cVarI != null) {
                return cVarI;
            }
            X0.c cVarK2 = k();
            X0.c cVarU2 = u();
            int i7 = cVarK2.f6884d;
            if (i7 > cVarU2.f6884d) {
                return X0.c.b(0, 0, 0, i7);
            }
            X0.c cVar2 = this.f8129g;
            return (cVar2 == null || cVar2.equals(cVar) || (i6 = this.f8129g.f6884d) <= cVarU2.f6884d) ? cVar : X0.c.b(0, 0, 0, i6);
        }
        if (i5 == 16) {
            return j();
        }
        if (i5 == 32) {
            return h();
        }
        if (i5 == 64) {
            return l();
        }
        if (i5 != 128) {
            return cVar;
        }
        T t6 = this.f8128f;
        C0667e c0667eE = t6 != null ? t6.a.e() : e();
        if (c0667eE == null) {
            return cVar;
        }
        int i8 = Build.VERSION.SDK_INT;
        return X0.c.b(i8 >= 28 ? AbstractC0665c.d(c0667eE.a) : 0, i8 >= 28 ? AbstractC0665c.f(c0667eE.a) : 0, i8 >= 28 ? AbstractC0665c.e(c0667eE.a) : 0, i8 >= 28 ? AbstractC0665c.c(c0667eE.a) : 0);
    }

    public boolean w(int i5) {
        if (i5 != 1 && i5 != 2) {
            if (i5 == 4) {
                return false;
            }
            if (i5 != 8 && i5 != 128) {
                return true;
            }
        }
        return !t(i5, false).equals(X0.c.f6881e);
    }

    public void y(X0.c cVar) {
        this.f8129g = cVar;
    }
}

package c1;

import android.os.Build;
import android.view.animation.Interpolator;

/* JADX INFO: renamed from: c1.E, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0653E {
    public AbstractC0652D a;

    public C0653E(int i5, Interpolator interpolator, long j5) {
        if (Build.VERSION.SDK_INT >= 30) {
            this.a = new C0651C(D0.k.h(i5, interpolator, j5));
        } else {
            this.a = new C0649A(interpolator, j5);
        }
    }
}

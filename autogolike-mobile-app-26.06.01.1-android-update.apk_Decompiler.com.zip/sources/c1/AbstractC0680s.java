package c1;

import android.os.Build;
import android.view.View;
import android.view.animation.PathInterpolator;
import dagger.hilt.android.R;
import java.util.WeakHashMap;

/* JADX INFO: renamed from: c1.s, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0680s {
    public static final /* synthetic */ int a = 0;

    static {
        new WeakHashMap();
    }

    public static void a(View view, q.O o3) {
        if (Build.VERSION.SDK_INT >= 30) {
            view.setWindowInsetsAnimationCallback(o3 != null ? new C0650B(o3) : null);
            return;
        }
        PathInterpolator pathInterpolator = C0649A.f8101d;
        Object tag = view.getTag(R.id.tag_on_apply_window_listener);
        if (o3 == null) {
            view.setTag(R.id.tag_window_insets_animation_callback, null);
            if (tag == null) {
                view.setOnApplyWindowInsetsListener(null);
                return;
            }
            return;
        }
        View.OnApplyWindowInsetsListener zVar = new z(view, o3);
        view.setTag(R.id.tag_window_insets_animation_callback, zVar);
        if (tag == null) {
            view.setOnApplyWindowInsetsListener(zVar);
        }
    }
}

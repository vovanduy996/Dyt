package c1;

import android.view.Window;

/* JADX INFO: loaded from: classes.dex */
public abstract class w {
    public static void a(Window window, boolean z3) {
        window.setDecorFitsSystemWindows(z3);
    }
}

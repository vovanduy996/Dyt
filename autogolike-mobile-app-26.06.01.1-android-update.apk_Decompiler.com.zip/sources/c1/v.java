package c1;

import android.view.ViewParent;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class v extends U3.h implements T3.c {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final v f8148t = new v(1, ViewParent.class, "getParent", "getParent()Landroid/view/ViewParent;", 0);

    @Override // T3.c
    public final Object invoke(Object obj) {
        return ((ViewParent) obj).getParent();
    }
}

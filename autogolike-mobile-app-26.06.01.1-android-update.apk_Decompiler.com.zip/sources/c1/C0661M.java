package c1;

import android.view.DisplayCutout;
import android.view.WindowInsets;
import java.util.Objects;

/* JADX INFO: renamed from: c1.M, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C0661M extends C0660L {
    public C0661M(T t5, WindowInsets windowInsets) {
        super(t5, windowInsets);
    }

    @Override // c1.P
    public T a() {
        return T.b(null, this.f8125c.consumeDisplayCutout());
    }

    @Override // c1.P
    public C0667e e() {
        DisplayCutout displayCutout = this.f8125c.getDisplayCutout();
        if (displayCutout == null) {
            return null;
        }
        return new C0667e(displayCutout);
    }

    @Override // c1.AbstractC0659K, c1.P
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0661M)) {
            return false;
        }
        C0661M c0661m = (C0661M) obj;
        return Objects.equals(this.f8125c, c0661m.f8125c) && Objects.equals(this.f8129g, c0661m.f8129g);
    }

    @Override // c1.P
    public int hashCode() {
        return this.f8125c.hashCode();
    }
}

package c1;

import android.animation.ValueAnimator;
import android.os.Build;
import android.view.View;
import android.view.animation.PathInterpolator;
import java.util.Collections;

/* JADX INFO: loaded from: classes.dex */
public final class x implements ValueAnimator.AnimatorUpdateListener {
    public final /* synthetic */ C0653E a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ T f8149b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ T f8150c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f8151d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ View f8152e;

    public x(C0653E c0653e, T t5, T t6, int i5, View view) {
        this.a = c0653e;
        this.f8149b = t5;
        this.f8150c = t6;
        this.f8151d = i5;
        this.f8152e = view;
    }

    @Override // android.animation.ValueAnimator.AnimatorUpdateListener
    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        float f5;
        C0653E c0653e;
        AbstractC0658J abstractC0658J;
        float animatedFraction = valueAnimator.getAnimatedFraction();
        C0653E c0653e2 = this.a;
        c0653e2.a.c(animatedFraction);
        float fB = c0653e2.a.b();
        PathInterpolator pathInterpolator = C0649A.f8101d;
        int i5 = Build.VERSION.SDK_INT;
        T t5 = this.f8149b;
        AbstractC0658J c0657i = i5 >= 30 ? new C0657I(t5) : i5 >= 29 ? new C0656H(t5) : new C0655G(t5);
        int i6 = 1;
        while (i6 <= 256) {
            int i7 = this.f8151d & i6;
            P p4 = t5.a;
            if (i7 == 0) {
                c0657i.c(i6, p4.f(i6));
                f5 = fB;
                c0653e = c0653e2;
                abstractC0658J = c0657i;
            } else {
                X0.c cVarF = p4.f(i6);
                X0.c cVarF2 = this.f8150c.a.f(i6);
                int i8 = cVarF.a;
                float f6 = 1.0f - fB;
                int i9 = (int) (((double) ((i8 - cVarF2.a) * f6)) + 0.5d);
                int i10 = cVarF2.f6882b;
                int i11 = cVarF.f6882b;
                f5 = fB;
                int i12 = (int) (((double) ((i11 - i10) * f6)) + 0.5d);
                int i13 = cVarF2.f6883c;
                int i14 = cVarF.f6883c;
                c0653e = c0653e2;
                int i15 = (int) (((double) ((i14 - i13) * f6)) + 0.5d);
                int i16 = cVarF2.f6884d;
                int i17 = cVarF.f6884d;
                float f7 = (i17 - i16) * f6;
                abstractC0658J = c0657i;
                int i18 = (int) (((double) f7) + 0.5d);
                int iMax = Math.max(0, i8 - i9);
                int iMax2 = Math.max(0, i11 - i12);
                int iMax3 = Math.max(0, i14 - i15);
                int iMax4 = Math.max(0, i17 - i18);
                if (iMax != i9 || iMax2 != i12 || iMax3 != i15 || iMax4 != i18) {
                    cVarF = X0.c.b(iMax, iMax2, iMax3, iMax4);
                }
                abstractC0658J.c(i6, cVarF);
            }
            i6 <<= 1;
            fB = f5;
            c0657i = abstractC0658J;
            c0653e2 = c0653e;
        }
        T tB = c0657i.b();
        Collections.singletonList(c0653e2);
        C0649A.f(this.f8152e, tB);
    }
}

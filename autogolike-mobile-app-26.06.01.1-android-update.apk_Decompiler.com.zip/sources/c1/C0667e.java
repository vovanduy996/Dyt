package c1;

import android.view.DisplayCutout;
import java.util.Objects;

/* JADX INFO: renamed from: c1.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0667e {
    public final DisplayCutout a;

    public C0667e(DisplayCutout displayCutout) {
        this.a = displayCutout;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C0667e.class != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.a, ((C0667e) obj).a);
    }

    public final int hashCode() {
        return this.a.hashCode();
    }

    public final String toString() {
        return "DisplayCutoutCompat{" + this.a + "}";
    }
}

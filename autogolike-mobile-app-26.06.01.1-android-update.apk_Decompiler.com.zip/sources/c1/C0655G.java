package c1;

import android.graphics.Rect;
import android.util.Log;
import android.view.WindowInsets;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

/* JADX INFO: renamed from: c1.G, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0655G extends AbstractC0658J {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static Field f8112e = null;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static boolean f8113f = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static Constructor f8114g = null;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static boolean f8115h = false;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public WindowInsets f8116c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public X0.c f8117d;

    public C0655G() {
        this.f8116c = i();
    }

    private static WindowInsets i() {
        if (!f8113f) {
            try {
                f8112e = WindowInsets.class.getDeclaredField("CONSUMED");
            } catch (ReflectiveOperationException e5) {
                Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", e5);
            }
            f8113f = true;
        }
        Field field = f8112e;
        if (field != null) {
            try {
                WindowInsets windowInsets = (WindowInsets) field.get(null);
                if (windowInsets != null) {
                    return new WindowInsets(windowInsets);
                }
            } catch (ReflectiveOperationException e6) {
                Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", e6);
            }
        }
        if (!f8115h) {
            try {
                f8114g = WindowInsets.class.getConstructor(Rect.class);
            } catch (ReflectiveOperationException e7) {
                Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", e7);
            }
            f8115h = true;
        }
        Constructor constructor = f8114g;
        if (constructor != null) {
            try {
                return (WindowInsets) constructor.newInstance(new Rect());
            } catch (ReflectiveOperationException e8) {
                Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", e8);
            }
        }
        return null;
    }

    @Override // c1.AbstractC0658J
    public T b() {
        a();
        T tB = T.b(null, this.f8116c);
        X0.c[] cVarArr = this.f8119b;
        P p4 = tB.a;
        p4.p(cVarArr);
        p4.r(this.f8117d);
        return tB;
    }

    @Override // c1.AbstractC0658J
    public void e(X0.c cVar) {
        this.f8117d = cVar;
    }

    @Override // c1.AbstractC0658J
    public void g(X0.c cVar) {
        WindowInsets windowInsets = this.f8116c;
        if (windowInsets != null) {
            this.f8116c = windowInsets.replaceSystemWindowInsets(cVar.a, cVar.f6882b, cVar.f6883c, cVar.f6884d);
        }
    }

    public C0655G(T t5) {
        super(t5);
        this.f8116c = t5.a();
    }
}

package c1;

import android.view.WindowInsets;

/* JADX INFO: renamed from: c1.L, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C0660L extends AbstractC0659K {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public X0.c f8130m;

    public C0660L(T t5, WindowInsets windowInsets) {
        super(t5, windowInsets);
        this.f8130m = null;
    }

    @Override // c1.P
    public T b() {
        return T.b(null, this.f8125c.consumeStableInsets());
    }

    @Override // c1.P
    public T c() {
        return T.b(null, this.f8125c.consumeSystemWindowInsets());
    }

    @Override // c1.P
    public final X0.c i() {
        if (this.f8130m == null) {
            WindowInsets windowInsets = this.f8125c;
            this.f8130m = X0.c.b(windowInsets.getStableInsetLeft(), windowInsets.getStableInsetTop(), windowInsets.getStableInsetRight(), windowInsets.getStableInsetBottom());
        }
        return this.f8130m;
    }

    @Override // c1.P
    public boolean m() {
        return this.f8125c.isConsumed();
    }

    @Override // c1.P
    public void r(X0.c cVar) {
        this.f8130m = cVar;
    }
}

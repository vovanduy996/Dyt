package c1;

/* JADX INFO: renamed from: c1.I, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0657I extends C0656H {
    public C0657I() {
    }

    @Override // c1.AbstractC0658J
    public void c(int i5, X0.c cVar) {
        this.f8118c.setInsets(S.a(i5), cVar.d());
    }

    public C0657I(T t5) {
        super(t5);
    }
}

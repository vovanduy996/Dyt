package t1;

import U3.j;

/* JADX INFO: renamed from: t1.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1819a extends AbstractC1821c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final C1819a f13679b = new C1819a();

    @Override // t1.AbstractC1821c
    public final Object a(InterfaceC1820b interfaceC1820b) {
        j.f(interfaceC1820b, "key");
        return null;
    }
}

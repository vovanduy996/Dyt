package t1;

import U3.j;

/* JADX INFO: renamed from: t1.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1822d extends AbstractC1821c {
    public /* synthetic */ C1822d() {
        this(C1819a.f13679b);
    }

    @Override // t1.AbstractC1821c
    public final Object a(InterfaceC1820b interfaceC1820b) {
        j.f(interfaceC1820b, "key");
        return this.a.get(interfaceC1820b);
    }

    public final void b(InterfaceC1820b interfaceC1820b, Object obj) {
        j.f(interfaceC1820b, "key");
        this.a.put(interfaceC1820b, obj);
    }

    public C1822d(AbstractC1821c abstractC1821c) {
        j.f(abstractC1821c, "initialExtras");
        this.a.putAll(abstractC1821c.a);
    }
}

package t1;

import java.util.LinkedHashMap;

/* JADX INFO: renamed from: t1.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1821c {
    public final LinkedHashMap a = new LinkedHashMap();

    public abstract Object a(InterfaceC1820b interfaceC1820b);
}

package g;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import l3.AbstractC1324b;

/* JADX INFO: renamed from: g.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0995c extends AbstractC1324b {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Object f9864g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final ExecutorService f9865h = Executors.newFixedThreadPool(4, new ThreadFactoryC0994b());
}

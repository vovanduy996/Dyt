package g;

import l3.AbstractC1324b;

/* JADX INFO: renamed from: g.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0993a extends AbstractC1324b {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static volatile C0993a f9861h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final B1.c f9862i = new B1.c(1);

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final C0995c f9863g = new C0995c();

    public static C0993a L() {
        if (f9861h != null) {
            return f9861h;
        }
        synchronized (C0993a.class) {
            try {
                if (f9861h == null) {
                    f9861h = new C0993a();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return f9861h;
    }
}

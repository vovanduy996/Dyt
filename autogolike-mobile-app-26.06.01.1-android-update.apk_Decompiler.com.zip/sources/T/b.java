package T;

import I.Z0;

/* JADX INFO: loaded from: classes.dex */
public abstract class b {
    public static final Z0 a = new Z0(a.f6077l);
}

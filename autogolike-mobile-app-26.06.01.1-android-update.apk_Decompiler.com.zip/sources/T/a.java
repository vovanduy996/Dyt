package T;

import U3.k;

/* JADX INFO: loaded from: classes.dex */
public final class a extends k implements T3.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final a f6077l = new a(0);

    @Override // T3.a
    public final /* bridge */ /* synthetic */ Object b() {
        return null;
    }
}

package X1;

import G3.AbstractC0164a;
import G3.C;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;
import l.AbstractC1279A;
import l.AbstractC1287d;
import l.B0;
import l.C1285c;

/* JADX INFO: loaded from: classes.dex */
public final class n extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f6990p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ C1285c f6991q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ long f6992r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ int f6993s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public n(C1285c c1285c, long j5, int i5, Continuation continuation) {
        super(2, continuation);
        this.f6991q = c1285c;
        this.f6992r = j5;
        this.f6993s = i5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((n) m((InterfaceC0991y) obj, (Continuation) obj2)).o(C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new n(this.f6991q, this.f6992r, this.f6993s, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f6990p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            Float f5 = new Float(this.f6992r);
            B0 b0O = AbstractC1287d.o(this.f6993s, 0, AbstractC1279A.a, 2);
            this.f6990p = 1;
            if (C1285c.c(this.f6991q, f5, b0O, null, this, 12) == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return C.a;
    }
}

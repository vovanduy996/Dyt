package X1;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class h {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public static final h f6937A;
    public static final h B;
    public static final h C;
    public static final h D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public static final h f6938E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public static final h f6939F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public static final h f6940G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public static final h f6941H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public static final h f6942I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public static final h f6943J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public static final h f6944K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public static final h f6945L;

    /* JADX INFO: renamed from: M, reason: collision with root package name */
    public static final h f6946M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public static final h f6947N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public static final h f6948O;

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public static final h f6949P;

    /* JADX INFO: renamed from: Q, reason: collision with root package name */
    public static final /* synthetic */ h[] f6950Q;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final h f6951l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final h f6952m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final h f6953n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final h f6954o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final h f6955p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final h f6956q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final h f6957r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final h f6958s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final h f6959t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final h f6960u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final h f6961v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final h f6962w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final h f6963x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public static final h f6964y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public static final h f6965z;

    static {
        h hVar = new h("Home", 0);
        f6951l = hVar;
        h hVar2 = new h("Users", 1);
        f6952m = hVar2;
        h hVar3 = new h("Play", 2);
        f6953n = hVar3;
        h hVar4 = new h("Settings", 3);
        f6954o = hVar4;
        h hVar5 = new h("Plus", 4);
        f6955p = hVar5;
        h hVar6 = new h("Chevron", 5);
        f6956q = hVar6;
        h hVar7 = new h("ChevronDown", 6);
        h hVar8 = new h("Search", 7);
        f6957r = hVar8;
        h hVar9 = new h("Close", 8);
        f6958s = hVar9;
        h hVar10 = new h("Refresh", 9);
        f6959t = hVar10;
        h hVar11 = new h("Pause", 10);
        f6960u = hVar11;
        h hVar12 = new h("Stop", 11);
        f6961v = hVar12;
        h hVar13 = new h("Alert", 12);
        f6962w = hVar13;
        h hVar14 = new h("Check", 13);
        f6963x = hVar14;
        h hVar15 = new h("Arrow", 14);
        f6964y = hVar15;
        h hVar16 = new h("ArrowBack", 15);
        f6965z = hVar16;
        h hVar17 = new h("ArrowUp", 16);
        f6937A = hVar17;
        h hVar18 = new h("Bolt", 17);
        B = hVar18;
        h hVar19 = new h("Filter", 18);
        C = hVar19;
        h hVar20 = new h("More", 19);
        D = hVar20;
        h hVar21 = new h("Wallet", 20);
        f6938E = hVar21;
        h hVar22 = new h("Trend", 21);
        h hVar23 = new h("Target", 22);
        f6939F = hVar23;
        h hVar24 = new h("Shield", 23);
        f6940G = hVar24;
        h hVar25 = new h("Globe", 24);
        f6941H = hVar25;
        h hVar26 = new h("Key", 25);
        f6942I = hVar26;
        h hVar27 = new h("Moon", 26);
        f6943J = hVar27;
        h hVar28 = new h("Bell", 27);
        f6944K = hVar28;
        h hVar29 = new h("Sparkle", 28);
        f6945L = hVar29;
        h hVar30 = new h("Chip", 29);
        f6946M = hVar30;
        h hVar31 = new h("Eye", 30);
        f6947N = hVar31;
        h hVar32 = new h("Clock", 31);
        f6948O = hVar32;
        h hVar33 = new h("Wifi", 32);
        h hVar34 = new h("Battery", 33);
        f6949P = hVar34;
        f6950Q = new h[]{hVar, hVar2, hVar3, hVar4, hVar5, hVar6, hVar7, hVar8, hVar9, hVar10, hVar11, hVar12, hVar13, hVar14, hVar15, hVar16, hVar17, hVar18, hVar19, hVar20, hVar21, hVar22, hVar23, hVar24, hVar25, hVar26, hVar27, hVar28, hVar29, hVar30, hVar31, hVar32, hVar33, hVar34, new h("Signal", 34)};
    }

    public static h valueOf(String str) {
        return (h) Enum.valueOf(h.class, str);
    }

    public static h[] values() {
        return (h[]) f6950Q.clone();
    }
}

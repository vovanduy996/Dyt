package X1;

import G3.C;
import com.autogolike.mobile.core.backup.ConfigBackupDto;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class l implements T3.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f6979l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ T3.c f6980m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ boolean f6981n;

    public /* synthetic */ l(T3.c cVar, boolean z3, int i5) {
        this.f6979l = i5;
        this.f6980m = cVar;
        this.f6981n = z3;
    }

    @Override // T3.a
    public final Object b() {
        switch (this.f6979l) {
            case ConfigBackupDto.$stable /* 0 */:
                this.f6980m.invoke(Boolean.valueOf(!this.f6981n));
                break;
            case 1:
                this.f6980m.invoke(Boolean.valueOf(!this.f6981n));
                break;
            case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                if (this.f6981n) {
                    this.f6980m.invoke(Boolean.FALSE);
                }
                break;
            case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                if (this.f6981n) {
                    this.f6980m.invoke(Boolean.TRUE);
                }
                break;
            default:
                this.f6980m.invoke(Boolean.valueOf(!this.f6981n));
                break;
        }
        return C.a;
    }

    public /* synthetic */ l(boolean z3, T3.c cVar, int i5) {
        this.f6979l = i5;
        this.f6981n = z3;
        this.f6980m = cVar;
    }
}

package X1;

import w1.AbstractC1987H;

/* JADX INFO: loaded from: classes.dex */
public final class c {
    public final String a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f6913b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final h f6914c;

    public c(String str, String str2, h hVar) {
        this.a = str;
        this.f6913b = str2;
        this.f6914c = hVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return U3.j.a(this.a, cVar.a) && U3.j.a(this.f6913b, cVar.f6913b) && this.f6914c == cVar.f6914c;
    }

    public final int hashCode() {
        return this.f6914c.hashCode() + AbstractC1987H.b(this.a.hashCode() * 31, 31, this.f6913b);
    }

    public final String toString() {
        return "AgBottomNavItem(key=" + this.a + ", label=" + this.f6913b + ", icon=" + this.f6914c + ")";
    }
}

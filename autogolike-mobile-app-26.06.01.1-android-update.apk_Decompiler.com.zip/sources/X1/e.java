package X1;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final e f6923l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final e f6924m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final /* synthetic */ e[] f6925n;

    static {
        e eVar = new e("Medium", 0);
        f6923l = eVar;
        e eVar2 = new e("Large", 1);
        f6924m = eVar2;
        f6925n = new e[]{eVar, eVar2};
    }

    public static e valueOf(String str) {
        return (e) Enum.valueOf(e.class, str);
    }

    public static e[] values() {
        return (e[]) f6925n.clone();
    }
}

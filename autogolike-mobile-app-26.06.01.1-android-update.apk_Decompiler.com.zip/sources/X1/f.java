package X1;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class f {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final f f6926l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final f f6927m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final f f6928n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final /* synthetic */ f[] f6929o;

    static {
        f fVar = new f("Primary", 0);
        f6926l = fVar;
        f fVar2 = new f("Danger", 1);
        f6927m = fVar2;
        f fVar3 = new f("Ghost", 2);
        f6928n = fVar3;
        f6929o = new f[]{fVar, fVar2, fVar3};
    }

    public static f valueOf(String str) {
        return (f) Enum.valueOf(f.class, str);
    }

    public static f[] values() {
        return (f[]) f6929o.clone();
    }
}

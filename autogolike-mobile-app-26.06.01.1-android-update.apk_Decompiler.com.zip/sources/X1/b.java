package X1;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final b f6907l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final b f6908m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final b f6909n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final b f6910o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final b f6911p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final /* synthetic */ b[] f6912q;

    static {
        b bVar = new b("Ok", 0);
        f6907l = bVar;
        b bVar2 = new b("Danger", 1);
        f6908m = bVar2;
        b bVar3 = new b("Warn", 2);
        f6909n = bVar3;
        b bVar4 = new b("Info", 3);
        f6910o = bVar4;
        b bVar5 = new b("Muted", 4);
        f6911p = bVar5;
        f6912q = new b[]{bVar, bVar2, bVar3, bVar4, bVar5};
    }

    public static b valueOf(String str) {
        return (b) Enum.valueOf(b.class, str);
    }

    public static b[] values() {
        return (b[]) f6912q.clone();
    }
}

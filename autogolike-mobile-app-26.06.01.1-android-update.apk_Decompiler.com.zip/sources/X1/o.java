package X1;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class o {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final o f6994o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final o f6995p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final o f6996q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final o f6997r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final o f6998s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final o f6999t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final /* synthetic */ o[] f7000u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final /* synthetic */ N3.a f7001v;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final String f7002l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final String f7003m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final String f7004n;

    static {
        o oVar = new o("Facebook", 0, "fb", "Facebook", "f");
        f6994o = oVar;
        o oVar2 = new o("TikTok", 1, "tt", "TikTok", "♪");
        f6995p = oVar2;
        o oVar3 = new o("Instagram", 2, "ig", "Instagram", "IG");
        f6996q = oVar3;
        o oVar4 = new o("Snapchat", 3, "sc", "Snapchat", "👻");
        f6997r = oVar4;
        o oVar5 = new o("Threads", 4, "th", "Threads", "@");
        f6998s = oVar5;
        o oVar6 = new o("LinkedIn", 5, "li", "LinkedIn", "in");
        f6999t = oVar6;
        o[] oVarArr = {oVar, oVar2, oVar3, oVar4, oVar5, oVar6};
        f7000u = oVarArr;
        f7001v = new N3.a(oVarArr);
    }

    public o(String str, int i5, String str2, String str3, String str4) {
        this.f7002l = str2;
        this.f7003m = str3;
        this.f7004n = str4;
    }

    public static o valueOf(String str) {
        return (o) Enum.valueOf(o.class, str);
    }

    public static o[] values() {
        return (o[]) f7000u.clone();
    }
}

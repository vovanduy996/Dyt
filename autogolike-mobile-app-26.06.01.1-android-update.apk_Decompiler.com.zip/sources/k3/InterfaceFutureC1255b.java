package k3;

import M4.ExecutorC0329a;
import java.util.concurrent.Future;

/* JADX INFO: renamed from: k3.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceFutureC1255b extends Future {
    void a(RunnableC1254a runnableC1254a, ExecutorC0329a executorC0329a);
}

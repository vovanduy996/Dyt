package k3;

import A4.e;
import F.A0;
import K3.i;
import Q2.v;
import android.animation.ValueAnimator;
import android.content.SharedPreferences;
import android.os.RemoteException;
import android.view.View;
import c1.C0653E;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import com.google.android.gms.internal.measurement.AbstractC0813y0;
import com.google.android.gms.internal.measurement.J;
import com.google.android.gms.internal.measurement.K1;
import e3.C0899k0;
import e3.C0907n;
import e3.C0929y0;
import e3.E0;
import e3.G;
import e3.O;
import e3.ServiceConnectionC0872b0;
import e3.V0;
import e3.X;
import e3.X0;
import e3.Y0;
import e3.w1;
import f4.AbstractC0952A;
import f4.AbstractC0987u;
import f4.C0978k;
import f4.V;
import g4.d;
import h3.C1083c;
import h3.C1086f;
import h3.InterfaceC1082b;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.Callable;
import k4.C1262g;
import r3.j;
import y.t;

/* JADX INFO: renamed from: k3.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class RunnableC1254a implements Runnable {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f11048l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public Object f11049m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public Object f11050n;

    public /* synthetic */ RunnableC1254a(int i5) {
        this.f11048l = i5;
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x0066  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0073 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final void a() {
        /*
            r8 = this;
            java.lang.Object r0 = r8.f11050n
            e3.E0 r0 = (e3.E0) r0
            e3.j1 r1 = r0.r()
            e3.X r2 = r1.m()
            e3.y0 r2 = r2.y()
            e3.x0 r3 = e3.EnumC0927x0.f9674n
            boolean r2 = r2.i(r3)
            r3 = 0
            if (r2 != 0) goto L26
            e3.O r1 = r1.d()
            java.lang.String r2 = "Analytics storage consent denied; will not get session id"
            A4.b r1 = r1.f9180v
            r1.g(r2)
        L24:
            r1 = r3
            goto L5c
        L26:
            e3.X r2 = r1.m()
            java.lang.Object r4 = r1.f9525l
            e3.k0 r4 = (e3.C0899k0) r4
            U2.a r4 = r4.f9436y
            r4.getClass()
            long r4 = java.lang.System.currentTimeMillis()
            boolean r2 = r2.t(r4)
            if (r2 != 0) goto L24
            e3.X r2 = r1.m()
            e3.Y r2 = r2.C
            long r4 = r2.a()
            r6 = 0
            int r2 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r2 != 0) goto L4e
            goto L24
        L4e:
            e3.X r1 = r1.m()
            e3.Y r1 = r1.C
            long r1 = r1.a()
            java.lang.Long r1 = java.lang.Long.valueOf(r1)
        L5c:
            java.lang.Object r0 = r0.f9525l
            e3.k0 r0 = (e3.C0899k0) r0
            java.lang.Object r2 = r8.f11049m
            com.google.android.gms.internal.measurement.W r2 = (com.google.android.gms.internal.measurement.W) r2
            if (r1 == 0) goto L73
            e3.H1 r0 = r0.f9434w
            e3.C0899k0.h(r0)
            long r3 = r1.longValue()
            r0.K(r2, r3)
            return
        L73:
            r2.a(r3)     // Catch: android.os.RemoteException -> L77
            return
        L77:
            r1 = move-exception
            e3.O r0 = r0.f9431t
            e3.C0899k0.i(r0)
            java.lang.String r2 = "getSessionId failed with exception"
            A4.b r0 = r0.f9175q
            r0.f(r1, r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: k3.RunnableC1254a.a():void");
    }

    private final void b() {
        E0 e02 = (E0) this.f11050n;
        X xM = e02.m();
        xM.o();
        xM.o();
        C0907n c0907nB = C0907n.b(xM.w().getString("dma_consent_settings", null));
        C0907n c0907n = (C0907n) this.f11049m;
        int i5 = c0907nB.a;
        int i6 = c0907n.a;
        if (!C0929y0.h(i6, i5)) {
            O oD = e02.d();
            oD.f9181w.f(Integer.valueOf(i6), "Lower precedence consent source ignored, proposed source");
            return;
        }
        SharedPreferences.Editor editorEdit = xM.w().edit();
        editorEdit.putString("dma_consent_settings", c0907n.f9457b);
        editorEdit.apply();
        e02.d().f9183y.f(c0907n, "Setting DMA consent(FE)");
        C0899k0 c0899k0 = (C0899k0) e02.f9525l;
        Y0 y0J = AbstractC0813y0.j(c0899k0);
        if (y0J.E() && y0J.n().s0() < 241200) {
            c0899k0.r().z(false);
            return;
        }
        Y0 y0J2 = AbstractC0813y0.j(c0899k0);
        X0 x02 = new X0(1);
        x02.f9256m = y0J2;
        y0J2.x(x02);
    }

    private final void c() {
        Y0 y02 = (Y0) this.f11050n;
        G g3 = y02.f9262o;
        if (g3 == null) {
            y02.d().f9175q.g("Failed to send current screen to service");
            return;
        }
        try {
            V0 v0 = (V0) this.f11049m;
            if (v0 == null) {
                g3.q(0L, null, null, ((C0899k0) y02.f9525l).f9423l.getPackageName());
            } else {
                g3.q(v0.f9226c, v0.a, v0.f9225b, ((C0899k0) y02.f9525l).f9423l.getPackageName());
            }
            y02.G();
        } catch (RemoteException e5) {
            y02.d().f9175q.f(e5, "Failed to send current screen to the service");
        }
    }

    private final void d() {
        w1 w1Var = (w1) this.f11049m;
        w1Var.e0();
        w1Var.e().o();
        if (w1Var.f9640A == null) {
            w1Var.f9640A = new ArrayList();
        }
        w1Var.f9640A.add((Runnable) this.f11050n);
        w1Var.g0();
    }

    private final void e() {
        ((C0978k) this.f11050n).E((V) this.f11049m);
    }

    private final void f() {
        ((C0978k) this.f11049m).E((d) this.f11050n);
    }

    private final void g() {
        synchronized (((C1086f) this.f11050n).f10249c) {
            t tVar = (t) ((C1086f) this.f11050n).f10250d;
            ((Map) ((K1) tVar.f15536n).f8411n).remove((C1083c) tVar.f15535m);
        }
    }

    private final void h() {
        synchronized (((C1086f) this.f11050n).f10249c) {
            InterfaceC1082b interfaceC1082b = (InterfaceC1082b) ((C1086f) this.f11050n).f10250d;
            v.h(((e) this.f11049m).c());
            interfaceC1082b.h();
        }
    }

    private final void i() {
        e eVar = (e) this.f11049m;
        try {
            eVar.n(((Callable) this.f11050n).call());
        } catch (Exception e5) {
            eVar.m(e5);
        } catch (Throwable th) {
            eVar.m(new RuntimeException(th));
        }
    }

    private final void j() {
        int i5 = 0;
        while (true) {
            try {
                ((Runnable) this.f11049m).run();
            } catch (Throwable th) {
                AbstractC0952A.n(i.f4514l, th);
            }
            C1262g c1262g = (C1262g) this.f11050n;
            Runnable runnableB0 = c1262g.b0();
            if (runnableB0 == null) {
                return;
            }
            this.f11049m = runnableB0;
            i5++;
            if (i5 >= 16) {
                AbstractC0987u abstractC0987u = c1262g.f11067o;
                if (abstractC0987u.Z(c1262g)) {
                    abstractC0987u.X(c1262g, this);
                    return;
                }
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:22:0x004c, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0052, code lost:
    
        r1 = r1 | java.lang.Thread.interrupted();
        r2 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0054, code lost:
    
        ((java.lang.Runnable) r10.f11049m).run();
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0060, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0062, code lost:
    
        r3 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0063, code lost:
    
        r3.j.f13029q.log(java.util.logging.Level.SEVERE, "Exception while executing runnable " + ((java.lang.Runnable) r10.f11049m), (java.lang.Throwable) r3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x0080, code lost:
    
        r10.f11049m = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x0082, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:?, code lost:
    
        return;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void k() {
        /*
            r10 = this;
            r0 = 0
            r1 = r0
        L2:
            java.lang.Object r2 = r10.f11050n     // Catch: java.lang.Throwable -> L5e
            r3.j r2 = (r3.j) r2     // Catch: java.lang.Throwable -> L5e
            java.util.ArrayDeque r2 = r2.f13031m     // Catch: java.lang.Throwable -> L5e
            monitor-enter(r2)     // Catch: java.lang.Throwable -> L5e
            r3 = 1
            if (r0 != 0) goto L2c
            java.lang.Object r0 = r10.f11050n     // Catch: java.lang.Throwable -> L20
            r3.j r0 = (r3.j) r0     // Catch: java.lang.Throwable -> L20
            int r4 = r0.f13032n     // Catch: java.lang.Throwable -> L20
            r5 = 4
            if (r4 != r5) goto L22
            monitor-exit(r2)     // Catch: java.lang.Throwable -> L20
            if (r1 == 0) goto L1f
            java.lang.Thread r0 = java.lang.Thread.currentThread()
            r0.interrupt()
        L1f:
            return
        L20:
            r0 = move-exception
            goto L83
        L22:
            long r6 = r0.f13033o     // Catch: java.lang.Throwable -> L20
            r8 = 1
            long r6 = r6 + r8
            r0.f13033o = r6     // Catch: java.lang.Throwable -> L20
            r0.f13032n = r5     // Catch: java.lang.Throwable -> L20
            r0 = r3
        L2c:
            java.lang.Object r4 = r10.f11050n     // Catch: java.lang.Throwable -> L20
            r3.j r4 = (r3.j) r4     // Catch: java.lang.Throwable -> L20
            java.util.ArrayDeque r4 = r4.f13031m     // Catch: java.lang.Throwable -> L20
            java.lang.Object r4 = r4.poll()     // Catch: java.lang.Throwable -> L20
            java.lang.Runnable r4 = (java.lang.Runnable) r4     // Catch: java.lang.Throwable -> L20
            r10.f11049m = r4     // Catch: java.lang.Throwable -> L20
            if (r4 != 0) goto L4d
            java.lang.Object r0 = r10.f11050n     // Catch: java.lang.Throwable -> L20
            r3.j r0 = (r3.j) r0     // Catch: java.lang.Throwable -> L20
            r0.f13032n = r3     // Catch: java.lang.Throwable -> L20
            monitor-exit(r2)     // Catch: java.lang.Throwable -> L20
            if (r1 == 0) goto L4c
            java.lang.Thread r0 = java.lang.Thread.currentThread()
            r0.interrupt()
        L4c:
            return
        L4d:
            monitor-exit(r2)     // Catch: java.lang.Throwable -> L20
            boolean r2 = java.lang.Thread.interrupted()     // Catch: java.lang.Throwable -> L5e
            r1 = r1 | r2
            r2 = 0
            java.lang.Object r3 = r10.f11049m     // Catch: java.lang.Throwable -> L60 java.lang.RuntimeException -> L62
            java.lang.Runnable r3 = (java.lang.Runnable) r3     // Catch: java.lang.Throwable -> L60 java.lang.RuntimeException -> L62
            r3.run()     // Catch: java.lang.Throwable -> L60 java.lang.RuntimeException -> L62
        L5b:
            r10.f11049m = r2     // Catch: java.lang.Throwable -> L5e
            goto L2
        L5e:
            r0 = move-exception
            goto L85
        L60:
            r0 = move-exception
            goto L80
        L62:
            r3 = move-exception
            java.util.logging.Logger r4 = r3.j.f13029q     // Catch: java.lang.Throwable -> L60
            java.util.logging.Level r5 = java.util.logging.Level.SEVERE     // Catch: java.lang.Throwable -> L60
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L60
            r6.<init>()     // Catch: java.lang.Throwable -> L60
            java.lang.String r7 = "Exception while executing runnable "
            r6.append(r7)     // Catch: java.lang.Throwable -> L60
            java.lang.Object r7 = r10.f11049m     // Catch: java.lang.Throwable -> L60
            java.lang.Runnable r7 = (java.lang.Runnable) r7     // Catch: java.lang.Throwable -> L60
            r6.append(r7)     // Catch: java.lang.Throwable -> L60
            java.lang.String r6 = r6.toString()     // Catch: java.lang.Throwable -> L60
            r4.log(r5, r6, r3)     // Catch: java.lang.Throwable -> L60
            goto L5b
        L80:
            r10.f11049m = r2     // Catch: java.lang.Throwable -> L5e
            throw r0     // Catch: java.lang.Throwable -> L5e
        L83:
            monitor-exit(r2)     // Catch: java.lang.Throwable -> L20
            throw r0     // Catch: java.lang.Throwable -> L5e
        L85:
            if (r1 == 0) goto L8e
            java.lang.Thread r1 = java.lang.Thread.currentThread()
            r1.interrupt()
        L8e:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: k3.RunnableC1254a.k():void");
    }

    /* JADX WARN: Removed duplicated region for block: B:111:0x029e A[Catch: NameNotFoundException -> 0x02bd, TryCatch #14 {NameNotFoundException -> 0x02bd, blocks: (B:109:0x0293, B:111:0x029e, B:113:0x02aa), top: B:508:0x0293 }] */
    /* JADX WARN: Removed duplicated region for block: B:156:0x03c2  */
    /* JADX WARN: Removed duplicated region for block: B:157:0x03c3  */
    /* JADX WARN: Removed duplicated region for block: B:160:0x03cc A[Catch: IllegalStateException -> 0x03ea, TryCatch #12 {IllegalStateException -> 0x03ea, blocks: (B:146:0x039e, B:150:0x03b0, B:154:0x03bc, B:158:0x03c4, B:160:0x03cc, B:164:0x03db, B:168:0x03e7, B:167:0x03e3, B:163:0x03d7, B:172:0x03ee, B:174:0x0400, B:176:0x0405, B:175:0x0403, B:153:0x03b8, B:149:0x03ac), top: B:504:0x039e }] */
    /* JADX WARN: Removed duplicated region for block: B:172:0x03ee A[Catch: IllegalStateException -> 0x03ea, TryCatch #12 {IllegalStateException -> 0x03ea, blocks: (B:146:0x039e, B:150:0x03b0, B:154:0x03bc, B:158:0x03c4, B:160:0x03cc, B:164:0x03db, B:168:0x03e7, B:167:0x03e3, B:163:0x03d7, B:172:0x03ee, B:174:0x0400, B:176:0x0405, B:175:0x0403, B:153:0x03b8, B:149:0x03ac), top: B:504:0x039e }] */
    /* JADX WARN: Removed duplicated region for block: B:188:0x044a  */
    /* JADX WARN: Removed duplicated region for block: B:197:0x0475  */
    /* JADX WARN: Removed duplicated region for block: B:206:0x04a4  */
    /* JADX WARN: Removed duplicated region for block: B:208:0x04a8  */
    /* JADX WARN: Removed duplicated region for block: B:209:0x04af  */
    /* JADX WARN: Removed duplicated region for block: B:212:0x04e3  */
    /* JADX WARN: Removed duplicated region for block: B:216:0x050b  */
    /* JADX WARN: Removed duplicated region for block: B:219:0x0521  */
    /* JADX WARN: Removed duplicated region for block: B:222:0x0556  */
    /* JADX WARN: Removed duplicated region for block: B:235:0x05c7  */
    /* JADX WARN: Removed duplicated region for block: B:239:0x05ed  */
    /* JADX WARN: Removed duplicated region for block: B:253:0x0631  */
    /* JADX WARN: Removed duplicated region for block: B:268:0x0677  */
    /* JADX WARN: Removed duplicated region for block: B:271:0x06a2  */
    /* JADX WARN: Removed duplicated region for block: B:272:0x06af  */
    /* JADX WARN: Removed duplicated region for block: B:275:0x06bd  */
    /* JADX WARN: Removed duplicated region for block: B:280:0x06df  */
    /* JADX WARN: Removed duplicated region for block: B:286:0x0701  */
    /* JADX WARN: Removed duplicated region for block: B:296:0x0731  */
    /* JADX WARN: Removed duplicated region for block: B:311:0x078a  */
    /* JADX WARN: Removed duplicated region for block: B:312:0x078c  */
    /* JADX WARN: Removed duplicated region for block: B:314:0x0792  */
    /* JADX WARN: Removed duplicated region for block: B:320:0x07e1  */
    /* JADX WARN: Removed duplicated region for block: B:323:0x07fd  */
    /* JADX WARN: Removed duplicated region for block: B:328:0x0816  */
    /* JADX WARN: Removed duplicated region for block: B:349:0x088a  */
    /* JADX WARN: Removed duplicated region for block: B:355:0x08b2  */
    /* JADX WARN: Removed duplicated region for block: B:402:0x0a6e  */
    /* JADX WARN: Removed duplicated region for block: B:488:0x044c A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:518:0x0740 A[SYNTHETIC] */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void run() {
        /*
            Method dump skipped, instruction units count: 3254
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: k3.RunnableC1254a.run():void");
    }

    public String toString() {
        switch (this.f11048l) {
            case ConfigBackupDto.$stable /* 0 */:
                A0 a02 = new A0(RunnableC1254a.class.getSimpleName());
                K1 k12 = new K1(17, false);
                ((K1) a02.f1396o).f8411n = k12;
                a02.f1396o = k12;
                k12.f8410m = (K1) this.f11050n;
                return a02.toString();
            case 25:
                Runnable runnable = (Runnable) this.f11049m;
                if (runnable != null) {
                    return "SequentialExecutorWorker{running=" + runnable + "}";
                }
                StringBuilder sb = new StringBuilder("SequentialExecutorWorker{state=");
                int i5 = ((j) this.f11050n).f13032n;
                sb.append(i5 != 1 ? i5 != 2 ? i5 != 3 ? i5 != 4 ? "null" : "RUNNING" : "QUEUED" : "QUEUING" : "IDLE");
                sb.append("}");
                return sb.toString();
            default:
                return super.toString();
        }
    }

    public /* synthetic */ RunnableC1254a(int i5, Object obj, Object obj2, boolean z3) {
        this.f11048l = i5;
        this.f11050n = obj;
        this.f11049m = obj2;
    }

    public /* synthetic */ RunnableC1254a(Object obj, int i5, Object obj2) {
        this.f11048l = i5;
        this.f11049m = obj;
        this.f11050n = obj2;
    }

    public RunnableC1254a(ServiceConnectionC0872b0 serviceConnectionC0872b0, J j5, ServiceConnectionC0872b0 serviceConnectionC0872b02) {
        this.f11048l = 7;
        this.f11049m = j5;
        this.f11050n = serviceConnectionC0872b0;
    }

    public RunnableC1254a(j jVar) {
        this.f11048l = 25;
        this.f11050n = jVar;
    }

    public RunnableC1254a(View view, C0653E c0653e, t tVar, ValueAnimator valueAnimator) {
        this.f11048l = 5;
        this.f11049m = view;
        this.f11050n = valueAnimator;
    }
}

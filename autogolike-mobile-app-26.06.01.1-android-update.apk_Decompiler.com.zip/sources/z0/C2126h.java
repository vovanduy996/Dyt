package z0;

import D0.p;

/* JADX INFO: renamed from: z0.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C2126h extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public p f16005o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public /* synthetic */ Object f16006p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ p f16007q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f16008r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C2126h(p pVar, M3.c cVar) {
        super(cVar);
        this.f16007q = pVar;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f16006p = obj;
        this.f16008r |= Integer.MIN_VALUE;
        return this.f16007q.b(0.0f, this);
    }
}

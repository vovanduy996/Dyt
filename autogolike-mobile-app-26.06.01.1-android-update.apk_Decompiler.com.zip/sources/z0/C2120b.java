package z0;

import G3.AbstractC0164a;
import G3.C;
import android.graphics.Rect;
import android.view.ScrollCaptureSession;
import b0.N;
import f4.InterfaceC0991y;
import java.util.function.Consumer;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: z0.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C2120b extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f15979p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ ScrollCaptureCallbackC2124f f15980q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ ScrollCaptureSession f15981r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ Rect f15982s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ Consumer f15983t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C2120b(ScrollCaptureCallbackC2124f scrollCaptureCallbackC2124f, ScrollCaptureSession scrollCaptureSession, Rect rect, Consumer consumer, Continuation continuation) {
        super(2, continuation);
        this.f15980q = scrollCaptureCallbackC2124f;
        this.f15981r = scrollCaptureSession;
        this.f15982s = rect;
        this.f15983t = consumer;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C2120b) m((InterfaceC0991y) obj, (Continuation) obj2)).o(C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new C2120b(this.f15980q, this.f15981r, this.f15982s, this.f15983t, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f15979p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            ScrollCaptureSession scrollCaptureSession = this.f15981r;
            Rect rect = this.f15982s;
            O0.i iVar = new O0.i(rect.left, rect.top, rect.right, rect.bottom);
            this.f15979p = 1;
            obj = ScrollCaptureCallbackC2124f.a(this.f15980q, scrollCaptureSession, iVar, this);
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        this.f15983t.accept(N.B((O0.i) obj));
        return C.a;
    }
}

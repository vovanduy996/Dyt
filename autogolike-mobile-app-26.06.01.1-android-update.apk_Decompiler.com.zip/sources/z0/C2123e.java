package z0;

import A0.r;
import G3.AbstractC0164a;
import G3.C;
import a0.C0492c;
import kotlin.coroutines.Continuation;
import m1.AbstractC1393s;

/* JADX INFO: renamed from: z0.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C2123e extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f15996p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f15997q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ float f15998r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ ScrollCaptureCallbackC2124f f15999s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C2123e(ScrollCaptureCallbackC2124f scrollCaptureCallbackC2124f, Continuation continuation) {
        super(2, continuation);
        this.f15999s = scrollCaptureCallbackC2124f;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C2123e) m(Float.valueOf(((Number) obj).floatValue()), (Continuation) obj2)).o(C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C2123e c2123e = new C2123e(this.f15999s, continuation);
        c2123e.f15998r = ((Number) obj).floatValue();
        return c2123e;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        boolean z3;
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f15997q;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            float f5 = this.f15998r;
            ScrollCaptureCallbackC2124f scrollCaptureCallbackC2124f = this.f15999s;
            Object obj2 = scrollCaptureCallbackC2124f.a.f237d.f226l.get(A0.h.f204e);
            if (obj2 == null) {
                obj2 = null;
            }
            T3.e eVar = (T3.e) obj2;
            if (eVar == null) {
                AbstractC1393s.b0("Required value was null.");
                throw null;
            }
            boolean z5 = ((A0.g) scrollCaptureCallbackC2124f.a.f237d.c(r.f273p)).f199c;
            if (z5) {
                f5 = -f5;
            }
            C0492c c0492c = new C0492c(X2.g.l(0.0f, f5));
            this.f15996p = z5;
            this.f15997q = 1;
            obj = eVar.i(c0492c, this);
            if (obj == aVar) {
                return aVar;
            }
            z3 = z5;
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            z3 = this.f15996p;
            AbstractC0164a.e(obj);
        }
        float fE = C0492c.e(((C0492c) obj).a);
        if (z3) {
            fE = -fE;
        }
        return new Float(fE);
    }
}

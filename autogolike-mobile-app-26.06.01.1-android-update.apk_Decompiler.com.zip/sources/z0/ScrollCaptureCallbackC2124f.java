package z0;

import A0.o;
import D0.p;
import android.graphics.Rect;
import android.os.CancellationSignal;
import android.view.ScrollCaptureCallback;
import android.view.ScrollCaptureSession;
import b0.N;
import f4.AbstractC0952A;
import f4.l0;
import f4.p0;
import java.util.function.Consumer;
import k4.C1258c;
import t0.C1794a;

/* JADX INFO: renamed from: z0.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class ScrollCaptureCallbackC2124f implements ScrollCaptureCallback {
    public final o a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final O0.i f16000b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final j f16001c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final C1258c f16002d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final p f16003e;

    public ScrollCaptureCallbackC2124f(o oVar, O0.i iVar, C1258c c1258c, j jVar) {
        this.a = oVar;
        this.f16000b = iVar;
        this.f16001c = jVar;
        this.f16002d = new C1258c(c1258c.f11058l.F(C2125g.f16004l));
        this.f16003e = new p(iVar.a(), new C2123e(this, null));
    }

    /* JADX WARN: Removed duplicated region for block: B:43:0x00e6  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00e9  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0016  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final java.lang.Object a(z0.ScrollCaptureCallbackC2124f r11, android.view.ScrollCaptureSession r12, O0.i r13, M3.c r14) {
        /*
            Method dump skipped, instruction units count: 371
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: z0.ScrollCaptureCallbackC2124f.a(z0.f, android.view.ScrollCaptureSession, O0.i, M3.c):java.lang.Object");
    }

    public final void onScrollCaptureEnd(Runnable runnable) {
        AbstractC0952A.s(this.f16002d, l0.f9832m, null, new C2119a(this, runnable, null), 2);
    }

    public final void onScrollCaptureImageRequest(ScrollCaptureSession scrollCaptureSession, CancellationSignal cancellationSignal, Rect rect, Consumer consumer) {
        p0 p0VarS = AbstractC0952A.s(this.f16002d, null, null, new C2120b(this, scrollCaptureSession, rect, consumer, null), 3);
        p0VarS.O(new C1794a(12, cancellationSignal));
        cancellationSignal.setOnCancelListener(new y.p(1, p0VarS));
    }

    public final void onScrollCaptureSearch(CancellationSignal cancellationSignal, Consumer consumer) {
        consumer.accept(N.B(this.f16000b));
    }

    public final void onScrollCaptureStart(ScrollCaptureSession scrollCaptureSession, CancellationSignal cancellationSignal, Runnable runnable) {
        this.f16003e.f1029b = 0.0f;
        j jVar = this.f16001c;
        jVar.a.setValue(Boolean.TRUE);
        runnable.run();
    }
}

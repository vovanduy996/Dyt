package z0;

import A0.o;
import A0.p;
import D0.m;
import I.C0234d;
import I.C0247j0;
import I.W;
import T3.c;
import a0.C0493d;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.ScrollCaptureTarget;
import android.view.View;
import b0.N;
import f4.AbstractC0952A;
import java.util.Comparator;
import java.util.function.Consumer;
import k4.C1258c;
import m1.AbstractC1393s;
import r0.AbstractC1655U;
import t0.a0;

/* JADX INFO: loaded from: classes.dex */
public final class j {
    public final C0247j0 a = C0234d.K(Boolean.FALSE, W.f3598q);

    public final void a(View view, p pVar, K3.h hVar, Consumer<ScrollCaptureTarget> consumer) {
        K.d dVar = new K.d(new k[16]);
        AbstractC1393s.e0(pVar.a(), 0, new C2127i(dVar));
        final T3.c[] cVarArr = {C2122d.f15993n, C2122d.f15994o};
        dVar.r(new Comparator() { // from class: J3.a
            @Override // java.util.Comparator
            public final int compare(Object obj, Object obj2) {
                for (c cVar : cVarArr) {
                    int iY = V2.a.y((Comparable) cVar.invoke(obj), (Comparable) cVar.invoke(obj2));
                    if (iY != 0) {
                        return iY;
                    }
                }
                return 0;
            }
        });
        k kVar = (k) (dVar.m() ? null : dVar.f4403l[dVar.f4405n - 1]);
        if (kVar == null) {
            return;
        }
        C1258c c1258cA = AbstractC0952A.a(hVar);
        o oVar = kVar.a;
        O0.i iVar = kVar.f16011c;
        ScrollCaptureCallbackC2124f scrollCaptureCallbackC2124f = new ScrollCaptureCallbackC2124f(oVar, iVar, c1258cA, this);
        a0 a0Var = kVar.f16012d;
        C0493d c0493dA = AbstractC1655U.f(a0Var).A(a0Var, true);
        long jH = E4.d.h(iVar.a, iVar.f5348b);
        ScrollCaptureTarget scrollCaptureTargetE = m.e(view, new Rect(Math.round(c0493dA.a), Math.round(c0493dA.f7216b), Math.round(c0493dA.f7217c), Math.round(c0493dA.f7218d)), new Point((int) (jH >> 32), (int) (jH & 4294967295L)), scrollCaptureCallbackC2124f);
        scrollCaptureTargetE.setScrollBounds(N.B(iVar));
        consumer.accept(scrollCaptureTargetE);
    }
}

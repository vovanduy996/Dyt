package z0;

import D0.p;
import G3.AbstractC0164a;
import G3.C;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: z0.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C2119a extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f15976p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ ScrollCaptureCallbackC2124f f15977q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ Runnable f15978r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C2119a(ScrollCaptureCallbackC2124f scrollCaptureCallbackC2124f, Runnable runnable, Continuation continuation) {
        super(2, continuation);
        this.f15977q = scrollCaptureCallbackC2124f;
        this.f15978r = runnable;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C2119a) m((InterfaceC0991y) obj, (Continuation) obj2)).o(C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new C2119a(this.f15977q, this.f15978r, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f15976p;
        C c5 = C.a;
        ScrollCaptureCallbackC2124f scrollCaptureCallbackC2124f = this.f15977q;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            p pVar = scrollCaptureCallbackC2124f.f16003e;
            this.f15976p = 1;
            Object objB = pVar.b(0.0f - pVar.f1029b, this);
            if (objB != aVar) {
                objB = c5;
            }
            if (objB == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        j jVar = scrollCaptureCallbackC2124f.f16001c;
        jVar.a.setValue(Boolean.FALSE);
        this.f15978r.run();
        return c5;
    }
}

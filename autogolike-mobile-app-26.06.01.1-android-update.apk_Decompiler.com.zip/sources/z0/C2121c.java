package z0;

/* JADX INFO: renamed from: z0.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C2121c extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public ScrollCaptureCallbackC2124f f15984o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Object f15985p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public O0.i f15986q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f15987r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f15988s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public /* synthetic */ Object f15989t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ ScrollCaptureCallbackC2124f f15990u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f15991v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C2121c(ScrollCaptureCallbackC2124f scrollCaptureCallbackC2124f, M3.c cVar) {
        super(cVar);
        this.f15990u = scrollCaptureCallbackC2124f;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f15989t = obj;
        this.f15991v |= Integer.MIN_VALUE;
        return ScrollCaptureCallbackC2124f.a(this.f15990u, null, null, this);
    }
}

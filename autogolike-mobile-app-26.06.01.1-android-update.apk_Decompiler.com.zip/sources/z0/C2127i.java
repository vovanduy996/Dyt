package z0;

import G3.C;
import U3.v;
import U3.w;
import java.io.Serializable;

/* JADX INFO: renamed from: z0.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C2127i implements T3.c, U3.g, Serializable {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final K.d f16009l;

    public C2127i(K.d dVar) {
        this.f16009l = dVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C2127i)) {
            return false;
        }
        C2127i c2127i = (C2127i) obj;
        c2127i.getClass();
        return this.f16009l.equals(c2127i.f16009l) && K.d.class.equals(K.d.class);
    }

    @Override // U3.g
    public final int getArity() {
        return 1;
    }

    public final int hashCode() {
        return ((((((((((K.d.class.hashCode() + (this.f16009l.hashCode() * 31)) * 31) + 96417) * 31) + 1636195860) * 31) + 1237) * 31) + 1) * 31) + 4;
    }

    @Override // T3.c
    public final Object invoke(Object obj) {
        this.f16009l.b((k) obj);
        return C.a;
    }

    public final String toString() {
        v.a.getClass();
        return w.a(this);
    }
}

package z0;

import G3.C;
import com.autogolike.mobile.core.backup.ConfigBackupDto;

/* JADX INFO: renamed from: z0.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C2122d extends U3.k implements T3.c {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final C2122d f15992m = new C2122d(1, 0);

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final C2122d f15993n = new C2122d(1, 1);

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final C2122d f15994o = new C2122d(1, 2);

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f15995l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C2122d(int i5, int i6) {
        super(i5);
        this.f15995l = i6;
    }

    @Override // T3.c
    public final Object invoke(Object obj) {
        switch (this.f15995l) {
            case ConfigBackupDto.$stable /* 0 */:
                ((Number) obj).longValue();
                return C.a;
            case 1:
                return Integer.valueOf(((k) obj).f16010b);
            default:
                return Integer.valueOf(((k) obj).f16011c.a());
        }
    }
}

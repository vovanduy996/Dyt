package z0;

import U.r;

/* JADX INFO: renamed from: z0.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C2125g implements r {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final C2125g f16004l = new C2125g();

    @Override // K3.h
    public final Object B(Object obj, T3.e eVar) {
        return eVar.i(obj, this);
    }

    @Override // U.r
    public final float C() {
        return 0.0f;
    }

    @Override // K3.h
    public final K3.h F(K3.h hVar) {
        return l0.c.q0(this, hVar);
    }

    @Override // K3.h
    public final K3.f m(K3.g gVar) {
        return l0.c.h0(this, gVar);
    }

    @Override // K3.h
    public final K3.h u(K3.g gVar) {
        return l0.c.p0(this, gVar);
    }
}

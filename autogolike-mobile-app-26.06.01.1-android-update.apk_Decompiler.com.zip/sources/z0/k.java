package z0;

import A0.o;
import t0.a0;

/* JADX INFO: loaded from: classes.dex */
public final class k {
    public final o a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f16010b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final O0.i f16011c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final a0 f16012d;

    public k(o oVar, int i5, O0.i iVar, a0 a0Var) {
        this.a = oVar;
        this.f16010b = i5;
        this.f16011c = iVar;
        this.f16012d = a0Var;
    }

    public final String toString() {
        return "ScrollCaptureCandidate(node=" + this.a + ", depth=" + this.f16010b + ", viewportBoundsInWindow=" + this.f16011c + ", coordinates=" + this.f16012d + ')';
    }
}

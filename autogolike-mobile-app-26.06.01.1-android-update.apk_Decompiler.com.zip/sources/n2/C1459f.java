package n2;

import n4.InterfaceC1472a;

/* JADX INFO: renamed from: n2.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1459f extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public C1460g f12005o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public InterfaceC1472a f12006p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f12007q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f12008r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ C1460g f12009s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f12010t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1459f(C1460g c1460g, M3.c cVar) {
        super(cVar);
        this.f12009s = c1460g;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f12008r = obj;
        this.f12010t |= Integer.MIN_VALUE;
        return this.f12009s.a(false, this);
    }
}

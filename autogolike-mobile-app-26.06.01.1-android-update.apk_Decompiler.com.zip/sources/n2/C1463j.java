package n2;

import G3.AbstractC0164a;
import G3.C;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;
import m2.w;

/* JADX INFO: renamed from: n2.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1463j extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f12021p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ C1464k f12022q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1463j(C1464k c1464k, Continuation continuation) {
        super(2, continuation);
        this.f12022q = c1464k;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C1463j) m((InterfaceC0991y) obj, (Continuation) obj2)).o(C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new C1463j(this.f12022q, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f12021p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            w wVar = this.f12022q.f12023b;
            this.f12021p = 1;
            if (wVar.a(this) == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return C.a;
    }
}

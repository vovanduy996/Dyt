package n2;

import com.autogolike.mobile.core.network.AutoUpdateApi;

/* JADX INFO: renamed from: n2.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1457d {
    public final AutoUpdateApi a;

    public C1457d(AutoUpdateApi autoUpdateApi) {
        U3.j.f(autoUpdateApi, "api");
        this.a = autoUpdateApi;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0015  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object a(M3.c r7) {
        /*
            r6 = this;
            java.lang.String r0 = "HTTP "
            boolean r1 = r7 instanceof n2.C1456c
            if (r1 == 0) goto L15
            r1 = r7
            n2.c r1 = (n2.C1456c) r1
            int r2 = r1.f12004q
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
            r4 = r2 & r3
            if (r4 == 0) goto L15
            int r2 = r2 - r3
            r1.f12004q = r2
            goto L1a
        L15:
            n2.c r1 = new n2.c
            r1.<init>(r6, r7)
        L1a:
            java.lang.Object r7 = r1.f12002o
            L3.a r2 = L3.a.f4629l
            int r3 = r1.f12004q
            r4 = 1
            if (r3 == 0) goto L33
            if (r3 != r4) goto L2b
            G3.AbstractC0164a.e(r7)     // Catch: java.lang.Exception -> L29
            goto L45
        L29:
            r7 = move-exception
            goto L78
        L2b:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r0)
            throw r7
        L33:
            G3.AbstractC0164a.e(r7)
            com.autogolike.mobile.core.network.AutoUpdateApi r7 = r6.a     // Catch: java.lang.Exception -> L29
            java.lang.String r3 = "autogolike-mobile-app"
            java.lang.String r5 = "ANDROID"
            r1.f12004q = r4     // Catch: java.lang.Exception -> L29
            java.lang.Object r7 = r7.getLatestRelease(r3, r5, r1)     // Catch: java.lang.Exception -> L29
            if (r7 != r2) goto L45
            return r2
        L45:
            M4.U r7 = (M4.U) r7     // Catch: java.lang.Exception -> L29
            w4.A r1 = r7.a     // Catch: java.lang.Exception -> L29
            boolean r1 = r1.b()     // Catch: java.lang.Exception -> L29
            if (r1 != 0) goto L65
            n2.l r1 = new n2.l     // Catch: java.lang.Exception -> L29
            w4.A r7 = r7.a     // Catch: java.lang.Exception -> L29
            int r7 = r7.f15141o     // Catch: java.lang.Exception -> L29
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch: java.lang.Exception -> L29
            r2.<init>(r0)     // Catch: java.lang.Exception -> L29
            r2.append(r7)     // Catch: java.lang.Exception -> L29
            java.lang.String r7 = r2.toString()     // Catch: java.lang.Exception -> L29
            r1.<init>(r7)     // Catch: java.lang.Exception -> L29
            goto L99
        L65:
            java.lang.Object r7 = r7.f4941b     // Catch: java.lang.Exception -> L29
            com.autogolike.mobile.core.network.dto.LatestReleaseDto r7 = (com.autogolike.mobile.core.network.dto.LatestReleaseDto) r7     // Catch: java.lang.Exception -> L29
            if (r7 != 0) goto L73
            n2.l r1 = new n2.l     // Catch: java.lang.Exception -> L29
            java.lang.String r7 = "Phản hồi rỗng từ server."
            r1.<init>(r7)     // Catch: java.lang.Exception -> L29
            goto L99
        L73:
            n2.q r1 = m1.AbstractC1378d.i(r7)     // Catch: java.lang.Exception -> L29
            goto L99
        L78:
            P4.c r0 = P4.e.a
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.String r2 = "Update check failed"
            r0.h(r7, r2, r1)
            n2.l r1 = new n2.l
            java.lang.Class r0 = r7.getClass()
            java.lang.String r0 = r0.getSimpleName()
            java.lang.String r7 = r7.getMessage()
            java.lang.String r2 = ": "
            java.lang.String r7 = z1.AbstractC2128a.s(r0, r2, r7)
            r1.<init>(r7)
        L99:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: n2.C1457d.a(M3.c):java.lang.Object");
    }
}

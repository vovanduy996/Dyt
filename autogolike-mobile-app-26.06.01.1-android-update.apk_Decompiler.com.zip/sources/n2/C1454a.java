package n2;

import F.H1;
import G3.C;
import I.C0258p;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import q.c0;

/* JADX INFO: renamed from: n2.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1454a implements T3.f {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final C1454a f11996m = new C1454a(0);

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final C1454a f11997n = new C1454a(1);

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final C1454a f11998o = new C1454a(2);

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f11999l;

    public /* synthetic */ C1454a(int i5) {
        this.f11999l = i5;
    }

    @Override // T3.f
    public final Object h(Object obj, Object obj2, Object obj3) {
        switch (this.f11999l) {
            case ConfigBackupDto.$stable /* 0 */:
                C0258p c0258p = (C0258p) obj2;
                int iIntValue = ((Number) obj3).intValue();
                U3.j.f((c0) obj, "$this$Button");
                if ((iIntValue & 17) == 16 && c0258p.x()) {
                    c0258p.L();
                } else {
                    H1.b("Tải bản mới", null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, 6, 0, 131070);
                }
                break;
            case 1:
                C0258p c0258p2 = (C0258p) obj2;
                int iIntValue2 = ((Number) obj3).intValue();
                U3.j.f((c0) obj, "$this$Button");
                if ((iIntValue2 & 17) == 16 && c0258p2.x()) {
                    c0258p2.L();
                } else {
                    H1.b("Tải bản mới", null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p2, 6, 0, 131070);
                }
                break;
            default:
                C0258p c0258p3 = (C0258p) obj2;
                int iIntValue3 = ((Number) obj3).intValue();
                U3.j.f((c0) obj, "$this$TextButton");
                if ((iIntValue3 & 17) == 16 && c0258p3.x()) {
                    c0258p3.L();
                } else {
                    H1.b("Để sau", null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p3, 6, 0, 131070);
                }
                break;
        }
        return C.a;
    }
}

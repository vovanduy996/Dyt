package n2;

/* JADX INFO: renamed from: n2.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1455b {
    public static final Q.a a = new Q.a(-338223313, C1454a.f11996m, false);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Q.a f12000b = new Q.a(-72195026, C1454a.f11997n, false);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Q.a f12001c = new Q.a(841412095, C1454a.f11998o, false);
}

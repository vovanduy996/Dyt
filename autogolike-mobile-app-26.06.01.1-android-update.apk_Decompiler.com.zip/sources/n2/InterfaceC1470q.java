package n2;

/* JADX INFO: renamed from: n2.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC1470q {
}

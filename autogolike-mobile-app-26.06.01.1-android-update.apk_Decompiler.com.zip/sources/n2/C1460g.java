package n2;

import i4.J;
import i4.O;
import i4.c0;

/* JADX INFO: renamed from: n2.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1460g {
    public static final C1458e Companion = new C1458e();
    public final C1457d a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final R1.a f12011b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final c0 f12012c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final J f12013d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final n4.c f12014e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public long f12015f;

    public C1460g(C1457d c1457d, R1.a aVar) {
        U3.j.f(c1457d, "repo");
        U3.j.f(aVar, "analyticsTracker");
        this.a = c1457d;
        this.f12011b = aVar;
        c0 c0VarC = O.c(C1467n.a);
        this.f12012c = c0VarC;
        this.f12013d = new J(c0VarC);
        this.f12014e = n4.d.a();
    }

    /* JADX WARN: Removed duplicated region for block: B:36:0x0090 A[Catch: all -> 0x002f, TryCatch #1 {all -> 0x002f, blocks: (B:13:0x002b, B:34:0x0085, B:36:0x0090, B:37:0x0096, B:39:0x009a, B:40:0x00a3), top: B:47:0x002b }] */
    /* JADX WARN: Removed duplicated region for block: B:39:0x009a A[Catch: all -> 0x002f, TryCatch #1 {all -> 0x002f, blocks: (B:13:0x002b, B:34:0x0085, B:36:0x0090, B:37:0x0096, B:39:0x009a, B:40:0x00a3), top: B:47:0x002b }] */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object a(boolean r13, M3.c r14) throws java.lang.Throwable {
        /*
            r12 = this;
            boolean r0 = r14 instanceof n2.C1459f
            if (r0 == 0) goto L13
            r0 = r14
            n2.f r0 = (n2.C1459f) r0
            int r1 = r0.f12010t
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f12010t = r1
            goto L18
        L13:
            n2.f r0 = new n2.f
            r0.<init>(r12, r14)
        L18:
            java.lang.Object r14 = r0.f12008r
            L3.a r1 = L3.a.f4629l
            int r2 = r0.f12010t
            r3 = 2
            r4 = 1
            r5 = 0
            if (r2 == 0) goto L45
            if (r2 == r4) goto L3a
            if (r2 != r3) goto L32
            n4.a r13 = r0.f12006p
            n2.g r0 = r0.f12005o
            G3.AbstractC0164a.e(r14)     // Catch: java.lang.Throwable -> L2f
            goto L85
        L2f:
            r14 = move-exception
            goto Lad
        L32:
            java.lang.IllegalStateException r13 = new java.lang.IllegalStateException
            java.lang.String r14 = "call to 'resume' before 'invoke' with coroutine"
            r13.<init>(r14)
            throw r13
        L3a:
            boolean r13 = r0.f12007q
            n4.a r2 = r0.f12006p
            n2.g r6 = r0.f12005o
            G3.AbstractC0164a.e(r14)
            r14 = r2
            goto L5a
        L45:
            G3.AbstractC0164a.e(r14)
            r0.f12005o = r12
            n4.c r14 = r12.f12014e
            r0.f12006p = r14
            r0.f12007q = r13
            r0.f12010t = r4
            java.lang.Object r2 = r14.c(r5, r0)
            if (r2 != r1) goto L59
            return r1
        L59:
            r6 = r12
        L5a:
            if (r13 != 0) goto L72
            long r7 = java.lang.System.currentTimeMillis()     // Catch: java.lang.Throwable -> L6d
            long r9 = r6.f12015f     // Catch: java.lang.Throwable -> L6d
            long r7 = r7 - r9
            r9 = 1800000(0x1b7740, double:8.89318E-318)
            int r13 = (r7 > r9 ? 1 : (r7 == r9 ? 0 : -1))
            if (r13 >= 0) goto L72
            r4 = 0
            r13 = r14
            goto La3
        L6d:
            r13 = move-exception
            r11 = r14
            r14 = r13
            r13 = r11
            goto Lad
        L72:
            n2.d r13 = r6.a     // Catch: java.lang.Throwable -> L6d
            r0.f12005o = r6     // Catch: java.lang.Throwable -> L6d
            r0.f12006p = r14     // Catch: java.lang.Throwable -> L6d
            r0.f12010t = r3     // Catch: java.lang.Throwable -> L6d
            java.lang.Object r13 = r13.a(r0)     // Catch: java.lang.Throwable -> L6d
            if (r13 != r1) goto L81
            return r1
        L81:
            r0 = r6
            r11 = r14
            r14 = r13
            r13 = r11
        L85:
            n2.q r14 = (n2.InterfaceC1470q) r14     // Catch: java.lang.Throwable -> L2f
            i4.c0 r1 = r0.f12012c     // Catch: java.lang.Throwable -> L2f
            r1.l(r14)     // Catch: java.lang.Throwable -> L2f
            boolean r1 = r14 instanceof n2.C1465l     // Catch: java.lang.Throwable -> L2f
            if (r1 != 0) goto L96
            long r1 = java.lang.System.currentTimeMillis()     // Catch: java.lang.Throwable -> L2f
            r0.f12015f = r1     // Catch: java.lang.Throwable -> L2f
        L96:
            boolean r1 = r14 instanceof n2.C1466m     // Catch: java.lang.Throwable -> L2f
            if (r1 == 0) goto La3
            R1.a r0 = r0.f12011b     // Catch: java.lang.Throwable -> L2f
            n2.m r14 = (n2.C1466m) r14     // Catch: java.lang.Throwable -> L2f
            java.lang.String r14 = r14.a     // Catch: java.lang.Throwable -> L2f
            r0.a(r14)     // Catch: java.lang.Throwable -> L2f
        La3:
            java.lang.Boolean r14 = java.lang.Boolean.valueOf(r4)     // Catch: java.lang.Throwable -> L2f
            n4.c r13 = (n4.c) r13
            r13.e(r5)
            return r14
        Lad:
            n4.c r13 = (n4.c) r13
            r13.e(r5)
            throw r14
        */
        throw new UnsupportedOperationException("Method not decompiled: n2.C1460g.a(boolean, M3.c):java.lang.Object");
    }
}

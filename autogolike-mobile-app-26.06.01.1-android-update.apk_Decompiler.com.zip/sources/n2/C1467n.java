package n2;

/* JADX INFO: renamed from: n2.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1467n implements InterfaceC1470q {
    public static final C1467n a = new C1467n();
}

package n2;

/* JADX INFO: renamed from: n2.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1456c extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public /* synthetic */ Object f12002o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ C1457d f12003p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f12004q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1456c(C1457d c1457d, M3.c cVar) {
        super(cVar);
        this.f12003p = c1457d;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f12002o = obj;
        this.f12004q |= Integer.MIN_VALUE;
        return this.f12003p.a(this);
    }
}

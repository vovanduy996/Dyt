package n2;

import androidx.lifecycle.U;
import androidx.lifecycle.a0;
import f4.AbstractC0952A;
import i4.J;
import i4.O;
import i4.c0;
import m2.w;

/* JADX INFO: renamed from: n2.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1464k extends a0 {
    public final C1460g a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final w f12023b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final J f12024c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final c0 f12025d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final c0 f12026e;

    public C1464k(C1460g c1460g, w wVar) {
        U3.j.f(c1460g, "controller");
        U3.j.f(wVar, "selectorsController");
        this.a = c1460g;
        this.f12023b = wVar;
        this.f12024c = c1460g.f12013d;
        c0 c0VarC = O.c(Boolean.FALSE);
        this.f12025d = c0VarC;
        this.f12026e = c0VarC;
        AbstractC0952A.s(U.k(this), null, null, new C1462i(this, null), 3);
        AbstractC0952A.s(U.k(this), null, null, new C1463j(this, null), 3);
    }
}

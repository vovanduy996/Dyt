package n2;

import w1.AbstractC1987H;
import z1.AbstractC2128a;

/* JADX INFO: renamed from: n2.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1466m implements InterfaceC1470q {
    public final String a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f12027b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f12028c;

    public C1466m(String str, String str2, String str3) {
        U3.j.f(str, "latestVersion");
        this.a = str;
        this.f12027b = str2;
        this.f12028c = str3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C1466m)) {
            return false;
        }
        C1466m c1466m = (C1466m) obj;
        return U3.j.a(this.a, c1466m.a) && U3.j.a(this.f12027b, c1466m.f12027b) && U3.j.a(this.f12028c, c1466m.f12028c);
    }

    public final int hashCode() {
        int iB = AbstractC1987H.b(this.a.hashCode() * 31, 31, this.f12027b);
        String str = this.f12028c;
        return iB + (str == null ? 0 : str.hashCode());
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Forced(latestVersion=");
        sb.append(this.a);
        sb.append(", downloadUrl=");
        sb.append(this.f12027b);
        sb.append(", releaseNotes=");
        return AbstractC2128a.k(sb, this.f12028c, ")");
    }
}

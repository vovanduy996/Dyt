package n2;

import z1.AbstractC2128a;

/* JADX INFO: renamed from: n2.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1465l implements InterfaceC1470q {
    public final String a;

    public C1465l(String str) {
        U3.j.f(str, "message");
        this.a = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof C1465l) && U3.j.a(this.a, ((C1465l) obj).a);
    }

    public final int hashCode() {
        return this.a.hashCode();
    }

    public final String toString() {
        return AbstractC2128a.k(new StringBuilder("Failed(message="), this.a, ")");
    }
}

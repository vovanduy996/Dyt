package n2;

import w1.AbstractC1987H;
import z1.AbstractC2128a;

/* JADX INFO: renamed from: n2.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1468o implements InterfaceC1470q {
    public final String a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f12029b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f12030c;

    public C1468o(String str, String str2, String str3) {
        U3.j.f(str, "latestVersion");
        this.a = str;
        this.f12029b = str2;
        this.f12030c = str3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C1468o)) {
            return false;
        }
        C1468o c1468o = (C1468o) obj;
        return U3.j.a(this.a, c1468o.a) && U3.j.a(this.f12029b, c1468o.f12029b) && U3.j.a(this.f12030c, c1468o.f12030c);
    }

    public final int hashCode() {
        int iB = AbstractC1987H.b(this.a.hashCode() * 31, 31, this.f12029b);
        String str = this.f12030c;
        return iB + (str == null ? 0 : str.hashCode());
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Optional(latestVersion=");
        sb.append(this.a);
        sb.append(", downloadUrl=");
        sb.append(this.f12029b);
        sb.append(", releaseNotes=");
        return AbstractC2128a.k(sb, this.f12030c, ")");
    }
}

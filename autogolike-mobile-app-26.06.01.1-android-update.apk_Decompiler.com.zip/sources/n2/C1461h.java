package n2;

import F.H1;
import G3.C;
import I.C0234d;
import I.C0258p;
import I.InterfaceC0255n0;
import I.Z0;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import com.google.android.gms.internal.measurement.AbstractC0813y0;
import q.AbstractC1594j;
import q.C1591g;
import q.C1603t;
import q.r;
import t0.C1802i;
import t0.C1803j;
import t0.C1804k;
import t0.InterfaceC1805l;
import z1.AbstractC2128a;

/* JADX INFO: renamed from: n2.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1461h implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f12016l = 1;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Y1.b f12017m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ C1468o f12018n;

    public C1461h(Y1.b bVar, C1468o c1468o) {
        this.f12017m = bVar;
        this.f12018n = c1468o;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        switch (this.f12016l) {
            case ConfigBackupDto.$stable /* 0 */:
                C0258p c0258p = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p.x()) {
                    c0258p.L();
                } else {
                    String strR = AbstractC2128a.r("Có bản mới ", this.f12018n.a);
                    Y1.b bVar = this.f12017m;
                    c0258p.Q(258792282);
                    Y1.f fVar = (Y1.f) c0258p.k(Y1.l.f7129c);
                    c0258p.p(false);
                    H1.b(strR, null, bVar.f7049h, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar.f7114c, c0258p, 0, 0, 65530);
                }
                break;
            default:
                C0258p c0258p2 = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p2.x()) {
                    c0258p2.L();
                } else {
                    C1591g c1591gG = AbstractC1594j.g(8);
                    U.n nVar = U.n.a;
                    C1603t c1603tA = r.a(c1591gG, U.b.f6119x, c0258p2, 6);
                    int i5 = c0258p2.f3669P;
                    InterfaceC0255n0 interfaceC0255n0M = c0258p2.m();
                    U.q qVarD = U.a.d(c0258p2, nVar);
                    InterfaceC1805l.f13649k.getClass();
                    C1803j c1803j = C1804k.f13641b;
                    c0258p2.U();
                    if (c0258p2.f3668O) {
                        c0258p2.l(c1803j);
                    } else {
                        c0258p2.d0();
                    }
                    C0234d.R(c0258p2, C1804k.f13645f, c1603tA);
                    C0234d.R(c0258p2, C1804k.f13644e, interfaceC0255n0M);
                    C1802i c1802i = C1804k.f13646g;
                    if (c0258p2.f3668O || !U3.j.a(c0258p2.G(), Integer.valueOf(i5))) {
                        AbstractC0813y0.r(i5, c0258p2, i5, c1802i);
                    }
                    C0234d.R(c0258p2, C1804k.f13643d, qVarD);
                    Y1.b bVar2 = this.f12017m;
                    c0258p2.Q(258792282);
                    Z0 z02 = Y1.l.f7129c;
                    Y1.f fVar2 = (Y1.f) c0258p2.k(z02);
                    c0258p2.p(false);
                    H1.b("Phiên bản mới đã có sẵn. Bạn có muốn tải về cài ngay không?", null, bVar2.f7051j, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar2.f7116e, c0258p2, 6, 0, 65530);
                    c0258p2.Q(-1763623652);
                    C1468o c1468o = this.f12018n;
                    String str = c1468o.f12030c;
                    if (str != null && !c4.l.u0(str)) {
                        c0258p2.Q(258792282);
                        Y1.f fVar3 = (Y1.f) c0258p2.k(z02);
                        c0258p2.p(false);
                        H1.b(c1468o.f12030c, null, bVar2.f7052k, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, fVar3.f7118g, c0258p2, 0, 0, 65530);
                    }
                    c0258p2.p(false);
                    c0258p2.p(true);
                }
                break;
        }
        return C.a;
    }

    public C1461h(C1468o c1468o, Y1.b bVar) {
        this.f12018n = c1468o;
        this.f12017m = bVar;
    }
}

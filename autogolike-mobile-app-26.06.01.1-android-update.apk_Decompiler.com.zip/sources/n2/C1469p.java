package n2;

/* JADX INFO: renamed from: n2.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1469p implements InterfaceC1470q {
    public static final C1469p a = new C1469p();
}

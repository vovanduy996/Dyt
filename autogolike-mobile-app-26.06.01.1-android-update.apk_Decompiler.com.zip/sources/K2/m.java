package K2;

import G3.AbstractC0164a;
import G3.C;
import f4.InterfaceC0991y;
import i4.c0;
import kotlin.coroutines.Continuation;
import q2.C1618h;
import z1.AbstractC2128a;

/* JADX INFO: loaded from: classes.dex */
public final class m extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f4491p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ q f4492q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ String f4493r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public m(q qVar, String str, Continuation continuation) {
        super(2, continuation);
        this.f4492q = qVar;
        this.f4493r = str;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((m) m((InterfaceC0991y) obj, (Continuation) obj2)).o(C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new m(this.f4492q, this.f4493r, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        Object value;
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f4491p;
        q qVar = this.f4492q;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            C1618h c1618h = qVar.a;
            this.f4491p = 1;
            obj = c1618h.a(qVar.f4502b, qVar.f4504d, this.f4493r, this);
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        int iIntValue = ((Number) obj).intValue();
        c0 c0Var = qVar.f4505e;
        do {
            value = c0Var.getValue();
        } while (!c0Var.j(value, i.a((i) value, null, null, "", false, iIntValue > 0 ? AbstractC2128a.e(iIntValue, "Đã thêm ", " mẫu") : "Không có dòng hợp lệ", 15)));
        return C.a;
    }
}

package K2;

import G3.AbstractC0164a;
import G3.C;
import f4.InterfaceC0991y;
import i4.InterfaceC1183g;
import kotlin.coroutines.Continuation;
import q2.C1618h;
import q2.EnumC1611a;

/* JADX INFO: loaded from: classes.dex */
public final class j extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f4486p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ q f4487q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j(q qVar, Continuation continuation) {
        super(2, continuation);
        this.f4487q = qVar;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((j) m((InterfaceC0991y) obj, (Continuation) obj2)).o(C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new j(this.f4487q, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f4486p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            q qVar = this.f4487q;
            C1618h c1618h = qVar.a;
            c1618h.getClass();
            String str = qVar.f4502b;
            U3.j.f(str, "platform");
            EnumC1611a enumC1611a = qVar.f4504d;
            U3.j.f(enumC1611a, "kind");
            InterfaceC1183g interfaceC1183gObserve = c1618h.a.observe(str, enumC1611a.f12679l);
            F2.k kVar = new F2.k(1, qVar);
            this.f4486p = 1;
            if (interfaceC1183gObserve.d(kVar, this) == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return C.a;
    }
}

package K2;

import com.google.android.gms.internal.measurement.AbstractC0813y0;
import java.util.List;
import w1.AbstractC1987H;
import z1.AbstractC2128a;

/* JADX INFO: loaded from: classes.dex */
public final class i {
    public final String a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f4480b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final List f4481c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f4482d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f4483e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f4484f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final String f4485g;

    public i(String str, String str2, List list, String str3, String str4, boolean z3, String str5) {
        U3.j.f(str, "platformCode");
        U3.j.f(str2, "kindCode");
        U3.j.f(list, "templates");
        U3.j.f(str3, "newText");
        U3.j.f(str4, "bulkText");
        this.a = str;
        this.f4480b = str2;
        this.f4481c = list;
        this.f4482d = str3;
        this.f4483e = str4;
        this.f4484f = z3;
        this.f4485g = str5;
    }

    public static i a(i iVar, List list, String str, String str2, boolean z3, String str3, int i5) {
        String str4 = iVar.a;
        String str5 = iVar.f4480b;
        if ((i5 & 4) != 0) {
            list = iVar.f4481c;
        }
        List list2 = list;
        if ((i5 & 8) != 0) {
            str = iVar.f4482d;
        }
        String str6 = str;
        if ((i5 & 16) != 0) {
            str2 = iVar.f4483e;
        }
        String str7 = str2;
        if ((i5 & 32) != 0) {
            z3 = iVar.f4484f;
        }
        boolean z5 = z3;
        if ((i5 & 64) != 0) {
            str3 = iVar.f4485g;
        }
        iVar.getClass();
        U3.j.f(str4, "platformCode");
        U3.j.f(str5, "kindCode");
        U3.j.f(list2, "templates");
        U3.j.f(str6, "newText");
        U3.j.f(str7, "bulkText");
        return new i(str4, str5, list2, str6, str7, z5, str3);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof i)) {
            return false;
        }
        i iVar = (i) obj;
        return U3.j.a(this.a, iVar.a) && U3.j.a(this.f4480b, iVar.f4480b) && U3.j.a(this.f4481c, iVar.f4481c) && U3.j.a(this.f4482d, iVar.f4482d) && U3.j.a(this.f4483e, iVar.f4483e) && this.f4484f == iVar.f4484f && U3.j.a(this.f4485g, iVar.f4485g);
    }

    public final int hashCode() {
        int iF = AbstractC0813y0.f(AbstractC1987H.b(AbstractC1987H.b(AbstractC0813y0.g(this.f4481c, AbstractC1987H.b(this.a.hashCode() * 31, 31, this.f4480b), 31), 31, this.f4482d), 31, this.f4483e), 31, this.f4484f);
        String str = this.f4485g;
        return iF + (str == null ? 0 : str.hashCode());
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("WarmupTemplateUiState(platformCode=");
        sb.append(this.a);
        sb.append(", kindCode=");
        sb.append(this.f4480b);
        sb.append(", templates=");
        sb.append(this.f4481c);
        sb.append(", newText=");
        sb.append(this.f4482d);
        sb.append(", bulkText=");
        sb.append(this.f4483e);
        sb.append(", bulkDialogOpen=");
        sb.append(this.f4484f);
        sb.append(", status=");
        return AbstractC2128a.k(sb, this.f4485g, ")");
    }
}

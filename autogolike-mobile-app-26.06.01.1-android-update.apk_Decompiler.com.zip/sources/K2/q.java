package K2;

import G3.t;
import H3.w;
import androidx.lifecycle.Q;
import androidx.lifecycle.U;
import androidx.lifecycle.a0;
import f4.AbstractC0952A;
import i4.J;
import i4.O;
import i4.c0;
import q2.C1618h;
import q2.EnumC1611a;

/* JADX INFO: loaded from: classes.dex */
public final class q extends a0 {
    public static final k Companion = new k();
    public final C1618h a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f4502b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f4503c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final EnumC1611a f4504d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final c0 f4505e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final J f4506f;

    public q(C1618h c1618h, Q q5) {
        Object next;
        U3.j.f(c1618h, "repo");
        U3.j.f(q5, "savedStateHandle");
        this.a = c1618h;
        String str = (String) q5.b("platform");
        this.f4502b = str == null ? "tt" : str;
        String str2 = (String) q5.b("kind");
        this.f4503c = str2 == null ? "comment" : str2;
        N3.a aVar = EnumC1611a.f12678p;
        aVar.getClass();
        t tVar = new t(4, aVar);
        while (true) {
            if (!tVar.hasNext()) {
                next = null;
                break;
            } else {
                next = tVar.next();
                if (((EnumC1611a) next).f12679l.equals(this.f4503c)) {
                    break;
                }
            }
        }
        EnumC1611a enumC1611a = (EnumC1611a) next;
        this.f4504d = enumC1611a == null ? EnumC1611a.f12675m : enumC1611a;
        c0 c0VarC = O.c(new i(this.f4502b, this.f4503c, w.f3464l, "", "", false, null));
        this.f4505e = c0VarC;
        this.f4506f = new J(c0VarC);
        AbstractC0952A.s(U.k(this), null, null, new j(this, null), 3);
    }
}

package K2;

import F.H1;
import G3.C;
import I.C0258p;
import com.autogolike.mobile.core.backup.ConfigBackupDto;

/* JADX INFO: loaded from: classes.dex */
public final class a implements T3.e {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final a f4440m = new a(0);

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final a f4441n = new a(1);

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final a f4442o = new a(2);

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f4443l;

    public /* synthetic */ a(int i5) {
        this.f4443l = i5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        switch (this.f4443l) {
            case ConfigBackupDto.$stable /* 0 */:
                C0258p c0258p = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p.x()) {
                    c0258p.L();
                } else {
                    H1.b("Nhập 1 mẫu rồi bấm Thêm", null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, 6, 0, 131070);
                }
                break;
            case 1:
                C0258p c0258p2 = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p2.x()) {
                    c0258p2.L();
                } else {
                    H1.b("Dán nhiều mẫu", null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p2, 6, 0, 131070);
                }
                break;
            default:
                C0258p c0258p3 = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p3.x()) {
                    c0258p3.L();
                } else {
                    H1.b("Hay quá!\nĐỉnh thật\n…", null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p3, 6, 0, 131070);
                }
                break;
        }
        return C.a;
    }
}

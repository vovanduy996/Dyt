package K2;

import G3.AbstractC0164a;
import G3.C;
import com.autogolike.mobile.core.warmup.template.WarmupTemplateEntity;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;
import q2.C1618h;

/* JADX INFO: loaded from: classes.dex */
public final class l extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f4488p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ q f4489q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ String f4490r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public l(q qVar, String str, Continuation continuation) {
        super(2, continuation);
        this.f4489q = qVar;
        this.f4490r = str;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((l) m((InterfaceC0991y) obj, (Continuation) obj2)).o(C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new l(this.f4489q, this.f4490r, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f4488p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            q qVar = this.f4489q;
            C1618h c1618h = qVar.a;
            this.f4488p = 1;
            c1618h.getClass();
            long jCurrentTimeMillis = System.currentTimeMillis();
            if (c1618h.a.insert(new WarmupTemplateEntity(0L, qVar.f4502b, qVar.f4504d.f12679l, c4.l.P0(this.f4490r).toString(), true, 0L, jCurrentTimeMillis, 33, null), this) == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return C.a;
    }
}

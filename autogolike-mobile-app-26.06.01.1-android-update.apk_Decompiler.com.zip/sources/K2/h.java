package K2;

import F.C0084c;
import G3.C;
import I.C0250l;
import I.C0258p;
import I.InterfaceC0233c0;
import I.Y0;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import com.autogolike.mobile.core.warmup.template.WarmupTemplateEntity;
import f.C0933a;
import f2.C0948l;
import java.util.List;
import java.util.ListIterator;
import k.C1233h;
import m.B0;
import r.C1624d;
import w1.C2006k;
import z2.AbstractC2143i;
import z2.C2141g;

/* JADX INFO: loaded from: classes.dex */
public final class h extends U3.k implements T3.g {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f4476l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Object f4477m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ Object f4478n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ Object f4479o;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ h(Object obj, Object obj2, Object obj3, int i5) {
        super(4);
        this.f4476l = i5;
        this.f4477m = obj;
        this.f4478n = obj2;
        this.f4479o = obj3;
    }

    @Override // T3.g
    public final Object f(Object obj, Object obj2, Object obj3, Object obj4) {
        int i5;
        Object objPrevious;
        int i6;
        switch (this.f4476l) {
            case ConfigBackupDto.$stable /* 0 */:
                C1624d c1624d = (C1624d) obj;
                int iIntValue = ((Number) obj2).intValue();
                C0258p c0258p = (C0258p) obj3;
                int iIntValue2 = ((Number) obj4).intValue();
                if ((iIntValue2 & 6) == 0) {
                    i5 = (c0258p.f(c1624d) ? 4 : 2) | iIntValue2;
                } else {
                    i5 = iIntValue2;
                }
                if ((iIntValue2 & 48) == 0) {
                    i5 |= c0258p.d(iIntValue) ? 32 : 16;
                }
                if ((i5 & 147) == 146 && c0258p.x()) {
                    c0258p.L();
                } else {
                    WarmupTemplateEntity warmupTemplateEntity = (WarmupTemplateEntity) ((List) this.f4477m).get(iIntValue);
                    c0258p.Q(-1523732955);
                    C0933a.y(warmupTemplateEntity, (T3.c) this.f4478n, (T3.c) this.f4479o, c0258p, 0);
                    c0258p.p(false);
                }
                break;
            case 1:
                C1233h c1233h = (C1233h) obj;
                C2006k c2006k = (C2006k) obj2;
                C0258p c0258p2 = (C0258p) obj3;
                ((Number) obj4).intValue();
                if (!((Boolean) ((InterfaceC0233c0) this.f4478n).getValue()).booleanValue()) {
                    List list = (List) ((Y0) this.f4479o).getValue();
                    ListIterator listIterator = list.listIterator(list.size());
                    while (true) {
                        if (listIterator.hasPrevious()) {
                            objPrevious = listIterator.previous();
                            if (U3.j.a(c2006k, (C2006k) objPrevious)) {
                            }
                        } else {
                            objPrevious = null;
                        }
                    }
                    c2006k = (C2006k) objPrevious;
                }
                if (c2006k != null) {
                    B0.e(c2006k, (R.i) this.f4477m, Q.f.b(-1263531443, new C0084c(c2006k, 12, c1233h), c0258p2), c0258p2, 384);
                }
                break;
            default:
                C1624d c1624d2 = (C1624d) obj;
                int iIntValue3 = ((Number) obj2).intValue();
                C0258p c0258p3 = (C0258p) obj3;
                int iIntValue4 = ((Number) obj4).intValue();
                if ((iIntValue4 & 6) == 0) {
                    i6 = (c0258p3.f(c1624d2) ? 4 : 2) | iIntValue4;
                } else {
                    i6 = iIntValue4;
                }
                if ((iIntValue4 & 48) == 0) {
                    i6 |= c0258p3.d(iIntValue3) ? 32 : 16;
                }
                if ((i6 & 147) == 146 && c0258p3.x()) {
                    c0258p3.L();
                } else {
                    C2141g c2141g = (C2141g) ((List) this.f4477m).get(iIntValue3);
                    c0258p3.Q(634903425);
                    z2.j jVar = (z2.j) this.f4478n;
                    int iIndexOf = jVar.a.indexOf(c2141g);
                    boolean zContains = jVar.f16090b.contains(c2141g.a);
                    c0258p3.Q(-1642080673);
                    T3.e eVar = (T3.e) this.f4479o;
                    boolean zF = c0258p3.f(eVar) | c0258p3.f(c2141g) | c0258p3.h(jVar);
                    Object objG = c0258p3.G();
                    if (zF || objG == C0250l.a) {
                        objG = new C0948l(eVar, c2141g, jVar, 1);
                        c0258p3.a0(objG);
                    }
                    c0258p3.p(false);
                    AbstractC2143i.k(c2141g, iIndexOf, zContains, (T3.a) objG, c0258p3, 0);
                    c0258p3.p(false);
                }
                break;
        }
        return C.a;
    }
}

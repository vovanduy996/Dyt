package K2;

import G3.AbstractC0164a;
import G3.C;
import f4.InterfaceC0991y;
import i4.c0;
import kotlin.coroutines.Continuation;
import q2.C1618h;

/* JADX INFO: loaded from: classes.dex */
public final class o extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f4497p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ q f4498q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o(q qVar, Continuation continuation) {
        super(2, continuation);
        this.f4498q = qVar;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((o) m((InterfaceC0991y) obj, (Continuation) obj2)).o(C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new o(this.f4498q, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        Object value;
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f4497p;
        C c5 = C.a;
        q qVar = this.f4498q;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            C1618h c1618h = qVar.a;
            this.f4497p = 1;
            c1618h.getClass();
            Object objDeleteAllOfKind = c1618h.a.deleteAllOfKind(qVar.f4502b, qVar.f4504d.f12679l, this);
            if (objDeleteAllOfKind != aVar) {
                objDeleteAllOfKind = c5;
            }
            if (objDeleteAllOfKind == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        c0 c0Var = qVar.f4505e;
        do {
            value = c0Var.getValue();
        } while (!c0Var.j(value, i.a((i) value, null, null, null, false, "Đã xoá tất cả mẫu", 63)));
        return c5;
    }
}

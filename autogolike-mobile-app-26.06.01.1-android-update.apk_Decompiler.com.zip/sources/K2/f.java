package K2;

import G3.AbstractC0164a;
import G3.C;
import I.InterfaceC0233c0;
import f4.AbstractC0952A;
import f4.InterfaceC0991y;
import i4.c0;
import kotlin.coroutines.Continuation;

/* JADX INFO: loaded from: classes.dex */
public final class f extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f4472p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ q f4473q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0233c0 f4474r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f(q qVar, InterfaceC0233c0 interfaceC0233c0, Continuation continuation) {
        super(2, continuation);
        this.f4473q = qVar;
        this.f4474r = interfaceC0233c0;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((f) m((InterfaceC0991y) obj, (Continuation) obj2)).o(C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new f(this.f4473q, this.f4474r, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        c0 c0Var;
        Object value;
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f4472p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            if (((i) this.f4474r.getValue()).f4485g != null) {
                this.f4472p = 1;
                if (AbstractC0952A.g(2000L, this) == aVar) {
                    return aVar;
                }
            }
            return C.a;
        }
        if (i5 != 1) {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        AbstractC0164a.e(obj);
        q qVar = this.f4473q;
        do {
            c0Var = qVar.f4505e;
            value = c0Var.getValue();
        } while (!c0Var.j(value, i.a((i) value, null, null, null, false, null, 63)));
        return C.a;
    }
}

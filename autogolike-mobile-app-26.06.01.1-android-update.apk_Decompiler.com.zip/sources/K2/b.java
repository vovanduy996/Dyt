package K2;

import F.H1;
import G3.C;
import I.C0258p;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import q.c0;

/* JADX INFO: loaded from: classes.dex */
public final class b implements T3.f {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final b f4444m = new b(0);

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final b f4445n = new b(1);

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f4446l;

    public /* synthetic */ b(int i5) {
        this.f4446l = i5;
    }

    @Override // T3.f
    public final Object h(Object obj, Object obj2, Object obj3) {
        switch (this.f4446l) {
            case ConfigBackupDto.$stable /* 0 */:
                C0258p c0258p = (C0258p) obj2;
                int iIntValue = ((Number) obj3).intValue();
                U3.j.f((c0) obj, "$this$TextButton");
                if ((iIntValue & 17) == 16 && c0258p.x()) {
                    c0258p.L();
                } else {
                    H1.b("Thêm hết", null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, 6, 0, 131070);
                }
                break;
            default:
                C0258p c0258p2 = (C0258p) obj2;
                int iIntValue2 = ((Number) obj3).intValue();
                U3.j.f((c0) obj, "$this$TextButton");
                if ((iIntValue2 & 17) == 16 && c0258p2.x()) {
                    c0258p2.L();
                } else {
                    H1.b("Hủy", null, 0L, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p2, 6, 0, 131070);
                }
                break;
        }
        return C.a;
    }
}

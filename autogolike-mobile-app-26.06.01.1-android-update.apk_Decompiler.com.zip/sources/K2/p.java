package K2;

import G3.AbstractC0164a;
import G3.C;
import com.autogolike.mobile.core.warmup.template.WarmupTemplateEntity;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;
import q2.C1618h;

/* JADX INFO: loaded from: classes.dex */
public final class p extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f4499p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ q f4500q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ WarmupTemplateEntity f4501r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public p(q qVar, WarmupTemplateEntity warmupTemplateEntity, Continuation continuation) {
        super(2, continuation);
        this.f4500q = qVar;
        this.f4501r = warmupTemplateEntity;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((p) m((InterfaceC0991y) obj, (Continuation) obj2)).o(C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new p(this.f4500q, this.f4501r, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f4499p;
        C c5 = C.a;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            C1618h c1618h = this.f4500q.a;
            WarmupTemplateEntity warmupTemplateEntity = this.f4501r;
            boolean z3 = !warmupTemplateEntity.getEnabled();
            this.f4499p = 1;
            c1618h.getClass();
            Object objUpdate = c1618h.a.update(warmupTemplateEntity.copy((111 & 1) != 0 ? warmupTemplateEntity.id : 0L, (111 & 2) != 0 ? warmupTemplateEntity.platform : null, (111 & 4) != 0 ? warmupTemplateEntity.kind : null, (111 & 8) != 0 ? warmupTemplateEntity.text : null, (111 & 16) != 0 ? warmupTemplateEntity.enabled : z3, (111 & 32) != 0 ? warmupTemplateEntity.lastUsedAt : 0L, (111 & 64) != 0 ? warmupTemplateEntity.createdAt : 0L), this);
            if (objUpdate != aVar) {
                objUpdate = c5;
            }
            if (objUpdate == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return c5;
    }
}

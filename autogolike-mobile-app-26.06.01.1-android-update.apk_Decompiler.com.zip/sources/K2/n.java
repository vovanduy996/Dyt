package K2;

import G3.AbstractC0164a;
import G3.C;
import com.autogolike.mobile.core.warmup.template.WarmupTemplateEntity;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;
import q2.C1618h;

/* JADX INFO: loaded from: classes.dex */
public final class n extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f4494p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ q f4495q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ WarmupTemplateEntity f4496r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public n(q qVar, WarmupTemplateEntity warmupTemplateEntity, Continuation continuation) {
        super(2, continuation);
        this.f4495q = qVar;
        this.f4496r = warmupTemplateEntity;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((n) m((InterfaceC0991y) obj, (Continuation) obj2)).o(C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new n(this.f4495q, this.f4496r, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f4494p;
        C c5 = C.a;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            C1618h c1618h = this.f4495q.a;
            this.f4494p = 1;
            Object objDelete = c1618h.a.delete(this.f4496r, this);
            if (objDelete != aVar) {
                objDelete = c5;
            }
            if (objDelete == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return c5;
    }
}

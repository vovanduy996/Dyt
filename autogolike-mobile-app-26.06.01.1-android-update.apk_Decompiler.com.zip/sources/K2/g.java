package K2;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class g extends U3.h implements T3.a {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f4475t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ g(int i5, Object obj, Class cls, String str, String str2, int i6, int i7) {
        super(i5, i6, cls, obj, str, str2);
        this.f4475t = i7;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:89:0x0255  */
    @Override // T3.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object b() {
        /*
            Method dump skipped, instruction units count: 2620
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: K2.g.b():java.lang.Object");
    }
}

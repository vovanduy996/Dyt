package l0;

import U.p;
import U3.k;
import android.view.KeyEvent;

/* JADX INFO: loaded from: classes.dex */
public final class e extends p implements d {

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public T3.c f11442y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public k f11443z;

    /* JADX WARN: Type inference failed for: r0v0, types: [T3.c, U3.k] */
    @Override // l0.d
    public final boolean p(KeyEvent keyEvent) {
        ?? r02 = this.f11443z;
        if (r02 != 0) {
            return ((Boolean) r02.invoke(new b(keyEvent))).booleanValue();
        }
        return false;
    }

    @Override // l0.d
    public final boolean t(KeyEvent keyEvent) {
        T3.c cVar = this.f11442y;
        if (cVar != null) {
            return ((Boolean) cVar.invoke(new b(keyEvent))).booleanValue();
        }
        return false;
    }
}

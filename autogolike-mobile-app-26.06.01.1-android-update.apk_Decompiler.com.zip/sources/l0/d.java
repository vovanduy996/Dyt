package l0;

import android.view.KeyEvent;
import t0.InterfaceC1807n;

/* JADX INFO: loaded from: classes.dex */
public interface d extends InterfaceC1807n {
    boolean p(KeyEvent keyEvent);

    boolean t(KeyEvent keyEvent);
}

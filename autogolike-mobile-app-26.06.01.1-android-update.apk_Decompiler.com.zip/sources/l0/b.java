package l0;

import U3.j;
import android.view.KeyEvent;

/* JADX INFO: loaded from: classes.dex */
public final class b {
    public final KeyEvent a;

    public final boolean equals(Object obj) {
        if (obj instanceof b) {
            return j.a(this.a, ((b) obj).a);
        }
        return false;
    }

    public final int hashCode() {
        return this.a.hashCode();
    }

    public final String toString() {
        return "KeyEvent(nativeKeyEvent=" + this.a + ')';
    }
}

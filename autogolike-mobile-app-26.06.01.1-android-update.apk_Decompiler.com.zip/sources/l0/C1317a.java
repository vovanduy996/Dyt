package l0;

import com.google.android.gms.dynamite.descriptors.com.google.android.gms.measurement.dynamite.ModuleDescriptor;
import com.google.android.gms.internal.measurement.AbstractC0813y0;

/* JADX INFO: renamed from: l0.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1317a {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final long f11423b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final long f11424c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final long f11425d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final long f11426e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final long f11427f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final long f11428g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final long f11429h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final long f11430i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final long f11431j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final long f11432k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final long f11433l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final long f11434m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final /* synthetic */ int f11435n = 0;
    public final long a;

    static {
        W3.a.i(0);
        W3.a.i(1);
        W3.a.i(2);
        W3.a.i(3);
        f11423b = W3.a.i(4);
        AbstractC0813y0.q(259, 260, 261, 262, 263);
        AbstractC0813y0.q(280, 281, 282, 283, 5);
        W3.a.i(6);
        f11424c = W3.a.i(19);
        f11425d = W3.a.i(20);
        f11426e = W3.a.i(21);
        f11427f = W3.a.i(22);
        f11428g = W3.a.i(23);
        AbstractC0813y0.q(268, 269, 270, 271, 24);
        AbstractC0813y0.q(25, 26, 27, 28, 7);
        AbstractC0813y0.q(8, 9, 10, 11, 12);
        AbstractC0813y0.q(13, 14, 15, 16, 81);
        AbstractC0813y0.q(69, 17, 70, 18, 29);
        AbstractC0813y0.q(30, 31, 32, 33, 34);
        AbstractC0813y0.q(35, 36, 37, 38, 39);
        AbstractC0813y0.q(40, 41, 42, 43, 44);
        AbstractC0813y0.q(45, 46, 47, 48, 49);
        AbstractC0813y0.q(50, 51, 52, 53, 54);
        AbstractC0813y0.q(55, 56, 57, 58, 59);
        W3.a.i(60);
        f11429h = W3.a.i(61);
        W3.a.i(62);
        W3.a.i(63);
        W3.a.i(64);
        W3.a.i(65);
        f11430i = W3.a.i(66);
        W3.a.i(67);
        W3.a.i(112);
        f11431j = W3.a.i(111);
        AbstractC0813y0.q(113, 114, 115, 116, 117);
        AbstractC0813y0.q(118, 119, 120, 121, 122);
        AbstractC0813y0.q(123, 124, 277, 278, 279);
        AbstractC0813y0.q(68, 71, 72, 76, 73);
        AbstractC0813y0.q(74, 75, 77, 78, 79);
        W3.a.i(80);
        W3.a.i(82);
        W3.a.i(83);
        W3.a.i(84);
        f11432k = W3.a.i(92);
        f11433l = W3.a.i(93);
        AbstractC0813y0.q(94, 95, 96, 97, 98);
        AbstractC0813y0.q(99, 100, 101, 102, 103);
        AbstractC0813y0.q(104, 105, 106, 107, 108);
        AbstractC0813y0.q(109, 110, 188, 189, 190);
        AbstractC0813y0.q(191, 192, 193, 194, 195);
        AbstractC0813y0.q(196, 197, 198, 199, 200);
        AbstractC0813y0.q(201, 202, 203, 125, 131);
        AbstractC0813y0.q(132, 133, 134, 135, 136);
        AbstractC0813y0.q(137, 138, 139, 140, 141);
        AbstractC0813y0.q(142, 143, 144, 145, 146);
        AbstractC0813y0.q(147, 148, 149, 150, 151);
        AbstractC0813y0.q(152, 153, 154, 155, 156);
        W3.a.i(157);
        W3.a.i(158);
        W3.a.i(159);
        f11434m = W3.a.i(160);
        AbstractC0813y0.q(161, 162, 163, 126, ModuleDescriptor.MODULE_VERSION);
        AbstractC0813y0.q(85, 86, 130, 87, 88);
        AbstractC0813y0.q(89, 90, 128, 222, 129);
        AbstractC0813y0.q(226, 272, 273, 274, 275);
        AbstractC0813y0.q(91, 164, 165, 166, 167);
        AbstractC0813y0.q(168, 169, 170, 171, 172);
        AbstractC0813y0.q(173, 174, 175, 176, 177);
        AbstractC0813y0.q(178, 179, 180, 181, 182);
        AbstractC0813y0.q(183, 184, 185, 186, 187);
        AbstractC0813y0.q(204, 205, 206, 207, 208);
        AbstractC0813y0.q(209, 210, 211, 212, 213);
        AbstractC0813y0.q(214, 215, 216, 217, 218);
        AbstractC0813y0.q(219, 220, 221, 223, 224);
        AbstractC0813y0.q(276, 225, 229, 230, 231);
        AbstractC0813y0.q(232, 233, 234, 235, 236);
        AbstractC0813y0.q(237, 238, 239, 240, 241);
        AbstractC0813y0.q(242, 243, 244, 245, 246);
        AbstractC0813y0.q(247, 248, 249, 250, 251);
        AbstractC0813y0.q(252, 253, 254, 255, 256);
        AbstractC0813y0.q(257, 258, 264, 265, 266);
        AbstractC0813y0.q(267, 284, 285, 286, 287);
        W3.a.i(288);
    }

    public /* synthetic */ C1317a(long j5) {
        this.a = j5;
    }

    public static final boolean a(long j5, long j6) {
        return j5 == j6;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof C1317a) {
            return this.a == ((C1317a) obj).a;
        }
        return false;
    }

    public final int hashCode() {
        return Long.hashCode(this.a);
    }

    public final String toString() {
        return "Key code: " + this.a;
    }
}

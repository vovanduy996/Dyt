package l0;

import A.Q;
import A.S;
import B2.C0028d;
import B2.C0031g;
import B2.C0033i;
import B2.C0038n;
import B2.C0041q;
import B2.C0043t;
import B2.M;
import B2.N;
import C0.C0047b;
import C0.K;
import C0.L;
import C2.m;
import E4.l;
import F.AbstractC0139x0;
import F.E0;
import F.H1;
import G3.C;
import H0.G;
import H0.InterfaceC0181n;
import H0.z;
import H2.A;
import H2.B;
import H2.C0199i;
import H2.C0205n;
import H2.C0208q;
import H2.C0215y;
import H2.C0216z;
import H2.EnumC0187c;
import H2.F;
import H2.I0;
import H3.w;
import I.C0234d;
import I.C0250l;
import I.C0258p;
import I.C0264s0;
import I.InterfaceC0233c0;
import I.InterfaceC0255n0;
import I.W;
import I.X0;
import I.Y0;
import N1.C0356b;
import N1.C0360d;
import N1.m0;
import N1.q0;
import Q.f;
import U.h;
import U.n;
import U.q;
import U3.j;
import X1.o;
import X2.g;
import Y1.i;
import Y1.k;
import a0.AbstractC0490a;
import a0.C0492c;
import a0.C0494e;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.util.Size;
import android.util.SizeF;
import android.util.SparseArray;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.ExtractedText;
import androidx.compose.foundation.BorderModifierNodeElement;
import androidx.lifecycle.InterfaceC0565j;
import androidx.lifecycle.InterfaceC0576v;
import androidx.lifecycle.h0;
import b0.C0603v;
import b0.T;
import b0.V;
import c1.AbstractC0680s;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import com.google.android.gms.internal.measurement.AbstractC0813y0;
import d4.EnumC0834c;
import dagger.hilt.android.R;
import f.C0933a;
import f1.AbstractC0936a;
import h0.AbstractC1016F;
import h0.C1023d;
import h0.C1024e;
import i2.C1128B;
import i2.C1129C;
import i2.C1138L;
import i2.C1139M;
import i2.C1156q;
import i2.C1161v;
import i2.C1162w;
import i2.EnumC1140a;
import java.io.IOException;
import java.io.Serializable;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import k.J;
import l.AbstractC1287d;
import l.AbstractC1293g;
import l.C1294g0;
import l.D0;
import m.AbstractC1369w;
import m1.AbstractC1383i;
import m1.AbstractC1393s;
import org.xmlpull.v1.XmlPullParserException;
import q.AbstractC1587c;
import q.AbstractC1594j;
import q.AbstractC1598n;
import q.C1586b;
import q.C1588d;
import q.C1589e;
import q.C1591g;
import q.C1603t;
import q.a0;
import q.b0;
import q.c0;
import q.r;
import r0.InterfaceC1642G;
import s1.AbstractC1745e;
import t0.AbstractC1800g;
import t0.C1802i;
import t0.C1803j;
import t0.C1804k;
import t0.C1813u;
import t0.InterfaceC1805l;
import t1.C1819a;
import u1.AbstractC1906b;
import u3.C1913d;
import v.AbstractC1921e;
import z1.AbstractC2128a;

/* JADX INFO: loaded from: classes.dex */
public abstract class c {
    public static C1024e a = null;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static C1024e f11436b = null;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static C1024e f11437c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static C1024e f11438d = null;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static C1024e f11439e = null;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static boolean f11440f = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static Method f11441g;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r5v10, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v9 */
    public static final void A(final C1138L c1138l, final boolean z3, final boolean z5, final boolean z6, final boolean z7, final T3.a aVar, final T3.e eVar, final T3.c cVar, final T3.a aVar2, final T3.a aVar3, final T3.a aVar4, final T3.a aVar5, final T3.a aVar6, final T3.a aVar7, final T3.a aVar8, final T3.a aVar9, final T3.a aVar10, final T3.a aVar11, C0258p c0258p, final int i5, final int i6) throws XmlPullParserException, IOException {
        int i7;
        C0258p c0258p2;
        int i8;
        ?? r5;
        j.f(c1138l, "snapshot");
        j.f(aVar, "onToggleCollapse");
        j.f(eVar, "onDrag");
        j.f(cVar, "onToggleStatusTooltip");
        j.f(aVar2, "onMarkDone");
        j.f(aVar3, "onMarkFail");
        j.f(aVar4, "onClose");
        j.f(aVar5, "onTestLike");
        j.f(aVar6, "onFetchNext");
        j.f(aVar7, "onOpenApp");
        j.f(aVar8, "onOpenLink");
        j.f(aVar9, "onToggleAuto");
        j.f(aVar10, "onDumpUi");
        j.f(aVar11, "onReportAnomaly");
        c0258p.S(1804323911);
        if ((i5 & 6) == 0) {
            i7 = i5 | ((i5 & 8) == 0 ? c0258p.f(c1138l) : c0258p.h(c1138l) ? 4 : 2);
        } else {
            i7 = i5;
        }
        if ((i5 & 48) == 0) {
            i7 |= c0258p.g(z3) ? 32 : 16;
        }
        if ((i5 & 384) == 0) {
            c0258p2 = c0258p;
            i7 |= c0258p2.g(z5) ? 256 : 128;
        } else {
            c0258p2 = c0258p;
        }
        if ((i5 & 3072) == 0) {
            i7 |= c0258p2.g(z6) ? 2048 : 1024;
        }
        if ((i5 & 24576) == 0) {
            i7 |= c0258p2.g(z7) ? 16384 : 8192;
        }
        if ((i5 & 196608) == 0) {
            i7 |= c0258p2.h(aVar) ? 131072 : 65536;
        }
        if ((i5 & 1572864) == 0) {
            i7 |= c0258p2.h(eVar) ? 1048576 : 524288;
        }
        if ((i5 & 12582912) == 0) {
            i7 |= c0258p2.h(cVar) ? 8388608 : 4194304;
        }
        if ((i5 & 100663296) == 0) {
            i7 |= c0258p2.h(aVar2) ? 67108864 : 33554432;
        }
        if ((i5 & 805306368) == 0) {
            i7 |= c0258p2.h(aVar3) ? 536870912 : 268435456;
        }
        if ((i6 & 6) == 0) {
            i8 = i6 | (c0258p2.h(aVar4) ? 4 : 2);
        } else {
            i8 = i6;
        }
        if ((i6 & 48) == 0) {
            i8 |= c0258p2.h(aVar5) ? 32 : 16;
        }
        if ((i6 & 384) == 0) {
            i8 |= c0258p2.h(aVar6) ? 256 : 128;
        }
        if ((i6 & 3072) == 0) {
            i8 |= c0258p2.h(aVar7) ? 2048 : 1024;
        }
        if ((i6 & 24576) == 0) {
            i8 |= c0258p2.h(aVar8) ? 16384 : 8192;
        }
        if ((i6 & 196608) == 0) {
            i8 |= c0258p2.h(aVar9) ? 131072 : 65536;
        }
        if ((i6 & 1572864) == 0) {
            i8 |= c0258p2.h(aVar10) ? 1048576 : 524288;
        }
        if ((i6 & 12582912) == 0) {
            i8 |= c0258p2.h(aVar11) ? 8388608 : 4194304;
        }
        int i9 = i8;
        if ((i7 & 306783379) == 306783378 && (i9 & 4793491) == 4793490 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p2.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p2.k(i.a);
            c0258p2.p(false);
            Y0 y0A = J.a(c1138l.f10443j ? bVar.f7053l : bVar.f7061t, null, "accent", c0258p, 384, 10);
            c0258p2.Q(1034843663);
            if (z3) {
                z(((C0603v) y0A.getValue()).a, c1138l.f10443j, c1138l.f10442i, z5, z6, aVar, c0258p, ((i7 << 3) & 64512) | (i7 & 458752));
                c0258p2.p(false);
                C0264s0 c0264s0R = c0258p.r();
                if (c0264s0R != null) {
                    final int i10 = 0;
                    c0264s0R.f3706d = new T3.e() { // from class: i2.p
                        @Override // T3.e
                        public final Object i(Object obj, Object obj2) throws XmlPullParserException, IOException {
                            C0258p c0258p3 = (C0258p) obj;
                            switch (i10) {
                                case ConfigBackupDto.$stable /* 0 */:
                                    ((Integer) obj2).intValue();
                                    l0.c.A(c1138l, z3, z5, z6, z7, aVar, eVar, cVar, aVar2, aVar3, aVar4, aVar5, aVar6, aVar7, aVar8, aVar9, aVar10, aVar11, c0258p3, C0234d.U(i5 | 1), C0234d.U(i6));
                                    break;
                                case 1:
                                    ((Integer) obj2).intValue();
                                    l0.c.A(c1138l, z3, z5, z6, z7, aVar, eVar, cVar, aVar2, aVar3, aVar4, aVar5, aVar6, aVar7, aVar8, aVar9, aVar10, aVar11, c0258p3, C0234d.U(i5 | 1), C0234d.U(i6));
                                    break;
                                case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                                    ((Integer) obj2).intValue();
                                    l0.c.A(c1138l, z3, z5, z6, z7, aVar, eVar, cVar, aVar2, aVar3, aVar4, aVar5, aVar6, aVar7, aVar8, aVar9, aVar10, aVar11, c0258p3, C0234d.U(i5 | 1), C0234d.U(i6));
                                    break;
                                default:
                                    ((Integer) obj2).intValue();
                                    l0.c.A(c1138l, z3, z5, z6, z7, aVar, eVar, cVar, aVar2, aVar3, aVar4, aVar5, aVar6, aVar7, aVar8, aVar9, aVar10, aVar11, c0258p3, C0234d.U(i5 | 1), C0234d.U(i6));
                                    break;
                            }
                            return G3.C.a;
                        }
                    };
                    return;
                }
                return;
            }
            c0258p2.p(false);
            c0258p2.Q(1034854376);
            if (c1138l.f10449p && !z3) {
                V(c1138l.a, c1138l.f10450q, c1138l.f10451r, c1138l.f10452s, c1138l.f10442i, aVar4, aVar, c0258p, ((i9 << 15) & 458752) | ((i7 << 3) & 3670016));
                c0258p2.p(false);
                C0264s0 c0264s0R2 = c0258p.r();
                if (c0264s0R2 != null) {
                    final int i11 = 1;
                    c0264s0R2.f3706d = new T3.e() { // from class: i2.p
                        @Override // T3.e
                        public final Object i(Object obj, Object obj2) throws XmlPullParserException, IOException {
                            C0258p c0258p3 = (C0258p) obj;
                            switch (i11) {
                                case ConfigBackupDto.$stable /* 0 */:
                                    ((Integer) obj2).intValue();
                                    l0.c.A(c1138l, z3, z5, z6, z7, aVar, eVar, cVar, aVar2, aVar3, aVar4, aVar5, aVar6, aVar7, aVar8, aVar9, aVar10, aVar11, c0258p3, C0234d.U(i5 | 1), C0234d.U(i6));
                                    break;
                                case 1:
                                    ((Integer) obj2).intValue();
                                    l0.c.A(c1138l, z3, z5, z6, z7, aVar, eVar, cVar, aVar2, aVar3, aVar4, aVar5, aVar6, aVar7, aVar8, aVar9, aVar10, aVar11, c0258p3, C0234d.U(i5 | 1), C0234d.U(i6));
                                    break;
                                case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                                    ((Integer) obj2).intValue();
                                    l0.c.A(c1138l, z3, z5, z6, z7, aVar, eVar, cVar, aVar2, aVar3, aVar4, aVar5, aVar6, aVar7, aVar8, aVar9, aVar10, aVar11, c0258p3, C0234d.U(i5 | 1), C0234d.U(i6));
                                    break;
                                default:
                                    ((Integer) obj2).intValue();
                                    l0.c.A(c1138l, z3, z5, z6, z7, aVar, eVar, cVar, aVar2, aVar3, aVar4, aVar5, aVar6, aVar7, aVar8, aVar9, aVar10, aVar11, c0258p3, C0234d.U(i5 | 1), C0234d.U(i6));
                                    break;
                            }
                            return G3.C.a;
                        }
                    };
                    return;
                }
                return;
            }
            c0258p2.p(false);
            c0258p2.Q(1034867776);
            if (c1138l.f10453t && !z3) {
                b(c1138l.f10454u, c1138l.f10455v, c1138l.f10456w, aVar4, aVar, c0258p, ((i9 << 9) & 7168) | ((i7 >> 3) & 57344));
                c0258p2.p(false);
                C0264s0 c0264s0R3 = c0258p.r();
                if (c0264s0R3 != null) {
                    final int i12 = 2;
                    c0264s0R3.f3706d = new T3.e() { // from class: i2.p
                        @Override // T3.e
                        public final Object i(Object obj, Object obj2) throws XmlPullParserException, IOException {
                            C0258p c0258p3 = (C0258p) obj;
                            switch (i12) {
                                case ConfigBackupDto.$stable /* 0 */:
                                    ((Integer) obj2).intValue();
                                    l0.c.A(c1138l, z3, z5, z6, z7, aVar, eVar, cVar, aVar2, aVar3, aVar4, aVar5, aVar6, aVar7, aVar8, aVar9, aVar10, aVar11, c0258p3, C0234d.U(i5 | 1), C0234d.U(i6));
                                    break;
                                case 1:
                                    ((Integer) obj2).intValue();
                                    l0.c.A(c1138l, z3, z5, z6, z7, aVar, eVar, cVar, aVar2, aVar3, aVar4, aVar5, aVar6, aVar7, aVar8, aVar9, aVar10, aVar11, c0258p3, C0234d.U(i5 | 1), C0234d.U(i6));
                                    break;
                                case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                                    ((Integer) obj2).intValue();
                                    l0.c.A(c1138l, z3, z5, z6, z7, aVar, eVar, cVar, aVar2, aVar3, aVar4, aVar5, aVar6, aVar7, aVar8, aVar9, aVar10, aVar11, c0258p3, C0234d.U(i5 | 1), C0234d.U(i6));
                                    break;
                                default:
                                    ((Integer) obj2).intValue();
                                    l0.c.A(c1138l, z3, z5, z6, z7, aVar, eVar, cVar, aVar2, aVar3, aVar4, aVar5, aVar6, aVar7, aVar8, aVar9, aVar10, aVar11, c0258p3, C0234d.U(i5 | 1), C0234d.U(i6));
                                    break;
                            }
                            return G3.C.a;
                        }
                    };
                    return;
                }
                return;
            }
            c0258p2.p(false);
            n nVar = n.a;
            float f5 = 16;
            q qVarH = androidx.compose.foundation.layout.b.h(Y(androidx.compose.foundation.a.a(androidx.compose.foundation.layout.c.n(240, 320), C1913d.g(H3.n.S0(new C0603v(bVar.f7043b), new C0603v(bVar.a))), AbstractC1921e.b(f5)), 1, C0603v.b(0.55f, ((C0603v) y0A.getValue()).a), AbstractC1921e.b(f5)), 12, 10);
            InterfaceC1642G interfaceC1642GE = AbstractC1598n.e(U.b.f6107l, false);
            int i13 = c0258p2.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p2, qVarH);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p2.f3668O) {
                c0258p2.l(c1803j);
            } else {
                c0258p.d0();
            }
            C1802i c1802i = C1804k.f13645f;
            C0234d.R(c0258p2, c1802i, interfaceC1642GE);
            C1802i c1802i2 = C1804k.f13644e;
            C0234d.R(c0258p2, c1802i2, interfaceC0255n0M);
            C1802i c1802i3 = C1804k.f13646g;
            if (c0258p2.f3668O || !j.a(c0258p.G(), Integer.valueOf(i13))) {
                AbstractC0813y0.r(i13, c0258p2, i13, c1802i3);
            }
            C1802i c1802i4 = C1804k.f13643d;
            C0234d.R(c0258p2, c1802i4, qVarD);
            C1603t c1603tA = r.a(AbstractC1594j.g(8), U.b.f6119x, c0258p2, 6);
            int i14 = c0258p2.f3669P;
            InterfaceC0255n0 interfaceC0255n0M2 = c0258p.m();
            q qVarD2 = U.a.d(c0258p2, nVar);
            c0258p.U();
            if (c0258p2.f3668O) {
                c0258p2.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p2, c1802i, c1603tA);
            C0234d.R(c0258p2, c1802i2, interfaceC0255n0M2);
            if (c0258p2.f3668O || !j.a(c0258p.G(), Integer.valueOf(i14))) {
                AbstractC0813y0.r(i14, c0258p2, i14, c1802i3);
            }
            C0234d.R(c0258p2, c1802i4, qVarD2);
            C0258p c0258p3 = c0258p2;
            v(c1138l.a, ((C0603v) y0A.getValue()).a, c1138l.f10443j, z7, aVar5, aVar7, aVar10, aVar, aVar4, eVar, c0258p, ((i7 >> 3) & 7168) | ((i9 << 9) & 57344) | ((i9 << 6) & 458752) | (i9 & 3670016) | ((i7 << 6) & 29360128) | ((i9 << 24) & 234881024) | ((i7 << 9) & 1879048192));
            s(0, c0258p3);
            M(c1138l, c0258p3, (i7 & 14) | 8);
            c0258p3.Q(-139807885);
            String str = c1138l.f10444k;
            if (str == null) {
                r5 = 0;
            } else {
                r5 = 0;
                s(0, c0258p3);
                x(str, aVar8, c0258p3, (i9 >> 9) & 112);
            }
            c0258p3.p(r5);
            s(r5, c0258p3);
            N(r5, ((C0603v) y0A.getValue()).a, c0258p3, c1138l.f10442i);
            c0258p3.Q(-139801137);
            if (z7 && !c1138l.f10446m.isEmpty()) {
                o(c1138l.f10446m, c0258p3, r5);
            }
            c0258p3.p(r5);
            c(c1138l.f10436c != null, c1138l.f10447n, c1138l.f10445l, c1138l.f10448o, aVar2, aVar3, aVar6, aVar11, c0258p, ((i7 >> 12) & 516096) | ((i9 << 12) & 3670016) | (i9 & 29360128));
            i((i9 >> 12) & 112, c0258p3, aVar9, c1138l.f10445l);
            O(z5, cVar, c0258p3, ((i7 >> 18) & 112) | ((i7 >> 6) & 14));
            U(0, c0258p3);
            c0258p3.p(true);
            c0258p3.p(true);
        }
        C0264s0 c0264s0R4 = c0258p.r();
        if (c0264s0R4 != null) {
            final int i15 = 3;
            c0264s0R4.f3706d = new T3.e() { // from class: i2.p
                @Override // T3.e
                public final Object i(Object obj, Object obj2) throws XmlPullParserException, IOException {
                    C0258p c0258p32 = (C0258p) obj;
                    switch (i15) {
                        case ConfigBackupDto.$stable /* 0 */:
                            ((Integer) obj2).intValue();
                            l0.c.A(c1138l, z3, z5, z6, z7, aVar, eVar, cVar, aVar2, aVar3, aVar4, aVar5, aVar6, aVar7, aVar8, aVar9, aVar10, aVar11, c0258p32, C0234d.U(i5 | 1), C0234d.U(i6));
                            break;
                        case 1:
                            ((Integer) obj2).intValue();
                            l0.c.A(c1138l, z3, z5, z6, z7, aVar, eVar, cVar, aVar2, aVar3, aVar4, aVar5, aVar6, aVar7, aVar8, aVar9, aVar10, aVar11, c0258p32, C0234d.U(i5 | 1), C0234d.U(i6));
                            break;
                        case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                            ((Integer) obj2).intValue();
                            l0.c.A(c1138l, z3, z5, z6, z7, aVar, eVar, cVar, aVar2, aVar3, aVar4, aVar5, aVar6, aVar7, aVar8, aVar9, aVar10, aVar11, c0258p32, C0234d.U(i5 | 1), C0234d.U(i6));
                            break;
                        default:
                            ((Integer) obj2).intValue();
                            l0.c.A(c1138l, z3, z5, z6, z7, aVar, eVar, cVar, aVar2, aVar3, aVar4, aVar5, aVar6, aVar7, aVar8, aVar9, aVar10, aVar11, c0258p32, C0234d.U(i5 | 1), C0234d.U(i6));
                            break;
                    }
                    return G3.C.a;
                }
            };
        }
    }

    public static int A0(Parcel parcel, int i5) {
        parcel.writeInt(i5 | (-65536));
        parcel.writeInt(0);
        return parcel.dataPosition();
    }

    public static C0047b B(String str, L l4, long j5, O0.b bVar, InterfaceC0181n interfaceC0181n, w wVar, int i5, int i6) {
        int i7 = i6 & 32;
        w wVar2 = w.f3464l;
        return new C0047b(new K0.c(str, l4, i7 != 0 ? wVar2 : wVar, wVar2, interfaceC0181n, bVar), i5, false, j5);
    }

    public static void B0(Parcel parcel, int i5) {
        int iDataPosition = parcel.dataPosition();
        parcel.setDataPosition(i5 - 4);
        parcel.writeInt(iDataPosition - i5);
        parcel.setDataPosition(iDataPosition);
    }

    public static final void C(final long j5, final boolean z3, C0258p c0258p, final int i5) {
        int i6;
        c0258p.S(1279121903);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.e(j5) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.g(z3) ? 32 : 16;
        }
        if ((i6 & 19) == 18 && c0258p.x()) {
            c0258p.L();
        } else {
            float f5 = z3 ? 1.0f : 0.45f;
            int i7 = AbstractC1293g.a;
            c0258p.Q(1125598679);
            boolean zC = c0258p.c(0.01f);
            Object objG = c0258p.G();
            if (zC || objG == C0250l.a) {
                objG = AbstractC1287d.n(0.0f, Float.valueOf(0.01f), 3);
                c0258p.a0(objG);
            }
            c0258p.p(false);
            AbstractC1598n.a(androidx.compose.foundation.a.b(l.f0(androidx.compose.foundation.layout.c.i(n.a, 8), ((Number) AbstractC1293g.b(Float.valueOf(f5), D0.a, (C1294g0) objG, Float.valueOf(0.01f), "pulse", null, c0258p, 24576, 0).getValue()).floatValue()), j5, AbstractC1921e.a), c0258p, 0);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new T3.e() { // from class: i2.t
                @Override // T3.e
                public final Object i(Object obj, Object obj2) {
                    ((Integer) obj2).intValue();
                    int iU = C0234d.U(i5 | 1);
                    l0.c.C(j5, z3, (C0258p) obj, iU);
                    return G3.C.a;
                }
            };
        }
    }

    public static void C0(Parcel parcel, int i5, int i6) {
        parcel.writeInt(i5 | (i6 << 16));
    }

    /* JADX WARN: Removed duplicated region for block: B:102:0x0202  */
    /* JADX WARN: Removed duplicated region for block: B:104:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:58:0x009a  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x009f  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00ba  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x00c8  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x00ca  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x00cc  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x00cf  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x00d3  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x00f1  */
    /* JADX WARN: Removed duplicated region for block: B:85:0x010a  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x015f  */
    /* JADX WARN: Removed duplicated region for block: B:98:0x0168  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final void D(final java.lang.String r28, final int r29, final int r30, final java.lang.String r31, final T3.a r32, final T3.e r33, int r34, int r35, I.C0258p r36, final int r37, final int r38) {
        /*
            Method dump skipped, instruction units count: 539
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: l0.c.D(java.lang.String, int, int, java.lang.String, T3.a, T3.e, int, int, I.p, int, int):void");
    }

    public static final void E(int i5, int i6, T3.c cVar, C0258p c0258p, int i7) {
        int i8;
        boolean z3;
        boolean z5;
        String str;
        c0258p.S(2137870249);
        if ((i7 & 6) == 0) {
            i8 = (c0258p.d(i5) ? 4 : 2) | i7;
        } else {
            i8 = i7;
        }
        if ((i7 & 48) == 0) {
            i8 |= c0258p.d(i6) ? 32 : 16;
        }
        if ((i7 & 384) == 0) {
            i8 |= c0258p.h(cVar) ? 256 : 128;
        }
        int i9 = i8;
        if ((i9 & 147) == 146 && c0258p.x()) {
            c0258p.L();
        } else {
            Y1.b bVarC = g.C(c0258p);
            n nVar = n.a;
            q qVarH = androidx.compose.foundation.layout.b.h(nVar, g.I(c0258p).f7109e, 13);
            C1588d c1588d = AbstractC1594j.f12606c;
            U.g gVar = U.b.f6119x;
            C1603t c1603tA = r.a(c1588d, gVar, c0258p, 0);
            int i10 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarH);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C1802i c1802i = C1804k.f13645f;
            C0234d.R(c0258p, c1802i, c1603tA);
            C1802i c1802i2 = C1804k.f13644e;
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M);
            C1802i c1802i3 = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i10))) {
                AbstractC0813y0.r(i10, c0258p, i10, c1802i3);
            }
            C1802i c1802i4 = C1804k.f13643d;
            C0234d.R(c0258p, c1802i4, qVarD);
            h hVar = U.b.f6117v;
            C1586b c1586b = AbstractC1594j.a;
            b0 b0VarB = a0.b(c1586b, hVar, c0258p, 48);
            int i11 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M2 = c0258p.m();
            q qVarD2 = U.a.d(c0258p, nVar);
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, c1802i, b0VarB);
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M2);
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i11))) {
                AbstractC0813y0.r(i11, c0258p, i11, c1802i3);
            }
            C0234d.R(c0258p, c1802i4, qVarD2);
            q qVarA = c0.a(1.0f);
            C1603t c1603tA2 = r.a(c1588d, gVar, c0258p, 0);
            int i12 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M3 = c0258p.m();
            q qVarD3 = U.a.d(c0258p, qVarA);
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, c1802i, c1603tA2);
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M3);
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i12))) {
                AbstractC0813y0.r(i12, c0258p, i12, c1802i3);
            }
            C0234d.R(c0258p, c1802i4, qVarD3);
            H1.b("Khởi động lại app gốc", null, bVarC.f7049h, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, g.L(c0258p).f7117f, c0258p, 6, 0, 65530);
            H1.b("Tắt nền app TT/FB/IG để thu hồi RAM, tránh lag", null, bVarC.f7052k, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, g.L(c0258p).f7118g, c0258p, 6, 0, 65530);
            c0258p.p(true);
            String str2 = "Sau " + i5;
            c0258p.Q(-713696434);
            int i13 = i9 & 896;
            boolean z6 = i13 == 256;
            Object objG = c0258p.G();
            W w5 = C0250l.a;
            if (z6 || objG == w5) {
                objG = new A2.l(9, cVar);
                c0258p.a0(objG);
            }
            c0258p.p(false);
            y(i5, (i9 & 14) | 48, c0258p, (T3.a) objG, str2);
            c0258p.p(true);
            c0258p.Q(-2071701849);
            if (i5 > 0) {
                AbstractC1587c.a(c0258p, androidx.compose.foundation.layout.c.d(nVar, 8));
                b0 b0VarB2 = a0.b(c1586b, hVar, c0258p, 48);
                int i14 = c0258p.f3669P;
                InterfaceC0255n0 interfaceC0255n0M4 = c0258p.m();
                q qVarD4 = U.a.d(c0258p, nVar);
                c0258p.U();
                if (c0258p.f3668O) {
                    c0258p.l(c1803j);
                } else {
                    c0258p.d0();
                }
                C0234d.R(c0258p, c1802i, b0VarB2);
                C0234d.R(c0258p, c1802i2, interfaceC0255n0M4);
                if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i14))) {
                    AbstractC0813y0.r(i14, c0258p, i14, c1802i3);
                }
                C0234d.R(c0258p, c1802i4, qVarD4);
                H1.b("Sau", null, bVarC.f7050i, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, g.L(c0258p).f7116e, c0258p, 6, 0, 65530);
                float f5 = 6;
                AbstractC1587c.a(c0258p, androidx.compose.foundation.layout.c.m(nVar, f5));
                String str3 = i5 + " job";
                c0258p.Q(-713684594);
                boolean z7 = i13 == 256;
                Object objG2 = c0258p.G();
                if (z7 || objG2 == w5) {
                    objG2 = new A2.l(10, cVar);
                    c0258p.a0(objG2);
                }
                c0258p.p(false);
                T(str3, (T3.a) objG2, c0258p, 0);
                H1.b("· đợi", null, bVarC.f7050i, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, AbstractC0813y0.i(nVar, f5, c0258p, c0258p).f7116e, c0258p, 6, 0, 65530);
                AbstractC1587c.a(c0258p, androidx.compose.foundation.layout.c.m(nVar, f5));
                if (i6 == 0) {
                    str = "Mở ngay";
                } else {
                    str = i6 + "s";
                }
                c0258p.Q(-713673485);
                boolean z8 = i13 == 256;
                Object objG3 = c0258p.G();
                if (z8 || objG3 == w5) {
                    objG3 = new A2.l(11, cVar);
                    c0258p.a0(objG3);
                }
                z5 = false;
                c0258p.p(false);
                T(str, (T3.a) objG3, c0258p, 0);
                z3 = true;
                c0258p.p(true);
            } else {
                z3 = true;
                z5 = false;
            }
            c0258p.p(z5);
            c0258p.p(z3);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new C0041q(i5, i6, cVar, i7, 1);
        }
    }

    public static final void F(int i5, int i6, T3.c cVar, C0258p c0258p, int i7) {
        int i8;
        c0258p.S(465074150);
        if ((i7 & 6) == 0) {
            i8 = (c0258p.d(i5) ? 4 : 2) | i7;
        } else {
            i8 = i7;
        }
        if ((i7 & 48) == 0) {
            i8 |= c0258p.d(i6) ? 32 : 16;
        }
        if ((i7 & 384) == 0) {
            i8 |= c0258p.h(cVar) ? 256 : 128;
        }
        if ((i8 & 147) == 146 && c0258p.x()) {
            c0258p.L();
        } else {
            C0933a.c(null, false, f.b(504346955, new B(i5, i6, cVar), c0258p), c0258p, 432, 1);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new C0041q(i5, i6, cVar, i7, 2);
        }
    }

    public static final void G(String str, C0258p c0258p, int i5) {
        int i6;
        c0258p.S(1723083709);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.f(str) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i6 & 3) == 2 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            long j5 = bVar.f7052k;
            c0258p.Q(258792282);
            Y1.f fVar = (Y1.f) c0258p.k(Y1.l.f7129c);
            c0258p.p(false);
            L l4 = fVar.f7119h;
            c0258p.Q(-633634936);
            Y1.e eVar = (Y1.e) c0258p.k(k.a);
            c0258p.p(false);
            H1.b(str, androidx.compose.foundation.layout.b.h(n.a, 4, eVar.f7107c), j5, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, l4, c0258p, i6 & 14, 0, 65528);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new B2.r(i5, 4, str);
        }
    }

    public static final void H(T3.a aVar, T3.a aVar2, I0 i02, C0258p c0258p, int i5) {
        int i6;
        int i7;
        I0 i03;
        W w5;
        T3.e eVar;
        T3.a aVar3;
        T3.a aVar4;
        T3.a aVar5;
        T3.a aVar6;
        T3.c cVar;
        T3.e eVar2;
        T3.a aVar7;
        T3.a aVar8;
        T3.a aVar9;
        T3.c cVar2;
        T3.c cVar3;
        T3.c cVar4;
        I0 i04;
        j.f(aVar, "onStart");
        j.f(aVar2, "onBack");
        c0258p.S(-986287268);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.h(aVar) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.h(aVar2) ? 32 : 16;
        }
        if ((i5 & 384) == 0) {
            i6 |= 128;
        }
        if ((i6 & 147) == 146 && c0258p.x()) {
            c0258p.L();
            i04 = i02;
        } else {
            c0258p.N();
            if ((i5 & 1) == 0 || c0258p.w()) {
                c0258p.R(1890788296);
                h0 h0VarA = AbstractC1906b.a(c0258p);
                if (h0VarA == null) {
                    throw new IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner");
                }
                androidx.lifecycle.c0 c0VarD = AbstractC1383i.D(h0VarA, c0258p);
                c0258p.R(1729797275);
                androidx.lifecycle.a0 a0VarD0 = AbstractC1393s.d0(I0.class, h0VarA, c0VarD, h0VarA instanceof InterfaceC0565j ? ((InterfaceC0565j) h0VarA).a() : C1819a.f13679b, c0258p);
                c0258p.p(false);
                c0258p.p(false);
                i7 = i6 & (-897);
                i03 = (I0) a0VarD0;
            } else {
                c0258p.L();
                i7 = i6 & (-897);
                i03 = i02;
            }
            c0258p.q();
            F f5 = (F) AbstractC1369w.j(i03.f3090f, c0258p).getValue();
            c0258p.Q(2059834851);
            boolean zH = c0258p.h(i03);
            Object objG = c0258p.G();
            W w6 = C0250l.a;
            if (zH || objG == w6) {
                w5 = w6;
                N n5 = new N(2, i03, I0.class, "onStepDelayChange", "onStepDelayChange(II)V", 0, 4);
                c0258p.a0(n5);
                objG = n5;
            } else {
                w5 = w6;
            }
            c0258p.p(false);
            T3.e eVar3 = (T3.e) ((U3.h) objG);
            c0258p.Q(2059836483);
            boolean zH2 = c0258p.h(i03);
            Object objG2 = c0258p.G();
            if (zH2 || objG2 == w5) {
                N n6 = new N(2, i03, I0.class, "onTaskDelayChange", "onTaskDelayChange(II)V", 0, 5);
                c0258p.a0(n6);
                objG2 = n6;
            }
            c0258p.p(false);
            T3.e eVar4 = (T3.e) ((U3.h) objG2);
            c0258p.Q(2059838148);
            boolean zH3 = c0258p.h(i03);
            Object objG3 = c0258p.G();
            if (zH3 || objG3 == w5) {
                N n7 = new N(2, i03, I0.class, "onNoJobDelayChange", "onNoJobDelayChange(II)V", 0, 6);
                c0258p.a0(n7);
                objG3 = n7;
            }
            c0258p.p(false);
            T3.e eVar5 = (T3.e) ((U3.h) objG3);
            c0258p.Q(2059840141);
            boolean zH4 = c0258p.h(i03);
            Object objG4 = c0258p.G();
            if (zH4 || objG4 == w5) {
                eVar = eVar5;
                m mVar = new m(0, i03, I0.class, "onStepDelayMinuteModeToggle", "onStepDelayMinuteModeToggle()V", 0, 18);
                c0258p.a0(mVar);
                objG4 = mVar;
            } else {
                eVar = eVar5;
            }
            c0258p.p(false);
            T3.a aVar10 = (T3.a) ((U3.h) objG4);
            c0258p.Q(2059842413);
            boolean zH5 = c0258p.h(i03);
            Object objG5 = c0258p.G();
            if (zH5 || objG5 == w5) {
                aVar3 = aVar10;
                m mVar2 = new m(0, i03, I0.class, "onTaskDelayMinuteModeToggle", "onTaskDelayMinuteModeToggle()V", 0, 19);
                c0258p.a0(mVar2);
                objG5 = mVar2;
            } else {
                aVar3 = aVar10;
            }
            c0258p.p(false);
            T3.a aVar11 = (T3.a) ((U3.h) objG5);
            c0258p.Q(2059844718);
            boolean zH6 = c0258p.h(i03);
            Object objG6 = c0258p.G();
            if (zH6 || objG6 == w5) {
                aVar4 = aVar11;
                m mVar3 = new m(0, i03, I0.class, "onNoJobDelayMinuteModeToggle", "onNoJobDelayMinuteModeToggle()V", 0, 20);
                c0258p.a0(mVar3);
                objG6 = mVar3;
            } else {
                aVar4 = aVar11;
            }
            c0258p.p(false);
            T3.a aVar12 = (T3.a) ((U3.h) objG6);
            c0258p.Q(2059846598);
            boolean zH7 = c0258p.h(i03);
            Object objG7 = c0258p.G();
            if (zH7 || objG7 == w5) {
                aVar5 = aVar12;
                m mVar4 = new m(0, i03, I0.class, "onBreakEvery50Toggle", "onBreakEvery50Toggle()V", 0, 21);
                c0258p.a0(mVar4);
                objG7 = mVar4;
            } else {
                aVar5 = aVar12;
            }
            c0258p.p(false);
            T3.a aVar13 = (T3.a) ((U3.h) objG7);
            c0258p.Q(2059848296);
            boolean zH8 = c0258p.h(i03);
            Object objG8 = c0258p.G();
            if (zH8 || objG8 == w5) {
                aVar6 = aVar13;
                M m5 = new M(1, i03, I0.class, "onBreakAfterJobsChange", "onBreakAfterJobsChange(I)V", 0, 16);
                c0258p.a0(m5);
                objG8 = m5;
            } else {
                aVar6 = aVar13;
            }
            c0258p.p(false);
            T3.c cVar5 = (T3.c) ((U3.h) objG8);
            c0258p.Q(2059849990);
            boolean zH9 = c0258p.h(i03);
            Object objG9 = c0258p.G();
            if (zH9 || objG9 == w5) {
                cVar = cVar5;
                N n8 = new N(2, i03, I0.class, "onBreakMinutesChange", "onBreakMinutesChange(II)V", 0, 7);
                c0258p.a0(n8);
                objG9 = n8;
            } else {
                cVar = cVar5;
            }
            c0258p.p(false);
            T3.e eVar6 = (T3.e) ((U3.h) objG9);
            c0258p.Q(2059851655);
            boolean zH10 = c0258p.h(i03);
            Object objG10 = c0258p.G();
            if (zH10 || objG10 == w5) {
                eVar2 = eVar6;
                m mVar5 = new m(0, i03, I0.class, "onWarmupOnBreakToggle", "onWarmupOnBreakToggle()V", 0, 12);
                c0258p.a0(mVar5);
                objG10 = mVar5;
            } else {
                eVar2 = eVar6;
            }
            c0258p.p(false);
            T3.a aVar14 = (T3.a) ((U3.h) objG10);
            c0258p.Q(2059853285);
            boolean zH11 = c0258p.h(i03);
            Object objG11 = c0258p.G();
            if (zH11 || objG11 == w5) {
                aVar7 = aVar14;
                m mVar6 = new m(0, i03, I0.class, "onRandomSwipeToggle", "onRandomSwipeToggle()V", 0, 13);
                c0258p.a0(mVar6);
                objG11 = mVar6;
            } else {
                aVar7 = aVar14;
            }
            c0258p.p(false);
            T3.a aVar15 = (T3.a) ((U3.h) objG11);
            c0258p.Q(2059854985);
            boolean zH12 = c0258p.h(i03);
            Object objG12 = c0258p.G();
            if (zH12 || objG12 == w5) {
                aVar8 = aVar15;
                m mVar7 = new m(0, i03, I0.class, "onWatchBeforeLikeToggle", "onWatchBeforeLikeToggle()V", 0, 14);
                c0258p.a0(mVar7);
                objG12 = mVar7;
            } else {
                aVar8 = aVar15;
            }
            c0258p.p(false);
            T3.a aVar16 = (T3.a) ((U3.h) objG12);
            c0258p.Q(2059856974);
            boolean zH13 = c0258p.h(i03);
            Object objG13 = c0258p.G();
            if (zH13 || objG13 == w5) {
                aVar9 = aVar16;
                M m6 = new M(1, i03, I0.class, "onMaxConsecutiveErrorsChange", "onMaxConsecutiveErrorsChange(I)V", 0, 7);
                c0258p.a0(m6);
                objG13 = m6;
            } else {
                aVar9 = aVar16;
            }
            c0258p.p(false);
            T3.c cVar6 = (T3.c) ((U3.h) objG13);
            c0258p.Q(2059858887);
            boolean zH14 = c0258p.h(i03);
            Object objG14 = c0258p.G();
            if (zH14 || objG14 == w5) {
                cVar2 = cVar6;
                M m7 = new M(1, i03, I0.class, "onMaxJobsToStopChange", "onMaxJobsToStopChange(I)V", 0, 8);
                c0258p.a0(m7);
                objG14 = m7;
            } else {
                cVar2 = cVar6;
            }
            c0258p.p(false);
            T3.c cVar7 = (T3.c) ((U3.h) objG14);
            c0258p.Q(2059860913);
            boolean zH15 = c0258p.h(i03);
            Object objG15 = c0258p.G();
            if (zH15 || objG15 == w5) {
                cVar3 = cVar7;
                M m8 = new M(1, i03, I0.class, "onRestartNativeEveryNJobsChange", "onRestartNativeEveryNJobsChange(I)V", 0, 9);
                c0258p.a0(m8);
                objG15 = m8;
            } else {
                cVar3 = cVar7;
            }
            c0258p.p(false);
            T3.c cVar8 = (T3.c) ((U3.h) objG15);
            c0258p.Q(2059863183);
            boolean zH16 = c0258p.h(i03);
            Object objG16 = c0258p.G();
            if (zH16 || objG16 == w5) {
                cVar4 = cVar8;
                M m9 = new M(1, i03, I0.class, "onRestartReopenDelaySecChange", "onRestartReopenDelaySecChange(I)V", 0, 10);
                c0258p.a0(m9);
                objG16 = m9;
            } else {
                cVar4 = cVar8;
            }
            c0258p.p(false);
            T3.c cVar9 = (T3.c) ((U3.h) objG16);
            c0258p.Q(2059865199);
            boolean zH17 = c0258p.h(i03);
            Object objG17 = c0258p.G();
            if (zH17 || objG17 == w5) {
                m mVar8 = new m(0, i03, I0.class, "onAutoRetryServerVerifyToggle", "onAutoRetryServerVerifyToggle()V", 0, 15);
                c0258p.a0(mVar8);
                objG17 = mVar8;
            }
            c0258p.p(false);
            T3.a aVar17 = (T3.a) ((U3.h) objG17);
            c0258p.Q(2059867380);
            boolean zH18 = c0258p.h(i03);
            Object objG18 = c0258p.G();
            if (zH18 || objG18 == w5) {
                M m10 = new M(1, i03, I0.class, "onAutoRetryServerVerifyDelayChange", "onAutoRetryServerVerifyDelayChange(I)V", 0, 11);
                c0258p.a0(m10);
                objG18 = m10;
            }
            c0258p.p(false);
            T3.c cVar10 = (T3.c) ((U3.h) objG18);
            c0258p.Q(2059869836);
            boolean zH19 = c0258p.h(i03);
            Object objG19 = c0258p.G();
            if (zH19 || objG19 == w5) {
                m mVar9 = new m(0, i03, I0.class, "onBackToHomeAfterJobToggle", "onBackToHomeAfterJobToggle()V", 0, 16);
                c0258p.a0(mVar9);
                objG19 = mVar9;
            }
            c0258p.p(false);
            T3.a aVar18 = (T3.a) ((U3.h) objG19);
            c0258p.Q(2059871945);
            boolean zH20 = c0258p.h(i03);
            Object objG20 = c0258p.G();
            if (zH20 || objG20 == w5) {
                M m11 = new M(1, i03, I0.class, "onBackToHomeDelayChange", "onBackToHomeDelayChange(I)V", 0, 12);
                c0258p.a0(m11);
                objG20 = m11;
            }
            c0258p.p(false);
            T3.c cVar11 = (T3.c) ((U3.h) objG20);
            c0258p.Q(2059873961);
            boolean zH21 = c0258p.h(i03);
            Object objG21 = c0258p.G();
            if (zH21 || objG21 == w5) {
                M m12 = new M(1, i03, I0.class, "onBackToHomeCountChange", "onBackToHomeCountChange(I)V", 0, 13);
                c0258p.a0(m12);
                objG21 = m12;
            }
            c0258p.p(false);
            T3.c cVar12 = (T3.c) ((U3.h) objG21);
            c0258p.Q(2059876208);
            boolean zH22 = c0258p.h(i03);
            Object objG22 = c0258p.G();
            if (zH22 || objG22 == w5) {
                M m13 = new M(1, i03, I0.class, "onRotateAfterSuccessJobsChange", "onRotateAfterSuccessJobsChange(I)V", 0, 14);
                c0258p.a0(m13);
                objG22 = m13;
            }
            c0258p.p(false);
            T3.c cVar13 = (T3.c) ((U3.h) objG22);
            c0258p.Q(2059878870);
            boolean zH23 = c0258p.h(i03);
            Object objG23 = c0258p.G();
            if (zH23 || objG23 == w5) {
                M m14 = new M(1, i03, I0.class, "onRotateAfterConsecutiveErrorsChange", "onRotateAfterConsecutiveErrorsChange(I)V", 0, 15);
                c0258p.a0(m14);
                objG23 = m14;
            }
            c0258p.p(false);
            T3.c cVar14 = (T3.c) ((U3.h) objG23);
            c0258p.Q(2059881421);
            boolean zH24 = c0258p.h(i03);
            Object objG24 = c0258p.G();
            if (zH24 || objG24 == w5) {
                m mVar10 = new m(0, i03, I0.class, "onHumanizeBetweenJobsToggle", "onHumanizeBetweenJobsToggle()V", 0, 17);
                c0258p.a0(mVar10);
                objG24 = mVar10;
            }
            c0258p.p(false);
            I(f5, eVar3, eVar4, eVar, aVar3, aVar4, aVar5, aVar6, cVar, eVar2, aVar7, aVar8, aVar9, cVar2, cVar3, cVar4, cVar9, aVar17, cVar10, aVar18, cVar11, cVar12, cVar13, cVar14, (T3.a) ((U3.h) objG24), aVar, aVar2, c0258p, 8, 0, (i7 << 15) & 4128768);
            i04 = i03;
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new C0031g(aVar, aVar2, i04, i5, 6);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:235:0x044e  */
    /* JADX WARN: Removed duplicated region for block: B:236:0x0452  */
    /* JADX WARN: Removed duplicated region for block: B:241:0x046d  */
    /* JADX WARN: Removed duplicated region for block: B:250:0x04cc  */
    /* JADX WARN: Removed duplicated region for block: B:253:0x04d3  */
    /* JADX WARN: Removed duplicated region for block: B:254:0x04d5  */
    /* JADX WARN: Removed duplicated region for block: B:257:0x04dd  */
    /* JADX WARN: Removed duplicated region for block: B:258:0x04df  */
    /* JADX WARN: Removed duplicated region for block: B:261:0x04e7  */
    /* JADX WARN: Removed duplicated region for block: B:262:0x04e9  */
    /* JADX WARN: Removed duplicated region for block: B:265:0x04f4  */
    /* JADX WARN: Removed duplicated region for block: B:266:0x04f6  */
    /* JADX WARN: Removed duplicated region for block: B:269:0x04ff  */
    /* JADX WARN: Removed duplicated region for block: B:270:0x0501  */
    /* JADX WARN: Removed duplicated region for block: B:273:0x050a  */
    /* JADX WARN: Removed duplicated region for block: B:274:0x050c  */
    /* JADX WARN: Removed duplicated region for block: B:277:0x0519  */
    /* JADX WARN: Removed duplicated region for block: B:278:0x051b  */
    /* JADX WARN: Removed duplicated region for block: B:281:0x0523  */
    /* JADX WARN: Removed duplicated region for block: B:282:0x0525  */
    /* JADX WARN: Removed duplicated region for block: B:285:0x052e  */
    /* JADX WARN: Removed duplicated region for block: B:286:0x0530  */
    /* JADX WARN: Removed duplicated region for block: B:289:0x0539  */
    /* JADX WARN: Removed duplicated region for block: B:290:0x053b  */
    /* JADX WARN: Removed duplicated region for block: B:293:0x0543  */
    /* JADX WARN: Removed duplicated region for block: B:294:0x0545  */
    /* JADX WARN: Removed duplicated region for block: B:297:0x054e  */
    /* JADX WARN: Removed duplicated region for block: B:298:0x0550  */
    /* JADX WARN: Removed duplicated region for block: B:301:0x0557  */
    /* JADX WARN: Removed duplicated region for block: B:302:0x0559  */
    /* JADX WARN: Removed duplicated region for block: B:305:0x0561  */
    /* JADX WARN: Removed duplicated region for block: B:309:0x0578  */
    /* JADX WARN: Removed duplicated region for block: B:313:0x0614  */
    /* JADX WARN: Removed duplicated region for block: B:314:0x0620  */
    /* JADX WARN: Removed duplicated region for block: B:317:0x0635  */
    /* JADX WARN: Removed duplicated region for block: B:318:0x0637  */
    /* JADX WARN: Removed duplicated region for block: B:321:0x063e A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:324:0x0644  */
    /* JADX WARN: Removed duplicated region for block: B:327:0x0663  */
    /* JADX WARN: Removed duplicated region for block: B:328:0x0665  */
    /* JADX WARN: Removed duplicated region for block: B:334:0x0672  */
    /* JADX WARN: Removed duplicated region for block: B:337:0x0690  */
    /* JADX WARN: Removed duplicated region for block: B:338:0x0692  */
    /* JADX WARN: Removed duplicated region for block: B:344:0x069f  */
    /* JADX WARN: Removed duplicated region for block: B:347:0x06bc  */
    /* JADX WARN: Removed duplicated region for block: B:348:0x06be  */
    /* JADX WARN: Removed duplicated region for block: B:354:0x06cb  */
    /* JADX WARN: Removed duplicated region for block: B:357:0x06e8  */
    /* JADX WARN: Removed duplicated region for block: B:358:0x06ea  */
    /* JADX WARN: Removed duplicated region for block: B:364:0x06f7  */
    /* JADX WARN: Removed duplicated region for block: B:367:0x0715  */
    /* JADX WARN: Removed duplicated region for block: B:368:0x0717  */
    /* JADX WARN: Removed duplicated region for block: B:374:0x0724  */
    /* JADX WARN: Removed duplicated region for block: B:377:0x0742  */
    /* JADX WARN: Removed duplicated region for block: B:378:0x0744  */
    /* JADX WARN: Removed duplicated region for block: B:384:0x0751  */
    /* JADX WARN: Removed duplicated region for block: B:387:0x076f  */
    /* JADX WARN: Removed duplicated region for block: B:388:0x0771  */
    /* JADX WARN: Removed duplicated region for block: B:394:0x0780  */
    /* JADX WARN: Removed duplicated region for block: B:397:0x07a0  */
    /* JADX WARN: Removed duplicated region for block: B:398:0x07a2  */
    /* JADX WARN: Removed duplicated region for block: B:404:0x07af  */
    /* JADX WARN: Removed duplicated region for block: B:407:0x07ce  */
    /* JADX WARN: Removed duplicated region for block: B:408:0x07d0  */
    /* JADX WARN: Removed duplicated region for block: B:414:0x07dd  */
    /* JADX WARN: Removed duplicated region for block: B:417:0x07fc  */
    /* JADX WARN: Removed duplicated region for block: B:418:0x07ff  */
    /* JADX WARN: Removed duplicated region for block: B:424:0x080d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final void I(final H2.F r46, final T3.e r47, final T3.e r48, final T3.e r49, final T3.a r50, final T3.a r51, final T3.a r52, final T3.a r53, final T3.c r54, final T3.e r55, final T3.a r56, final T3.a r57, final T3.a r58, final T3.c r59, final T3.c r60, final T3.c r61, final T3.c r62, final T3.a r63, final T3.c r64, final T3.a r65, final T3.c r66, final T3.c r67, final T3.c r68, final T3.c r69, final T3.a r70, final T3.a r71, final T3.a r72, I.C0258p r73, final int r74, final int r75, final int r76) {
        /*
            Method dump skipped, instruction units count: 2197
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: l0.c.I(H2.F, T3.e, T3.e, T3.e, T3.a, T3.a, T3.a, T3.a, T3.c, T3.e, T3.a, T3.a, T3.a, T3.c, T3.c, T3.c, T3.c, T3.a, T3.c, T3.a, T3.c, T3.c, T3.c, T3.c, T3.a, T3.a, T3.a, I.p, int, int, int):void");
    }

    public static final void J(q qVar, Q.a aVar, C0258p c0258p, int i5) {
        int i6;
        c0258p.S(-2105228848);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.f(qVar) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.h(aVar) ? 32 : 16;
        }
        if ((i6 & 19) == 18 && c0258p.x()) {
            c0258p.L();
        } else {
            Q q5 = Q.a;
            int i7 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVar);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            int i8 = (((((i6 << 3) & 112) | (((i6 >> 3) & 14) | 384)) << 6) & 896) | 6;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, C1804k.f13645f, q5);
            C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
            C1802i c1802i = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i7))) {
                AbstractC0813y0.r(i7, c0258p, i7, c1802i);
            }
            C0234d.R(c0258p, C1804k.f13643d, qVarD);
            aVar.i(c0258p, Integer.valueOf((i8 >> 6) & 14));
            c0258p.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new S(qVar, aVar, i5, 0);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:44:0x0074  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0087  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x00ac  */
    /* JADX WARN: Removed duplicated region for block: B:64:0x00af  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x00b2  */
    /* JADX WARN: Removed duplicated region for block: B:68:0x00ce  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x00f4  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x00fe  */
    /* JADX WARN: Removed duplicated region for block: B:83:0x0173  */
    /* JADX WARN: Removed duplicated region for block: B:85:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final void K(final java.lang.String r34, final int r35, final java.lang.String r36, final boolean r37, boolean r38, final T3.a r39, final T3.c r40, I.C0258p r41, final int r42, final int r43) {
        /*
            Method dump skipped, instruction units count: 396
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: l0.c.K(java.lang.String, int, java.lang.String, boolean, boolean, T3.a, T3.c, I.p, int, int):void");
    }

    public static final void L(String str, String str2, long j5, C0258p c0258p, int i5) {
        int i6;
        c0258p.S(1722692103);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.f(str) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.f(str2) ? 32 : 16;
        }
        if ((i5 & 384) == 0) {
            i6 |= c0258p.e(j5) ? 256 : 128;
        }
        int i7 = i6;
        if ((i7 & 147) == 146 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            h hVar = U.b.f6117v;
            C1589e c1589e = AbstractC1594j.f12608e;
            q qVarC = androidx.compose.foundation.layout.c.c(n.a, 1.0f);
            b0 b0VarB = a0.b(c1589e, hVar, c0258p, 54);
            int i8 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarC);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, C1804k.f13645f, b0VarB);
            C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
            C1802i c1802i = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i8))) {
                AbstractC0813y0.r(i8, c0258p, i8, c1802i);
            }
            C0234d.R(c0258p, C1804k.f13643d, qVarD);
            H1.b(str, null, bVar.f7051j, V2.a.M(11), null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, (i7 & 14) | 3072, 0, 131058);
            H1.b(str2, null, j5, V2.a.M(12), null, z.f2957q, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, ((i7 >> 3) & 14) | 199680 | (i7 & 896), 0, 131026);
            c0258p.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new C1161v(j5, i5, str, str2);
        }
    }

    public static final void M(C1138L c1138l, C0258p c0258p, int i5) {
        int i6;
        String strConcat;
        c0258p.S(-1509268505);
        if ((i5 & 6) == 0) {
            i6 = ((i5 & 8) == 0 ? c0258p.f(c1138l) : c0258p.h(c1138l) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i6 & 3) == 2 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            C1591g c1591gG = AbstractC1594j.g(4);
            n nVar = n.a;
            C1603t c1603tA = r.a(c1591gG, U.b.f6119x, c0258p, 6);
            int i7 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, nVar);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, C1804k.f13645f, c1603tA);
            C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
            C1802i c1802i = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i7))) {
                AbstractC0813y0.r(i7, c0258p, i7, c1802i);
            }
            C0234d.R(c0258p, C1804k.f13643d, qVarD);
            String str = c1138l.f10435b;
            String str2 = "—";
            L("Tài khoản", str == null ? "—" : str, bVar.f7049h, c0258p, 6);
            Long l4 = c1138l.f10436c;
            if (l4 != null) {
                String str3 = c1138l.f10437d;
                if (str3 == null || (strConcat = " · ".concat(str3)) == null) {
                    strConcat = "";
                }
                str2 = "#" + l4 + strConcat;
            }
            L("Job", str2, bVar.f7049h, c0258p, 6);
            L("Giá", AbstractC2128a.f(g0(c1138l.f10438e), "đ"), bVar.f7059r, c0258p, 6);
            StringBuilder sb = new StringBuilder();
            sb.append(c1138l.f10439f);
            sb.append(" / ");
            int i8 = c1138l.f10440g;
            sb.append(i8);
            L("Xong / Lỗi", sb.toString(), i8 > 0 ? bVar.f7056o : bVar.f7053l, c0258p, 6);
            L("Tổng", AbstractC2128a.f(g0(c1138l.f10441h), "đ"), bVar.f7053l, c0258p, 6);
            c0258p.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new F2.f(i5, 3, c1138l);
        }
    }

    public static final void N(int i5, long j5, C0258p c0258p, String str) {
        int i6;
        c0258p.S(1989270248);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.f(str) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.e(j5) ? 32 : 16;
        }
        if ((i6 & 19) == 18 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            h hVar = U.b.f6117v;
            float f5 = 6;
            C1591g c1591gG = AbstractC1594j.g(f5);
            n nVar = n.a;
            q qVarC = androidx.compose.foundation.layout.c.c(nVar, 1.0f);
            b0 b0VarB = a0.b(c1591gG, hVar, c0258p, 54);
            int i7 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarC);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, C1804k.f13645f, b0VarB);
            C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
            C1802i c1802i = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i7))) {
                AbstractC0813y0.r(i7, c0258p, i7, c1802i);
            }
            C0234d.R(c0258p, C1804k.f13643d, qVarD);
            AbstractC1598n.a(androidx.compose.foundation.a.b(androidx.compose.foundation.layout.c.i(nVar, f5), j5, AbstractC1921e.a), c0258p, 0);
            H1.b(str, c0.a(1.0f), bVar.f7050i, V2.a.M(11), null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, (i6 & 14) | 3072, 0, 131056);
            c0258p.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new C1156q(j5, str, i5);
        }
    }

    public static final void O(boolean z3, T3.c cVar, C0258p c0258p, int i5) {
        int i6;
        int i7;
        c0258p.S(-1790155308);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.g(z3) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.h(cVar) ? 32 : 16;
        }
        int i8 = i6;
        if ((i8 & 19) == 18 && c0258p.x()) {
            c0258p.L();
            i7 = i5;
        } else {
            c0258p.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            h hVar = U.b.f6117v;
            C1589e c1589e = AbstractC1594j.f12608e;
            q qVarC = androidx.compose.foundation.layout.c.c(n.a, 1.0f);
            b0 b0VarB = a0.b(c1589e, hVar, c0258p, 54);
            int i9 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarC);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, C1804k.f13645f, b0VarB);
            C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
            C1802i c1802i = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i9))) {
                AbstractC0813y0.r(i9, c0258p, i9, c1802i);
            }
            C0234d.R(c0258p, C1804k.f13643d, qVarD);
            H1.b("Hiện status khi thu nhỏ", c0.a(1.0f), bVar.f7050i, V2.a.M(11), null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, 3078, 0, 131056);
            i7 = i5;
            androidx.compose.material3.a.a(z3, cVar, null, null, false, E0.g(bVar.a, bVar.f7053l, bVar.f7051j, bVar.f7044c, c0258p), null, c0258p, i8 & 126);
            c0258p.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new Y1.g(z3, cVar, i7, 1);
        }
    }

    public static final void P(int i5, T3.a aVar, q qVar, C0258p c0258p, int i6) {
        int i7;
        c0258p.S(-1078355279);
        if ((i6 & 6) == 0) {
            i7 = (c0258p.d(i5) ? 4 : 2) | i6;
        } else {
            i7 = i6;
        }
        if ((i6 & 48) == 0) {
            i7 |= c0258p.h(aVar) ? 32 : 16;
        }
        if ((i6 & 384) == 0) {
            i7 |= c0258p.f(qVar) ? 256 : 128;
        }
        if ((i7 & 147) == 146 && c0258p.x()) {
            c0258p.L();
        } else {
            Y1.b bVarC = g.C(c0258p);
            q qVarG = androidx.compose.foundation.layout.b.g(androidx.compose.foundation.layout.c.c(qVar, 1.0f), g.I(c0258p).f7110f);
            InterfaceC1642G interfaceC1642GE = AbstractC1598n.e(U.b.f6107l, false);
            int i8 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarG);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C1802i c1802i = C1804k.f13645f;
            C0234d.R(c0258p, c1802i, interfaceC1642GE);
            C1802i c1802i2 = C1804k.f13644e;
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M);
            C1802i c1802i3 = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i8))) {
                AbstractC0813y0.r(i8, c0258p, i8, c1802i3);
            }
            C1802i c1802i4 = C1804k.f13643d;
            C0234d.R(c0258p, c1802i4, qVarD);
            n nVar = n.a;
            float f5 = 16;
            q qVarH = androidx.compose.foundation.layout.b.h(androidx.compose.foundation.a.e(7, aVar, androidx.compose.foundation.a.b(androidx.compose.foundation.layout.c.c(nVar, 1.0f), bVarC.f7053l, AbstractC1921e.b(14)), null, false), 20, f5);
            b0 b0VarB = a0.b(AbstractC1594j.a, U.b.f6117v, c0258p, 48);
            int i9 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M2 = c0258p.m();
            q qVarD2 = U.a.d(c0258p, qVarH);
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, c1802i, b0VarB);
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M2);
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i9))) {
                AbstractC0813y0.r(i9, c0258p, i9, c1802i3);
            }
            C0234d.R(c0258p, c1802i4, qVarD2);
            e(X1.h.f6953n, null, f5, bVarC.f7055n, 0.0f, c0258p, 390, 18);
            H1.b("BẮT ĐẦU CHẠY", null, bVarC.f7055n, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, AbstractC0813y0.i(nVar, 8, c0258p, c0258p).f7114c, c0258p, 6, 0, 65530);
            AbstractC1587c.a(c0258p, c0.a(1.0f));
            H1.b(i5 + " accounts", null, C0603v.b(0.75f, bVarC.f7055n), 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, g.L(c0258p).f7117f, c0258p, 0, 0, 65530);
            c0258p.p(true);
            c0258p.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new C0208q(i5, aVar, qVar, i6, 0);
        }
    }

    public static final void Q(String str, String str2, int i5, String str3, T3.a aVar, C0258p c0258p, int i6) {
        int i7;
        c0258p.S(-1064602859);
        if ((i6 & 6) == 0) {
            i7 = (c0258p.f(str) ? 4 : 2) | i6;
        } else {
            i7 = i6;
        }
        if ((i6 & 48) == 0) {
            i7 |= c0258p.f(str2) ? 32 : 16;
        }
        if ((i6 & 384) == 0) {
            i7 |= c0258p.d(i5) ? 256 : 128;
        }
        if ((i6 & 3072) == 0) {
            i7 |= c0258p.f(str3) ? 2048 : 1024;
        }
        if ((i6 & 24576) == 0) {
            i7 |= c0258p.h(aVar) ? 16384 : 8192;
        }
        int i8 = i7;
        if ((i8 & 9363) == 9362 && c0258p.x()) {
            c0258p.L();
        } else {
            Y1.b bVarC = g.C(c0258p);
            n nVar = n.a;
            q qVarH = androidx.compose.foundation.layout.b.h(androidx.compose.foundation.layout.c.c(nVar, 1.0f), g.I(c0258p).f7109e, 13);
            b0 b0VarB = a0.b(AbstractC1594j.a, U.b.f6117v, c0258p, 48);
            int i9 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarH);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C1802i c1802i = C1804k.f13645f;
            C0234d.R(c0258p, c1802i, b0VarB);
            C1802i c1802i2 = C1804k.f13644e;
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M);
            C1802i c1802i3 = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i9))) {
                AbstractC0813y0.r(i9, c0258p, i9, c1802i3);
            }
            C1802i c1802i4 = C1804k.f13643d;
            C0234d.R(c0258p, c1802i4, qVarD);
            q qVarA = c0.a(1.0f);
            C1603t c1603tA = r.a(AbstractC1594j.f12606c, U.b.f6119x, c0258p, 0);
            int i10 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M2 = c0258p.m();
            q qVarD2 = U.a.d(c0258p, qVarA);
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, c1802i, c1603tA);
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M2);
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i10))) {
                AbstractC0813y0.r(i10, c0258p, i10, c1802i3);
            }
            C0234d.R(c0258p, c1802i4, qVarD2);
            H1.b(str, null, bVarC.f7049h, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, g.L(c0258p).f7117f, c0258p, i8 & 14, 0, 65530);
            int i11 = i8 >> 3;
            H1.b(str2, null, bVarC.f7052k, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, g.L(c0258p).f7118g, c0258p, i11 & 14, 0, 65530);
            c0258p.p(true);
            AbstractC1587c.a(c0258p, androidx.compose.foundation.layout.c.m(nVar, g.I(c0258p).f7107c));
            y(i5, (i11 & 7168) | ((i8 >> 6) & 14) | 48, c0258p, aVar, i5 + str3);
            c0258p.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new C0199i(str, str2, i5, str3, aVar, i6);
        }
    }

    public static final void R(int i5, C0258p c0258p, T3.a aVar, String str, String str2, boolean z3) {
        int i6;
        c0258p.S(-1274522891);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.f(str) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.f(str2) ? 32 : 16;
        }
        if ((i5 & 384) == 0) {
            i6 |= c0258p.g(z3) ? 256 : 128;
        }
        if ((i5 & 3072) == 0) {
            i6 |= c0258p.h(aVar) ? 2048 : 1024;
        }
        if ((i6 & 1171) == 1170 && c0258p.x()) {
            c0258p.L();
        } else {
            Y1.b bVarC = g.C(c0258p);
            q qVarH = androidx.compose.foundation.layout.b.h(androidx.compose.foundation.layout.c.c(n.a, 1.0f), g.I(c0258p).f7109e, 13);
            b0 b0VarB = a0.b(AbstractC1594j.a, U.b.f6117v, c0258p, 48);
            int i7 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarH);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C1802i c1802i = C1804k.f13645f;
            C0234d.R(c0258p, c1802i, b0VarB);
            C1802i c1802i2 = C1804k.f13644e;
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M);
            C1802i c1802i3 = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i7))) {
                AbstractC0813y0.r(i7, c0258p, i7, c1802i3);
            }
            C1802i c1802i4 = C1804k.f13643d;
            C0234d.R(c0258p, c1802i4, qVarD);
            q qVarA = c0.a(1.0f);
            C1603t c1603tA = r.a(AbstractC1594j.f12606c, U.b.f6119x, c0258p, 0);
            int i8 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M2 = c0258p.m();
            q qVarD2 = U.a.d(c0258p, qVarA);
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, c1802i, c1603tA);
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M2);
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i8))) {
                AbstractC0813y0.r(i8, c0258p, i8, c1802i3);
            }
            C0234d.R(c0258p, c1802i4, qVarD2);
            H1.b(str, null, bVarC.f7049h, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, g.L(c0258p).f7117f, c0258p, i6 & 14, 0, 65530);
            H1.b(str2, null, bVarC.f7052k, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, g.L(c0258p).f7118g, c0258p, (i6 >> 3) & 14, 0, 65530);
            c0258p.p(true);
            c0258p.Q(-1357002703);
            boolean z5 = (i6 & 7168) == 2048;
            Object objG = c0258p.G();
            if (z5 || objG == C0250l.a) {
                objG = new C0043t(aVar, 7);
                c0258p.a0(objG);
            }
            c0258p.p(false);
            C0933a.d(z3, (T3.c) objG, null, c0258p, (i6 >> 6) & 14);
            c0258p.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new C0038n(str, str2, z3, aVar, i5);
        }
    }

    public static final void S(String str, T3.a aVar, C0258p c0258p, int i5) {
        int i6;
        c0258p.S(-1532171194);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.f(str) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.h(aVar) ? 32 : 16;
        }
        if ((i6 & 19) == 18 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            q qVarH = androidx.compose.foundation.layout.b.h(androidx.compose.foundation.a.e(7, aVar, androidx.compose.foundation.a.b(n.a, bVar.f7045d, AbstractC1921e.b(6)), null, false), 8, 4);
            InterfaceC1642G interfaceC1642GE = AbstractC1598n.e(U.b.f6107l, false);
            int i7 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarH);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, C1804k.f13645f, interfaceC1642GE);
            C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
            C1802i c1802i = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i7))) {
                AbstractC0813y0.r(i7, c0258p, i7, c1802i);
            }
            C0234d.R(c0258p, C1804k.f13643d, qVarD);
            c0258p.Q(258792282);
            Y1.f fVar = (Y1.f) c0258p.k(Y1.l.f7129c);
            c0258p.p(false);
            H1.b(str, null, bVar.f7051j, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, L.a(fVar.f7118g, 0L, 0L, z.f2959s, null, 0L, null, 0L, null, null, 16777211), c0258p, i6 & 14, 0, 65530);
            c0258p.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new H2.r(str, aVar, i5, 0);
        }
    }

    public static final void T(String str, T3.a aVar, C0258p c0258p, int i5) {
        int i6;
        c0258p.S(525935843);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.f(str) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.h(aVar) ? 32 : 16;
        }
        if ((i6 & 19) == 18 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            q qVarE = n.a;
            q qVarB = androidx.compose.foundation.a.b(qVarE, bVar.f7054m, AbstractC1921e.b(6));
            if (aVar != null) {
                qVarE = androidx.compose.foundation.a.e(7, aVar, qVarE, null, false);
            }
            q qVarH = androidx.compose.foundation.layout.b.h(qVarB.i(qVarE), 9, 4);
            InterfaceC1642G interfaceC1642GE = AbstractC1598n.e(U.b.f6107l, false);
            int i7 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarH);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, C1804k.f13645f, interfaceC1642GE);
            C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
            C1802i c1802i = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i7))) {
                AbstractC0813y0.r(i7, c0258p, i7, c1802i);
            }
            C0234d.R(c0258p, C1804k.f13643d, qVarD);
            c0258p.Q(258792282);
            Y1.f fVar = (Y1.f) c0258p.k(Y1.l.f7129c);
            c0258p.p(false);
            H1.b(str, null, bVar.f7053l, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, L.a(fVar.f7121j, 0L, 0L, z.f2959s, null, 0L, null, 0L, null, null, 16777211), c0258p, i6 & 14, 0, 65530);
            c0258p.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new H2.r(str, aVar, i5, 1);
        }
    }

    public static final void U(int i5, C0258p c0258p) {
        c0258p.S(-1849435615);
        if (i5 == 0 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            H1.b("v26.06.01.1 (26060101)", androidx.compose.foundation.layout.c.c(n.a, 1.0f), bVar.f7051j, V2.a.M(9), null, null, null, 0L, null, new N0.i(3), 0L, 0, false, 0, 0, null, null, c0258p, 3120, 0, 130544);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new A2.j(i5, 10);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:100:0x03a6  */
    /* JADX WARN: Removed duplicated region for block: B:101:0x03a8  */
    /* JADX WARN: Removed duplicated region for block: B:108:0x03b7  */
    /* JADX WARN: Removed duplicated region for block: B:111:0x03ee  */
    /* JADX WARN: Removed duplicated region for block: B:112:0x03f2  */
    /* JADX WARN: Removed duplicated region for block: B:117:0x040d  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x0176  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x017a  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x0195  */
    /* JADX WARN: Removed duplicated region for block: B:80:0x01b8  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x01bc  */
    /* JADX WARN: Removed duplicated region for block: B:86:0x01d7  */
    /* JADX WARN: Removed duplicated region for block: B:89:0x02cd  */
    /* JADX WARN: Removed duplicated region for block: B:90:0x02d1  */
    /* JADX WARN: Removed duplicated region for block: B:95:0x02ee  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final void V(final X1.o r45, final int r46, final int r47, final int r48, final java.lang.String r49, final T3.a r50, final T3.a r51, I.C0258p r52, final int r53) {
        /*
            Method dump skipped, instruction units count: 1127
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: l0.c.V(X1.o, int, int, int, java.lang.String, T3.a, T3.a, I.p, int):void");
    }

    public static final boolean W(X.d dVar, long j5) {
        if (!dVar.f6127l.f6139x) {
            return false;
        }
        C1813u c1813u = (C1813u) AbstractC1800g.v(dVar).f13436G.f3711c;
        if (!c1813u.f13666U.f6139x) {
            return false;
        }
        long j6 = c1813u.f12946n;
        long jO = c1813u.O(0L);
        float fD = C0492c.d(jO);
        float fE = C0492c.e(jO);
        float f5 = ((int) (j6 >> 32)) + fD;
        float f6 = ((int) (j6 & 4294967295L)) + fE;
        float fD2 = C0492c.d(j5);
        if (fD > fD2 || fD2 > f5) {
            return false;
        }
        float fE2 = C0492c.e(j5);
        return fE <= fE2 && fE2 <= f6;
    }

    public static final Typeface X(G g3, Context context) {
        int i5 = g3.a;
        int i6 = W0.k.a;
        Typeface typefaceA = context.isRestricted() ? null : W0.k.a(context, i5, new TypedValue(), null);
        j.c(typefaceA);
        return typefaceA;
    }

    public static final q Y(q qVar, float f5, long j5, T t5) {
        return qVar.i(new BorderModifierNodeElement(f5, new V(j5), t5));
    }

    public static final Bundle Z(G3.l... lVarArr) {
        Bundle bundle = new Bundle(lVarArr.length);
        for (G3.l lVar : lVarArr) {
            String str = (String) lVar.f2637l;
            Object obj = lVar.f2638m;
            if (obj == null) {
                bundle.putString(str, null);
            } else if (obj instanceof Boolean) {
                bundle.putBoolean(str, ((Boolean) obj).booleanValue());
            } else if (obj instanceof Byte) {
                bundle.putByte(str, ((Number) obj).byteValue());
            } else if (obj instanceof Character) {
                bundle.putChar(str, ((Character) obj).charValue());
            } else if (obj instanceof Double) {
                bundle.putDouble(str, ((Number) obj).doubleValue());
            } else if (obj instanceof Float) {
                bundle.putFloat(str, ((Number) obj).floatValue());
            } else if (obj instanceof Integer) {
                bundle.putInt(str, ((Number) obj).intValue());
            } else if (obj instanceof Long) {
                bundle.putLong(str, ((Number) obj).longValue());
            } else if (obj instanceof Short) {
                bundle.putShort(str, ((Number) obj).shortValue());
            } else if (obj instanceof Bundle) {
                bundle.putBundle(str, (Bundle) obj);
            } else if (obj instanceof CharSequence) {
                bundle.putCharSequence(str, (CharSequence) obj);
            } else if (obj instanceof Parcelable) {
                bundle.putParcelable(str, (Parcelable) obj);
            } else if (obj instanceof boolean[]) {
                bundle.putBooleanArray(str, (boolean[]) obj);
            } else if (obj instanceof byte[]) {
                bundle.putByteArray(str, (byte[]) obj);
            } else if (obj instanceof char[]) {
                bundle.putCharArray(str, (char[]) obj);
            } else if (obj instanceof double[]) {
                bundle.putDoubleArray(str, (double[]) obj);
            } else if (obj instanceof float[]) {
                bundle.putFloatArray(str, (float[]) obj);
            } else if (obj instanceof int[]) {
                bundle.putIntArray(str, (int[]) obj);
            } else if (obj instanceof long[]) {
                bundle.putLongArray(str, (long[]) obj);
            } else if (obj instanceof short[]) {
                bundle.putShortArray(str, (short[]) obj);
            } else if (obj instanceof Object[]) {
                Class<?> componentType = obj.getClass().getComponentType();
                j.c(componentType);
                if (Parcelable.class.isAssignableFrom(componentType)) {
                    bundle.putParcelableArray(str, (Parcelable[]) obj);
                } else if (String.class.isAssignableFrom(componentType)) {
                    bundle.putStringArray(str, (String[]) obj);
                } else if (CharSequence.class.isAssignableFrom(componentType)) {
                    bundle.putCharSequenceArray(str, (CharSequence[]) obj);
                } else {
                    if (!Serializable.class.isAssignableFrom(componentType)) {
                        throw new IllegalArgumentException("Illegal value array type " + componentType.getCanonicalName() + " for key \"" + str + '\"');
                    }
                    bundle.putSerializable(str, (Serializable) obj);
                }
            } else if (obj instanceof Serializable) {
                bundle.putSerializable(str, (Serializable) obj);
            } else if (obj instanceof IBinder) {
                bundle.putBinder(str, (IBinder) obj);
            } else if (obj instanceof Size) {
                Z0.a.a(bundle, str, (Size) obj);
            } else {
                if (!(obj instanceof SizeF)) {
                    throw new IllegalArgumentException("Illegal value type " + obj.getClass().getCanonicalName() + " for key \"" + str + '\"');
                }
                Z0.a.b(bundle, str, (SizeF) obj);
            }
        }
        return bundle;
    }

    public static final void a(Q.a aVar, C0258p c0258p, int i5) {
        int i6;
        c0258p.S(-20186103);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.h(aVar) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i6 & 3) == 2 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.R(1890788296);
            h0 h0VarA = AbstractC1906b.a(c0258p);
            if (h0VarA == null) {
                throw new IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner");
            }
            androidx.lifecycle.c0 c0VarD = AbstractC1383i.D(h0VarA, c0258p);
            c0258p.R(1729797275);
            androidx.lifecycle.a0 a0VarD0 = AbstractC1393s.d0(C0360d.class, h0VarA, c0VarD, h0VarA instanceof InterfaceC0565j ? ((InterfaceC0565j) h0VarA).a() : C1819a.f13679b, c0258p);
            c0258p.p(false);
            c0258p.p(false);
            C0360d c0360d = (C0360d) a0VarD0;
            InterfaceC0233c0 interfaceC0233c0J = AbstractC1369w.j(c0360d.f5185d, c0258p);
            InterfaceC0233c0 interfaceC0233c0J2 = AbstractC1369w.j(c0360d.f5187f, c0258p);
            Object obj = (InterfaceC0576v) c0258p.k(AbstractC1745e.a);
            c0258p.Q(867826340);
            boolean zH = c0258p.h(c0360d) | c0258p.h(obj);
            Object objG = c0258p.G();
            Object obj2 = C0250l.a;
            if (zH || objG == obj2) {
                objG = new A2.h(obj, 8, c0360d);
                c0258p.a0(objG);
            }
            c0258p.p(false);
            C0234d.c(obj, (T3.c) objG, c0258p);
            aVar.i(c0258p, Integer.valueOf(i6 & 14));
            if (!((Boolean) interfaceC0233c0J.getValue()).booleanValue() && !((Boolean) interfaceC0233c0J2.getValue()).booleanValue()) {
                c0258p.Q(867838606);
                boolean zH2 = c0258p.h(c0360d);
                Object objG2 = c0258p.G();
                if (zH2 || objG2 == obj2) {
                    objG2 = new K2.g(0, c0360d, C0360d.class, "dismiss", "dismiss()V", 0, 4);
                    c0258p.a0(objG2);
                }
                c0258p.p(false);
                E0.a((T3.a) ((U3.h) objG2), f.b(-1885255908, new C0356b(c0360d, 0), c0258p), null, f.b(1086532442, new C0356b(c0360d, 1), c0258p), null, m0.f5255c, m0.f5256d, null, 0L, 0L, 0L, 0L, 0.0f, null, c0258p, 1772592, 0, 16276);
            }
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new I2.L(aVar, i5, 1);
        }
    }

    public static final void a0(int i5, int i6) {
        if (i5 < 0 || i5 >= i6) {
            throw new IndexOutOfBoundsException(AbstractC0813y0.k(i5, i6, "index: ", ", size: "));
        }
    }

    public static final void b(final String str, final boolean z3, final boolean z5, final T3.a aVar, final T3.a aVar2, C0258p c0258p, final int i5) {
        int i6;
        Y1.b bVar;
        int i7;
        c0258p.S(713611543);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.f(str) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.g(z3) ? 32 : 16;
        }
        if ((i5 & 384) == 0) {
            i6 |= c0258p.g(z5) ? 256 : 128;
        }
        if ((i5 & 3072) == 0) {
            i6 |= c0258p.h(aVar) ? 2048 : 1024;
        }
        if ((i5 & 24576) == 0) {
            i6 |= c0258p.h(aVar2) ? 16384 : 8192;
        }
        int i8 = i6;
        if ((i8 & 9363) == 9362 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.Q(-1101863115);
            Y1.b bVar2 = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            long j5 = !z3 ? bVar2.f7061t : z5 ? bVar2.f7053l : bVar2.f7056o;
            n nVar = n.a;
            float f5 = 16;
            q qVarH = androidx.compose.foundation.layout.b.h(Y(androidx.compose.foundation.a.a(androidx.compose.foundation.layout.c.n(200, 280), C1913d.g(H3.n.S0(new C0603v(bVar2.f7043b), new C0603v(bVar2.a))), AbstractC1921e.b(f5)), 1, C0603v.b(0.55f, j5), AbstractC1921e.b(f5)), 12, 10);
            InterfaceC1642G interfaceC1642GE = AbstractC1598n.e(U.b.f6107l, false);
            int i9 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarH);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C1802i c1802i = C1804k.f13645f;
            C0234d.R(c0258p, c1802i, interfaceC1642GE);
            C1802i c1802i2 = C1804k.f13644e;
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M);
            C1802i c1802i3 = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i9))) {
                AbstractC0813y0.r(i9, c0258p, i9, c1802i3);
            }
            C1802i c1802i4 = C1804k.f13643d;
            C0234d.R(c0258p, c1802i4, qVarD);
            float f6 = 8;
            C1603t c1603tA = r.a(AbstractC1594j.g(f6), U.b.f6119x, c0258p, 6);
            int i10 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M2 = c0258p.m();
            q qVarD2 = U.a.d(c0258p, nVar);
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, c1802i, c1603tA);
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M2);
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i10))) {
                AbstractC0813y0.r(i10, c0258p, i10, c1802i3);
            }
            C0234d.R(c0258p, c1802i4, qVarD2);
            h hVar = U.b.f6117v;
            b0 b0VarB = a0.b(AbstractC1594j.g(6), hVar, c0258p, 54);
            int i11 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M3 = c0258p.m();
            q qVarD3 = U.a.d(c0258p, nVar);
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, c1802i, b0VarB);
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M3);
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i11))) {
                AbstractC0813y0.r(i11, c0258p, i11, c1802i3);
            }
            C0234d.R(c0258p, c1802i4, qVarD3);
            C(j5, !z3, c0258p, 0);
            long j6 = j5;
            H1.b("Chuyển tài khoản", c0.a(1.0f), bVar2.f7049h, V2.a.M(13), null, z.f2958r, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, 199686, 0, 131024);
            w("—", bVar2.f7044c, bVar2.f7051j, aVar2, c0258p, ((i8 >> 3) & 7168) | 6);
            c0258p.Q(605318149);
            if (z3) {
                w("×", bVar2.f7057p, bVar2.f7056o, aVar, c0258p, (i8 & 7168) | 6);
            }
            c0258p.p(false);
            c0258p.p(true);
            b0 b0VarB2 = a0.b(AbstractC1594j.g(f6), hVar, c0258p, 54);
            int i12 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M4 = c0258p.m();
            q qVarD4 = U.a.d(c0258p, nVar);
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, c1802i, b0VarB2);
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M4);
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i12))) {
                AbstractC0813y0.r(i12, c0258p, i12, c1802i3);
            }
            C0234d.R(c0258p, c1802i4, qVarD4);
            if (z3) {
                c0258p.Q(1585699338);
                bVar = bVar2;
                i7 = i8;
                H1.b(z5 ? "✓" : "!", null, j6, V2.a.M(16), null, z.f2959s, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, 199680, 0, 131026);
                c0258p.p(false);
            } else {
                c0258p.Q(1585439279);
                AbstractC0139x0.a(androidx.compose.foundation.layout.c.i(nVar, 14), j6, 2, 0L, 0, c0258p, 390);
                c0258p.p(false);
                bVar = bVar2;
                i7 = i8;
            }
            H1.b(str, c0.a(1.0f), bVar.f7050i, V2.a.M(12), null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, (i7 & 14) | 3072, 0, 131056);
            AbstractC2128a.o(c0258p, true, true, true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new T3.e() { // from class: i2.z
                @Override // T3.e
                public final Object i(Object obj, Object obj2) {
                    ((Integer) obj2).intValue();
                    l0.c.b(str, z3, z5, aVar, aVar2, (C0258p) obj, C0234d.U(i5 | 1));
                    return G3.C.a;
                }
            };
        }
    }

    public static final void b0(int i5, int i6) {
        if (i5 < 0 || i5 > i6) {
            throw new IndexOutOfBoundsException(AbstractC0813y0.k(i5, i6, "index: ", ", size: "));
        }
    }

    public static final void c(final boolean z3, final boolean z5, final boolean z6, final EnumC1140a enumC1140a, final T3.a aVar, final T3.a aVar2, final T3.a aVar3, final T3.a aVar4, C0258p c0258p, final int i5) {
        int i6;
        boolean z7;
        c0258p.S(1249511087);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.g(z3) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.g(z5) ? 32 : 16;
        }
        if ((i5 & 384) == 0) {
            i6 |= c0258p.g(z6) ? 256 : 128;
        }
        if ((i5 & 3072) == 0) {
            i6 |= c0258p.f(enumC1140a) ? 2048 : 1024;
        }
        if ((i5 & 24576) == 0) {
            i6 |= c0258p.h(aVar) ? 16384 : 8192;
        }
        if ((196608 & i5) == 0) {
            i6 |= c0258p.h(aVar2) ? 131072 : 65536;
        }
        if ((1572864 & i5) == 0) {
            i6 |= c0258p.h(aVar3) ? 1048576 : 524288;
        }
        if ((12582912 & i5) == 0) {
            i6 |= c0258p.h(aVar4) ? 8388608 : 4194304;
        }
        if ((4793491 & i6) == 4793490 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            float f5 = 6;
            C1591g c1591gG = AbstractC1594j.g(f5);
            n nVar = n.a;
            q qVarC = androidx.compose.foundation.layout.c.c(nVar, 1.0f);
            C1603t c1603tA = r.a(c1591gG, U.b.f6119x, c0258p, 6);
            int i7 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarC);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C1802i c1802i = C1804k.f13645f;
            C0234d.R(c0258p, c1802i, c1603tA);
            C1802i c1802i2 = C1804k.f13644e;
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M);
            C1802i c1802i3 = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i7))) {
                AbstractC0813y0.r(i7, c0258p, i7, c1802i3);
            }
            C1802i c1802i4 = C1804k.f13643d;
            C0234d.R(c0258p, c1802i4, qVarD);
            if (z3) {
                c0258p.Q(1634125099);
                C1591g c1591gG2 = AbstractC1594j.g(f5);
                q qVarC2 = androidx.compose.foundation.layout.c.c(nVar, 1.0f);
                b0 b0VarB = a0.b(c1591gG2, U.b.f6116u, c0258p, 6);
                int i8 = c0258p.f3669P;
                InterfaceC0255n0 interfaceC0255n0M2 = c0258p.m();
                q qVarD2 = U.a.d(c0258p, qVarC2);
                c0258p.U();
                if (c0258p.f3668O) {
                    c0258p.l(c1803j);
                } else {
                    c0258p.d0();
                }
                C0234d.R(c0258p, c1802i, b0VarB);
                C0234d.R(c0258p, c1802i2, interfaceC0255n0M2);
                if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i8))) {
                    AbstractC0813y0.r(i8, c0258p, i8, c1802i3);
                }
                C0234d.R(c0258p, c1802i4, qVarD2);
                z7 = false;
                d("Bỏ qua", bVar.f7057p, bVar.f7056o, aVar2, z5 ? c0.a(1.0f) : androidx.compose.foundation.layout.c.c(nVar, 1.0f), c0258p, ((i6 >> 6) & 7168) | 6);
                c0258p.Q(-897367600);
                if (z5) {
                    d("Đã xong", bVar.f7053l, bVar.f7055n, aVar, c0.a(2.0f), c0258p, ((i6 >> 3) & 7168) | 6);
                }
                AbstractC2128a.o(c0258p, false, true, false);
            } else {
                z7 = false;
                if (z6) {
                    c0258p.Q(1635469228);
                    c0258p.p(false);
                } else {
                    c0258p.Q(1635113658);
                    d("Lấy job kế tiếp", bVar.f7061t, bVar.a, aVar3, androidx.compose.foundation.layout.c.c(nVar, 1.0f), c0258p, ((i6 >> 9) & 7168) | 24582);
                    c0258p.p(false);
                }
            }
            c0258p.Q(-1886898119);
            if (enumC1140a != EnumC1140a.f10460l) {
                g(enumC1140a, aVar4, c0258p, ((i6 >> 9) & 14) | ((i6 >> 18) & 112));
            }
            c0258p.p(z7);
            c0258p.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new T3.e() { // from class: i2.x
                @Override // T3.e
                public final Object i(Object obj, Object obj2) {
                    ((Integer) obj2).intValue();
                    l0.c.c(z3, z5, z6, enumC1140a, aVar, aVar2, aVar3, aVar4, (C0258p) obj, C0234d.U(i5 | 1));
                    return G3.C.a;
                }
            };
        }
    }

    public static final void c0(int i5, int i6, int i7) {
        if (i5 >= 0 && i6 <= i7) {
            if (i5 > i6) {
                throw new IllegalArgumentException(AbstractC0813y0.k(i5, i6, "fromIndex: ", " > toIndex: "));
            }
            return;
        }
        throw new IndexOutOfBoundsException("fromIndex: " + i5 + ", toIndex: " + i6 + ", size: " + i7);
    }

    public static final void d(String str, long j5, long j6, T3.a aVar, q qVar, C0258p c0258p, int i5) {
        int i6;
        c0258p.S(867586967);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.f(str) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.e(j5) ? 32 : 16;
        }
        if ((i5 & 384) == 0) {
            i6 |= c0258p.e(j6) ? 256 : 128;
        }
        if ((i5 & 3072) == 0) {
            i6 |= c0258p.h(aVar) ? 2048 : 1024;
        }
        if ((i5 & 24576) == 0) {
            i6 |= c0258p.f(qVar) ? 16384 : 8192;
        }
        if ((i6 & 9363) == 9362 && c0258p.x()) {
            c0258p.L();
        } else {
            float f5 = 10;
            q qVarI = androidx.compose.foundation.layout.b.i(androidx.compose.foundation.a.e(7, aVar, androidx.compose.foundation.a.b(qVar, j5, AbstractC1921e.b(f5)), null, false), 0.0f, f5, 1);
            InterfaceC1642G interfaceC1642GE = AbstractC1598n.e(U.b.f6111p, false);
            int i7 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarI);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, C1804k.f13645f, interfaceC1642GE);
            C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
            C1802i c1802i = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i7))) {
                AbstractC0813y0.r(i7, c0258p, i7, c1802i);
            }
            C0234d.R(c0258p, C1804k.f13643d, qVarD);
            H1.b(str, null, j6, V2.a.M(13), null, z.f2958r, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, (i6 & 14) | 199680 | (i6 & 896), 0, 131026);
            c0258p.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new C2.i(str, j5, j6, aVar, qVar, i5);
        }
    }

    public static final double d0(double d3, EnumC0834c enumC0834c, EnumC0834c enumC0834c2) {
        j.f(enumC0834c2, "targetUnit");
        long jConvert = enumC0834c2.f8774l.convert(1L, enumC0834c.f8774l);
        return jConvert > 0 ? d3 * jConvert : d3 / r8.convert(1L, r9);
    }

    /* JADX WARN: Removed duplicated region for block: B:100:0x0c12  */
    /* JADX WARN: Removed duplicated region for block: B:104:0x0cda  */
    /* JADX WARN: Removed duplicated region for block: B:108:0x0e10  */
    /* JADX WARN: Removed duplicated region for block: B:112:0x0e9b  */
    /* JADX WARN: Removed duplicated region for block: B:113:0x0ea3  */
    /* JADX WARN: Removed duplicated region for block: B:114:0x0eab  */
    /* JADX WARN: Removed duplicated region for block: B:115:0x0eb3  */
    /* JADX WARN: Removed duplicated region for block: B:116:0x0ebb  */
    /* JADX WARN: Removed duplicated region for block: B:120:0x0f33  */
    /* JADX WARN: Removed duplicated region for block: B:124:0x0fb0  */
    /* JADX WARN: Removed duplicated region for block: B:125:0x0fb8  */
    /* JADX WARN: Removed duplicated region for block: B:126:0x0fc0  */
    /* JADX WARN: Removed duplicated region for block: B:127:0x0fc7  */
    /* JADX WARN: Removed duplicated region for block: B:128:0x0fce  */
    /* JADX WARN: Removed duplicated region for block: B:129:0x0fd5  */
    /* JADX WARN: Removed duplicated region for block: B:130:0x0fdc  */
    /* JADX WARN: Removed duplicated region for block: B:131:0x0fe3  */
    /* JADX WARN: Removed duplicated region for block: B:132:0x0fea  */
    /* JADX WARN: Removed duplicated region for block: B:133:0x0ff1  */
    /* JADX WARN: Removed duplicated region for block: B:134:0x0ff8  */
    /* JADX WARN: Removed duplicated region for block: B:135:0x0fff  */
    /* JADX WARN: Removed duplicated region for block: B:136:0x1006  */
    /* JADX WARN: Removed duplicated region for block: B:137:0x100d  */
    /* JADX WARN: Removed duplicated region for block: B:138:0x1014  */
    /* JADX WARN: Removed duplicated region for block: B:142:0x1034  */
    /* JADX WARN: Removed duplicated region for block: B:144:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x004b  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0071  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0087  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x008b  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x008f  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0094  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x009b  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00ac  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x00b2  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x013b  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x01f4  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x02d0  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x03a5  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x04eb  */
    /* JADX WARN: Removed duplicated region for block: B:80:0x064a  */
    /* JADX WARN: Removed duplicated region for block: B:84:0x076d  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x0882  */
    /* JADX WARN: Removed duplicated region for block: B:92:0x092d  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x0aad  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final void e(final X1.h r51, U.q r52, float r53, final long r54, float r56, I.C0258p r57, final int r58, final int r59) {
        /*
            Method dump skipped, instruction units count: 4240
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: l0.c.e(X1.h, U.q, float, long, float, I.p, int, int):void");
    }

    public static boolean e0(String str, String str2) {
        j.f(str, "current");
        if (str.equals(str2)) {
            return true;
        }
        if (str.length() != 0) {
            int i5 = 0;
            int i6 = 0;
            int i7 = 0;
            while (true) {
                if (i5 < str.length()) {
                    char cCharAt = str.charAt(i5);
                    int i8 = i7 + 1;
                    if (i7 == 0 && cCharAt != '(') {
                        break;
                    }
                    if (cCharAt != '(') {
                        if (cCharAt == ')' && i6 - 1 == 0 && i7 != str.length() - 1) {
                            break;
                        }
                    } else {
                        i6++;
                    }
                    i5++;
                    i7 = i8;
                } else if (i6 == 0) {
                    String strSubstring = str.substring(1, str.length() - 1);
                    j.e(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
                    return j.a(c4.l.P0(strSubstring).toString(), str2);
                }
            }
        }
        return false;
    }

    /* JADX WARN: Removed duplicated region for block: B:100:0x022b  */
    /* JADX WARN: Removed duplicated region for block: B:103:0x023b  */
    /* JADX WARN: Removed duplicated region for block: B:105:0x0249  */
    /* JADX WARN: Removed duplicated region for block: B:108:0x02bf  */
    /* JADX WARN: Removed duplicated region for block: B:111:0x0315  */
    /* JADX WARN: Removed duplicated region for block: B:124:0x0378  */
    /* JADX WARN: Removed duplicated region for block: B:128:0x038c  */
    /* JADX WARN: Removed duplicated region for block: B:130:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0042  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0047  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x005d  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0063  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x007c  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x008d  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x0091  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0094  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x0098  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x009a  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x009f  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x00e5  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x00e9  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x00fc  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x010d  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x0121  */
    /* JADX WARN: Removed duplicated region for block: B:95:0x01f3  */
    /* JADX WARN: Removed duplicated region for block: B:98:0x0225  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final void f(java.lang.String r42, U.q r43, java.lang.String r44, T3.a r45, T3.f r46, I.C0258p r47, int r48, int r49) {
        /*
            Method dump skipped, instruction units count: 923
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: l0.c.f(java.lang.String, U.q, java.lang.String, T3.a, T3.f, I.p, int, int):void");
    }

    public static boolean f0(View view, KeyEvent keyEvent) {
        ArrayList arrayList;
        int size;
        int iIndexOfKey;
        int i5 = AbstractC0680s.a;
        if (Build.VERSION.SDK_INT >= 28) {
            return false;
        }
        ArrayList arrayList2 = c1.r.f8145d;
        c1.r rVar = (c1.r) view.getTag(R.id.tag_unhandled_key_event_manager);
        WeakReference weakReference = null;
        if (rVar == null) {
            rVar = new c1.r();
            rVar.a = null;
            rVar.f8146b = null;
            rVar.f8147c = null;
            view.setTag(R.id.tag_unhandled_key_event_manager, rVar);
        }
        WeakReference weakReference2 = rVar.f8147c;
        if (weakReference2 != null && weakReference2.get() == keyEvent) {
            return false;
        }
        rVar.f8147c = new WeakReference(keyEvent);
        if (rVar.f8146b == null) {
            rVar.f8146b = new SparseArray();
        }
        SparseArray sparseArray = rVar.f8146b;
        if (keyEvent.getAction() == 1 && (iIndexOfKey = sparseArray.indexOfKey(keyEvent.getKeyCode())) >= 0) {
            weakReference = (WeakReference) sparseArray.valueAt(iIndexOfKey);
            sparseArray.removeAt(iIndexOfKey);
        }
        if (weakReference == null) {
            weakReference = (WeakReference) sparseArray.get(keyEvent.getKeyCode());
        }
        if (weakReference == null) {
            return false;
        }
        View view2 = (View) weakReference.get();
        if (view2 == null || !view2.isAttachedToWindow() || (arrayList = (ArrayList) view2.getTag(R.id.tag_unhandled_key_listeners)) == null || (size = arrayList.size() - 1) < 0) {
            return true;
        }
        arrayList.get(size).getClass();
        throw new ClassCastException();
    }

    public static final void g(final EnumC1140a enumC1140a, final T3.a aVar, C0258p c0258p, final int i5) {
        int i6;
        C1139M c1139m;
        T3.a aVar2;
        c0258p.S(-247692668);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.f(enumC1140a) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.h(aVar) ? 32 : 16;
        }
        if ((i6 & 19) == 18 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            int iOrdinal = enumC1140a.ordinal();
            if (iOrdinal == 0) {
                C0264s0 c0264s0R = c0258p.r();
                if (c0264s0R != null) {
                    final int i7 = 0;
                    c0264s0R.f3706d = new T3.e() { // from class: i2.u
                        @Override // T3.e
                        public final Object i(Object obj, Object obj2) {
                            int i8 = i7;
                            C0258p c0258p2 = (C0258p) obj;
                            ((Integer) obj2).intValue();
                            switch (i8) {
                                case ConfigBackupDto.$stable /* 0 */:
                                    l0.c.g(enumC1140a, aVar, c0258p2, C0234d.U(i5 | 1));
                                    break;
                                default:
                                    l0.c.g(enumC1140a, aVar, c0258p2, C0234d.U(i5 | 1));
                                    break;
                            }
                            return G3.C.a;
                        }
                    };
                    return;
                }
                return;
            }
            if (iOrdinal == 1) {
                c1139m = new C1139M("Gửi log lỗi cho admin", new C0603v(bVar.f7060s), new C0603v(bVar.f7059r), Boolean.TRUE);
            } else if (iOrdinal == 2) {
                c1139m = new C1139M("Đang gửi…", new C0603v(bVar.f7044c), new C0603v(bVar.f7051j), Boolean.FALSE);
            } else if (iOrdinal == 3) {
                c1139m = new C1139M("✓ Đã gửi log", new C0603v(bVar.f7053l), new C0603v(bVar.f7055n), Boolean.FALSE);
            } else {
                if (iOrdinal != 4) {
                    throw new G3.f();
                }
                c1139m = new C1139M("Gửi lại log", new C0603v(bVar.f7057p), new C0603v(bVar.f7056o), Boolean.TRUE);
            }
            String str = c1139m.a;
            C0603v c0603v = c1139m.f10457b;
            C0603v c0603v2 = c1139m.f10458c;
            boolean zBooleanValue = c1139m.f10459d.booleanValue();
            c0258p.Q(799683418);
            if (zBooleanValue) {
                aVar2 = aVar;
            } else {
                c0258p.Q(799684254);
                Object objG = c0258p.G();
                if (objG == C0250l.a) {
                    objG = new q0(7);
                    c0258p.a0(objG);
                }
                c0258p.p(false);
                aVar2 = (T3.a) objG;
            }
            c0258p.p(false);
            d(str, c0603v.a, c0603v2.a, aVar2, androidx.compose.foundation.layout.c.c(n.a, 1.0f), c0258p, 24576);
        }
        C0264s0 c0264s0R2 = c0258p.r();
        if (c0264s0R2 != null) {
            final int i8 = 1;
            c0264s0R2.f3706d = new T3.e() { // from class: i2.u
                @Override // T3.e
                public final Object i(Object obj, Object obj2) {
                    int i82 = i8;
                    C0258p c0258p2 = (C0258p) obj;
                    ((Integer) obj2).intValue();
                    switch (i82) {
                        case ConfigBackupDto.$stable /* 0 */:
                            l0.c.g(enumC1140a, aVar, c0258p2, C0234d.U(i5 | 1));
                            break;
                        default:
                            l0.c.g(enumC1140a, aVar, c0258p2, C0234d.U(i5 | 1));
                            break;
                    }
                    return G3.C.a;
                }
            };
        }
    }

    public static final String g0(int i5) {
        if (i5 < 1000) {
            return String.valueOf(i5);
        }
        String strReplace = String.format("%,d", Arrays.copyOf(new Object[]{Integer.valueOf(i5)}, 1)).replace(',', '.');
        j.e(strReplace, "replace(...)");
        return strReplace;
    }

    public static final void h(boolean z3, int i5, T3.a aVar, T3.c cVar, C0258p c0258p, int i6) {
        int i7;
        boolean z5;
        c0258p.S(1724567662);
        if ((i6 & 6) == 0) {
            i7 = (c0258p.g(z3) ? 4 : 2) | i6;
        } else {
            i7 = i6;
        }
        if ((i6 & 48) == 0) {
            i7 |= c0258p.d(i5) ? 32 : 16;
        }
        if ((i6 & 384) == 0) {
            i7 |= c0258p.h(aVar) ? 256 : 128;
        }
        if ((i6 & 3072) == 0) {
            i7 |= c0258p.h(cVar) ? 2048 : 1024;
        }
        int i8 = i7;
        if ((i8 & 1171) == 1170 && c0258p.x()) {
            c0258p.L();
        } else {
            Y1.b bVarC = g.C(c0258p);
            n nVar = n.a;
            q qVarH = androidx.compose.foundation.layout.b.h(nVar, g.I(c0258p).f7109e, 13);
            C1588d c1588d = AbstractC1594j.f12606c;
            U.g gVar = U.b.f6119x;
            C1603t c1603tA = r.a(c1588d, gVar, c0258p, 0);
            int i9 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarH);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C1802i c1802i = C1804k.f13645f;
            C0234d.R(c0258p, c1802i, c1603tA);
            C1802i c1802i2 = C1804k.f13644e;
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M);
            C1802i c1802i3 = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i9))) {
                AbstractC0813y0.r(i9, c0258p, i9, c1802i3);
            }
            C1802i c1802i4 = C1804k.f13643d;
            C0234d.R(c0258p, c1802i4, qVarD);
            h hVar = U.b.f6117v;
            C1586b c1586b = AbstractC1594j.a;
            b0 b0VarB = a0.b(c1586b, hVar, c0258p, 48);
            int i10 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M2 = c0258p.m();
            q qVarD2 = U.a.d(c0258p, nVar);
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, c1802i, b0VarB);
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M2);
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i10))) {
                AbstractC0813y0.r(i10, c0258p, i10, c1802i3);
            }
            C0234d.R(c0258p, c1802i4, qVarD2);
            q qVarA = c0.a(1.0f);
            C1603t c1603tA2 = r.a(c1588d, gVar, c0258p, 0);
            int i11 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M3 = c0258p.m();
            q qVarD3 = U.a.d(c0258p, qVarA);
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, c1802i, c1603tA2);
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M3);
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i11))) {
                AbstractC0813y0.r(i11, c0258p, i11, c1802i3);
            }
            C0234d.R(c0258p, c1802i4, qVarD3);
            H1.b("Thử lại khi báo cáo lỗi", null, bVarC.f7049h, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, g.L(c0258p).f7117f, c0258p, 6, 0, 65530);
            H1.b("Refresh app social rồi thử lại 1 lần", null, bVarC.f7052k, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, g.L(c0258p).f7118g, c0258p, 6, 0, 65530);
            boolean z6 = true;
            c0258p.p(true);
            c0258p.Q(36563343);
            boolean z7 = (i8 & 896) == 256;
            Object objG = c0258p.G();
            W w5 = C0250l.a;
            if (z7 || objG == w5) {
                objG = new C0043t(aVar, 4);
                c0258p.a0(objG);
            }
            c0258p.p(false);
            C0933a.d(z3, (T3.c) objG, null, c0258p, i8 & 14);
            c0258p.p(true);
            c0258p.Q(-1939566430);
            if (z3) {
                AbstractC1587c.a(c0258p, androidx.compose.foundation.layout.c.d(nVar, 8));
                b0 b0VarB2 = a0.b(c1586b, hVar, c0258p, 48);
                int i12 = c0258p.f3669P;
                InterfaceC0255n0 interfaceC0255n0M4 = c0258p.m();
                q qVarD4 = U.a.d(c0258p, nVar);
                c0258p.U();
                if (c0258p.f3668O) {
                    c0258p.l(c1803j);
                } else {
                    c0258p.d0();
                }
                C0234d.R(c0258p, c1802i, b0VarB2);
                C0234d.R(c0258p, c1802i2, interfaceC0255n0M4);
                if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i12))) {
                    AbstractC0813y0.r(i12, c0258p, i12, c1802i3);
                }
                C0234d.R(c0258p, c1802i4, qVarD4);
                H1.b("Chờ", null, bVarC.f7050i, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, g.L(c0258p).f7116e, c0258p, 6, 0, 65530);
                float f5 = 6;
                AbstractC1587c.a(c0258p, androidx.compose.foundation.layout.c.m(nVar, f5));
                String str = i5 + "s";
                c0258p.Q(36573861);
                boolean z8 = (i8 & 7168) == 2048;
                Object objG2 = c0258p.G();
                if (z8 || objG2 == w5) {
                    objG2 = new A2.l(8, cVar);
                    c0258p.a0(objG2);
                }
                c0258p.p(false);
                T(str, (T3.a) objG2, c0258p, 0);
                H1.b("rồi thử lại", null, bVarC.f7050i, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, AbstractC0813y0.i(nVar, f5, c0258p, c0258p).f7116e, c0258p, 6, 0, 65530);
                z6 = true;
                c0258p.p(true);
                z5 = false;
            } else {
                z5 = false;
            }
            c0258p.p(z5);
            c0258p.p(z6);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new C0205n(z3, i5, aVar, cVar, i6);
        }
    }

    public static K3.f h0(K3.f fVar, K3.g gVar) {
        j.f(gVar, "key");
        if (j.a(fVar.getKey(), gVar)) {
            return fVar;
        }
        return null;
    }

    public static final void i(int i5, C0258p c0258p, T3.a aVar, boolean z3) {
        int i6;
        c0258p.S(-1181482635);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.g(z3) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.h(aVar) ? 32 : 16;
        }
        if ((i6 & 19) == 18 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            G3.r rVar = z3 ? new G3.r("■ Dừng Auto", new C0603v(bVar.f7056o), new C0603v(bVar.f7058q)) : new G3.r("▶ Bật Auto (full flow)", new C0603v(bVar.f7059r), new C0603v(bVar.a));
            String str = (String) rVar.f2647l;
            long j5 = ((C0603v) rVar.f2648m).a;
            long j6 = ((C0603v) rVar.f2649n).a;
            float f5 = 10;
            q qVarI = androidx.compose.foundation.layout.b.i(androidx.compose.foundation.a.e(7, aVar, androidx.compose.foundation.a.b(androidx.compose.foundation.layout.c.c(n.a, 1.0f), j5, AbstractC1921e.b(f5)), null, false), 0.0f, f5, 1);
            InterfaceC1642G interfaceC1642GE = AbstractC1598n.e(U.b.f6111p, false);
            int i7 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarI);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, C1804k.f13645f, interfaceC1642GE);
            C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
            C1802i c1802i = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i7))) {
                AbstractC0813y0.r(i7, c0258p, i7, c1802i);
            }
            C0234d.R(c0258p, C1804k.f13643d, qVarD);
            H1.b(str, null, j6, V2.a.M(13), null, z.f2958r, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, 199680, 0, 131026);
            c0258p.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new C2.j(i5, 3, aVar, z3);
        }
    }

    public static final C1024e i0() {
        C1024e c1024e = a;
        if (c1024e != null) {
            return c1024e;
        }
        C1023d c1023d = new C1023d("AutoMirrored.Outlined.ArrowForward", 24.0f, 24.0f, 24.0f, 24.0f, 0L, 0, true, 96);
        int i5 = AbstractC1016F.a;
        V v5 = new V(C0603v.f7969b);
        X0 x02 = new X0(1);
        x02.m(12.0f, 4.0f);
        x02.l(-1.41f, 1.41f);
        x02.k(16.17f, 11.0f);
        x02.i(4.0f);
        x02.r(2.0f);
        x02.j(12.17f);
        x02.l(-5.58f, 5.59f);
        x02.k(12.0f, 20.0f);
        x02.l(8.0f, -8.0f);
        x02.l(-8.0f, -8.0f);
        x02.e();
        C1023d.a(c1023d, x02.f3603l, v5);
        C1024e c1024eB = c1023d.b();
        a = c1024eB;
        return c1024eB;
    }

    public static final void j(final boolean z3, final boolean z5, final boolean z6, final int i5, final boolean z7, final int i6, final int i7, final boolean z8, final boolean z9, final T3.a aVar, final T3.a aVar2, final T3.a aVar3, final T3.a aVar4, final T3.a aVar5, final T3.c cVar, C0258p c0258p, final int i8, final int i9) {
        int i10;
        int i11;
        c0258p.S(-381072277);
        if ((i8 & 6) == 0) {
            i10 = (c0258p.g(z3) ? 4 : 2) | i8;
        } else {
            i10 = i8;
        }
        if ((i8 & 48) == 0) {
            i10 |= c0258p.g(z5) ? 32 : 16;
        }
        if ((i8 & 384) == 0) {
            i10 |= c0258p.g(z6) ? 256 : 128;
        }
        if ((i8 & 3072) == 0) {
            i10 |= c0258p.d(i5) ? 2048 : 1024;
        }
        if ((12582912 & i8) == 0) {
            i10 |= c0258p.g(z8) ? 8388608 : 4194304;
        }
        if ((100663296 & i8) == 0) {
            i10 |= c0258p.g(z9) ? 67108864 : 33554432;
        }
        if ((i8 & 805306368) == 0) {
            i10 |= c0258p.h(aVar) ? 536870912 : 268435456;
        }
        if ((i9 & 6) == 0) {
            i11 = (c0258p.h(aVar2) ? 4 : 2) | i9;
        } else {
            i11 = i9;
        }
        if ((i9 & 48) == 0) {
            i11 |= c0258p.h(aVar3) ? 32 : 16;
        }
        if ((i9 & 3072) == 0) {
            i11 |= c0258p.h(aVar5) ? 2048 : 1024;
        }
        if ((i9 & 24576) == 0) {
            i11 |= c0258p.h(cVar) ? 16384 : 8192;
        }
        if ((i10 & 306185363) == 306185362 && (i11 & 9235) == 9234 && c0258p.x()) {
            c0258p.L();
        } else {
            C0933a.c(null, false, f.b(-737562096, new C0215y(z3, aVar, z5, aVar2, z6, i5, aVar3, cVar, z9, z8, aVar5), c0258p), c0258p, 432, 1);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new T3.e() { // from class: H2.x
                @Override // T3.e
                public final Object i(Object obj, Object obj2) {
                    ((Integer) obj2).intValue();
                    int iU = C0234d.U(i8 | 1);
                    int iU2 = C0234d.U(i9);
                    l0.c.j(z3, z5, z6, i5, z7, i6, i7, z8, z9, aVar, aVar2, aVar3, aVar4, aVar5, cVar, (C0258p) obj, iU, iU2);
                    return G3.C.a;
                }
            };
        }
    }

    public static final C1024e j0() {
        C1024e c1024e = f11437c;
        if (c1024e != null) {
            return c1024e;
        }
        C1023d c1023d = new C1023d("Outlined.Home", 24.0f, 24.0f, 24.0f, 24.0f, 0L, 0, false, 96);
        int i5 = AbstractC1016F.a;
        V v5 = new V(C0603v.f7969b);
        X0 x02 = new X0(1);
        x02.m(12.0f, 5.69f);
        x02.l(5.0f, 4.5f);
        x02.q(18.0f);
        x02.j(-2.0f);
        x02.r(-6.0f);
        x02.i(9.0f);
        x02.r(6.0f);
        x02.i(7.0f);
        x02.r(-7.81f);
        x02.l(5.0f, -4.5f);
        x02.m(12.0f, 3.0f);
        x02.k(2.0f, 12.0f);
        x02.j(3.0f);
        x02.r(8.0f);
        x02.j(6.0f);
        x02.r(-6.0f);
        x02.j(2.0f);
        x02.r(6.0f);
        x02.j(6.0f);
        x02.r(-8.0f);
        x02.j(3.0f);
        x02.k(12.0f, 3.0f);
        x02.e();
        C1023d.a(c1023d, x02.f3603l, v5);
        C1024e c1024eB = c1023d.b();
        f11437c = c1024eB;
        return c1024eB;
    }

    /* JADX WARN: Removed duplicated region for block: B:132:0x0396  */
    /* JADX WARN: Removed duplicated region for block: B:134:0x03a4  */
    /* JADX WARN: Removed duplicated region for block: B:137:0x03bf  */
    /* JADX WARN: Removed duplicated region for block: B:138:0x03c1  */
    /* JADX WARN: Removed duplicated region for block: B:144:0x03d0  */
    /* JADX WARN: Removed duplicated region for block: B:147:0x03ea  */
    /* JADX WARN: Removed duplicated region for block: B:177:0x0522  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final void k(final boolean r49, final int r50, final int r51, final int r52, final boolean r53, final boolean r54, final T3.a r55, final T3.a r56, final T3.c r57, I.C0258p r58, final int r59) {
        /*
            Method dump skipped, instruction units count: 1367
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: l0.c.k(boolean, int, int, int, boolean, boolean, T3.a, T3.a, T3.c, I.p, int):void");
    }

    public static final long k0(KeyEvent keyEvent) {
        return W3.a.i(keyEvent.getKeyCode());
    }

    public static final void l(final boolean z3, final int i5, final int i6, final int i7, final boolean z5, final boolean z6, final int i8, final int i9, final int i10, final int i11, final T3.a aVar, final T3.a aVar2, final T3.c cVar, C0258p c0258p, final int i12, final int i13) {
        int i14;
        int i15;
        c0258p.S(1290789188);
        if ((i12 & 6) == 0) {
            i14 = (c0258p.g(z3) ? 4 : 2) | i12;
        } else {
            i14 = i12;
        }
        if ((i12 & 48) == 0) {
            i14 |= c0258p.d(i5) ? 32 : 16;
        }
        if ((i12 & 384) == 0) {
            i14 |= c0258p.d(i6) ? 256 : 128;
        }
        if ((i12 & 3072) == 0) {
            i14 |= c0258p.d(i7) ? 2048 : 1024;
        }
        if ((i12 & 24576) == 0) {
            i14 |= c0258p.g(z5) ? 16384 : 8192;
        }
        if ((196608 & i12) == 0) {
            i14 |= c0258p.g(z6) ? 131072 : 65536;
        }
        if ((i12 & 1572864) == 0) {
            i14 |= c0258p.d(i8) ? 1048576 : 524288;
        }
        if ((i12 & 12582912) == 0) {
            i14 |= c0258p.d(i9) ? 8388608 : 4194304;
        }
        if ((i12 & 100663296) == 0) {
            i14 |= c0258p.d(i10) ? 67108864 : 33554432;
        }
        if ((i12 & 805306368) == 0) {
            i14 |= c0258p.d(i11) ? 536870912 : 268435456;
        }
        if ((i13 & 6) == 0) {
            i15 = (c0258p.h(aVar) ? 4 : 2) | i13;
        } else {
            i15 = i13;
        }
        if ((i13 & 48) == 0) {
            i15 |= c0258p.h(aVar2) ? 32 : 16;
        }
        if ((i13 & 384) == 0) {
            i15 |= c0258p.h(cVar) ? 256 : 128;
        }
        if ((i14 & 306783379) == 306783378 && (i15 & 147) == 146 && c0258p.x()) {
            c0258p.L();
        } else {
            C0933a.c(null, false, f.b(-1010207617, new C0216z(z3, i5, i6, i7, z5, z6, aVar, aVar2, cVar, i8, i9, i10, i11), c0258p), c0258p, 432, 1);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new T3.e() { // from class: H2.v
                @Override // T3.e
                public final Object i(Object obj, Object obj2) {
                    ((Integer) obj2).intValue();
                    int iU = C0234d.U(i12 | 1);
                    int iU2 = C0234d.U(i13);
                    l0.c.l(z3, i5, i6, i7, z5, z6, i8, i9, i10, i11, aVar, aVar2, cVar, (C0258p) obj, iU, iU2);
                    return G3.C.a;
                }
            };
        }
    }

    public static final C1024e l0() {
        C1024e c1024e = f11438d;
        if (c1024e != null) {
            return c1024e;
        }
        C1023d c1023d = new C1023d("Outlined.Refresh", 24.0f, 24.0f, 24.0f, 24.0f, 0L, 0, false, 96);
        int i5 = AbstractC1016F.a;
        V v5 = new V(C0603v.f7969b);
        X0 x02 = new X0(1);
        x02.m(17.65f, 6.35f);
        x02.f(16.2f, 4.9f, 14.21f, 4.0f, 12.0f, 4.0f);
        x02.g(-4.42f, 0.0f, -7.99f, 3.58f, -7.99f, 8.0f);
        x02.o(3.57f, 8.0f, 7.99f, 8.0f);
        x02.g(3.73f, 0.0f, 6.84f, -2.55f, 7.73f, -6.0f);
        x02.j(-2.08f);
        x02.g(-0.82f, 2.33f, -3.04f, 4.0f, -5.65f, 4.0f);
        x02.g(-3.31f, 0.0f, -6.0f, -2.69f, -6.0f, -6.0f);
        x02.o(2.69f, -6.0f, 6.0f, -6.0f);
        x02.g(1.66f, 0.0f, 3.14f, 0.69f, 4.22f, 1.78f);
        x02.k(13.0f, 11.0f);
        x02.j(7.0f);
        x02.q(4.0f);
        x02.l(-2.35f, 2.35f);
        x02.e();
        C1023d.a(c1023d, x02.f3603l, v5);
        C1024e c1024eB = c1023d.b();
        f11438d = c1024eB;
        return c1024eB;
    }

    /* JADX WARN: Removed duplicated region for block: B:100:0x027c  */
    /* JADX WARN: Removed duplicated region for block: B:102:0x0287  */
    /* JADX WARN: Removed duplicated region for block: B:106:0x029e  */
    /* JADX WARN: Removed duplicated region for block: B:112:0x02a9  */
    /* JADX WARN: Removed duplicated region for block: B:121:0x02e2  */
    /* JADX WARN: Removed duplicated region for block: B:155:0x03fc  */
    /* JADX WARN: Removed duplicated region for block: B:204:0x052c  */
    /* JADX WARN: Removed duplicated region for block: B:205:0x0531  */
    /* JADX WARN: Removed duplicated region for block: B:208:0x0541  */
    /* JADX WARN: Removed duplicated region for block: B:212:0x054a  */
    /* JADX WARN: Removed duplicated region for block: B:215:0x058a  */
    /* JADX WARN: Removed duplicated region for block: B:216:0x058f  */
    /* JADX WARN: Removed duplicated region for block: B:221:0x05ab  */
    /* JADX WARN: Removed duplicated region for block: B:229:0x05ce  */
    /* JADX WARN: Removed duplicated region for block: B:234:0x05e8  */
    /* JADX WARN: Removed duplicated region for block: B:235:0x05eb  */
    /* JADX WARN: Removed duplicated region for block: B:238:0x05f1  */
    /* JADX WARN: Removed duplicated region for block: B:318:0x060e A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final void m(long r58, boolean r60, T3.a r61, I.C0258p r62, int r63) throws org.xmlpull.v1.XmlPullParserException, java.io.IOException {
        /*
            Method dump skipped, instruction units count: 2124
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: l0.c.m(long, boolean, T3.a, I.p, int):void");
    }

    public static final int m0(KeyEvent keyEvent) {
        int action = keyEvent.getAction();
        if (action != 0) {
            return action != 1 ? 0 : 1;
        }
        return 2;
    }

    public static final void n(String str, long j5, boolean z3, C0258p c0258p, int i5) {
        int i6;
        c0258p.S(1998392321);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.f(str) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.e(j5) ? 32 : 16;
        }
        if ((i5 & 384) == 0) {
            i6 |= c0258p.g(z3) ? 256 : 128;
        }
        if ((i6 & 147) == 146 && c0258p.x()) {
            c0258p.L();
        } else {
            if (!z3 || str == null || c4.l.u0(str)) {
                C0264s0 c0264s0R = c0258p.r();
                if (c0264s0R != null) {
                    c0264s0R.f3706d = new C1162w(str, j5, z3, i5, 0);
                    return;
                }
                return;
            }
            c0258p.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            float f5 = 12;
            q qVarH = androidx.compose.foundation.layout.b.h(Y(androidx.compose.foundation.a.a(androidx.compose.foundation.layout.c.n(Float.NaN, 200), C1913d.g(H3.n.S0(new C0603v(bVar.f7043b), new C0603v(bVar.a))), AbstractC1921e.b(f5)), 1, C0603v.b(0.55f, j5), AbstractC1921e.b(f5)), 10, 6);
            InterfaceC1642G interfaceC1642GE = AbstractC1598n.e(U.b.f6107l, false);
            int i7 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarH);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, C1804k.f13645f, interfaceC1642GE);
            C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
            C1802i c1802i = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i7))) {
                AbstractC0813y0.r(i7, c0258p, i7, c1802i);
            }
            C0234d.R(c0258p, C1804k.f13643d, qVarD);
            H1.b(str, null, bVar.f7050i, V2.a.M(11), null, null, null, 0L, null, null, 0L, 0, false, 2, 0, null, null, c0258p, (i6 & 14) | 3072, 3072, 122866);
            c0258p.p(true);
        }
        C0264s0 c0264s0R2 = c0258p.r();
        if (c0264s0R2 != null) {
            c0264s0R2.f3706d = new C1162w(str, j5, z3, i5, 1);
        }
    }

    public static final int n0(int i5, int i6) {
        return (i5 >> i6) & 31;
    }

    public static final void o(List list, C0258p c0258p, int i5) {
        int i6;
        C0258p c0258p2;
        boolean z3;
        c0258p.S(-713807571);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.h(list) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i6 & 3) == 2 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            C1591g c1591gG = AbstractC1594j.g(2);
            float f5 = 8;
            q qVarH = androidx.compose.foundation.layout.b.h(androidx.compose.foundation.a.b(androidx.compose.foundation.layout.c.c(n.a, 1.0f), bVar.f7057p, AbstractC1921e.b(f5)), f5, 6);
            C1603t c1603tA = r.a(c1591gG, U.b.f6119x, c0258p, 6);
            int i7 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarH);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, C1804k.f13645f, c1603tA);
            C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
            C1802i c1802i = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i7))) {
                AbstractC0813y0.r(i7, c0258p, i7, c1802i);
            }
            C0234d.R(c0258p, C1804k.f13643d, qVarD);
            Y1.b bVar2 = bVar;
            H1.b(AbstractC2128a.e(list.size(), "Clickable thấy được (", "):"), null, bVar.f7056o, V2.a.M(10), null, z.f2958r, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, 199680, 0, 131026);
            C0258p c0258p3 = c0258p;
            c0258p3.Q(1185193178);
            Iterator it = H3.m.x1(list, 6).iterator();
            while (it.hasNext()) {
                Y1.b bVar3 = bVar2;
                H1.b((String) it.next(), null, bVar3.f7050i, V2.a.M(9), null, null, null, 0L, null, null, 0L, 0, false, 2, 0, null, null, c0258p, 3072, 3072, 122866);
                c0258p3 = c0258p;
                bVar2 = bVar3;
            }
            C0258p c0258p4 = c0258p3;
            Y1.b bVar4 = bVar2;
            c0258p4.p(false);
            c0258p4.Q(1185199184);
            if (list.size() > 6) {
                H1.b(AbstractC2128a.e(list.size() - 6, "… +", " (xem logcat AgA11y)"), null, bVar4.f7052k, V2.a.M(9), null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, 3072, 0, 131058);
                c0258p2 = c0258p;
                z3 = false;
            } else {
                c0258p2 = c0258p;
                z3 = false;
            }
            c0258p2.p(z3);
            c0258p2.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new W1.e(list, i5, 2);
        }
    }

    public static final boolean o0(C0494e c0494e) {
        float fB = AbstractC0490a.b(c0494e.f7222e);
        long j5 = c0494e.f7222e;
        if (fB == AbstractC0490a.c(j5)) {
            float fB2 = AbstractC0490a.b(j5);
            long j6 = c0494e.f7223f;
            if (fB2 == AbstractC0490a.b(j6) && AbstractC0490a.b(j5) == AbstractC0490a.c(j6)) {
                float fB3 = AbstractC0490a.b(j5);
                long j7 = c0494e.f7224g;
                if (fB3 == AbstractC0490a.b(j7) && AbstractC0490a.b(j5) == AbstractC0490a.c(j7)) {
                    float fB4 = AbstractC0490a.b(j5);
                    long j8 = c0494e.f7225h;
                    if (fB4 == AbstractC0490a.b(j8) && AbstractC0490a.b(j5) == AbstractC0490a.c(j8)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static final void p(final String str, final String str2, final int i5, final int i6, final boolean z3, final int i7, final int i8, final T3.e eVar, final T3.a aVar, C0258p c0258p, final int i9) {
        int i10;
        StringBuilder sb;
        String string;
        final InterfaceC0233c0 interfaceC0233c0;
        c0258p.S(-145684927);
        if ((i9 & 6) == 0) {
            i10 = (c0258p.f(str) ? 4 : 2) | i9;
        } else {
            i10 = i9;
        }
        if ((i9 & 48) == 0) {
            i10 |= c0258p.f(str2) ? 32 : 16;
        }
        if ((i9 & 384) == 0) {
            i10 |= c0258p.d(i5) ? 256 : 128;
        }
        if ((i9 & 3072) == 0) {
            i10 |= c0258p.d(i6) ? 2048 : 1024;
        }
        if ((i9 & 24576) == 0) {
            i10 |= c0258p.g(z3) ? 16384 : 8192;
        }
        if ((196608 & i9) == 0) {
            i10 |= c0258p.d(i7) ? 131072 : 65536;
        }
        if ((1572864 & i9) == 0) {
            i10 |= c0258p.d(i8) ? 1048576 : 524288;
        }
        if ((12582912 & i9) == 0) {
            i10 |= c0258p.h(eVar) ? 8388608 : 4194304;
        }
        if ((100663296 & i9) == 0) {
            i10 |= c0258p.h(aVar) ? 67108864 : 33554432;
        }
        int i11 = i10;
        if ((i11 & 38347923) == 38347922 && c0258p.x()) {
            c0258p.L();
        } else {
            Y1.b bVarC = g.C(c0258p);
            c0258p.Q(1121375200);
            Object objG = c0258p.G();
            W w5 = C0250l.a;
            if (objG == w5) {
                objG = C0234d.K(Boolean.FALSE, W.f3598q);
                c0258p.a0(objG);
            }
            InterfaceC0233c0 interfaceC0233c02 = (InterfaceC0233c0) objG;
            c0258p.p(false);
            if (z3) {
                int i12 = i5 / 60;
                if (i12 < 1) {
                    i12 = 1;
                }
                int i13 = i6 / 60;
                if (i13 < i12) {
                    i13 = i12;
                }
                if (i12 == i13) {
                    string = i12 + " phút";
                } else {
                    string = i12 + "–" + i13 + " phút";
                }
            } else {
                if (i5 == i6) {
                    sb = new StringBuilder();
                    sb.append(i5);
                } else {
                    sb = new StringBuilder();
                    sb.append(i5);
                    sb.append("–");
                    sb.append(i6);
                }
                sb.append("s");
                string = sb.toString();
            }
            String str3 = string;
            String str4 = z3 ? "PHÚT" : "GIÂY";
            n nVar = n.a;
            q qVarH = androidx.compose.foundation.layout.b.h(nVar, g.I(c0258p).f7109e, 13);
            String str5 = str4;
            b0 b0VarB = a0.b(AbstractC1594j.a, U.b.f6117v, c0258p, 48);
            int i14 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarH);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C1802i c1802i = C1804k.f13645f;
            C0234d.R(c0258p, c1802i, b0VarB);
            C1802i c1802i2 = C1804k.f13644e;
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M);
            C1802i c1802i3 = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i14))) {
                AbstractC0813y0.r(i14, c0258p, i14, c1802i3);
            }
            C1802i c1802i4 = C1804k.f13643d;
            C0234d.R(c0258p, c1802i4, qVarD);
            q qVarA = c0.a(1.0f);
            C1603t c1603tA = r.a(AbstractC1594j.f12606c, U.b.f6119x, c0258p, 0);
            int i15 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M2 = c0258p.m();
            q qVarD2 = U.a.d(c0258p, qVarA);
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, c1802i, c1603tA);
            C0234d.R(c0258p, c1802i2, interfaceC0255n0M2);
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i15))) {
                AbstractC0813y0.r(i15, c0258p, i15, c1802i3);
            }
            C0234d.R(c0258p, c1802i4, qVarD2);
            int i16 = i11 & 14;
            H1.b(str, null, bVarC.f7049h, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, g.L(c0258p).f7117f, c0258p, i16, 0, 65530);
            H1.b(str2, null, bVarC.f7052k, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, g.L(c0258p).f7118g, c0258p, (i11 >> 3) & 14, 0, 65530);
            c0258p.p(true);
            S(str5, aVar, c0258p, (i11 >> 21) & 112);
            AbstractC1587c.a(c0258p, androidx.compose.foundation.layout.c.m(nVar, 6));
            c0258p.Q(742057199);
            Object objG2 = c0258p.G();
            if (objG2 == w5) {
                interfaceC0233c0 = interfaceC0233c02;
                objG2 = new C0033i(interfaceC0233c0, 2);
                c0258p.a0(objG2);
            } else {
                interfaceC0233c0 = interfaceC0233c02;
            }
            c0258p.p(false);
            T(str3, (T3.a) objG2, c0258p, 48);
            c0258p.p(true);
            if (((Boolean) interfaceC0233c0.getValue()).booleanValue()) {
                String str6 = z3 ? "phút" : "giây";
                int i17 = z3 ? i8 : i7;
                int iO0 = l.o0(z3 ? i5 / 60 : i5, z3 ? 1 : 0, i17);
                int iO02 = l.o0(z3 ? i6 / 60 : i6, iO0, i17);
                c0258p.Q(1121426513);
                Object objG3 = c0258p.G();
                if (objG3 == w5) {
                    objG3 = new C0033i(interfaceC0233c0, 3);
                    c0258p.a0(objG3);
                }
                T3.a aVar2 = (T3.a) objG3;
                c0258p.p(false);
                c0258p.Q(1121428001);
                boolean z5 = ((i11 & 57344) == 16384) | ((i11 & 29360128) == 8388608);
                Object objG4 = c0258p.G();
                if (z5 || objG4 == w5) {
                    objG4 = new T3.e() { // from class: H2.s
                        @Override // T3.e
                        public final Object i(Object obj, Object obj2) {
                            int iIntValue = ((Integer) obj).intValue();
                            int iIntValue2 = ((Integer) obj2).intValue();
                            int i18 = z3 ? 60 : 1;
                            eVar.i(Integer.valueOf(iIntValue * i18), Integer.valueOf(iIntValue2 * i18));
                            interfaceC0233c0.setValue(Boolean.FALSE);
                            return G3.C.a;
                        }
                    };
                    c0258p.a0(objG4);
                }
                c0258p.p(false);
                D(str, iO0, iO02, str6, aVar2, (T3.e) objG4, z3 ? 1 : 0, i17, c0258p, i16 | 24576, 0);
            }
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new T3.e() { // from class: H2.t
                @Override // T3.e
                public final Object i(Object obj, Object obj2) {
                    ((Integer) obj2).getClass();
                    int iU = C0234d.U(i9 | 1);
                    String str7 = str;
                    String str8 = str2;
                    T3.e eVar2 = eVar;
                    T3.a aVar3 = aVar;
                    l0.c.p(str7, str8, i5, i6, z3, i7, i8, eVar2, aVar3, (C0258p) obj, iU);
                    return G3.C.a;
                }
            };
        }
    }

    public static K3.h p0(K3.f fVar, K3.g gVar) {
        j.f(gVar, "key");
        return j.a(fVar.getKey(), gVar) ? K3.i.f4514l : fVar;
    }

    public static final void q(final int i5, final int i6, final int i7, final int i8, final int i9, final int i10, final boolean z3, final boolean z5, final boolean z6, final T3.e eVar, final T3.e eVar2, final T3.e eVar3, final T3.a aVar, final T3.a aVar2, final T3.a aVar3, C0258p c0258p, final int i11, final int i12) {
        int i13;
        int i14;
        c0258p.S(-1816637421);
        if ((i11 & 6) == 0) {
            i13 = (c0258p.d(i5) ? 4 : 2) | i11;
        } else {
            i13 = i11;
        }
        if ((i11 & 48) == 0) {
            i13 |= c0258p.d(i6) ? 32 : 16;
        }
        if ((i11 & 384) == 0) {
            i13 |= c0258p.d(i7) ? 256 : 128;
        }
        if ((i11 & 3072) == 0) {
            i13 |= c0258p.d(i8) ? 2048 : 1024;
        }
        if ((i11 & 24576) == 0) {
            i13 |= c0258p.d(i9) ? 16384 : 8192;
        }
        if ((i11 & 196608) == 0) {
            i13 |= c0258p.d(i10) ? 131072 : 65536;
        }
        if ((i11 & 1572864) == 0) {
            i13 |= c0258p.g(z3) ? 1048576 : 524288;
        }
        if ((i11 & 12582912) == 0) {
            i13 |= c0258p.g(z5) ? 8388608 : 4194304;
        }
        if ((i11 & 100663296) == 0) {
            i13 |= c0258p.g(z6) ? 67108864 : 33554432;
        }
        if ((i11 & 805306368) == 0) {
            i13 |= c0258p.h(eVar) ? 536870912 : 268435456;
        }
        if ((i12 & 6) == 0) {
            i14 = i12 | (c0258p.h(eVar2) ? 4 : 2);
        } else {
            i14 = i12;
        }
        if ((i12 & 48) == 0) {
            i14 |= c0258p.h(eVar3) ? 32 : 16;
        }
        if ((i12 & 384) == 0) {
            i14 |= c0258p.h(aVar) ? 256 : 128;
        }
        if ((i12 & 3072) == 0) {
            i14 |= c0258p.h(aVar2) ? 2048 : 1024;
        }
        if ((i12 & 24576) == 0) {
            i14 |= c0258p.h(aVar3) ? 16384 : 8192;
        }
        if ((i13 & 306783379) == 306783378 && (i14 & 9363) == 9362 && c0258p.x()) {
            c0258p.L();
        } else {
            C0933a.c(null, false, f.b(1915046520, new A(i5, i6, z3, eVar, aVar, i7, i8, z5, eVar2, aVar2, i9, i10, z6, eVar3, aVar3), c0258p), c0258p, 432, 1);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new T3.e() { // from class: H2.o
                @Override // T3.e
                public final Object i(Object obj, Object obj2) {
                    ((Integer) obj2).intValue();
                    int iU = C0234d.U(i11 | 1);
                    int iU2 = C0234d.U(i12);
                    l0.c.q(i5, i6, i7, i8, i9, i10, z3, z5, z6, eVar, eVar2, eVar3, aVar, aVar2, aVar3, (C0258p) obj, iU, iU2);
                    return G3.C.a;
                }
            };
        }
    }

    public static K3.h q0(K3.f fVar, K3.h hVar) {
        j.f(hVar, "context");
        return hVar == K3.i.f4514l ? fVar : (K3.h) hVar.B(fVar, K3.b.f4509n);
    }

    public static final void r(int i5, C0258p c0258p) {
        c0258p.S(-2092462596);
        if (i5 == 0 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            AbstractC1598n.a(androidx.compose.foundation.a.b(androidx.compose.foundation.layout.c.d(androidx.compose.foundation.layout.c.c(n.a, 1.0f), 1), bVar.f7047f, b0.N.a), c0258p, 0);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new A2.j(i5, 7);
        }
    }

    public static void r0(EditorInfo editorInfo, CharSequence charSequence) {
        int i5 = Build.VERSION.SDK_INT;
        if (i5 >= 30) {
            AbstractC0936a.a(editorInfo, charSequence);
            return;
        }
        charSequence.getClass();
        if (i5 >= 30) {
            AbstractC0936a.a(editorInfo, charSequence);
            return;
        }
        int i6 = editorInfo.initialSelStart;
        int i7 = editorInfo.initialSelEnd;
        int i8 = i6 > i7 ? i7 : i6;
        if (i6 <= i7) {
            i6 = i7;
        }
        int length = charSequence.length();
        if (i8 < 0 || i6 > length) {
            s0(editorInfo, null, 0, 0);
            return;
        }
        int i9 = editorInfo.inputType & 4095;
        if (i9 == 129 || i9 == 225 || i9 == 18) {
            s0(editorInfo, null, 0, 0);
            return;
        }
        if (length <= 2048) {
            s0(editorInfo, charSequence, i8, i6);
            return;
        }
        int i10 = i6 - i8;
        int i11 = i10 > 1024 ? 0 : i10;
        int i12 = 2048 - i11;
        int iMin = Math.min(charSequence.length() - i6, i12 - Math.min(i8, (int) (((double) i12) * 0.8d)));
        int iMin2 = Math.min(i8, i12 - iMin);
        int i13 = i8 - iMin2;
        if (Character.isLowSurrogate(charSequence.charAt(i13))) {
            i13++;
            iMin2--;
        }
        if (Character.isHighSurrogate(charSequence.charAt((i6 + iMin) - 1))) {
            iMin--;
        }
        int i14 = iMin2 + i11;
        s0(editorInfo, i11 != i10 ? TextUtils.concat(charSequence.subSequence(i13, i13 + iMin2), charSequence.subSequence(i6, iMin + i6)) : charSequence.subSequence(i13, i14 + iMin + i13), iMin2, i14);
    }

    public static final void s(int i5, C0258p c0258p) {
        c0258p.S(1644760231);
        if (i5 == 0 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            E0.d(1, 48, C0603v.b(0.4f, bVar.f7047f), c0258p, null);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new A2.j(i5, 11);
        }
    }

    public static void s0(EditorInfo editorInfo, CharSequence charSequence, int i5, int i6) {
        if (editorInfo.extras == null) {
            editorInfo.extras = new Bundle();
        }
        editorInfo.extras.putCharSequence("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SURROUNDING_TEXT", charSequence != null ? new SpannableStringBuilder(charSequence) : null);
        editorInfo.extras.putInt("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SELECTION_HEAD", i5);
        editorInfo.extras.putInt("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_SELECTION_END", i6);
    }

    public static final long t(float f5, float f6) {
        return (((long) Float.floatToRawIntBits(f6)) & 4294967295L) | (Float.floatToRawIntBits(f5) << 32);
    }

    public static final long t0(float f5, long j5) {
        return V2.a.d(Math.max(0.0f, AbstractC0490a.b(j5) - f5), Math.max(0.0f, AbstractC0490a.c(j5) - f5));
    }

    public static final void u(final EnumC0187c enumC0187c, final F f5, final T3.a aVar, final T3.c cVar, final T3.e eVar, final T3.c cVar2, final T3.c cVar3, final T3.c cVar4, final T3.c cVar5, final T3.c cVar6, final T3.c cVar7, final T3.c cVar8, final T3.c cVar9, final T3.c cVar10, C0258p c0258p, final int i5, final int i6) {
        int i7;
        int i8;
        c0258p.S(-232849127);
        if ((i5 & 6) == 0) {
            i7 = (c0258p.f(enumC0187c) ? 4 : 2) | i5;
        } else {
            i7 = i5;
        }
        if ((i5 & 48) == 0) {
            i7 |= (i5 & 64) == 0 ? c0258p.f(f5) : c0258p.h(f5) ? 32 : 16;
        }
        if ((i5 & 384) == 0) {
            i7 |= c0258p.h(aVar) ? 256 : 128;
        }
        if ((i5 & 3072) == 0) {
            i7 |= c0258p.h(cVar) ? 2048 : 1024;
        }
        if ((i5 & 24576) == 0) {
            i7 |= c0258p.h(eVar) ? 16384 : 8192;
        }
        if ((i5 & 196608) == 0) {
            i7 |= c0258p.h(cVar2) ? 131072 : 65536;
        }
        if ((i5 & 1572864) == 0) {
            i7 |= c0258p.h(cVar3) ? 1048576 : 524288;
        }
        if ((i5 & 12582912) == 0) {
            i7 |= c0258p.h(cVar4) ? 8388608 : 4194304;
        }
        if ((i5 & 100663296) == 0) {
            i7 |= c0258p.h(cVar5) ? 67108864 : 33554432;
        }
        if ((i5 & 805306368) == 0) {
            i7 |= c0258p.h(cVar6) ? 536870912 : 268435456;
        }
        if ((i6 & 6) == 0) {
            i8 = i6 | (c0258p.h(cVar7) ? 4 : 2);
        } else {
            i8 = i6;
        }
        if ((i6 & 48) == 0) {
            i8 |= c0258p.h(cVar8) ? 32 : 16;
        }
        if ((i6 & 384) == 0) {
            i8 |= c0258p.h(cVar9) ? 256 : 128;
        }
        if ((i6 & 3072) == 0) {
            i8 |= c0258p.h(cVar10) ? 2048 : 1024;
        }
        if ((306783379 & i7) == 306783378 && (i8 & 1171) == 1170 && c0258p.x()) {
            c0258p.L();
        } else {
            if (enumC0187c == null) {
                C0264s0 c0264s0R = c0258p.r();
                if (c0264s0R != null) {
                    final int i9 = 0;
                    c0264s0R.f3706d = new T3.e() { // from class: H2.p
                        @Override // T3.e
                        public final Object i(Object obj, Object obj2) {
                            C0258p c0258p2 = (C0258p) obj;
                            switch (i9) {
                                case ConfigBackupDto.$stable /* 0 */:
                                    ((Integer) obj2).intValue();
                                    l0.c.u(enumC0187c, f5, aVar, cVar, eVar, cVar2, cVar3, cVar4, cVar5, cVar6, cVar7, cVar8, cVar9, cVar10, c0258p2, C0234d.U(i5 | 1), C0234d.U(i6));
                                    break;
                                default:
                                    ((Integer) obj2).intValue();
                                    l0.c.u(enumC0187c, f5, aVar, cVar, eVar, cVar2, cVar3, cVar4, cVar5, cVar6, cVar7, cVar8, cVar9, cVar10, c0258p2, C0234d.U(i5 | 1), C0234d.U(i6));
                                    break;
                            }
                            return G3.C.a;
                        }
                    };
                    return;
                }
                return;
            }
            switch (enumC0187c.ordinal()) {
                case ConfigBackupDto.$stable /* 0 */:
                    c0258p.Q(878984656);
                    int i10 = i7 << 9;
                    K("Nghỉ sau bao nhiêu job?", f5.f3043d, "job", false, false, aVar, cVar, c0258p, (i10 & 458752) | 3462 | (i10 & 3670016), 16);
                    c0258p.p(false);
                    break;
                case 1:
                    c0258p.Q(878995425);
                    D("Nghỉ ngẫu nhiên (phút)", f5.f3044e, f5.f3045f, "phút", aVar, eVar, 0, 0, c0258p, ((i7 << 6) & 57344) | 3078 | ((i7 << 3) & 458752), 192);
                    c0258p.p(false);
                    break;
                case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                    c0258p.Q(879006631);
                    K("Chờ bao lâu trước khi thử lại?", f5.f3064y, "giây", false, false, aVar, cVar2, c0258p, ((i7 << 9) & 458752) | 3462 | ((i7 << 3) & 3670016), 16);
                    c0258p.p(false);
                    break;
                case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                    c0258p.Q(879018076);
                    K("Chờ bao lâu trước khi back?", f5.f3040A, "giây", false, true, aVar, cVar3, c0258p, ((i7 << 9) & 458752) | 28038 | (i7 & 3670016), 0);
                    c0258p.p(false);
                    break;
                case k1.h.LONG_FIELD_NUMBER /* 4 */:
                    c0258p.Q(879030134);
                    K("Bấm back mấy lần liên tiếp?", f5.B, "lần", false, false, aVar, cVar4, c0258p, ((i7 << 9) & 458752) | 3462 | ((i7 >> 3) & 3670016), 16);
                    c0258p.p(false);
                    break;
                case k1.h.STRING_FIELD_NUMBER /* 5 */:
                    c0258p.Q(879040964);
                    K("Khởi động lại app sau bao nhiêu job?", f5.f3061v, "job", true, false, aVar, cVar5, c0258p, ((i7 << 9) & 458752) | 3462 | ((i7 >> 6) & 3670016), 16);
                    c0258p.p(false);
                    break;
                case k1.h.STRING_SET_FIELD_NUMBER /* 6 */:
                    c0258p.Q(879052424);
                    K("Đợi bao lâu trước khi mở lại app?", f5.f3062w, "giây", false, true, aVar, cVar6, c0258p, ((i7 << 9) & 458752) | 28038 | ((i7 >> 9) & 3670016), 0);
                    c0258p.p(false);
                    break;
                case k1.h.DOUBLE_FIELD_NUMBER /* 7 */:
                    c0258p.Q(879065022);
                    K("Dừng khi gặp bao nhiêu lỗi liên tiếp?", f5.f3059t, "lỗi", true, false, aVar, cVar7, c0258p, ((i7 << 9) & 458752) | 3462 | ((i8 << 18) & 3670016), 16);
                    c0258p.p(false);
                    break;
                case 8:
                    c0258p.Q(879076085);
                    K("Dừng khi đủ bao nhiêu job thành công?", f5.f3060u, "job", true, false, aVar, cVar8, c0258p, ((i7 << 9) & 458752) | 3462 | ((i8 << 15) & 3670016), 16);
                    c0258p.p(false);
                    break;
                case 9:
                    c0258p.Q(879087172);
                    K("Đổi acc sau bao nhiêu job thành công?", f5.C, "job", true, false, aVar, cVar9, c0258p, ((i7 << 9) & 458752) | 3462 | ((i8 << 12) & 3670016), 16);
                    c0258p.p(false);
                    break;
                case 10:
                    c0258p.Q(879098924);
                    K("Đổi acc khi gặp bao nhiêu lỗi liên tiếp?", f5.D, "lỗi", true, false, aVar, cVar10, c0258p, ((i7 << 9) & 458752) | 3462 | ((i8 << 9) & 3670016), 16);
                    c0258p.p(false);
                    break;
                default:
                    c0258p.Q(878986307);
                    c0258p.p(false);
                    throw new G3.f();
            }
        }
        C0264s0 c0264s0R2 = c0258p.r();
        if (c0264s0R2 != null) {
            final int i11 = 1;
            c0264s0R2.f3706d = new T3.e() { // from class: H2.p
                @Override // T3.e
                public final Object i(Object obj, Object obj2) {
                    C0258p c0258p2 = (C0258p) obj;
                    switch (i11) {
                        case ConfigBackupDto.$stable /* 0 */:
                            ((Integer) obj2).intValue();
                            l0.c.u(enumC0187c, f5, aVar, cVar, eVar, cVar2, cVar3, cVar4, cVar5, cVar6, cVar7, cVar8, cVar9, cVar10, c0258p2, C0234d.U(i5 | 1), C0234d.U(i6));
                            break;
                        default:
                            ((Integer) obj2).intValue();
                            l0.c.u(enumC0187c, f5, aVar, cVar, eVar, cVar2, cVar3, cVar4, cVar5, cVar6, cVar7, cVar8, cVar9, cVar10, c0258p2, C0234d.U(i5 | 1), C0234d.U(i6));
                            break;
                    }
                    return G3.C.a;
                }
            };
        }
    }

    public static final ExtractedText u0(I0.A a5) {
        ExtractedText extractedText = new ExtractedText();
        String str = a5.a.a;
        extractedText.text = str;
        extractedText.startOffset = 0;
        extractedText.partialEndOffset = str.length();
        extractedText.partialStartOffset = -1;
        long j5 = a5.f3798b;
        extractedText.selectionStart = K.e(j5);
        extractedText.selectionEnd = K.d(j5);
        extractedText.flags = !c4.l.l0(a5.a.a, '\n') ? 1 : 0;
        return extractedText;
    }

    public static final void v(final o oVar, final long j5, final boolean z3, final boolean z5, final T3.a aVar, final T3.a aVar2, final T3.a aVar3, final T3.a aVar4, final T3.a aVar5, final T3.e eVar, C0258p c0258p, final int i5) {
        int i6;
        c0258p.S(-542795381);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.f(oVar) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.e(j5) ? 32 : 16;
        }
        if ((i5 & 384) == 0) {
            i6 |= c0258p.g(z3) ? 256 : 128;
        }
        if ((i5 & 3072) == 0) {
            i6 |= c0258p.g(z5) ? 2048 : 1024;
        }
        if ((i5 & 24576) == 0) {
            i6 |= c0258p.h(aVar) ? 16384 : 8192;
        }
        if ((196608 & i5) == 0) {
            i6 |= c0258p.h(aVar2) ? 131072 : 65536;
        }
        if ((1572864 & i5) == 0) {
            i6 |= c0258p.h(aVar3) ? 1048576 : 524288;
        }
        if ((12582912 & i5) == 0) {
            i6 |= c0258p.h(aVar4) ? 8388608 : 4194304;
        }
        if ((100663296 & i5) == 0) {
            i6 |= c0258p.h(aVar5) ? 67108864 : 33554432;
        }
        if ((805306368 & i5) == 0) {
            i6 |= c0258p.h(eVar) ? 536870912 : 268435456;
        }
        if ((306783379 & i6) == 306783378 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            h hVar = U.b.f6117v;
            C1591g c1591gG = AbstractC1594j.g(6);
            q qVarC = androidx.compose.foundation.layout.c.c(n.a, 1.0f);
            b0 b0VarB = a0.b(c1591gG, hVar, c0258p, 54);
            int i7 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarC);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, C1804k.f13645f, b0VarB);
            C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
            C1802i c1802i = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i7))) {
                AbstractC0813y0.r(i7, c0258p, i7, c1802i);
            }
            C0234d.R(c0258p, C1804k.f13643d, qVarD);
            int i8 = i6 >> 3;
            C(j5, z3, c0258p, i8 & 126);
            H1.b("AutoGoLike", null, bVar.f7049h, V2.a.M(14), null, z.f2958r, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, 199686, 0, 131026);
            String strConcat = "· ".concat(oVar.f7003m);
            long jM = V2.a.M(12);
            q qVarA = c0.a(1.0f);
            C c5 = C.a;
            c0258p.Q(-1246782770);
            boolean z6 = (1879048192 & i6) == 536870912;
            Object objG = c0258p.G();
            if (z6 || objG == C0250l.a) {
                objG = new C1128B(eVar, null);
                c0258p.a0(objG);
            }
            c0258p.p(false);
            H1.b(strConcat, n0.w.a(qVarA, c5, (T3.e) objG), bVar.f7051j, jM, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, 3072, 0, 131056);
            w("↩", bVar.f7062u, bVar.f7061t, aVar2, c0258p, ((i6 >> 6) & 7168) | 6);
            c0258p.Q(-1246771929);
            if (z5) {
                w("⚡", bVar.f7060s, bVar.f7059r, aVar, c0258p, (i8 & 7168) | 6);
                w("🐞", bVar.f7044c, bVar.f7050i, aVar3, c0258p, ((i6 >> 9) & 7168) | 6);
            }
            c0258p.p(false);
            w("—", bVar.f7044c, bVar.f7050i, aVar4, c0258p, ((i6 >> 12) & 7168) | 6);
            w("×", bVar.f7057p, bVar.f7056o, aVar5, c0258p, ((i6 >> 15) & 7168) | 6);
            c0258p.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new T3.e() { // from class: i2.r
                @Override // T3.e
                public final Object i(Object obj, Object obj2) {
                    ((Integer) obj2).intValue();
                    l0.c.v(oVar, j5, z3, z5, aVar, aVar2, aVar3, aVar4, aVar5, eVar, (C0258p) obj, C0234d.U(i5 | 1));
                    return G3.C.a;
                }
            };
        }
    }

    public static void v0(Parcel parcel, int i5, Bundle bundle) {
        if (bundle == null) {
            return;
        }
        int iA0 = A0(parcel, i5);
        parcel.writeBundle(bundle);
        B0(parcel, iA0);
    }

    public static final void w(String str, long j5, long j6, T3.a aVar, C0258p c0258p, int i5) {
        int i6;
        c0258p.S(879842692);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.f(str) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.e(j5) ? 32 : 16;
        }
        if ((i5 & 384) == 0) {
            i6 |= c0258p.e(j6) ? 256 : 128;
        }
        if ((i5 & 3072) == 0) {
            i6 |= c0258p.h(aVar) ? 2048 : 1024;
        }
        if ((i6 & 1171) == 1170 && c0258p.x()) {
            c0258p.L();
        } else {
            q qVarE = androidx.compose.foundation.a.e(7, aVar, androidx.compose.foundation.a.b(androidx.compose.foundation.layout.c.i(n.a, 24), j5, AbstractC1921e.a), null, false);
            InterfaceC1642G interfaceC1642GE = AbstractC1598n.e(U.b.f6111p, false);
            int i7 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarE);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, C1804k.f13645f, interfaceC1642GE);
            C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
            C1802i c1802i = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i7))) {
                AbstractC0813y0.r(i7, c0258p, i7, c1802i);
            }
            C0234d.R(c0258p, C1804k.f13643d, qVarD);
            H1.b(str, null, j6, V2.a.M(14), null, z.f2959s, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, (i6 & 14) | 199680 | (i6 & 896), 0, 131026);
            c0258p.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new W1.g(str, j5, j6, aVar, i5, 1);
        }
    }

    public static void w0(Parcel parcel, int i5, IBinder iBinder) {
        if (iBinder == null) {
            return;
        }
        int iA0 = A0(parcel, i5);
        parcel.writeStrongBinder(iBinder);
        B0(parcel, iA0);
    }

    public static final void x(String str, T3.a aVar, C0258p c0258p, int i5) {
        int i6;
        c0258p.S(1217741681);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.f(str) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.h(aVar) ? 32 : 16;
        }
        int i7 = i6;
        if ((i7 & 19) == 18 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            h hVar = U.b.f6117v;
            float f5 = 6;
            C1591g c1591gG = AbstractC1594j.g(f5);
            float f6 = 8;
            q qVarH = androidx.compose.foundation.layout.b.h(androidx.compose.foundation.a.e(7, aVar, androidx.compose.foundation.a.b(androidx.compose.foundation.layout.c.c(n.a, 1.0f), bVar.f7044c, AbstractC1921e.b(f6)), null, false), f6, f5);
            b0 b0VarB = a0.b(c1591gG, hVar, c0258p, 54);
            int i8 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarH);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, C1804k.f13645f, b0VarB);
            C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
            C1802i c1802i = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i8))) {
                AbstractC0813y0.r(i8, c0258p, i8, c1802i);
            }
            C0234d.R(c0258p, C1804k.f13643d, qVarD);
            H1.b("↗", null, bVar.f7061t, V2.a.M(12), null, z.f2959s, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, c0258p, 199686, 0, 131026);
            H1.b(str, c0.a(1.0f), bVar.f7061t, V2.a.M(10), null, null, null, 0L, null, null, 0L, 0, false, 2, 0, null, null, c0258p, (i7 & 14) | 3072, 3072, 122864);
            c0258p.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new H2.r(str, aVar, i5, 3);
        }
    }

    public static void x0(Parcel parcel, int i5, Parcelable parcelable, int i6) {
        if (parcelable == null) {
            return;
        }
        int iA0 = A0(parcel, i5);
        parcelable.writeToParcel(parcel, i6);
        B0(parcel, iA0);
    }

    public static final void y(int i5, int i6, C0258p c0258p, T3.a aVar, String str) {
        int i7;
        c0258p.S(1625740461);
        if ((i6 & 6) == 0) {
            i7 = (c0258p.d(i5) ? 4 : 2) | i6;
        } else {
            i7 = i6;
        }
        if ((i6 & 48) == 0) {
            i7 |= c0258p.f("Tắt") ? 32 : 16;
        }
        if ((i6 & 384) == 0) {
            i7 |= c0258p.f(str) ? 256 : 128;
        }
        if ((i6 & 3072) == 0) {
            i7 |= c0258p.h(aVar) ? 2048 : 1024;
        }
        if ((i7 & 1171) == 1170 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.Q(-1101863115);
            Y1.b bVar = (Y1.b) c0258p.k(i.a);
            c0258p.p(false);
            boolean z3 = i5 == 0;
            q qVarH = androidx.compose.foundation.layout.b.h(androidx.compose.foundation.a.e(7, aVar, androidx.compose.foundation.a.b(n.a, z3 ? bVar.f7045d : bVar.f7054m, AbstractC1921e.b(6)), null, false), 9, 4);
            InterfaceC1642G interfaceC1642GE = AbstractC1598n.e(U.b.f6107l, false);
            int i8 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, qVarH);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, C1804k.f13645f, interfaceC1642GE);
            C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
            C1802i c1802i = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i8))) {
                AbstractC0813y0.r(i8, c0258p, i8, c1802i);
            }
            C0234d.R(c0258p, C1804k.f13643d, qVarD);
            String str2 = z3 ? "Tắt" : str;
            long j5 = z3 ? bVar.f7052k : bVar.f7053l;
            c0258p.Q(258792282);
            Y1.f fVar = (Y1.f) c0258p.k(Y1.l.f7129c);
            c0258p.p(false);
            H1.b(str2, null, j5, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, L.a(fVar.f7121j, 0L, 0L, z.f2959s, null, 0L, null, 0L, null, null, 16777211), c0258p, 0, 0, 65530);
            c0258p.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new C0028d(i5, str, aVar, i6);
        }
    }

    public static void y0(Parcel parcel, int i5, String str) {
        if (str == null) {
            return;
        }
        int iA0 = A0(parcel, i5);
        parcel.writeString(str);
        B0(parcel, iA0);
    }

    public static final void z(final long j5, final boolean z3, final String str, final boolean z5, final boolean z6, final T3.a aVar, C0258p c0258p, final int i5) throws XmlPullParserException, IOException {
        int i6;
        c0258p.S(295765096);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.e(j5) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= c0258p.g(z3) ? 32 : 16;
        }
        if ((i5 & 384) == 0) {
            i6 |= c0258p.f(str) ? 256 : 128;
        }
        if ((i5 & 3072) == 0) {
            i6 |= c0258p.g(z5) ? 2048 : 1024;
        }
        if ((i5 & 24576) == 0) {
            i6 |= c0258p.g(z6) ? 16384 : 8192;
        }
        if ((196608 & i5) == 0) {
            i6 |= c0258p.h(aVar) ? 131072 : 65536;
        }
        int i7 = i6;
        if ((74899 & i7) == 74898 && c0258p.x()) {
            c0258p.L();
        } else {
            c0258p.Q(-687717879);
            Object objG = c0258p.G();
            W w5 = C0250l.a;
            if (objG == w5) {
                objG = C0234d.K(Boolean.TRUE, W.f3598q);
                c0258p.a0(objG);
            }
            InterfaceC0233c0 interfaceC0233c0 = (InterfaceC0233c0) objG;
            c0258p.p(false);
            Boolean boolValueOf = Boolean.valueOf(z5);
            c0258p.Q(-687715228);
            boolean z7 = ((i7 & 896) == 256) | ((i7 & 7168) == 2048);
            Object objG2 = c0258p.G();
            if (z7 || objG2 == w5) {
                objG2 = new C1129C(z5, str, interfaceC0233c0, null);
                c0258p.a0(objG2);
            }
            c0258p.p(false);
            int i8 = (i7 >> 6) & 14;
            C0234d.f(str, boolValueOf, (T3.e) objG2, c0258p);
            h hVar = U.b.f6117v;
            C1591g c1591gG = AbstractC1594j.g(6);
            n nVar = n.a;
            b0 b0VarB = a0.b(c1591gG, hVar, c0258p, 54);
            int i9 = c0258p.f3669P;
            InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
            q qVarD = U.a.d(c0258p, nVar);
            InterfaceC1805l.f13649k.getClass();
            C1803j c1803j = C1804k.f13641b;
            c0258p.U();
            if (c0258p.f3668O) {
                c0258p.l(c1803j);
            } else {
                c0258p.d0();
            }
            C0234d.R(c0258p, C1804k.f13645f, b0VarB);
            C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
            C1802i c1802i = C1804k.f13646g;
            if (c0258p.f3668O || !j.a(c0258p.G(), Integer.valueOf(i9))) {
                AbstractC0813y0.r(i9, c0258p, i9, c1802i);
            }
            C0234d.R(c0258p, C1804k.f13643d, qVarD);
            if (z6) {
                c0258p.Q(-2114386281);
                n(str, j5, ((Boolean) interfaceC0233c0.getValue()).booleanValue() && z5, c0258p, i8 | ((i7 << 3) & 112));
                m(j5, z3, aVar, c0258p, (i7 & 126) | ((i7 >> 9) & 896));
                c0258p.p(false);
            } else {
                c0258p.Q(-2114122409);
                m(j5, z3, aVar, c0258p, (i7 & 126) | ((i7 >> 9) & 896));
                n(str, j5, ((Boolean) interfaceC0233c0.getValue()).booleanValue() && z5, c0258p, i8 | ((i7 << 3) & 112));
                c0258p.p(false);
            }
            c0258p.p(true);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new T3.e() { // from class: i2.y
                @Override // T3.e
                public final Object i(Object obj, Object obj2) throws XmlPullParserException, IOException {
                    ((Integer) obj2).intValue();
                    l0.c.z(j5, z3, str, z5, z6, aVar, (C0258p) obj, C0234d.U(i5 | 1));
                    return G3.C.a;
                }
            };
        }
    }

    public static void z0(Parcel parcel, int i5, Parcelable[] parcelableArr, int i6) {
        if (parcelableArr == null) {
            return;
        }
        int iA0 = A0(parcel, i5);
        parcel.writeInt(parcelableArr.length);
        for (Parcelable parcelable : parcelableArr) {
            if (parcelable == null) {
                parcel.writeInt(0);
            } else {
                int iDataPosition = parcel.dataPosition();
                parcel.writeInt(1);
                int iDataPosition2 = parcel.dataPosition();
                parcelable.writeToParcel(parcel, i6);
                int iDataPosition3 = parcel.dataPosition();
                parcel.setDataPosition(iDataPosition);
                parcel.writeInt(iDataPosition3 - iDataPosition2);
                parcel.setDataPosition(iDataPosition3);
            }
        }
        B0(parcel, iA0);
    }
}

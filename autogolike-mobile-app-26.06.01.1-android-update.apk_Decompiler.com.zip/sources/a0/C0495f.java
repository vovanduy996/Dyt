package a0;

/* JADX INFO: renamed from: a0.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0495f {
    public final long a;

    public /* synthetic */ C0495f(long j5) {
        this.a = j5;
    }

    public static final boolean a(long j5, long j6) {
        return j5 == j6;
    }

    public static final float b(long j5) {
        if (j5 != 9205357640488583168L) {
            return Float.intBitsToFloat((int) (j5 & 4294967295L));
        }
        throw new IllegalStateException("Size is unspecified");
    }

    public static final float c(long j5) {
        if (j5 != 9205357640488583168L) {
            return Math.min(Float.intBitsToFloat((int) ((j5 >> 32) & 2147483647L)), Float.intBitsToFloat((int) (j5 & 2147483647L)));
        }
        throw new IllegalStateException("Size is unspecified");
    }

    public static final float d(long j5) {
        if (j5 != 9205357640488583168L) {
            return Float.intBitsToFloat((int) (j5 >> 32));
        }
        throw new IllegalStateException("Size is unspecified");
    }

    public static final boolean e(long j5) {
        if (j5 == 9205357640488583168L) {
            throw new IllegalStateException("Size is unspecified");
        }
        long j6 = j5 & (~((((-9223372034707292160L) & j5) >>> 31) * ((long) (-1))));
        return ((j6 & 4294967295L) & (j6 >>> 32)) == 0;
    }

    public static String f(long j5) {
        if (j5 == 9205357640488583168L) {
            return "Size.Unspecified";
        }
        return "Size(" + W3.a.U(d(j5)) + ", " + W3.a.U(b(j5)) + ')';
    }

    public final boolean equals(Object obj) {
        if (obj instanceof C0495f) {
            return this.a == ((C0495f) obj).a;
        }
        return false;
    }

    public final int hashCode() {
        return Long.hashCode(this.a);
    }

    public final String toString() {
        return f(this.a);
    }
}

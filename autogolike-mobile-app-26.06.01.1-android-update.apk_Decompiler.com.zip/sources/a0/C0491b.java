package a0;

/* JADX INFO: renamed from: a0.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0491b {
    public float a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public float f7212b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f7213c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f7214d;

    public final void a(float f5, float f6, float f7, float f8) {
        this.a = Math.max(f5, this.a);
        this.f7212b = Math.max(f6, this.f7212b);
        this.f7213c = Math.min(f7, this.f7213c);
        this.f7214d = Math.min(f8, this.f7214d);
    }

    public final boolean b() {
        return this.a >= this.f7213c || this.f7212b >= this.f7214d;
    }

    public final String toString() {
        return "MutableRect(" + W3.a.U(this.a) + ", " + W3.a.U(this.f7212b) + ", " + W3.a.U(this.f7213c) + ", " + W3.a.U(this.f7214d) + ')';
    }
}

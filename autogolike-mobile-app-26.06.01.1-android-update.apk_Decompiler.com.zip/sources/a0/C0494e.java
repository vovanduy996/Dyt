package a0;

import com.google.android.gms.internal.measurement.AbstractC0813y0;

/* JADX INFO: renamed from: a0.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0494e {
    public final float a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f7219b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f7220c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final float f7221d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f7222e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final long f7223f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final long f7224g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final long f7225h;

    static {
        long j5 = AbstractC0490a.a;
        V2.a.d(AbstractC0490a.b(j5), AbstractC0490a.c(j5));
    }

    public C0494e(float f5, float f6, float f7, float f8, long j5, long j6, long j7, long j8) {
        this.a = f5;
        this.f7219b = f6;
        this.f7220c = f7;
        this.f7221d = f8;
        this.f7222e = j5;
        this.f7223f = j6;
        this.f7224g = j7;
        this.f7225h = j8;
    }

    public final float a() {
        return this.f7221d - this.f7219b;
    }

    public final float b() {
        return this.f7220c - this.a;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0494e)) {
            return false;
        }
        C0494e c0494e = (C0494e) obj;
        return Float.compare(this.a, c0494e.a) == 0 && Float.compare(this.f7219b, c0494e.f7219b) == 0 && Float.compare(this.f7220c, c0494e.f7220c) == 0 && Float.compare(this.f7221d, c0494e.f7221d) == 0 && AbstractC0490a.a(this.f7222e, c0494e.f7222e) && AbstractC0490a.a(this.f7223f, c0494e.f7223f) && AbstractC0490a.a(this.f7224g, c0494e.f7224g) && AbstractC0490a.a(this.f7225h, c0494e.f7225h);
    }

    public final int hashCode() {
        int iD = AbstractC0813y0.d(this.f7221d, AbstractC0813y0.d(this.f7220c, AbstractC0813y0.d(this.f7219b, Float.hashCode(this.a) * 31, 31), 31), 31);
        int i5 = AbstractC0490a.f7211b;
        return Long.hashCode(this.f7225h) + AbstractC0813y0.e(AbstractC0813y0.e(AbstractC0813y0.e(iD, 31, this.f7222e), 31, this.f7223f), 31, this.f7224g);
    }

    public final String toString() {
        String str = W3.a.U(this.a) + ", " + W3.a.U(this.f7219b) + ", " + W3.a.U(this.f7220c) + ", " + W3.a.U(this.f7221d);
        long j5 = this.f7222e;
        long j6 = this.f7223f;
        boolean zA = AbstractC0490a.a(j5, j6);
        long j7 = this.f7224g;
        long j8 = this.f7225h;
        if (!zA || !AbstractC0490a.a(j6, j7) || !AbstractC0490a.a(j7, j8)) {
            StringBuilder sbP = AbstractC0813y0.p("RoundRect(rect=", str, ", topLeft=");
            sbP.append((Object) AbstractC0490a.d(j5));
            sbP.append(", topRight=");
            sbP.append((Object) AbstractC0490a.d(j6));
            sbP.append(", bottomRight=");
            sbP.append((Object) AbstractC0490a.d(j7));
            sbP.append(", bottomLeft=");
            sbP.append((Object) AbstractC0490a.d(j8));
            sbP.append(')');
            return sbP.toString();
        }
        if (AbstractC0490a.b(j5) == AbstractC0490a.c(j5)) {
            StringBuilder sbP2 = AbstractC0813y0.p("RoundRect(rect=", str, ", radius=");
            sbP2.append(W3.a.U(AbstractC0490a.b(j5)));
            sbP2.append(')');
            return sbP2.toString();
        }
        StringBuilder sbP3 = AbstractC0813y0.p("RoundRect(rect=", str, ", x=");
        sbP3.append(W3.a.U(AbstractC0490a.b(j5)));
        sbP3.append(", y=");
        sbP3.append(W3.a.U(AbstractC0490a.c(j5)));
        sbP3.append(')');
        return sbP3.toString();
    }
}

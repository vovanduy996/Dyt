package a0;

/* JADX INFO: renamed from: a0.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0490a {
    public static final long a = V2.a.d(0.0f, 0.0f);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final /* synthetic */ int f7211b = 0;

    public static final boolean a(long j5, long j6) {
        return j5 == j6;
    }

    public static final float b(long j5) {
        return Float.intBitsToFloat((int) (j5 >> 32));
    }

    public static final float c(long j5) {
        return Float.intBitsToFloat((int) (j5 & 4294967295L));
    }

    public static String d(long j5) {
        if (b(j5) == c(j5)) {
            return "CornerRadius.circular(" + W3.a.U(b(j5)) + ')';
        }
        return "CornerRadius.elliptical(" + W3.a.U(b(j5)) + ", " + W3.a.U(c(j5)) + ')';
    }
}

package a0;

import X2.g;
import com.google.android.gms.internal.measurement.AbstractC0813y0;

/* JADX INFO: renamed from: a0.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0493d {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final C0493d f7215e = new C0493d(0.0f, 0.0f, 0.0f, 0.0f);
    public final float a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f7216b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f7217c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final float f7218d;

    public C0493d(float f5, float f6, float f7, float f8) {
        this.a = f5;
        this.f7216b = f6;
        this.f7217c = f7;
        this.f7218d = f8;
    }

    public final long a() {
        return g.l((c() / 2.0f) + this.a, (b() / 2.0f) + this.f7216b);
    }

    public final float b() {
        return this.f7218d - this.f7216b;
    }

    public final float c() {
        return this.f7217c - this.a;
    }

    public final C0493d d(C0493d c0493d) {
        return new C0493d(Math.max(this.a, c0493d.a), Math.max(this.f7216b, c0493d.f7216b), Math.min(this.f7217c, c0493d.f7217c), Math.min(this.f7218d, c0493d.f7218d));
    }

    public final boolean e() {
        return this.a >= this.f7217c || this.f7216b >= this.f7218d;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0493d)) {
            return false;
        }
        C0493d c0493d = (C0493d) obj;
        return Float.compare(this.a, c0493d.a) == 0 && Float.compare(this.f7216b, c0493d.f7216b) == 0 && Float.compare(this.f7217c, c0493d.f7217c) == 0 && Float.compare(this.f7218d, c0493d.f7218d) == 0;
    }

    public final boolean f(C0493d c0493d) {
        return this.f7217c > c0493d.a && c0493d.f7217c > this.a && this.f7218d > c0493d.f7216b && c0493d.f7218d > this.f7216b;
    }

    public final C0493d g(float f5, float f6) {
        return new C0493d(this.a + f5, this.f7216b + f6, this.f7217c + f5, this.f7218d + f6);
    }

    public final C0493d h(long j5) {
        return new C0493d(C0492c.d(j5) + this.a, C0492c.e(j5) + this.f7216b, C0492c.d(j5) + this.f7217c, C0492c.e(j5) + this.f7218d);
    }

    public final int hashCode() {
        return Float.hashCode(this.f7218d) + AbstractC0813y0.d(this.f7217c, AbstractC0813y0.d(this.f7216b, Float.hashCode(this.a) * 31, 31), 31);
    }

    public final String toString() {
        return "Rect.fromLTRB(" + W3.a.U(this.a) + ", " + W3.a.U(this.f7216b) + ", " + W3.a.U(this.f7217c) + ", " + W3.a.U(this.f7218d) + ')';
    }
}

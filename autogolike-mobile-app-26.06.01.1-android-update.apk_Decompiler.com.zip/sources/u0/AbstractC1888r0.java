package u0;

/* JADX INFO: renamed from: u0.r0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1888r0 {
    public static final I.Z0 a = new I.Z0(C1847L.f13949N);
}

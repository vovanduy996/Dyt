package u0;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import b0.C0590h;
import com.google.android.gms.internal.measurement.D1;
import dagger.hilt.android.R;
import f.C0933a;
import f4.AbstractC0952A;
import f4.AbstractC0960I;
import f4.AbstractC0967a;
import f4.EnumC0992z;
import i4.C1175C;
import i4.InterfaceC1183g;
import java.util.LinkedHashMap;
import k4.AbstractC1268m;
import l3.AbstractC1324b;
import m4.C1408e;

/* JADX INFO: loaded from: classes.dex */
public abstract class f1 {
    public static final LinkedHashMap a = new LinkedHashMap();

    public static final i4.a0 a(Context context) {
        i4.a0 a0Var;
        LinkedHashMap linkedHashMap = a;
        synchronized (linkedHashMap) {
            try {
                Object j5 = linkedHashMap.get(context);
                if (j5 == null) {
                    ContentResolver contentResolver = context.getContentResolver();
                    Uri uriFor = Settings.Global.getUriFor("animator_duration_scale");
                    h4.g gVarI = C0933a.i(-1, 6, null);
                    O1.B b3 = new O1.B(new e1(contentResolver, uriFor, new D1(gVarI, AbstractC1324b.m(Looper.getMainLooper())), gVarI, context, null));
                    f4.q0 q0VarB = AbstractC0952A.b();
                    C1408e c1408e = AbstractC0960I.a;
                    K3.h hVarQ0 = l0.c.q0(q0VarB, AbstractC1268m.a);
                    i4.Z z3 = new i4.Z(0L, Long.MAX_VALUE);
                    Float fValueOf = Float.valueOf(Settings.Global.getFloat(context.getContentResolver(), "animator_duration_scale", 1.0f));
                    C0590h c0590hI = i4.O.i(b3, 1);
                    i4.c0 c0VarC = i4.O.c(fValueOf);
                    InterfaceC1183g interfaceC1183g = (InterfaceC1183g) c0590hI.f7959b;
                    EnumC0992z enumC0992z = z3.equals(i4.S.a) ? EnumC0992z.f9856l : EnumC0992z.f9859o;
                    C1175C c1175c = new C1175C(z3, interfaceC1183g, c0VarC, fValueOf, null);
                    K3.h hVarI = AbstractC0952A.i(hVarQ0, (K3.h) c0590hI.f7961d, true);
                    C1408e c1408e2 = AbstractC0960I.a;
                    if (hVarI != c1408e2 && hVarI.m(K3.d.f4513l) == null) {
                        hVarI = hVarI.F(c1408e2);
                    }
                    AbstractC0967a j0Var = enumC0992z == EnumC0992z.f9857m ? new f4.j0(hVarI, c1175c) : new f4.p0(hVarI, true);
                    j0Var.n0(enumC0992z, j0Var, c1175c);
                    j5 = new i4.J(c0VarC);
                    linkedHashMap.put(context, j5);
                }
                a0Var = (i4.a0) j5;
            } catch (Throwable th) {
                throw th;
            }
        }
        return a0Var;
    }

    public static final I.r b(View view) {
        Object tag = view.getTag(R.id.androidx_compose_ui_view_composition_context);
        if (tag instanceof I.r) {
            return (I.r) tag;
        }
        return null;
    }
}

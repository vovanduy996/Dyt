package u0;

import android.view.View;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityManager;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import dagger.hilt.android.R;
import java.util.Iterator;

/* JADX INFO: renamed from: u0.v, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class ViewOnAttachStateChangeListenerC1895v implements View.OnAttachStateChangeListener {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f14225l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Object f14226m;

    public /* synthetic */ ViewOnAttachStateChangeListenerC1895v(int i5, Object obj) {
        this.f14225l = i5;
        this.f14226m = obj;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
        switch (this.f14225l) {
            case ConfigBackupDto.$stable /* 0 */:
                C1839D c1839d = (C1839D) this.f14226m;
                AccessibilityManager accessibilityManager = c1839d.f13896g;
                accessibilityManager.addAccessibilityStateChangeListener(c1839d.f13898i);
                accessibilityManager.addTouchExplorationStateChangeListener(c1839d.f13899j);
                break;
        }
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
        boolean z3;
        switch (this.f14225l) {
            case ConfigBackupDto.$stable /* 0 */:
                C1839D c1839d = (C1839D) this.f14226m;
                c1839d.f13901l.removeCallbacks(c1839d.f13890K);
                AccessibilityManager accessibilityManager = c1839d.f13896g;
                accessibilityManager.removeAccessibilityStateChangeListener(c1839d.f13898i);
                accessibilityManager.removeTouchExplorationStateChangeListener(c1839d.f13899j);
                break;
            case 1:
                AbstractC1853a abstractC1853a = (AbstractC1853a) this.f14226m;
                U3.j.f(abstractC1853a, "<this>");
                Iterator it = b4.k.d0(abstractC1853a.getParent(), c1.v.f8148t).iterator();
                while (true) {
                    if (it.hasNext()) {
                        Object obj = (ViewParent) it.next();
                        if (obj instanceof View) {
                            View view2 = (View) obj;
                            U3.j.f(view2, "<this>");
                            Object tag = view2.getTag(R.id.is_pooling_container_tag);
                            Boolean bool = tag instanceof Boolean ? (Boolean) tag : null;
                            if (bool != null ? bool.booleanValue() : false) {
                                z3 = true;
                            }
                        }
                    }
                }
                if (!z3) {
                    j1 j1Var = abstractC1853a.f14022n;
                    if (j1Var != null) {
                        j1Var.c();
                    }
                    abstractC1853a.f14022n = null;
                    abstractC1853a.requestLayout();
                }
                break;
            default:
                view.removeOnAttachStateChangeListener(this);
                ((f4.p0) this.f14226m).a(null);
                break;
        }
    }

    private final void a(View view) {
    }

    private final void b(View view) {
    }
}

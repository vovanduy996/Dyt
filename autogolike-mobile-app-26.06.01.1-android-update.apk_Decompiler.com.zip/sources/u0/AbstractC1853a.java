package u0;

import A.C0016q;
import C0.C0046a;
import I.C0258p;
import android.content.Context;
import android.os.IBinder;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import java.lang.ref.WeakReference;

/* JADX INFO: renamed from: u0.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1853a extends ViewGroup {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public WeakReference f14020l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public IBinder f14021m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public j1 f14022n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public I.r f14023o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public A4.l f14024p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f14025q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f14026r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f14027s;

    public /* synthetic */ AbstractC1853a(Context context) {
        this(context, null, 0);
    }

    private final void setParentContext(I.r rVar) {
        if (this.f14023o != rVar) {
            this.f14023o = rVar;
            if (rVar != null) {
                this.f14020l = null;
            }
            j1 j1Var = this.f14022n;
            if (j1Var != null) {
                j1Var.c();
                this.f14022n = null;
                if (isAttachedToWindow()) {
                    c();
                }
            }
        }
    }

    private final void setPreviousAttachedWindowToken(IBinder iBinder) {
        if (this.f14021m != iBinder) {
            this.f14021m = iBinder;
            this.f14020l = null;
        }
    }

    public abstract void a(int i5, C0258p c0258p);

    @Override // android.view.ViewGroup
    public final void addView(View view) {
        b();
        super.addView(view);
    }

    @Override // android.view.ViewGroup
    public final boolean addViewInLayout(View view, int i5, ViewGroup.LayoutParams layoutParams) {
        b();
        return super.addViewInLayout(view, i5, layoutParams);
    }

    public final void b() {
        if (this.f14026r) {
            return;
        }
        throw new UnsupportedOperationException("Cannot add views to " + getClass().getSimpleName() + "; only Compose content is supported");
    }

    public final void c() {
        if (this.f14022n == null) {
            try {
                this.f14026r = true;
                this.f14022n = l1.a(this, f(), new Q.a(-656146368, new C0046a(14, this), true));
            } finally {
                this.f14026r = false;
            }
        }
    }

    public void d(boolean z3, int i5, int i6, int i7, int i8) {
        View childAt = getChildAt(0);
        if (childAt != null) {
            childAt.layout(getPaddingLeft(), getPaddingTop(), (i7 - i5) - getPaddingRight(), (i8 - i6) - getPaddingBottom());
        }
    }

    public void e(int i5, int i6) {
        View childAt = getChildAt(0);
        if (childAt == null) {
            super.onMeasure(i5, i6);
            return;
        }
        childAt.measure(View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i5) - getPaddingLeft()) - getPaddingRight()), View.MeasureSpec.getMode(i5)), View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i6) - getPaddingTop()) - getPaddingBottom()), View.MeasureSpec.getMode(i6)));
        setMeasuredDimension(getPaddingRight() + getPaddingLeft() + childAt.getMeasuredWidth(), getPaddingBottom() + getPaddingTop() + childAt.getMeasuredHeight());
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0071  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0074  */
    /* JADX WARN: Type inference failed for: r1v0, types: [I.r] */
    /* JADX WARN: Type inference failed for: r1v1, types: [I.r] */
    /* JADX WARN: Type inference failed for: r1v17, types: [I.z0] */
    /* JADX WARN: Type inference failed for: r1v2, types: [I.r] */
    /* JADX WARN: Type inference failed for: r1v3 */
    /* JADX WARN: Type inference failed for: r1v33 */
    /* JADX WARN: Type inference failed for: r1v4 */
    /* JADX WARN: Type inference failed for: r1v40 */
    /* JADX WARN: Type inference failed for: r1v44 */
    /* JADX WARN: Type inference failed for: r1v45 */
    /* JADX WARN: Type inference failed for: r1v46 */
    /* JADX WARN: Type inference failed for: r1v47 */
    /* JADX WARN: Type inference failed for: r1v48 */
    /* JADX WARN: Type inference failed for: r1v5 */
    /* JADX WARN: Type inference failed for: r1v7 */
    /* JADX WARN: Type inference failed for: r1v8 */
    /* JADX WARN: Type inference failed for: r2v0 */
    /* JADX WARN: Type inference failed for: r2v1, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v2 */
    /* JADX WARN: Type inference failed for: r3v28 */
    /* JADX WARN: Type inference failed for: r3v29, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v30 */
    /* JADX WARN: Type inference failed for: r3v36 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final I.r f() {
        /*
            Method dump skipped, instruction units count: 453
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.AbstractC1853a.f():I.r");
    }

    public final boolean getHasComposition() {
        return this.f14022n != null;
    }

    public boolean getShouldCreateCompositionOnAttachedToWindow() {
        return true;
    }

    public final boolean getShowLayoutBounds() {
        return this.f14025q;
    }

    @Override // android.view.ViewGroup
    public final boolean isTransitionGroup() {
        return !this.f14027s || super.isTransitionGroup();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        setPreviousAttachedWindowToken(getWindowToken());
        if (getShouldCreateCompositionOnAttachedToWindow()) {
            c();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i5, int i6, int i7, int i8) {
        d(z3, i5, i6, i7, i8);
    }

    @Override // android.view.View
    public final void onMeasure(int i5, int i6) {
        c();
        e(i5, i6);
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i5) {
        View childAt = getChildAt(0);
        if (childAt == null) {
            return;
        }
        childAt.setLayoutDirection(i5);
    }

    public final void setParentCompositionContext(I.r rVar) {
        setParentContext(rVar);
    }

    public final void setShowLayoutBounds(boolean z3) {
        this.f14025q = z3;
        KeyEvent.Callback childAt = getChildAt(0);
        if (childAt != null) {
            ((C1889s) ((t0.g0) childAt)).setShowLayoutBounds(z3);
        }
    }

    @Override // android.view.ViewGroup
    public void setTransitionGroup(boolean z3) {
        super.setTransitionGroup(z3);
        this.f14027s = true;
    }

    public final void setViewCompositionStrategy(N0 n02) {
        A4.l lVar = this.f14024p;
        if (lVar != null) {
            lVar.b();
        }
        ((AbstractC1846K) n02).getClass();
        ViewOnAttachStateChangeListenerC1895v viewOnAttachStateChangeListenerC1895v = new ViewOnAttachStateChangeListenerC1895v(1, this);
        addOnAttachStateChangeListener(viewOnAttachStateChangeListenerC1895v);
        C0016q c0016q = new C0016q(21);
        E4.d.I(this).a.add(c0016q);
        this.f14024p = new A4.l(this, viewOnAttachStateChangeListenerC1895v, c0016q, 7);
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public AbstractC1853a(Context context, AttributeSet attributeSet, int i5) {
        super(context, attributeSet, i5);
        setClipChildren(false);
        setClipToPadding(false);
        ViewOnAttachStateChangeListenerC1895v viewOnAttachStateChangeListenerC1895v = new ViewOnAttachStateChangeListenerC1895v(1, this);
        addOnAttachStateChangeListener(viewOnAttachStateChangeListenerC1895v);
        C0016q c0016q = new C0016q(21);
        E4.d.I(this).a.add(c0016q);
        this.f14024p = new A4.l(this, viewOnAttachStateChangeListenerC1895v, c0016q, 7);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i5) {
        b();
        super.addView(view, i5);
    }

    @Override // android.view.ViewGroup
    public final boolean addViewInLayout(View view, int i5, ViewGroup.LayoutParams layoutParams, boolean z3) {
        b();
        return super.addViewInLayout(view, i5, layoutParams, z3);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i5, int i6) {
        b();
        super.addView(view, i5, i6);
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        b();
        super.addView(view, layoutParams);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i5, ViewGroup.LayoutParams layoutParams) {
        b();
        super.addView(view, i5, layoutParams);
    }

    private static /* synthetic */ void getDisposeViewCompositionStrategy$annotations() {
    }

    public static /* synthetic */ void getShowLayoutBounds$annotations() {
    }
}

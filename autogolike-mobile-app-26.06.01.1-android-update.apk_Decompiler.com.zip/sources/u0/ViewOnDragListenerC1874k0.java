package u0;

import U.p;
import android.view.DragEvent;
import android.view.View;
import androidx.compose.ui.platform.DragAndDropModifierOnDragListener$modifier$1;
import i.C1099a;
import i.C1104f;
import t0.AbstractC1800g;

/* JADX INFO: renamed from: u0.k0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class ViewOnDragListenerC1874k0 implements View.OnDragListener, X.a {
    public final X.d a = new X.d();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C1104f f14100b = new C1104f(0);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final DragAndDropModifierOnDragListener$modifier$1 f14101c = new t0.T() { // from class: androidx.compose.ui.platform.DragAndDropModifierOnDragListener$modifier$1
        public final boolean equals(Object obj) {
            return obj == this;
        }

        public final int hashCode() {
            return this.a.a.hashCode();
        }

        @Override // t0.T
        public final p j() {
            return this.a.a;
        }

        @Override // t0.T
        public final /* bridge */ /* synthetic */ void k(p pVar) {
        }
    };

    @Override // android.view.View.OnDragListener
    public final boolean onDrag(View view, DragEvent dragEvent) {
        C3.c cVar = new C3.c(21, dragEvent);
        int action = dragEvent.getAction();
        X.d dVar = this.a;
        t0.p0 p0Var = t0.p0.f13653l;
        switch (action) {
            case 1:
                U3.q qVar = new U3.q();
                X.c cVar2 = new X.c(cVar, dVar, qVar);
                if (cVar2.invoke(dVar) == p0Var) {
                    AbstractC1800g.z(dVar, cVar2);
                }
                boolean z3 = qVar.f6188l;
                C1104f c1104f = this.f14100b;
                c1104f.getClass();
                C1099a c1099a = new C1099a(c1104f);
                while (c1099a.hasNext()) {
                    ((X.d) c1099a.next()).E0(cVar);
                }
                break;
            case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                dVar.D0(cVar);
                break;
            case k1.h.LONG_FIELD_NUMBER /* 4 */:
                H0.I i5 = new H0.I(1, cVar);
                if (i5.invoke(dVar) == p0Var) {
                    AbstractC1800g.z(dVar, i5);
                    break;
                }
                break;
            case k1.h.STRING_FIELD_NUMBER /* 5 */:
                dVar.B0(cVar);
                break;
            case k1.h.STRING_SET_FIELD_NUMBER /* 6 */:
                dVar.C0(cVar);
                break;
        }
        return false;
    }
}

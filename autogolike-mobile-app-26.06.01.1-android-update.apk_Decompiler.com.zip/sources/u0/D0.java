package u0;

import C0.C0046a;
import a0.C0491b;
import a0.C0492c;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Build;
import b0.AbstractC0586d;
import b0.C0590h;
import b0.C0600s;
import e0.C0844b;
import s.C1703N;

/* JADX INFO: loaded from: classes.dex */
public final class D0 implements t0.f0 {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final C1889s f13916l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public C0046a f13917m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public C1703N f13918n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f13919o;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f13921q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f13922r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public C0590h f13923s;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final InterfaceC1868h0 f13927w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f13928x;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final C1896v0 f13920p = new C1896v0();

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final C1890s0 f13924t = new C1890s0(C1838C.f13879o);

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final C0600s f13925u = new C0600s();

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public long f13926v = b0.X.f7952b;

    public D0(C1889s c1889s, C0046a c0046a, C1703N c1703n) {
        this.f13916l = c1889s;
        this.f13917m = c0046a;
        this.f13918n = c1703n;
        InterfaceC1868h0 b02 = Build.VERSION.SDK_INT >= 29 ? new B0() : new C1904z0(c1889s);
        b02.I();
        b02.E(false);
        this.f13927w = b02;
    }

    @Override // t0.f0
    public final void a(float[] fArr) {
        float[] fArrA = this.f13924t.a(this.f13927w);
        if (fArrA != null) {
            b0.H.g(fArr, fArrA);
        }
    }

    @Override // t0.f0
    public final void b(C0491b c0491b, boolean z3) {
        InterfaceC1868h0 interfaceC1868h0 = this.f13927w;
        C1890s0 c1890s0 = this.f13924t;
        if (!z3) {
            b0.H.c(c1890s0.b(interfaceC1868h0), c0491b);
            return;
        }
        float[] fArrA = c1890s0.a(interfaceC1868h0);
        if (fArrA != null) {
            b0.H.c(fArrA, c0491b);
            return;
        }
        c0491b.a = 0.0f;
        c0491b.f7212b = 0.0f;
        c0491b.f7213c = 0.0f;
        c0491b.f7214d = 0.0f;
    }

    @Override // t0.f0
    public final void c() {
        InterfaceC1868h0 interfaceC1868h0 = this.f13927w;
        if (interfaceC1868h0.l()) {
            interfaceC1868h0.o();
        }
        this.f13917m = null;
        this.f13918n = null;
        this.f13921q = true;
        m(false);
        C1889s c1889s = this.f13916l;
        c1889s.f14164J = true;
        c1889s.C(this);
    }

    @Override // t0.f0
    public final void d(long j5) {
        InterfaceC1868h0 interfaceC1868h0 = this.f13927w;
        int iA = interfaceC1868h0.A();
        int iZ = interfaceC1868h0.z();
        int i5 = (int) (j5 >> 32);
        int i6 = (int) (j5 & 4294967295L);
        if (iA == i5 && iZ == i6) {
            return;
        }
        if (iA != i5) {
            interfaceC1868h0.r(i5 - iA);
        }
        if (iZ != i6) {
            interfaceC1868h0.v(i6 - iZ);
        }
        int i7 = Build.VERSION.SDK_INT;
        C1889s c1889s = this.f13916l;
        if (i7 >= 26) {
            k1.a.a(c1889s);
        } else {
            c1889s.invalidate();
        }
        this.f13924t.c();
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x001e  */
    @Override // t0.f0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void e() {
        /*
            r5 = this;
            boolean r0 = r5.f13919o
            u0.h0 r1 = r5.f13927w
            if (r0 != 0) goto Lc
            boolean r0 = r1.l()
            if (r0 != 0) goto L32
        Lc:
            boolean r0 = r1.u()
            if (r0 == 0) goto L1e
            u0.v0 r0 = r5.f13920p
            boolean r2 = r0.f14232g
            if (r2 == 0) goto L1e
            r0.d()
            b0.M r0 = r0.f14230e
            goto L1f
        L1e:
            r0 = 0
        L1f:
            C0.a r2 = r5.f13917m
            if (r2 == 0) goto L2e
            t0.a r3 = new t0.a
            r4 = 5
            r3.<init>(r4, r2)
            b0.s r2 = r5.f13925u
            r1.x(r2, r0, r3)
        L2e:
            r0 = 0
            r5.m(r0)
        L32:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.D0.e():void");
    }

    @Override // t0.f0
    public final void f(long j5) {
        int i5 = (int) (j5 >> 32);
        int i6 = (int) (j5 & 4294967295L);
        float fB = b0.X.b(this.f13926v) * i5;
        InterfaceC1868h0 interfaceC1868h0 = this.f13927w;
        interfaceC1868h0.D(fB);
        interfaceC1868h0.p(b0.X.c(this.f13926v) * i6);
        if (interfaceC1868h0.H(interfaceC1868h0.A(), interfaceC1868h0.z(), interfaceC1868h0.A() + i5, interfaceC1868h0.z() + i6)) {
            interfaceC1868h0.F(this.f13920p.b());
            if (!this.f13919o && !this.f13921q) {
                this.f13916l.invalidate();
                m(true);
            }
            this.f13924t.c();
        }
    }

    @Override // t0.f0
    public final void g(b0.r rVar, C0844b c0844b) {
        Canvas canvasA = AbstractC0586d.a(rVar);
        boolean zIsHardwareAccelerated = canvasA.isHardwareAccelerated();
        InterfaceC1868h0 interfaceC1868h0 = this.f13927w;
        if (zIsHardwareAccelerated) {
            e();
            boolean z3 = interfaceC1868h0.K() > 0.0f;
            this.f13922r = z3;
            if (z3) {
                rVar.q();
            }
            interfaceC1868h0.y(canvasA);
            if (this.f13922r) {
                rVar.h();
                return;
            }
            return;
        }
        float fA = interfaceC1868h0.A();
        float fZ = interfaceC1868h0.z();
        float fT = interfaceC1868h0.t();
        float fS = interfaceC1868h0.s();
        if (interfaceC1868h0.a() < 1.0f) {
            C0590h c0590hG = this.f13923s;
            if (c0590hG == null) {
                c0590hG = b0.N.g();
                this.f13923s = c0590hG;
            }
            c0590hG.c(interfaceC1868h0.a());
            canvasA.saveLayer(fA, fZ, fT, fS, (Paint) c0590hG.f7959b);
        } else {
            rVar.f();
        }
        rVar.t(fA, fZ);
        rVar.o(this.f13924t.b(interfaceC1868h0));
        if (interfaceC1868h0.u() || interfaceC1868h0.w()) {
            this.f13920p.a(rVar);
        }
        C0046a c0046a = this.f13917m;
        if (c0046a != null) {
            c0046a.i(rVar, null);
        }
        rVar.a();
        m(false);
    }

    @Override // t0.f0
    public final void h(float[] fArr) {
        b0.H.g(fArr, this.f13924t.b(this.f13927w));
    }

    @Override // t0.f0
    public final long i(boolean z3, long j5) {
        InterfaceC1868h0 interfaceC1868h0 = this.f13927w;
        C1890s0 c1890s0 = this.f13924t;
        if (!z3) {
            return b0.H.b(j5, c1890s0.b(interfaceC1868h0));
        }
        float[] fArrA = c1890s0.a(interfaceC1868h0);
        if (fArrA != null) {
            return b0.H.b(j5, fArrA);
        }
        return 9187343241974906880L;
    }

    @Override // t0.f0
    public final void invalidate() {
        if (this.f13919o || this.f13921q) {
            return;
        }
        this.f13916l.invalidate();
        m(true);
    }

    @Override // t0.f0
    public final boolean j(long j5) {
        b0.L l4;
        float fD = C0492c.d(j5);
        float fE = C0492c.e(j5);
        InterfaceC1868h0 interfaceC1868h0 = this.f13927w;
        if (interfaceC1868h0.w()) {
            return 0.0f <= fD && fD < ((float) interfaceC1868h0.f()) && 0.0f <= fE && fE < ((float) interfaceC1868h0.h());
        }
        if (!interfaceC1868h0.u()) {
            return true;
        }
        C1896v0 c1896v0 = this.f13920p;
        if (c1896v0.f14238m && (l4 = c1896v0.f14228c) != null) {
            return AbstractC1846K.s(l4, C0492c.d(j5), C0492c.e(j5), null, null);
        }
        return true;
    }

    @Override // t0.f0
    public final void k(b0.P p4) {
        C1703N c1703n;
        int i5 = p4.f7919l | this.f13928x;
        int i6 = i5 & 4096;
        if (i6 != 0) {
            this.f13926v = p4.f7932y;
        }
        InterfaceC1868h0 interfaceC1868h0 = this.f13927w;
        boolean zU = interfaceC1868h0.u();
        C1896v0 c1896v0 = this.f13920p;
        boolean z3 = false;
        boolean z5 = zU && c1896v0.f14232g;
        if ((i5 & 1) != 0) {
            interfaceC1868h0.m(p4.f7920m);
        }
        if ((i5 & 2) != 0) {
            interfaceC1868h0.e(p4.f7921n);
        }
        if ((i5 & 4) != 0) {
            interfaceC1868h0.d(p4.f7922o);
        }
        if ((i5 & 8) != 0) {
            interfaceC1868h0.c(p4.f7923p);
        }
        if ((i5 & 16) != 0) {
            interfaceC1868h0.j(p4.f7924q);
        }
        if ((i5 & 32) != 0) {
            interfaceC1868h0.q(p4.f7925r);
        }
        if ((i5 & 64) != 0) {
            interfaceC1868h0.L(b0.N.E(p4.f7926s));
        }
        if ((i5 & 128) != 0) {
            interfaceC1868h0.G(b0.N.E(p4.f7927t));
        }
        if ((i5 & 1024) != 0) {
            interfaceC1868h0.i(p4.f7930w);
        }
        if ((i5 & 256) != 0) {
            interfaceC1868h0.n(p4.f7928u);
        }
        if ((i5 & 512) != 0) {
            interfaceC1868h0.b(p4.f7929v);
        }
        if ((i5 & 2048) != 0) {
            interfaceC1868h0.k(p4.f7931x);
        }
        if (i6 != 0) {
            interfaceC1868h0.D(b0.X.b(this.f13926v) * interfaceC1868h0.f());
            interfaceC1868h0.p(b0.X.c(this.f13926v) * interfaceC1868h0.h());
        }
        boolean z6 = p4.f7916A;
        Q2.j jVar = b0.N.a;
        boolean z7 = z6 && p4.f7933z != jVar;
        if ((i5 & 24576) != 0) {
            interfaceC1868h0.B(z7);
            interfaceC1868h0.E(p4.f7916A && p4.f7933z == jVar);
        }
        if ((131072 & i5) != 0) {
            interfaceC1868h0.g();
        }
        if ((32768 & i5) != 0) {
            interfaceC1868h0.C(p4.B);
        }
        boolean zC = this.f13920p.c(p4.f7918F, p4.f7922o, z7, p4.f7925r, p4.C);
        if (c1896v0.f14231f) {
            interfaceC1868h0.F(c1896v0.b());
        }
        if (z7 && c1896v0.f14232g) {
            z3 = true;
        }
        C1889s c1889s = this.f13916l;
        if (z5 != z3 || (z3 && zC)) {
            if (!this.f13919o && !this.f13921q) {
                c1889s.invalidate();
                m(true);
            }
        } else if (Build.VERSION.SDK_INT >= 26) {
            k1.a.a(c1889s);
        } else {
            c1889s.invalidate();
        }
        if (!this.f13922r && interfaceC1868h0.K() > 0.0f && (c1703n = this.f13918n) != null) {
            c1703n.b();
        }
        if ((i5 & 7963) != 0) {
            this.f13924t.c();
        }
        this.f13928x = p4.f7919l;
    }

    @Override // t0.f0
    public final void l(C0046a c0046a, C1703N c1703n) {
        m(false);
        this.f13921q = false;
        this.f13922r = false;
        this.f13926v = b0.X.f7952b;
        this.f13917m = c0046a;
        this.f13918n = c1703n;
    }

    public final void m(boolean z3) {
        if (z3 != this.f13919o) {
            this.f13919o = z3;
            this.f13916l.u(this, z3);
        }
    }
}

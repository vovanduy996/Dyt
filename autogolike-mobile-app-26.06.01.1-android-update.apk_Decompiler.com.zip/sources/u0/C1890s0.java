package u0;

import android.graphics.Matrix;

/* JADX INFO: renamed from: u0.s0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1890s0 {
    public final U3.k a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Matrix f14217b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Matrix f14218c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float[] f14219d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float[] f14220e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f14221f = true;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f14222g = true;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f14223h = true;

    /* JADX WARN: Multi-variable type inference failed */
    public C1890s0(T3.e eVar) {
        this.a = (U3.k) eVar;
    }

    public final float[] a(Object obj) {
        float[] fArrA = this.f14220e;
        if (fArrA == null) {
            fArrA = b0.H.a();
            this.f14220e = fArrA;
        }
        if (this.f14222g) {
            this.f14223h = AbstractC1846K.q(b(obj), fArrA);
            this.f14222g = false;
        }
        if (this.f14223h) {
            return fArrA;
        }
        return null;
    }

    /* JADX WARN: Type inference failed for: r2v0, types: [T3.e, U3.k] */
    public final float[] b(Object obj) {
        float[] fArrA = this.f14219d;
        if (fArrA == null) {
            fArrA = b0.H.a();
            this.f14219d = fArrA;
        }
        if (!this.f14221f) {
            return fArrA;
        }
        Matrix matrix = this.f14217b;
        if (matrix == null) {
            matrix = new Matrix();
            this.f14217b = matrix;
        }
        this.a.i(obj, matrix);
        Matrix matrix2 = this.f14218c;
        if (matrix2 == null || !matrix.equals(matrix2)) {
            b0.N.z(matrix, fArrA);
            this.f14217b = matrix2;
            this.f14218c = matrix;
        }
        this.f14221f = false;
        return fArrA;
    }

    public final void c() {
        this.f14221f = true;
        this.f14222g = true;
    }
}

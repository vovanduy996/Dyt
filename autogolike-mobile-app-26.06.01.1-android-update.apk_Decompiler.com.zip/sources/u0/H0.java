package u0;

import i.AbstractC1109k;
import i.C1116r;
import i.C1117s;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class H0 {
    public final A0.i a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C1117s f13935b;

    public H0(A0.o oVar, C1116r c1116r) {
        this.a = oVar.f237d;
        int[] iArr = AbstractC1109k.a;
        this.f13935b = new C1117s();
        List listH = A0.o.h(oVar, true, 4);
        int size = listH.size();
        for (int i5 = 0; i5 < size; i5++) {
            A0.o oVar2 = (A0.o) listH.get(i5);
            if (c1116r.b(oVar2.f240g)) {
                this.f13935b.a(oVar2.f240g);
            }
        }
    }
}

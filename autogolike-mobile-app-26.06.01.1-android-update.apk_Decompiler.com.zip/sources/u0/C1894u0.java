package u0;

import android.view.MotionEvent;

/* JADX INFO: renamed from: u0.u0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1894u0 {
    public static final C1894u0 a = new C1894u0();

    public final boolean a(MotionEvent motionEvent, int i5) {
        float rawX = motionEvent.getRawX(i5);
        if (!Float.isInfinite(rawX) && !Float.isNaN(rawX)) {
            float rawY = motionEvent.getRawY(i5);
            if (!Float.isInfinite(rawY) && !Float.isNaN(rawY)) {
                return true;
            }
        }
        return false;
    }
}

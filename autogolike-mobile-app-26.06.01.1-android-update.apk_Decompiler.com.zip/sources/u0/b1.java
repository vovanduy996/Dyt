package u0;

import G3.AbstractC0164a;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: loaded from: classes.dex */
public final class b1 extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f14030p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ i4.a0 f14031q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ C1892t0 f14032r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b1(i4.a0 a0Var, C1892t0 c1892t0, Continuation continuation) {
        super(2, continuation);
        this.f14031q = a0Var;
        this.f14032r = c1892t0;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        ((b1) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
        return L3.a.f4629l;
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new b1(this.f14031q, this.f14032r, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f14030p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            F2.k kVar = new F2.k(9, this.f14032r);
            this.f14030p = 1;
            if (this.f14031q.d(kVar, this) == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        throw new G3.f();
    }
}

package u0;

import a0.C0493d;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import f4.InterfaceC0991y;
import l0.C1317a;

/* JADX INFO: renamed from: u0.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1881o extends U3.k implements T3.c {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f14117l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ C1889s f14118m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C1881o(C1889s c1889s, int i5) {
        super(1);
        this.f14117l = i5;
        this.f14118m = c1889s;
    }

    @Override // T3.c
    public final Object invoke(Object obj) {
        Z.b bVar;
        switch (this.f14117l) {
            case ConfigBackupDto.$stable /* 0 */:
                KeyEvent keyEvent = ((l0.b) obj).a;
                C1889s c1889s = this.f14118m;
                c1889s.getClass();
                long jK0 = l0.c.k0(keyEvent);
                if (C1317a.a(jK0, C1317a.f11429h)) {
                    bVar = new Z.b(keyEvent.isShiftPressed() ? 2 : 1);
                } else if (C1317a.a(jK0, C1317a.f11427f)) {
                    bVar = new Z.b(4);
                } else if (C1317a.a(jK0, C1317a.f11426e)) {
                    bVar = new Z.b(3);
                } else {
                    bVar = C1317a.a(jK0, C1317a.f11424c) ? true : C1317a.a(jK0, C1317a.f11432k) ? new Z.b(5) : C1317a.a(jK0, C1317a.f11425d) ? true : C1317a.a(jK0, C1317a.f11433l) ? new Z.b(6) : C1317a.a(jK0, C1317a.f11428g) ? true : C1317a.a(jK0, C1317a.f11430i) ? true : C1317a.a(jK0, C1317a.f11434m) ? new Z.b(7) : C1317a.a(jK0, C1317a.f11423b) ? true : C1317a.a(jK0, C1317a.f11431j) ? new Z.b(8) : null;
                }
                if (bVar == null || !V2.a.D(l0.c.m0(keyEvent), 2)) {
                    return Boolean.FALSE;
                }
                C0493d c0493dW = c1889s.w();
                Z.g focusOwner = c1889s.getFocusOwner();
                C1879n c1879n = new C1879n(bVar, 1);
                int i5 = bVar.a;
                Boolean boolC = ((androidx.compose.ui.focus.b) focusOwner).c(i5, c0493dW, c1879n);
                if (boolC != null ? boolC.booleanValue() : true) {
                    return Boolean.TRUE;
                }
                if (!(Z.b.a(i5, 1) ? true : Z.b.a(i5, 2))) {
                    return Boolean.FALSE;
                }
                Integer numJ = Z.d.J(i5);
                if (numJ == null) {
                    throw new IllegalStateException("Invalid focus direction");
                }
                int iIntValue = numJ.intValue();
                Rect rectC = c0493dW != null ? b0.N.C(c0493dW) : null;
                if (rectC == null) {
                    throw new IllegalStateException("Invalid rect");
                }
                View viewFindNextFocus = c1889s;
                while (true) {
                    if (viewFindNextFocus != null) {
                        FocusFinder focusFinder = FocusFinder.getInstance();
                        View rootView = c1889s.getRootView();
                        U3.j.d(rootView, "null cannot be cast to non-null type android.view.ViewGroup");
                        viewFindNextFocus = focusFinder.findNextFocus((ViewGroup) rootView, viewFindNextFocus, iIntValue);
                        if (viewFindNextFocus != null) {
                            if (!viewFindNextFocus.equals(c1889s)) {
                                for (ViewParent parent = viewFindNextFocus.getParent(); parent != null; parent = parent.getParent()) {
                                    if (parent == c1889s) {
                                    }
                                    break;
                                }
                            }
                        }
                    } else {
                        viewFindNextFocus = null;
                    }
                }
                if (U3.j.a(viewFindNextFocus, c1889s)) {
                    viewFindNextFocus = null;
                }
                if (viewFindNextFocus != null && Z.d.E(viewFindNextFocus, Integer.valueOf(iIntValue), rectC)) {
                    return Boolean.TRUE;
                }
                if (!((androidx.compose.ui.focus.b) c1889s.getFocusOwner()).a(i5, false, false)) {
                    return Boolean.TRUE;
                }
                Boolean boolC2 = ((androidx.compose.ui.focus.b) c1889s.getFocusOwner()).c(i5, null, new C1879n(bVar, 0));
                return Boolean.valueOf(boolC2 != null ? boolC2.booleanValue() : true);
            case 1:
                T3.a aVar = (T3.a) obj;
                C1889s c1889s2 = this.f14118m;
                Handler handler = c1889s2.getHandler();
                if ((handler != null ? handler.getLooper() : null) == Looper.myLooper()) {
                    aVar.b();
                } else {
                    Handler handler2 = c1889s2.getHandler();
                    if (handler2 != null) {
                        handler2.post(new R0.z(aVar, 1));
                    }
                }
                return G3.C.a;
            default:
                C1889s c1889s3 = this.f14118m;
                return new C1852Q(c1889s3, c1889s3.getTextInputService(), (InterfaceC0991y) obj);
        }
    }
}

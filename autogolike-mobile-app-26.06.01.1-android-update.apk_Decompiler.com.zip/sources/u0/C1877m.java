package u0;

/* JADX INFO: renamed from: u0.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1877m extends U3.k implements T3.c {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final C1877m f14104m = new C1877m(1, 0);

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final C1877m f14105n = new C1877m(1, 1);

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final C1877m f14106o = new C1877m(1, 2);

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final C1877m f14107p = new C1877m(1, 3);

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final C1877m f14108q = new C1877m(1, 4);

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f14109l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C1877m(int i5, int i6) {
        super(i5);
        this.f14109l = i6;
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x0026  */
    @Override // T3.c
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object invoke(java.lang.Object r3) {
        /*
            r2 = this;
            int r0 = r2.f14109l
            switch(r0) {
                case 0: goto L36;
                case 1: goto L31;
                case 2: goto L2c;
                case 3: goto Le;
                default: goto L5;
            }
        L5:
            boolean r3 = u0.AbstractC1846K.l(r3)
            java.lang.Boolean r3 = java.lang.Boolean.valueOf(r3)
            return r3
        Le:
            t0.E r3 = (t0.E) r3
            A0.i r3 = r3.o()
            if (r3 == 0) goto L26
            boolean r0 = r3.f227m
            r1 = 1
            if (r0 != r1) goto L26
            A0.u r0 = A0.r.f281x
            java.util.LinkedHashMap r3 = r3.f226l
            boolean r3 = r3.containsKey(r0)
            if (r3 == 0) goto L26
            goto L27
        L26:
            r1 = 0
        L27:
            java.lang.Boolean r3 = java.lang.Boolean.valueOf(r1)
            return r3
        L2c:
            p0.b r3 = (p0.AbstractC1555b) r3
            java.lang.Boolean r3 = java.lang.Boolean.FALSE
            return r3
        L31:
            Z.r r3 = (Z.r) r3
            java.lang.Boolean r3 = java.lang.Boolean.TRUE
            return r3
        L36:
            android.content.res.Configuration r3 = (android.content.res.Configuration) r3
            G3.C r3 = G3.C.a
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.C1877m.invoke(java.lang.Object):java.lang.Object");
    }
}

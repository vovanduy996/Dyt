package u0;

import android.view.View;

/* JADX INFO: renamed from: u0.J, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1845J {
    public static final C1845J a = new C1845J();

    public final void a(View view, int i5, boolean z3) {
        view.setFocusable(i5);
        view.setDefaultFocusHighlightEnabled(z3);
    }
}

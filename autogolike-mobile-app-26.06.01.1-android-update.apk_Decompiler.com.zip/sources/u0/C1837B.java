package u0;

import com.autogolike.mobile.core.backup.ConfigBackupDto;
import java.util.Comparator;

/* JADX INFO: renamed from: u0.B, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1837B implements Comparator {
    public final /* synthetic */ int a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Comparator f13876b;

    public C1837B(Comparator comparator) {
        this.f13876b = comparator;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        switch (this.a) {
            case ConfigBackupDto.$stable /* 0 */:
                int iCompare = this.f13876b.compare(obj, obj2);
                if (iCompare != 0) {
                    return iCompare;
                }
                return t0.E.f13432T.compare(((A0.o) obj).f236c, ((A0.o) obj2).f236c);
            default:
                int iCompare2 = ((C1837B) this.f13876b).compare(obj, obj2);
                return iCompare2 != 0 ? iCompare2 : V2.a.y(Integer.valueOf(((A0.o) obj).f240g), Integer.valueOf(((A0.o) obj2).f240g));
        }
    }

    public C1837B(C1837B c1837b) {
        this.f13876b = c1837b;
    }
}

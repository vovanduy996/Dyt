package u0;

import I.C0251l0;
import I.C0278z0;
import android.view.View;
import androidx.lifecycle.EnumC0569n;
import androidx.lifecycle.InterfaceC0574t;
import androidx.lifecycle.InterfaceC0576v;
import f4.AbstractC0952A;
import f4.C0978k;
import f4.EnumC0992z;
import f4.InterfaceC0977j;
import java.util.ArrayList;
import k4.C1258c;
import kotlin.coroutines.Continuation;

/* JADX INFO: loaded from: classes.dex */
public final class d1 implements InterfaceC0574t {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ C1258c f14048l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ C0251l0 f14049m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ C0278z0 f14050n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ U3.u f14051o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ View f14052p;

    public d1(C1258c c1258c, C0251l0 c0251l0, C0278z0 c0278z0, U3.u uVar, View view) {
        this.f14048l = c1258c;
        this.f14049m = c0251l0;
        this.f14050n = c0278z0;
        this.f14051o = uVar;
        this.f14052p = view;
    }

    @Override // androidx.lifecycle.InterfaceC0574t
    public final void onStateChanged(InterfaceC0576v interfaceC0576v, EnumC0569n enumC0569n) {
        boolean z3;
        int i5 = a1.a[enumC0569n.ordinal()];
        InterfaceC0977j interfaceC0977jT = null;
        if (i5 == 1) {
            AbstractC0952A.s(this.f14048l, null, EnumC0992z.f9859o, new c1(this.f14051o, this.f14050n, interfaceC0576v, this, this.f14052p, null), 1);
            return;
        }
        if (i5 != 2) {
            if (i5 != 3) {
                if (i5 != 4) {
                    return;
                }
                this.f14050n.s();
                return;
            } else {
                C0278z0 c0278z0 = this.f14050n;
                synchronized (c0278z0.f3778b) {
                    c0278z0.f3793q = true;
                }
                return;
            }
        }
        C0251l0 c0251l0 = this.f14049m;
        if (c0251l0 != null) {
            I.S s3 = (I.S) c0251l0.f3641n;
            synchronized (s3.f3570b) {
                try {
                    synchronized (s3.f3570b) {
                        z3 = s3.a;
                    }
                    if (!z3) {
                        ArrayList arrayList = (ArrayList) s3.f3571c;
                        s3.f3571c = (ArrayList) s3.f3572d;
                        s3.f3572d = arrayList;
                        s3.a = true;
                        int size = arrayList.size();
                        for (int i6 = 0; i6 < size; i6++) {
                            ((Continuation) arrayList.get(i6)).p(G3.C.a);
                        }
                        arrayList.clear();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        C0278z0 c0278z02 = this.f14050n;
        synchronized (c0278z02.f3778b) {
            if (c0278z02.f3793q) {
                c0278z02.f3793q = false;
                interfaceC0977jT = c0278z02.t();
            }
        }
        if (interfaceC0977jT != null) {
            ((C0978k) interfaceC0977jT).p(G3.C.a);
        }
    }
}

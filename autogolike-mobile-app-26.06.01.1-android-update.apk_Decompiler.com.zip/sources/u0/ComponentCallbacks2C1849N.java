package u0;

import android.content.ComponentCallbacks2;
import android.content.res.Configuration;
import y0.C2076d;

/* JADX INFO: renamed from: u0.N, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class ComponentCallbacks2C1849N implements ComponentCallbacks2 {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ C2076d f13968l;

    public ComponentCallbacks2C1849N(C2076d c2076d) {
        this.f13968l = c2076d;
    }

    @Override // android.content.ComponentCallbacks
    public final void onConfigurationChanged(Configuration configuration) {
        C2076d c2076d = this.f13968l;
        synchronized (c2076d) {
            c2076d.a.a();
        }
    }

    @Override // android.content.ComponentCallbacks
    public final void onLowMemory() {
        C2076d c2076d = this.f13968l;
        synchronized (c2076d) {
            c2076d.a.a();
        }
    }

    @Override // android.content.ComponentCallbacks2
    public final void onTrimMemory(int i5) {
        C2076d c2076d = this.f13968l;
        synchronized (c2076d) {
            c2076d.a.a();
        }
    }
}

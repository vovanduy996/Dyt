package u0;

import android.view.View;

/* JADX INFO: renamed from: u0.a0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC1854a0 {
    void a(View view, float[] fArr);
}

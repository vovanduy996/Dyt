package u0;

import android.R;
import java.util.LinkedHashMap;

/* JADX INFO: renamed from: u0.x, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1899x {
    public static final void a(d1.h hVar, A0.o oVar) {
        if (AbstractC1846K.j(oVar)) {
            A0.u uVar = A0.h.f222w;
            LinkedHashMap linkedHashMap = oVar.f237d.f226l;
            Object obj = linkedHashMap.get(uVar);
            if (obj == null) {
                obj = null;
            }
            A0.a aVar = (A0.a) obj;
            if (aVar != null) {
                hVar.a(new d1.c(null, R.id.accessibilityActionPageUp, aVar.a, null));
            }
            Object obj2 = linkedHashMap.get(A0.h.f224y);
            if (obj2 == null) {
                obj2 = null;
            }
            A0.a aVar2 = (A0.a) obj2;
            if (aVar2 != null) {
                hVar.a(new d1.c(null, R.id.accessibilityActionPageDown, aVar2.a, null));
            }
            Object obj3 = linkedHashMap.get(A0.h.f223x);
            if (obj3 == null) {
                obj3 = null;
            }
            A0.a aVar3 = (A0.a) obj3;
            if (aVar3 != null) {
                hVar.a(new d1.c(null, R.id.accessibilityActionPageLeft, aVar3.a, null));
            }
            Object obj4 = linkedHashMap.get(A0.h.f225z);
            if (obj4 == null) {
                obj4 = null;
            }
            A0.a aVar4 = (A0.a) obj4;
            if (aVar4 != null) {
                hVar.a(new d1.c(null, R.id.accessibilityActionPageRight, aVar4.a, null));
            }
        }
    }
}

package u0;

import com.autogolike.mobile.core.backup.ConfigBackupDto;

/* JADX INFO: renamed from: u0.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1879n extends U3.k implements T3.c {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f14114l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Z.b f14115m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C1879n(Z.b bVar, int i5) {
        super(1);
        this.f14114l = i5;
        this.f14115m = bVar;
    }

    @Override // T3.c
    public final Object invoke(Object obj) {
        switch (this.f14114l) {
            case ConfigBackupDto.$stable /* 0 */:
                Boolean boolC = Z.d.C((Z.r) obj, this.f14115m.a);
                return Boolean.valueOf(boolC != null ? boolC.booleanValue() : true);
            default:
                Boolean boolC2 = Z.d.C((Z.r) obj, this.f14115m.a);
                return Boolean.valueOf(boolC2 != null ? boolC2.booleanValue() : true);
        }
    }
}

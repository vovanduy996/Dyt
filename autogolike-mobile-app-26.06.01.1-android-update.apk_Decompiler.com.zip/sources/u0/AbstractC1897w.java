package u0;

import android.R;

/* JADX INFO: renamed from: u0.w, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1897w {
    public static final void a(d1.h hVar, A0.o oVar) {
        if (AbstractC1846K.j(oVar)) {
            Object obj = oVar.f237d.f226l.get(A0.h.f206g);
            if (obj == null) {
                obj = null;
            }
            A0.a aVar = (A0.a) obj;
            if (aVar != null) {
                hVar.a(new d1.c(null, R.id.accessibilityActionSetProgress, aVar.a, null));
            }
        }
    }
}

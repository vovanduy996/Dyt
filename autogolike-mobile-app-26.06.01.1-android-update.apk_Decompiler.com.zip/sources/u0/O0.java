package u0;

/* JADX INFO: loaded from: classes.dex */
public interface O0 {
    float a();

    default float b() {
        return 2.0f;
    }

    default float c() {
        return 16.0f;
    }

    default float d() {
        return Float.MAX_VALUE;
    }

    long e();

    long f();

    default long g() {
        float f5 = 48;
        return l0.c.t(f5, f5);
    }
}

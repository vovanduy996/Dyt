package u0;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.RecordingCanvas;
import android.graphics.RenderNode;
import android.os.Build;
import b0.C0585c;
import b0.C0600s;
import t0.C1794a;

/* JADX INFO: loaded from: classes.dex */
public final class B0 implements InterfaceC1868h0 {
    public final RenderNode a = A0.c();

    @Override // u0.InterfaceC1868h0
    public final int A() {
        return this.a.getLeft();
    }

    @Override // u0.InterfaceC1868h0
    public final void B(boolean z3) {
        this.a.setClipToOutline(z3);
    }

    @Override // u0.InterfaceC1868h0
    public final void C(int i5) {
        RenderNode renderNode = this.a;
        if (b0.N.q(i5, 1)) {
            renderNode.setUseCompositingLayer(true, null);
            renderNode.setHasOverlappingRendering(true);
        } else if (b0.N.q(i5, 2)) {
            renderNode.setUseCompositingLayer(false, null);
            renderNode.setHasOverlappingRendering(false);
        } else {
            renderNode.setUseCompositingLayer(false, null);
            renderNode.setHasOverlappingRendering(true);
        }
    }

    @Override // u0.InterfaceC1868h0
    public final void D(float f5) {
        this.a.setPivotX(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void E(boolean z3) {
        this.a.setClipToBounds(z3);
    }

    @Override // u0.InterfaceC1868h0
    public final void F(Outline outline) {
        this.a.setOutline(outline);
    }

    @Override // u0.InterfaceC1868h0
    public final void G(int i5) {
        this.a.setSpotShadowColor(i5);
    }

    @Override // u0.InterfaceC1868h0
    public final boolean H(int i5, int i6, int i7, int i8) {
        return this.a.setPosition(i5, i6, i7, i8);
    }

    @Override // u0.InterfaceC1868h0
    public final boolean I() {
        return this.a.setHasOverlappingRendering(true);
    }

    @Override // u0.InterfaceC1868h0
    public final void J(Matrix matrix) {
        this.a.getMatrix(matrix);
    }

    @Override // u0.InterfaceC1868h0
    public final float K() {
        return this.a.getElevation();
    }

    @Override // u0.InterfaceC1868h0
    public final void L(int i5) {
        this.a.setAmbientShadowColor(i5);
    }

    @Override // u0.InterfaceC1868h0
    public final float a() {
        return this.a.getAlpha();
    }

    @Override // u0.InterfaceC1868h0
    public final void b(float f5) {
        this.a.setRotationY(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void c(float f5) {
        this.a.setTranslationX(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void d(float f5) {
        this.a.setAlpha(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void e(float f5) {
        this.a.setScaleY(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final int f() {
        return this.a.getWidth();
    }

    @Override // u0.InterfaceC1868h0
    public final void g() {
        if (Build.VERSION.SDK_INT >= 31) {
            C0.a.a(this.a, null);
        }
    }

    @Override // u0.InterfaceC1868h0
    public final int h() {
        return this.a.getHeight();
    }

    @Override // u0.InterfaceC1868h0
    public final void i(float f5) {
        this.a.setRotationZ(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void j(float f5) {
        this.a.setTranslationY(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void k(float f5) {
        this.a.setCameraDistance(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final boolean l() {
        return this.a.hasDisplayList();
    }

    @Override // u0.InterfaceC1868h0
    public final void m(float f5) {
        this.a.setScaleX(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void n(float f5) {
        this.a.setRotationX(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void o() {
        this.a.discardDisplayList();
    }

    @Override // u0.InterfaceC1868h0
    public final void p(float f5) {
        this.a.setPivotY(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void q(float f5) {
        this.a.setElevation(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void r(int i5) {
        this.a.offsetLeftAndRight(i5);
    }

    @Override // u0.InterfaceC1868h0
    public final int s() {
        return this.a.getBottom();
    }

    @Override // u0.InterfaceC1868h0
    public final int t() {
        return this.a.getRight();
    }

    @Override // u0.InterfaceC1868h0
    public final boolean u() {
        return this.a.getClipToOutline();
    }

    @Override // u0.InterfaceC1868h0
    public final void v(int i5) {
        this.a.offsetTopAndBottom(i5);
    }

    @Override // u0.InterfaceC1868h0
    public final boolean w() {
        return this.a.getClipToBounds();
    }

    @Override // u0.InterfaceC1868h0
    public final void x(C0600s c0600s, b0.M m5, C1794a c1794a) {
        RecordingCanvas recordingCanvasBeginRecording = this.a.beginRecording();
        C0585c c0585c = c0600s.a;
        Canvas canvas = c0585c.a;
        c0585c.a = recordingCanvasBeginRecording;
        if (m5 != null) {
            c0585c.f();
            c0585c.i(m5, 1);
        }
        c1794a.invoke(c0585c);
        if (m5 != null) {
            c0585c.a();
        }
        c0600s.a.a = canvas;
        this.a.endRecording();
    }

    @Override // u0.InterfaceC1868h0
    public final void y(Canvas canvas) {
        canvas.drawRenderNode(this.a);
    }

    @Override // u0.InterfaceC1868h0
    public final int z() {
        return this.a.getTop();
    }
}

package u0;

/* JADX INFO: loaded from: classes.dex */
public interface L0 {
}

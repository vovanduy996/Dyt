package u0;

import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: renamed from: u0.m0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1878m0 extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public h4.u f14110p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public h4.c f14111q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f14112r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ h4.g f14113s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1878m0(h4.g gVar, Continuation continuation) {
        super(2, continuation);
        this.f14113s = gVar;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C1878m0) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new C1878m0(this.f14113s, continuation);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0033 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:19:0x003c A[Catch: all -> 0x0012, TryCatch #1 {all -> 0x0012, blocks: (B:6:0x000e, B:17:0x0034, B:19:0x003c, B:20:0x004a, B:28:0x0061, B:14:0x0027, B:30:0x0064, B:31:0x0068, B:32:0x0069, B:13:0x0021, B:21:0x004b, B:23:0x0057), top: B:46:0x0006, inners: #2 }] */
    /* JADX WARN: Removed duplicated region for block: B:33:0x006a  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:15:0x0031 -> B:17:0x0034). Please report as a decompilation issue!!! */
    @Override // M3.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object o(java.lang.Object r8) {
        /*
            r7 = this;
            L3.a r0 = L3.a.f4629l
            int r1 = r7.f14112r
            r2 = 0
            r3 = 1
            if (r1 == 0) goto L1c
            if (r1 != r3) goto L14
            h4.c r1 = r7.f14111q
            h4.u r4 = r7.f14110p
            G3.AbstractC0164a.e(r8)     // Catch: java.lang.Throwable -> L12
            goto L34
        L12:
            r8 = move-exception
            goto L70
        L14:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r0)
            throw r8
        L1c:
            G3.AbstractC0164a.e(r8)
            h4.g r4 = r7.f14113s
            h4.c r8 = new h4.c     // Catch: java.lang.Throwable -> L12
            r8.<init>(r4)     // Catch: java.lang.Throwable -> L12
            r1 = r8
        L27:
            r7.f14110p = r4     // Catch: java.lang.Throwable -> L12
            r7.f14111q = r1     // Catch: java.lang.Throwable -> L12
            r7.f14112r = r3     // Catch: java.lang.Throwable -> L12
            java.lang.Object r8 = r1.b(r7)     // Catch: java.lang.Throwable -> L12
            if (r8 != r0) goto L34
            return r0
        L34:
            java.lang.Boolean r8 = (java.lang.Boolean) r8     // Catch: java.lang.Throwable -> L12
            boolean r8 = r8.booleanValue()     // Catch: java.lang.Throwable -> L12
            if (r8 == 0) goto L6a
            java.lang.Object r8 = r1.c()     // Catch: java.lang.Throwable -> L12
            G3.C r8 = (G3.C) r8     // Catch: java.lang.Throwable -> L12
            java.util.concurrent.atomic.AtomicBoolean r8 = u0.AbstractC1880n0.f14116b     // Catch: java.lang.Throwable -> L12
            r5 = 0
            r8.set(r5)     // Catch: java.lang.Throwable -> L12
            java.lang.Object r8 = S.p.f5938b     // Catch: java.lang.Throwable -> L12
            monitor-enter(r8)     // Catch: java.lang.Throwable -> L12
            java.util.concurrent.atomic.AtomicReference r6 = S.p.f5945i     // Catch: java.lang.Throwable -> L5f
            java.lang.Object r6 = r6.get()     // Catch: java.lang.Throwable -> L5f
            S.c r6 = (S.C0425c) r6     // Catch: java.lang.Throwable -> L5f
            i.C r6 = r6.f5902h     // Catch: java.lang.Throwable -> L5f
            if (r6 == 0) goto L61
            boolean r6 = r6.h()     // Catch: java.lang.Throwable -> L5f
            if (r6 != r3) goto L61
            r5 = r3
            goto L61
        L5f:
            r0 = move-exception
            goto L68
        L61:
            monitor-exit(r8)     // Catch: java.lang.Throwable -> L12
            if (r5 == 0) goto L27
            S.p.a()     // Catch: java.lang.Throwable -> L12
            goto L27
        L68:
            monitor-exit(r8)     // Catch: java.lang.Throwable -> L12
            throw r0     // Catch: java.lang.Throwable -> L12
        L6a:
            r4.a(r2)
            G3.C r8 = G3.C.a
            return r8
        L70:
            throw r8     // Catch: java.lang.Throwable -> L71
        L71:
            r0 = move-exception
            boolean r1 = r8 instanceof java.util.concurrent.CancellationException
            if (r1 == 0) goto L79
            r2 = r8
            java.util.concurrent.CancellationException r2 = (java.util.concurrent.CancellationException) r2
        L79:
            if (r2 != 0) goto L85
            java.util.concurrent.CancellationException r2 = new java.util.concurrent.CancellationException
            java.lang.String r1 = "Channel was consumed, consumer had failed"
            r2.<init>(r1)
            r2.initCause(r8)
        L85:
            r4.a(r2)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.C1878m0.o(java.lang.Object):java.lang.Object");
    }
}

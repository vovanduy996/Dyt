package u0;

/* JADX INFO: renamed from: u0.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1865g implements InterfaceC1863f {
}

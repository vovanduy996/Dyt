package u0;

import A.C0000a;
import I.C0234d;
import I.C0258p;
import I.C0261q0;
import I.C0264s0;
import I.C0277z;

/* JADX INFO: renamed from: u0.f0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1864f0 {
    public static final I.Z0 a = new I.Z0(C1847L.f13958t);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final I.Z0 f14064b = new I.Z0(C1847L.f13959u);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final I.Z0 f14065c = new I.Z0(C1847L.f13960v);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final I.Z0 f14066d = new I.Z0(C1847L.f13961w);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final I.Z0 f14067e = new I.Z0(C1847L.B);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final I.Z0 f14068f = new I.Z0(C1847L.f13962x);

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final I.Z0 f14069g = new I.Z0(C1847L.f13963y);

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final I.Z0 f14070h = new I.Z0(C1847L.f13939A);

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final I.Z0 f14071i = new I.Z0(C1847L.f13964z);

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final I.Z0 f14072j = new I.Z0(C1847L.C);

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final I.Z0 f14073k = new I.Z0(C1847L.D);

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final I.Z0 f14074l = new I.Z0(C1847L.f13940E);

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final I.Z0 f14075m = new I.Z0(C1847L.f13944I);

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final I.Z0 f14076n = new I.Z0(C1847L.f13943H);

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final I.Z0 f14077o = new I.Z0(C1847L.f13945J);

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final I.Z0 f14078p = new I.Z0(C1847L.f13946K);

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final I.Z0 f14079q = new I.Z0(C1847L.f13947L);

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final I.Z0 f14080r = new I.Z0(C1847L.f13948M);

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final I.Z0 f14081s = new I.Z0(C1847L.f13941F);

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final C0277z f14082t = new C0277z(I.W.f3598q, C1847L.f13942G);

    public static final void a(t0.g0 g0Var, W w5, Q.a aVar, C0258p c0258p, int i5) {
        int i6;
        c0258p.S(874662829);
        if ((i5 & 6) == 0) {
            i6 = ((i5 & 8) == 0 ? c0258p.f(g0Var) : c0258p.h(g0Var) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i5 & 48) == 0) {
            i6 |= (i5 & 64) == 0 ? c0258p.f(w5) : c0258p.h(w5) ? 32 : 16;
        }
        if ((i5 & 384) == 0) {
            i6 |= c0258p.h(aVar) ? 256 : 128;
        }
        if ((i6 & 147) == 146 && c0258p.x()) {
            c0258p.L();
        } else {
            C1889s c1889s = (C1889s) g0Var;
            C0261q0 c0261q0A = a.a(c1889s.getAccessibilityManager());
            C0261q0 c0261q0A2 = f14064b.a(c1889s.getAutofill());
            C0261q0 c0261q0A3 = f14065c.a(c1889s.getAutofillTree());
            C0261q0 c0261q0A4 = f14066d.a(c1889s.getClipboardManager());
            C0261q0 c0261q0A5 = f14068f.a(c1889s.getDensity());
            C0261q0 c0261q0A6 = f14069g.a(c1889s.getFocusOwner());
            C0261q0 c0261q0A7 = f14070h.a(c1889s.getFontLoader());
            c0261q0A7.f3699f = false;
            C0261q0 c0261q0A8 = f14071i.a(c1889s.getFontFamilyResolver());
            c0261q0A8.f3699f = false;
            C0234d.b(new C0261q0[]{c0261q0A, c0261q0A2, c0261q0A3, c0261q0A4, c0261q0A5, c0261q0A6, c0261q0A7, c0261q0A8, f14072j.a(c1889s.getHapticFeedBack()), f14073k.a(c1889s.getInputModeManager()), f14074l.a(c1889s.getLayoutDirection()), f14075m.a(c1889s.getTextInputService()), f14076n.a(c1889s.getSoftwareKeyboardController()), f14077o.a(c1889s.getTextToolbar()), f14078p.a(w5), f14079q.a(c1889s.getViewConfiguration()), f14080r.a(c1889s.getWindowInfo()), f14081s.a(c1889s.getPointerIconService()), f14067e.a(c1889s.getGraphicsContext())}, aVar, c0258p, ((i6 >> 3) & 112) | 8);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new C0000a(g0Var, w5, aVar, i5, 7);
        }
    }

    public static final void b(String str) {
        throw new IllegalStateException(("CompositionLocal " + str + " not present").toString());
    }
}

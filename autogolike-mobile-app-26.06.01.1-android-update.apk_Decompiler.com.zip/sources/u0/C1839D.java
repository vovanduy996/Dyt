package u0;

import C0.C0052g;
import a0.C0492c;
import a0.C0493d;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.os.SystemClock;
import android.os.Trace;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import c1.AbstractC0664b;
import com.google.android.gms.internal.measurement.AbstractC0813y0;
import com.google.android.gms.internal.measurement.K1;
import dagger.hilt.android.R;
import f.C0933a;
import i.AbstractC1107i;
import i.AbstractC1108j;
import i.C1097I;
import i.C1104f;
import i.C1114p;
import i.C1115q;
import i.C1116r;
import i.C1117s;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import q.C1580B;

/* JADX INFO: renamed from: u0.D, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1839D extends AbstractC0664b {

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public static final C1115q f13882N;

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public C1116r f13883A;
    public final C1117s B;
    public final C1114p C;
    public final C1114p D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final String f13884E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public final String f13885F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public final F.A0 f13886G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public final C1116r f13887H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public H0 f13888I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public boolean f13889J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public final E.t f13890K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public final ArrayList f13891L;

    /* JADX INFO: renamed from: M, reason: collision with root package name */
    public final C1836A f13892M;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final C1889s f13893d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f13894e = Integer.MIN_VALUE;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final C1836A f13895f = new C1836A(this, 0);

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final AccessibilityManager f13896g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public long f13897h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final AccessibilityManagerAccessibilityStateChangeListenerC1891t f13898i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final AccessibilityManagerTouchExplorationStateChangeListenerC1893u f13899j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public List f13900k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final Handler f13901l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final K1 f13902m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f13903n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public d1.h f13904o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f13905p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final C1116r f13906q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final C1116r f13907r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final C1097I f13908s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final C1097I f13909t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f13910u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public Integer f13911v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final C1104f f13912w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final h4.g f13913x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public boolean f13914y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public C1580B f13915z;

    static {
        int[] iArr = {R.id.accessibility_custom_action_0, R.id.accessibility_custom_action_1, R.id.accessibility_custom_action_2, R.id.accessibility_custom_action_3, R.id.accessibility_custom_action_4, R.id.accessibility_custom_action_5, R.id.accessibility_custom_action_6, R.id.accessibility_custom_action_7, R.id.accessibility_custom_action_8, R.id.accessibility_custom_action_9, R.id.accessibility_custom_action_10, R.id.accessibility_custom_action_11, R.id.accessibility_custom_action_12, R.id.accessibility_custom_action_13, R.id.accessibility_custom_action_14, R.id.accessibility_custom_action_15, R.id.accessibility_custom_action_16, R.id.accessibility_custom_action_17, R.id.accessibility_custom_action_18, R.id.accessibility_custom_action_19, R.id.accessibility_custom_action_20, R.id.accessibility_custom_action_21, R.id.accessibility_custom_action_22, R.id.accessibility_custom_action_23, R.id.accessibility_custom_action_24, R.id.accessibility_custom_action_25, R.id.accessibility_custom_action_26, R.id.accessibility_custom_action_27, R.id.accessibility_custom_action_28, R.id.accessibility_custom_action_29, R.id.accessibility_custom_action_30, R.id.accessibility_custom_action_31};
        int i5 = AbstractC1107i.a;
        C1115q c1115q = new C1115q(32);
        int i6 = c1115q.f10367b;
        if (i6 < 0) {
            StringBuilder sbO = AbstractC0813y0.o(i6, "Index ", " must be in 0..");
            sbO.append(c1115q.f10367b);
            throw new IndexOutOfBoundsException(sbO.toString());
        }
        int i7 = i6 + 32;
        c1115q.b(i7);
        int[] iArr2 = c1115q.a;
        int i8 = c1115q.f10367b;
        if (i6 != i8) {
            H3.l.d0(iArr2, iArr2, i7, i6, i8);
        }
        H3.l.f0(iArr, iArr2, i6, 0, 12);
        c1115q.f10367b += 32;
        f13882N = c1115q;
    }

    /* JADX WARN: Type inference failed for: r2v4, types: [u0.t] */
    /* JADX WARN: Type inference failed for: r2v5, types: [u0.u] */
    public C1839D(C1889s c1889s) {
        this.f13893d = c1889s;
        Object systemService = c1889s.getContext().getSystemService("accessibility");
        U3.j.d(systemService, "null cannot be cast to non-null type android.view.accessibility.AccessibilityManager");
        AccessibilityManager accessibilityManager = (AccessibilityManager) systemService;
        this.f13896g = accessibilityManager;
        this.f13897h = 100L;
        this.f13898i = new AccessibilityManager.AccessibilityStateChangeListener() { // from class: u0.t
            @Override // android.view.accessibility.AccessibilityManager.AccessibilityStateChangeListener
            public final void onAccessibilityStateChanged(boolean z3) {
                C1839D c1839d = this.a;
                c1839d.f13900k = z3 ? c1839d.f13896g.getEnabledAccessibilityServiceList(-1) : H3.w.f3464l;
            }
        };
        this.f13899j = new AccessibilityManager.TouchExplorationStateChangeListener() { // from class: u0.u
            @Override // android.view.accessibility.AccessibilityManager.TouchExplorationStateChangeListener
            public final void onTouchExplorationStateChanged(boolean z3) {
                C1839D c1839d = this.a;
                c1839d.f13900k = c1839d.f13896g.getEnabledAccessibilityServiceList(-1);
            }
        };
        this.f13900k = accessibilityManager.getEnabledAccessibilityServiceList(-1);
        this.f13901l = new Handler(Looper.getMainLooper());
        this.f13902m = new K1(this);
        this.f13903n = Integer.MIN_VALUE;
        this.f13906q = new C1116r();
        this.f13907r = new C1116r();
        this.f13908s = new C1097I();
        this.f13909t = new C1097I();
        this.f13910u = -1;
        this.f13912w = new C1104f(0);
        this.f13913x = C0933a.i(1, 6, null);
        this.f13914y = true;
        C1116r c1116r = AbstractC1108j.a;
        U3.j.d(c1116r, "null cannot be cast to non-null type androidx.collection.IntObjectMap<V of androidx.collection.IntObjectMapKt.intObjectMapOf>");
        this.f13883A = c1116r;
        this.B = new C1117s();
        this.C = new C1114p();
        this.D = new C1114p();
        this.f13884E = "android.view.accessibility.extra.EXTRA_DATA_TEST_TRAVERSALBEFORE_VAL";
        this.f13885F = "android.view.accessibility.extra.EXTRA_DATA_TEST_TRAVERSALAFTER_VAL";
        this.f13886G = new F.A0(6);
        this.f13887H = new C1116r();
        A0.o oVarA = c1889s.getSemanticsOwner().a();
        U3.j.d(c1116r, "null cannot be cast to non-null type androidx.collection.IntObjectMap<V of androidx.collection.IntObjectMapKt.intObjectMapOf>");
        this.f13888I = new H0(oVarA, c1116r);
        c1889s.addOnAttachStateChangeListener(new ViewOnAttachStateChangeListenerC1895v(0, this));
        this.f13890K = new E.t(9, this);
        this.f13891L = new ArrayList();
        this.f13892M = new C1836A(this, 1);
    }

    public static /* synthetic */ void A(C1839D c1839d, int i5, int i6, Integer num, int i7) {
        if ((i7 & 4) != 0) {
            num = null;
        }
        c1839d.z(i5, i6, num, null);
    }

    public static CharSequence I(CharSequence charSequence) {
        if (charSequence.length() != 0) {
            int i5 = 100000;
            if (charSequence.length() > 100000) {
                if (Character.isHighSurrogate(charSequence.charAt(99999)) && Character.isLowSurrogate(charSequence.charAt(100000))) {
                    i5 = 99999;
                }
                CharSequence charSequenceSubSequence = charSequence.subSequence(0, i5);
                U3.j.d(charSequenceSubSequence, "null cannot be cast to non-null type T of androidx.compose.ui.platform.AndroidComposeViewAccessibilityDelegateCompat.trimToSize");
                return charSequenceSubSequence;
            }
        }
        return charSequence;
    }

    public static boolean m(A0.o oVar) {
        Object obj = oVar.f237d.f226l.get(A0.r.B);
        if (obj == null) {
            obj = null;
        }
        B0.a aVar = (B0.a) obj;
        A0.u uVar = A0.r.f276s;
        LinkedHashMap linkedHashMap = oVar.f237d.f226l;
        Object obj2 = linkedHashMap.get(uVar);
        if (obj2 == null) {
            obj2 = null;
        }
        A0.f fVar = (A0.f) obj2;
        boolean z3 = aVar != null;
        Object obj3 = linkedHashMap.get(A0.r.f255A);
        if (((Boolean) (obj3 != null ? obj3 : null)) != null) {
            return fVar != null ? A0.f.a(fVar.a, 4) : false ? z3 : true;
        }
        return z3;
    }

    public static C0052g o(A0.o oVar) {
        Object obj = oVar.f237d.f226l.get(A0.r.f281x);
        if (obj == null) {
            obj = null;
        }
        C0052g c0052g = (C0052g) obj;
        Object obj2 = oVar.f237d.f226l.get(A0.r.f278u);
        if (obj2 == null) {
            obj2 = null;
        }
        List list = (List) obj2;
        return c0052g == null ? list != null ? (C0052g) H3.m.i1(list) : null : c0052g;
    }

    public static String p(A0.o oVar) {
        C0052g c0052g;
        if (oVar == null) {
            return null;
        }
        A0.u uVar = A0.r.a;
        A0.i iVar = oVar.f237d;
        LinkedHashMap linkedHashMap = iVar.f226l;
        if (linkedHashMap.containsKey(uVar)) {
            return E4.d.G((List) iVar.c(uVar), ",", null, 62);
        }
        A0.u uVar2 = A0.r.f281x;
        if (linkedHashMap.containsKey(uVar2)) {
            Object obj = linkedHashMap.get(uVar2);
            if (obj == null) {
                obj = null;
            }
            C0052g c0052g2 = (C0052g) obj;
            if (c0052g2 != null) {
                return c0052g2.a;
            }
            return null;
        }
        Object obj2 = linkedHashMap.get(A0.r.f278u);
        if (obj2 == null) {
            obj2 = null;
        }
        List list = (List) obj2;
        if (list == null || (c0052g = (C0052g) H3.m.i1(list)) == null) {
            return null;
        }
        return c0052g.a;
    }

    /* JADX WARN: Type inference failed for: r2v0, types: [T3.a, U3.k] */
    /* JADX WARN: Type inference failed for: r3v2, types: [T3.a, U3.k] */
    public static final boolean t(A0.g gVar, float f5) {
        ?? r22 = gVar.a;
        return (f5 < 0.0f && ((Number) r22.b()).floatValue() > 0.0f) || (f5 > 0.0f && ((Number) r22.b()).floatValue() < ((Number) gVar.f198b.b()).floatValue());
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [T3.a, U3.k] */
    /* JADX WARN: Type inference failed for: r3v1, types: [T3.a, U3.k] */
    public static final boolean u(A0.g gVar) {
        ?? r02 = gVar.a;
        float fFloatValue = ((Number) r02.b()).floatValue();
        boolean z3 = gVar.f199c;
        return (fFloatValue > 0.0f && !z3) || (((Number) r02.b()).floatValue() < ((Number) gVar.f198b.b()).floatValue() && z3);
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [T3.a, U3.k] */
    /* JADX WARN: Type inference failed for: r2v0, types: [T3.a, U3.k] */
    public static final boolean v(A0.g gVar) {
        ?? r02 = gVar.a;
        float fFloatValue = ((Number) r02.b()).floatValue();
        float fFloatValue2 = ((Number) gVar.f198b.b()).floatValue();
        boolean z3 = gVar.f199c;
        return (fFloatValue < fFloatValue2 && !z3) || (((Number) r02.b()).floatValue() > 0.0f && z3);
    }

    public final void B(int i5, int i6, String str) {
        AccessibilityEvent accessibilityEventG = g(w(i5), 32);
        accessibilityEventG.setContentChangeTypes(i6);
        if (str != null) {
            accessibilityEventG.getText().add(str);
        }
        y(accessibilityEventG);
    }

    public final void C(int i5) {
        C1580B c1580b = this.f13915z;
        if (c1580b != null) {
            A0.o oVar = (A0.o) c1580b.f12510f;
            if (i5 != oVar.f240g) {
                return;
            }
            if (SystemClock.uptimeMillis() - c1580b.f12509e <= 1000) {
                AccessibilityEvent accessibilityEventG = g(w(oVar.f240g), 131072);
                accessibilityEventG.setFromIndex(c1580b.f12507c);
                accessibilityEventG.setToIndex(c1580b.f12508d);
                accessibilityEventG.setAction(c1580b.a);
                accessibilityEventG.setMovementGranularity(c1580b.f12506b);
                accessibilityEventG.getText().add(p(oVar));
                y(accessibilityEventG);
            }
        }
        this.f13915z = null;
    }

    /* JADX WARN: Removed duplicated region for block: B:220:0x0535  */
    /* JADX WARN: Removed duplicated region for block: B:236:0x05aa  */
    /* JADX WARN: Removed duplicated region for block: B:266:0x0624  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00cb  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00f5  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void D(i.C1116r r40) {
        /*
            Method dump skipped, instruction units count: 1645
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.C1839D.D(i.r):void");
    }

    public final void E(t0.E e5, C1117s c1117s) {
        A0.i iVarO;
        if (e5.D() && !this.f13893d.getAndroidViewsHandler$ui_release().getLayoutNodeToHolder().containsKey(e5)) {
            t0.E e6 = null;
            if (!e5.f13436G.f(8)) {
                e5 = e5.s();
                while (true) {
                    if (e5 == null) {
                        e5 = null;
                        break;
                    } else if (e5.f13436G.f(8)) {
                        break;
                    } else {
                        e5 = e5.s();
                    }
                }
            }
            if (e5 == null || (iVarO = e5.o()) == null) {
                return;
            }
            if (!iVarO.f227m) {
                t0.E eS = e5.s();
                while (true) {
                    if (eS != null) {
                        A0.i iVarO2 = eS.o();
                        if (iVarO2 != null && iVarO2.f227m) {
                            e6 = eS;
                            break;
                        }
                        eS = eS.s();
                    } else {
                        break;
                    }
                }
                if (e6 != null) {
                    e5 = e6;
                }
            }
            int i5 = e5.f13448m;
            if (c1117s.a(i5)) {
                A(this, w(i5), 2048, 1, 8);
            }
        }
    }

    /* JADX WARN: Type inference failed for: r0v13, types: [T3.a, U3.k] */
    /* JADX WARN: Type inference failed for: r0v18, types: [T3.a, U3.k] */
    /* JADX WARN: Type inference failed for: r0v8, types: [T3.a, U3.k] */
    /* JADX WARN: Type inference failed for: r2v1, types: [T3.a, U3.k] */
    public final void F(t0.E e5) {
        if (e5.D() && !this.f13893d.getAndroidViewsHandler$ui_release().getLayoutNodeToHolder().containsKey(e5)) {
            int i5 = e5.f13448m;
            A0.g gVar = (A0.g) this.f13906q.f(i5);
            A0.g gVar2 = (A0.g) this.f13907r.f(i5);
            if (gVar == null && gVar2 == null) {
                return;
            }
            AccessibilityEvent accessibilityEventG = g(i5, 4096);
            if (gVar != null) {
                accessibilityEventG.setScrollX((int) ((Number) gVar.a.b()).floatValue());
                accessibilityEventG.setMaxScrollX((int) ((Number) gVar.f198b.b()).floatValue());
            }
            if (gVar2 != null) {
                accessibilityEventG.setScrollY((int) ((Number) gVar2.a.b()).floatValue());
                accessibilityEventG.setMaxScrollY((int) ((Number) gVar2.f198b.b()).floatValue());
            }
            y(accessibilityEventG);
        }
    }

    public final boolean G(A0.o oVar, int i5, int i6, boolean z3) {
        String strP;
        A0.i iVar = oVar.f237d;
        A0.u uVar = A0.h.f207h;
        if (iVar.f226l.containsKey(uVar) && AbstractC1846K.j(oVar)) {
            T3.f fVar = (T3.f) ((A0.a) oVar.f237d.c(uVar)).f191b;
            if (fVar != null) {
                return ((Boolean) fVar.h(Integer.valueOf(i5), Integer.valueOf(i6), Boolean.valueOf(z3))).booleanValue();
            }
            return false;
        }
        if ((i5 == i6 && i6 == this.f13910u) || (strP = p(oVar)) == null) {
            return false;
        }
        if (i5 < 0 || i5 != i6 || i6 > strP.length()) {
            i5 = -1;
        }
        this.f13910u = i5;
        boolean z5 = strP.length() > 0;
        int i7 = oVar.f240g;
        y(h(w(i7), z5 ? Integer.valueOf(this.f13910u) : null, z5 ? Integer.valueOf(this.f13910u) : null, z5 ? Integer.valueOf(strP.length()) : null, strP));
        C(i7);
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:28:0x00b8 A[EDGE_INSN: B:53:0x00b8->B:28:0x00b8 BREAK  A[LOOP:2: B:17:0x0051->B:27:0x00b6]] */
    /* JADX WARN: Removed duplicated region for block: B:30:0x00ce A[LOOP:1: B:8:0x002f->B:30:0x00ce, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00d1 A[EDGE_INSN: B:51:0x00d1->B:31:0x00d1 BREAK  A[LOOP:1: B:8:0x002f->B:30:0x00ce], SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.util.ArrayList H(boolean r18, java.util.ArrayList r19) {
        /*
            Method dump skipped, instruction units count: 329
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.C1839D.H(boolean, java.util.ArrayList):java.util.ArrayList");
    }

    /* JADX WARN: Code restructure failed: missing block: B:47:0x0140, code lost:
    
        r28 = r13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x014e, code lost:
    
        if (((r0 & ((~r0) << 6)) & (-9187201950435737472L)) == 0) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x0150, code lost:
    
        r24 = -1;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0091  */
    /* JADX WARN: Type inference failed for: r12v19, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r13v1 */
    /* JADX WARN: Type inference failed for: r13v2, types: [u0.D] */
    /* JADX WARN: Type inference failed for: r13v25 */
    /* JADX WARN: Type inference failed for: r13v3 */
    /* JADX WARN: Type inference failed for: r13v4 */
    /* JADX WARN: Type inference failed for: r13v5 */
    /* JADX WARN: Type inference failed for: r29v0, types: [u0.D] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void J() {
        /*
            Method dump skipped, instruction units count: 594
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.C1839D.J():void");
    }

    @Override // c1.AbstractC0664b
    public final K1 a(View view) {
        return this.f13902m;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void b(int i5, d1.h hVar, String str, Bundle bundle) {
        A0.o oVar;
        RectF rectF;
        I0 i02 = (I0) l().f(i5);
        if (i02 == null || (oVar = i02.a) == null) {
            return;
        }
        String strP = p(oVar);
        boolean zA = U3.j.a(str, this.f13884E);
        AccessibilityNodeInfo accessibilityNodeInfo = hVar.a;
        if (zA) {
            C1114p c1114p = this.C;
            int iC = c1114p.c(i5);
            int i6 = iC >= 0 ? c1114p.f10363c[iC] : -1;
            if (i6 != -1) {
                accessibilityNodeInfo.getExtras().putInt(str, i6);
                return;
            }
            return;
        }
        if (U3.j.a(str, this.f13885F)) {
            C1114p c1114p2 = this.D;
            int iC2 = c1114p2.c(i5);
            int i7 = iC2 >= 0 ? c1114p2.f10363c[iC2] : -1;
            if (i7 != -1) {
                accessibilityNodeInfo.getExtras().putInt(str, i7);
                return;
            }
            return;
        }
        A0.u uVar = A0.h.a;
        A0.i iVar = oVar.f237d;
        LinkedHashMap linkedHashMap = iVar.f226l;
        t0.a0 a0Var = null;
        if (!linkedHashMap.containsKey(uVar) || bundle == null || !U3.j.a(str, "android.view.accessibility.extra.DATA_TEXT_CHARACTER_LOCATION_KEY")) {
            A0.u uVar2 = A0.r.f277t;
            if (!linkedHashMap.containsKey(uVar2) || bundle == null || !U3.j.a(str, "androidx.compose.ui.semantics.testTag")) {
                if (U3.j.a(str, "androidx.compose.ui.semantics.id")) {
                    accessibilityNodeInfo.getExtras().putInt(str, oVar.f240g);
                    return;
                }
                return;
            } else {
                Object obj = linkedHashMap.get(uVar2);
                String str2 = (String) (obj == null ? null : obj);
                if (str2 != null) {
                    accessibilityNodeInfo.getExtras().putCharSequence(str, str2);
                    return;
                }
                return;
            }
        }
        int i8 = bundle.getInt("android.view.accessibility.extra.DATA_TEXT_CHARACTER_LOCATION_ARG_START_INDEX", -1);
        int i9 = bundle.getInt("android.view.accessibility.extra.DATA_TEXT_CHARACTER_LOCATION_ARG_LENGTH", -1);
        if (i9 > 0 && i8 >= 0) {
            if (i8 < (strP != null ? strP.length() : Integer.MAX_VALUE)) {
                C0.I iP = AbstractC1846K.p(iVar);
                if (iP == null) {
                    return;
                }
                ArrayList arrayList = new ArrayList();
                int i10 = 0;
                while (i10 < i9) {
                    int i11 = i8 + i10;
                    if (i11 >= iP.a.a.a.length()) {
                        arrayList.add(a0Var);
                    } else {
                        C0493d c0493dB = iP.b(i11);
                        t0.a0 a0VarC = oVar.c();
                        long jO = 0;
                        if (a0VarC != null) {
                            if (!a0VarC.N0().f6139x) {
                                a0VarC = a0Var;
                            }
                            if (a0VarC != null) {
                                jO = a0VarC.O(0L);
                            }
                        }
                        C0493d c0493dH = c0493dB.h(jO);
                        C0493d c0493dE = oVar.e();
                        C0493d c0493dD = c0493dH.f(c0493dE) ? c0493dH.d(c0493dE) : a0Var;
                        if (c0493dD != 0) {
                            long jL = X2.g.l(c0493dD.a, c0493dD.f7216b);
                            C1889s c1889s = this.f13893d;
                            long jR = c1889s.r(jL);
                            long jR2 = c1889s.r(X2.g.l(c0493dD.f7217c, c0493dD.f7218d));
                            rectF = new RectF(C0492c.d(jR), C0492c.e(jR), C0492c.d(jR2), C0492c.e(jR2));
                        } else {
                            rectF = null;
                        }
                        arrayList.add(rectF);
                    }
                    i10++;
                    a0Var = null;
                }
                accessibilityNodeInfo.getExtras().putParcelableArray(str, (Parcelable[]) arrayList.toArray(new RectF[0]));
                return;
            }
        }
        Log.e("AccessibilityDelegate", "Invalid arguments for accessibility character locations");
    }

    public final Rect c(I0 i02) {
        Rect rect = i02.f13936b;
        long jL = X2.g.l(rect.left, rect.top);
        C1889s c1889s = this.f13893d;
        long jR = c1889s.r(jL);
        long jR2 = c1889s.r(X2.g.l(rect.right, rect.bottom));
        return new Rect((int) Math.floor(C0492c.d(jR)), (int) Math.floor(C0492c.e(jR)), (int) Math.ceil(C0492c.d(jR2)), (int) Math.ceil(C0492c.e(jR2)));
    }

    /* JADX WARN: Removed duplicated region for block: B:27:0x0067 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0068  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0074 A[Catch: all -> 0x0031, TRY_LEAVE, TryCatch #0 {all -> 0x0031, blocks: (B:13:0x002c, B:25:0x0059, B:29:0x006c, B:31:0x0074, B:34:0x007f, B:36:0x0084, B:37:0x0093, B:39:0x009a, B:40:0x00a3, B:20:0x0042), top: B:51:0x0020 }] */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00c4  */
    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:33:0x007d -> B:43:0x00c1). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:41:0x00be -> B:43:0x00c1). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object d(M3.c r12) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 214
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.C1839D.d(M3.c):java.lang.Object");
    }

    /* JADX WARN: Type inference failed for: r2v23, types: [T3.a, U3.k] */
    /* JADX WARN: Type inference failed for: r3v10, types: [T3.a, U3.k] */
    public final boolean e(int i5, long j5, boolean z3) {
        A0.u uVar;
        long[] jArr;
        Object[] objArr;
        long[] jArr2;
        Object[] objArr2;
        int i6;
        int i7 = 0;
        if (!U3.j.a(Looper.getMainLooper().getThread(), Thread.currentThread())) {
            return false;
        }
        C1116r c1116rL = l();
        if (!C0492c.b(j5, 9205357640488583168L) && C0492c.f(j5)) {
            if (z3) {
                uVar = A0.r.f273p;
            } else {
                if (z3) {
                    throw new G3.f();
                }
                uVar = A0.r.f272o;
            }
            Object[] objArr3 = c1116rL.f10369c;
            long[] jArr3 = c1116rL.a;
            int length = jArr3.length - 2;
            if (length >= 0) {
                int i8 = 0;
                boolean z5 = false;
                while (true) {
                    long j6 = jArr3[i8];
                    if ((((~j6) << 7) & j6 & (-9187201950435737472L)) != -9187201950435737472L) {
                        int i9 = 8;
                        int i10 = 8 - ((~(i8 - length)) >>> 31);
                        int i11 = i7;
                        while (i11 < i10) {
                            if ((j6 & 255) < 128) {
                                I0 i02 = (I0) objArr3[(i8 << 3) + i11];
                                Rect rect = i02.f13936b;
                                jArr2 = jArr3;
                                objArr2 = objArr3;
                                if (C0492c.d(j5) >= ((float) rect.left) && C0492c.d(j5) < ((float) rect.right) && C0492c.e(j5) >= ((float) rect.top) && C0492c.e(j5) < ((float) rect.bottom)) {
                                    Object obj = i02.a.f237d.f226l.get(uVar);
                                    if (obj == null) {
                                        obj = null;
                                    }
                                    A0.g gVar = (A0.g) obj;
                                    if (gVar != null) {
                                        boolean z6 = gVar.f199c;
                                        int i12 = z6 ? -i5 : i5;
                                        if (i5 == 0 && z6) {
                                            i12 = -1;
                                        }
                                        ?? r32 = gVar.a;
                                        if (i12 >= 0 ? ((Number) r32.b()).floatValue() < ((Number) gVar.f198b.b()).floatValue() : ((Number) r32.b()).floatValue() > 0.0f) {
                                            z5 = true;
                                        }
                                    }
                                }
                                i6 = 8;
                            } else {
                                jArr2 = jArr3;
                                objArr2 = objArr3;
                                i6 = i9;
                            }
                            j6 >>= i6;
                            i11++;
                            i9 = i6;
                            jArr3 = jArr2;
                            objArr3 = objArr2;
                        }
                        jArr = jArr3;
                        objArr = objArr3;
                        if (i10 != i9) {
                            break;
                        }
                    } else {
                        jArr = jArr3;
                        objArr = objArr3;
                    }
                    if (i8 == length) {
                        break;
                    }
                    i8++;
                    jArr3 = jArr;
                    objArr3 = objArr;
                    i7 = 0;
                }
                return z5;
            }
        }
        return false;
    }

    public final void f() {
        Trace.beginSection("sendAccessibilitySemanticsStructureChangeEvents");
        try {
            if (q()) {
                x(this.f13893d.getSemanticsOwner().a(), this.f13888I);
            }
            Trace.endSection();
            Trace.beginSection("sendSemanticsPropertyChangeEvents");
            try {
                D(l());
                Trace.endSection();
                Trace.beginSection("updateSemanticsNodesCopyAndPanes");
                try {
                    J();
                } finally {
                }
            } finally {
            }
        } finally {
        }
    }

    public final AccessibilityEvent g(int i5, int i6) {
        I0 i02;
        AccessibilityEvent accessibilityEventObtain = AccessibilityEvent.obtain(i6);
        accessibilityEventObtain.setEnabled(true);
        accessibilityEventObtain.setClassName("android.view.View");
        C1889s c1889s = this.f13893d;
        accessibilityEventObtain.setPackageName(c1889s.getContext().getPackageName());
        accessibilityEventObtain.setSource(c1889s, i5);
        if (q() && (i02 = (I0) l().f(i5)) != null) {
            accessibilityEventObtain.setPassword(i02.a.f237d.f226l.containsKey(A0.r.C));
        }
        return accessibilityEventObtain;
    }

    public final AccessibilityEvent h(int i5, Integer num, Integer num2, Integer num3, CharSequence charSequence) {
        AccessibilityEvent accessibilityEventG = g(i5, 8192);
        if (num != null) {
            accessibilityEventG.setFromIndex(num.intValue());
        }
        if (num2 != null) {
            accessibilityEventG.setToIndex(num2.intValue());
        }
        if (num3 != null) {
            accessibilityEventG.setItemCount(num3.intValue());
        }
        if (charSequence != null) {
            accessibilityEventG.getText().add(charSequence);
        }
        return accessibilityEventG;
    }

    public final void i(A0.o oVar, ArrayList arrayList, C1116r c1116r) {
        boolean zK = AbstractC1846K.k(oVar);
        Object obj = oVar.f237d.f226l.get(A0.r.f269l);
        if (obj == null) {
            obj = Boolean.FALSE;
        }
        boolean zBooleanValue = ((Boolean) obj).booleanValue();
        int i5 = oVar.f240g;
        if ((zBooleanValue || r(oVar)) && l().c(i5)) {
            arrayList.add(oVar);
        }
        if (zBooleanValue) {
            c1116r.i(i5, H(zK, H3.m.C1(A0.o.h(oVar, false, 7))));
            return;
        }
        List listH = A0.o.h(oVar, false, 7);
        int size = listH.size();
        for (int i6 = 0; i6 < size; i6++) {
            i((A0.o) listH.get(i6), arrayList, c1116r);
        }
    }

    public final int j(A0.o oVar) {
        A0.i iVar = oVar.f237d;
        if (!iVar.f226l.containsKey(A0.r.a)) {
            A0.u uVar = A0.r.f282y;
            A0.i iVar2 = oVar.f237d;
            if (iVar2.f226l.containsKey(uVar)) {
                return (int) (4294967295L & ((C0.K) iVar2.c(uVar)).a);
            }
        }
        return this.f13910u;
    }

    public final int k(A0.o oVar) {
        A0.i iVar = oVar.f237d;
        if (!iVar.f226l.containsKey(A0.r.a)) {
            A0.u uVar = A0.r.f282y;
            A0.i iVar2 = oVar.f237d;
            if (iVar2.f226l.containsKey(uVar)) {
                return (int) (((C0.K) iVar2.c(uVar)).a >> 32);
            }
        }
        return this.f13910u;
    }

    public final C1116r l() {
        if (this.f13914y) {
            this.f13914y = false;
            this.f13883A = AbstractC1846K.n(this.f13893d.getSemanticsOwner());
            if (q()) {
                C1114p c1114p = this.C;
                c1114p.a();
                C1114p c1114p2 = this.D;
                c1114p2.a();
                I0 i02 = (I0) l().f(-1);
                A0.o oVar = i02 != null ? i02.a : null;
                U3.j.c(oVar);
                ArrayList arrayListH = H(AbstractC1846K.k(oVar), H3.n.T0(oVar));
                int iR0 = H3.n.R0(arrayListH);
                int i5 = 1;
                if (1 <= iR0) {
                    while (true) {
                        int i6 = ((A0.o) arrayListH.get(i5 - 1)).f240g;
                        int i7 = ((A0.o) arrayListH.get(i5)).f240g;
                        c1114p.f(i6, i7);
                        c1114p2.f(i7, i6);
                        if (i5 == iR0) {
                            break;
                        }
                        i5++;
                    }
                }
            }
        }
        return this.f13883A;
    }

    public final String n(A0.o oVar) {
        Object string = oVar.f237d.f226l.get(A0.r.f259b);
        String string2 = null;
        if (string == null) {
            string = null;
        }
        A0.u uVar = A0.r.B;
        A0.i iVar = oVar.f237d;
        LinkedHashMap linkedHashMap = iVar.f226l;
        Object obj = linkedHashMap.get(uVar);
        if (obj == null) {
            obj = null;
        }
        B0.a aVar = (B0.a) obj;
        Object obj2 = linkedHashMap.get(A0.r.f276s);
        if (obj2 == null) {
            obj2 = null;
        }
        A0.f fVar = (A0.f) obj2;
        C1889s c1889s = this.f13893d;
        if (aVar != null) {
            int iOrdinal = aVar.ordinal();
            if (iOrdinal == 0) {
                if ((fVar == null ? false : A0.f.a(fVar.a, 2)) && string == null) {
                    string = c1889s.getContext().getResources().getString(R.string.state_on);
                }
            } else if (iOrdinal == 1) {
                if ((fVar == null ? false : A0.f.a(fVar.a, 2)) && string == null) {
                    string = c1889s.getContext().getResources().getString(R.string.state_off);
                }
            } else if (iOrdinal == 2 && string == null) {
                string = c1889s.getContext().getResources().getString(R.string.indeterminate);
            }
        }
        Object obj3 = linkedHashMap.get(A0.r.f255A);
        if (obj3 == null) {
            obj3 = null;
        }
        Boolean bool = (Boolean) obj3;
        if (bool != null) {
            boolean zBooleanValue = bool.booleanValue();
            if (!(fVar == null ? false : A0.f.a(fVar.a, 4)) && string == null) {
                string = zBooleanValue ? c1889s.getContext().getResources().getString(R.string.selected) : c1889s.getContext().getResources().getString(R.string.not_selected);
            }
        }
        Object obj4 = linkedHashMap.get(A0.r.f260c);
        if (obj4 == null) {
            obj4 = null;
        }
        A0.e eVar = (A0.e) obj4;
        if (eVar != null) {
            if (eVar != A0.e.f195d) {
                if (string == null) {
                    Z3.a aVar2 = eVar.f196b;
                    float f5 = aVar2.f7195b;
                    float f6 = aVar2.a;
                    float f7 = ((f5 - f6) > 0.0f ? 1 : ((f5 - f6) == 0.0f ? 0 : -1)) == 0 ? 0.0f : (eVar.a - f6) / (f5 - f6);
                    if (f7 < 0.0f) {
                        f7 = 0.0f;
                    }
                    if (f7 > 1.0f) {
                        f7 = 1.0f;
                    }
                    if (!(f7 == 0.0f)) {
                        iO0 = (f7 == 1.0f ? 1 : 0) != 0 ? 100 : E4.l.o0(Math.round(f7 * 100), 1, 99);
                    }
                    string = c1889s.getContext().getResources().getString(R.string.template_percent, Integer.valueOf(iO0));
                }
            } else if (string == null) {
                string = c1889s.getContext().getResources().getString(R.string.in_progress);
            }
        }
        A0.u uVar2 = A0.r.f281x;
        if (linkedHashMap.containsKey(uVar2)) {
            A0.i iVarI = new A0.o(oVar.a, true, oVar.f236c, iVar).i();
            A0.u uVar3 = A0.r.a;
            LinkedHashMap linkedHashMap2 = iVarI.f226l;
            Object obj5 = linkedHashMap2.get(uVar3);
            if (obj5 == null) {
                obj5 = null;
            }
            Collection collection = (Collection) obj5;
            if (collection == null || collection.isEmpty()) {
                Object obj6 = linkedHashMap2.get(A0.r.f278u);
                if (obj6 == null) {
                    obj6 = null;
                }
                Collection collection2 = (Collection) obj6;
                if (collection2 == null || collection2.isEmpty()) {
                    Object obj7 = linkedHashMap2.get(uVar2);
                    if (obj7 == null) {
                        obj7 = null;
                    }
                    CharSequence charSequence = (CharSequence) obj7;
                    if (charSequence == null || charSequence.length() == 0) {
                        string2 = c1889s.getContext().getResources().getString(R.string.state_empty);
                    }
                }
            }
            string = string2;
        }
        return (String) string;
    }

    public final boolean q() {
        return this.f13896g.isEnabled() && !this.f13900k.isEmpty();
    }

    public final boolean r(A0.o oVar) {
        Object obj = oVar.f237d.f226l.get(A0.r.a);
        if (obj == null) {
            obj = null;
        }
        List list = (List) obj;
        boolean z3 = ((list != null ? (String) H3.m.i1(list) : null) == null && o(oVar) == null && n(oVar) == null && !m(oVar)) ? false : true;
        if (oVar.f237d.f227m) {
            return true;
        }
        return oVar.m() && z3;
    }

    public final void s(t0.E e5) {
        if (this.f13912w.add(e5)) {
            this.f13913x.n(G3.C.a);
        }
    }

    public final int w(int i5) {
        if (i5 == this.f13893d.getSemanticsOwner().a().f240g) {
            return -1;
        }
        return i5;
    }

    /* JADX WARN: Removed duplicated region for block: B:28:0x0088  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void x(A0.o r21, u0.H0 r22) {
        /*
            r20 = this;
            r0 = r20
            r1 = r21
            r2 = r22
            r3 = 1
            int[] r4 = i.AbstractC1109k.a
            i.s r4 = new i.s
            r4.<init>()
            r5 = 4
            java.util.List r6 = A0.o.h(r1, r3, r5)
            int r7 = r6.size()
            r9 = 0
        L18:
            t0.E r10 = r1.f236c
            if (r9 >= r7) goto L41
            java.lang.Object r11 = r6.get(r9)
            A0.o r11 = (A0.o) r11
            i.r r12 = r20.l()
            int r13 = r11.f240g
            boolean r12 = r12.b(r13)
            if (r12 == 0) goto L3f
            i.s r12 = r2.f13935b
            int r11 = r11.f240g
            boolean r12 = r12.c(r11)
            if (r12 != 0) goto L3c
            r0.s(r10)
            return
        L3c:
            r4.a(r11)
        L3f:
            int r9 = r9 + r3
            goto L18
        L41:
            i.s r2 = r2.f13935b
            int[] r6 = r2.f10373b
            long[] r2 = r2.a
            int r7 = r2.length
            int r7 = r7 + (-2)
            if (r7 < 0) goto L8c
            r9 = 0
        L4d:
            r11 = r2[r9]
            long r13 = ~r11
            r15 = 7
            long r13 = r13 << r15
            long r13 = r13 & r11
            r15 = -9187201950435737472(0x8080808080808080, double:-2.937446524422997E-306)
            long r13 = r13 & r15
            int r13 = (r13 > r15 ? 1 : (r13 == r15 ? 0 : -1))
            if (r13 == 0) goto L88
            int r13 = r9 - r7
            int r13 = ~r13
            int r13 = r13 >>> 31
            r14 = 8
            int r13 = 8 - r13
            r15 = 0
        L67:
            if (r15 >= r13) goto L86
            r16 = 255(0xff, double:1.26E-321)
            long r16 = r11 & r16
            r18 = 128(0x80, double:6.3E-322)
            int r16 = (r16 > r18 ? 1 : (r16 == r18 ? 0 : -1))
            if (r16 >= 0) goto L83
            int r16 = r9 << 3
            int r16 = r16 + r15
            r8 = r6[r16]
            boolean r8 = r4.c(r8)
            if (r8 != 0) goto L83
            r0.s(r10)
            return
        L83:
            long r11 = r11 >> r14
            int r15 = r15 + r3
            goto L67
        L86:
            if (r13 != r14) goto L8c
        L88:
            if (r9 == r7) goto L8c
            int r9 = r9 + r3
            goto L4d
        L8c:
            java.util.List r1 = A0.o.h(r1, r3, r5)
            int r2 = r1.size()
            r8 = 0
        L95:
            if (r8 >= r2) goto Lbb
            java.lang.Object r4 = r1.get(r8)
            A0.o r4 = (A0.o) r4
            i.r r5 = r20.l()
            int r6 = r4.f240g
            boolean r5 = r5.b(r6)
            if (r5 == 0) goto Lb9
            i.r r5 = r0.f13887H
            int r6 = r4.f240g
            java.lang.Object r5 = r5.f(r6)
            U3.j.c(r5)
            u0.H0 r5 = (u0.H0) r5
            r0.x(r4, r5)
        Lb9:
            int r8 = r8 + r3
            goto L95
        Lbb:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.C1839D.x(A0.o, u0.H0):void");
    }

    public final boolean y(AccessibilityEvent accessibilityEvent) {
        if (!q()) {
            return false;
        }
        if (accessibilityEvent.getEventType() == 2048 || accessibilityEvent.getEventType() == 32768) {
            this.f13905p = true;
        }
        try {
            return ((Boolean) this.f13895f.invoke(accessibilityEvent)).booleanValue();
        } finally {
            this.f13905p = false;
        }
    }

    public final boolean z(int i5, int i6, Integer num, List list) {
        if (i5 == Integer.MIN_VALUE || !q()) {
            return false;
        }
        AccessibilityEvent accessibilityEventG = g(i5, i6);
        if (num != null) {
            accessibilityEventG.setContentChangeTypes(num.intValue());
        }
        if (list != null) {
            accessibilityEventG.setContentDescription(E4.d.G(list, ",", null, 62));
        }
        Trace.beginSection("sendEvent");
        try {
            return y(accessibilityEventG);
        } finally {
            Trace.endSection();
        }
    }
}

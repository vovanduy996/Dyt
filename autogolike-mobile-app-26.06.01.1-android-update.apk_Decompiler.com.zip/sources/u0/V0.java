package u0;

import I.C0234d;
import I.C0247j0;

/* JADX INFO: loaded from: classes.dex */
public final class V0 implements U0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final C0247j0 f14012b = C0234d.K(new n0.v(0), I.W.f3598q);
    public final C0247j0 a = C0234d.K(Boolean.FALSE, I.W.f3598q);

    public final boolean a() {
        return ((Boolean) this.a.getValue()).booleanValue();
    }
}

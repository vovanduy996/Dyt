package u0;

import G3.AbstractC0164a;
import android.view.Choreographer;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: loaded from: classes.dex */
public final class T extends M3.i implements T3.e {
    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((T) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new T(2, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        AbstractC0164a.e(obj);
        return Choreographer.getInstance();
    }
}

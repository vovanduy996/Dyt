package u0;

import android.os.Looper;
import android.view.Choreographer;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import f4.AbstractC0952A;
import f4.AbstractC0960I;
import k4.AbstractC1268m;
import l3.AbstractC1324b;
import m4.C1408e;

/* JADX INFO: renamed from: u0.L, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1847L extends U3.k implements T3.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f13965l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final C1847L f13951m = new C1847L(0, 0);

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final C1847L f13952n = new C1847L(0, 1);

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final C1847L f13953o = new C1847L(0, 2);

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final C1847L f13954p = new C1847L(0, 3);

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final C1847L f13955q = new C1847L(0, 4);

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final C1847L f13956r = new C1847L(0, 5);

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final C1847L f13957s = new C1847L(0, 6);

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final C1847L f13958t = new C1847L(0, 7);

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final C1847L f13959u = new C1847L(0, 8);

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final C1847L f13960v = new C1847L(0, 9);

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final C1847L f13961w = new C1847L(0, 10);

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final C1847L f13962x = new C1847L(0, 11);

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public static final C1847L f13963y = new C1847L(0, 12);

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public static final C1847L f13964z = new C1847L(0, 13);

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public static final C1847L f13939A = new C1847L(0, 14);
    public static final C1847L B = new C1847L(0, 15);
    public static final C1847L C = new C1847L(0, 16);
    public static final C1847L D = new C1847L(0, 17);

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public static final C1847L f13940E = new C1847L(0, 18);

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public static final C1847L f13941F = new C1847L(0, 19);

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public static final C1847L f13942G = new C1847L(0, 20);

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public static final C1847L f13943H = new C1847L(0, 21);

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public static final C1847L f13944I = new C1847L(0, 22);

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public static final C1847L f13945J = new C1847L(0, 23);

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public static final C1847L f13946K = new C1847L(0, 24);

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public static final C1847L f13947L = new C1847L(0, 25);

    /* JADX INFO: renamed from: M, reason: collision with root package name */
    public static final C1847L f13948M = new C1847L(0, 26);

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public static final C1847L f13949N = new C1847L(0, 27);

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public static final C1847L f13950O = new C1847L(0, 28);

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C1847L(int i5, int i6) {
        super(i5);
        this.f13965l = i6;
    }

    @Override // T3.a
    public final Object b() {
        Choreographer choreographer;
        switch (this.f13965l) {
            case ConfigBackupDto.$stable /* 0 */:
                AndroidCompositionLocals_androidKt.b("LocalConfiguration");
                throw null;
            case 1:
                AndroidCompositionLocals_androidKt.b("LocalContext");
                throw null;
            case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                AndroidCompositionLocals_androidKt.b("LocalImageVectorCache");
                throw null;
            case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                AndroidCompositionLocals_androidKt.b("LocalResourceIdCache");
                throw null;
            case k1.h.LONG_FIELD_NUMBER /* 4 */:
                AndroidCompositionLocals_androidKt.b("LocalSavedStateRegistryOwner");
                throw null;
            case k1.h.STRING_FIELD_NUMBER /* 5 */:
                AndroidCompositionLocals_androidKt.b("LocalView");
                throw null;
            case k1.h.STRING_SET_FIELD_NUMBER /* 6 */:
                if (Looper.myLooper() == Looper.getMainLooper()) {
                    choreographer = Choreographer.getInstance();
                } else {
                    C1408e c1408e = AbstractC0960I.a;
                    choreographer = (Choreographer) AbstractC0952A.w(AbstractC1268m.a, new T(2, null));
                }
                V v5 = new V(choreographer, AbstractC1324b.m(Looper.getMainLooper()));
                return l0.c.q0(v5, v5.f14011w);
            case k1.h.DOUBLE_FIELD_NUMBER /* 7 */:
            case 8:
                return null;
            case 9:
                AbstractC1864f0.b("LocalAutofillTree");
                throw null;
            case 10:
                AbstractC1864f0.b("LocalClipboardManager");
                throw null;
            case 11:
                AbstractC1864f0.b("LocalDensity");
                throw null;
            case 12:
                AbstractC1864f0.b("LocalFocusManager");
                throw null;
            case 13:
                AbstractC1864f0.b("LocalFontFamilyResolver");
                throw null;
            case 14:
                AbstractC1864f0.b("LocalFontLoader");
                throw null;
            case 15:
                AbstractC1864f0.b("LocalGraphicsContext");
                throw null;
            case 16:
                AbstractC1864f0.b("LocalHapticFeedback");
                throw null;
            case 17:
                AbstractC1864f0.b("LocalInputManager");
                throw null;
            case 18:
                AbstractC1864f0.b("LocalLayoutDirection");
                throw null;
            case 19:
                return null;
            case 20:
                return Boolean.FALSE;
            case 21:
            case 22:
                return null;
            case 23:
                AbstractC1864f0.b("LocalTextToolbar");
                throw null;
            case 24:
                AbstractC1864f0.b("LocalUriHandler");
                throw null;
            case 25:
                AbstractC1864f0.b("LocalViewConfiguration");
                throw null;
            case 26:
                AbstractC1864f0.b("LocalWindowInfo");
                throw null;
            case 27:
                return Boolean.FALSE;
            default:
                return null;
        }
    }
}

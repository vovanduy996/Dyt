package u0;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class S0 {
    public static final S0 a = new S0();

    public final void a(View view, int i5) {
        view.setOutlineAmbientShadowColor(i5);
    }

    public final void b(View view, int i5) {
        view.setOutlineSpotShadowColor(i5);
    }
}

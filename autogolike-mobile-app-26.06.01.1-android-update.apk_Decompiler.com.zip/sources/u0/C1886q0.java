package u0;

import java.lang.ref.WeakReference;
import s.C1703N;

/* JADX INFO: renamed from: u0.q0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1886q0 {
    public final y.z a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C1703N f14140b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f14141c = new Object();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final K.d f14142d = new K.d(new WeakReference[16]);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f14143e;

    public C1886q0(y.z zVar, C1703N c1703n) {
        this.a = zVar;
        this.f14140b = c1703n;
    }
}

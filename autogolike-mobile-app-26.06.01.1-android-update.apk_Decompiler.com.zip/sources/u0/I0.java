package u0;

import android.graphics.Rect;

/* JADX INFO: loaded from: classes.dex */
public final class I0 {
    public final A0.o a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Rect f13936b;

    public I0(A0.o oVar, Rect rect) {
        this.a = oVar;
        this.f13936b = rect;
    }
}

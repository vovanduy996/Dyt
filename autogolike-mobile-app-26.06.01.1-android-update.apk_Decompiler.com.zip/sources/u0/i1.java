package u0;

import I.C0234d;
import I.C0250l;
import I.C0258p;
import android.view.View;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import dagger.hilt.android.R;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class i1 extends U3.k implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f14088l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ j1 f14089m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ Q.a f14090n;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ i1(j1 j1Var, Q.a aVar, int i5) {
        super(2);
        this.f14088l = i5;
        this.f14089m = j1Var;
        this.f14090n = aVar;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        switch (this.f14088l) {
            case ConfigBackupDto.$stable /* 0 */:
                C0258p c0258p = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p.x()) {
                    c0258p.L();
                } else {
                    AndroidCompositionLocals_androidKt.a(this.f14089m.f14095l, this.f14090n, c0258p, 0);
                }
                break;
            default:
                C0258p c0258p2 = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p2.x()) {
                    c0258p2.L();
                } else {
                    j1 j1Var = this.f14089m;
                    Object tag = j1Var.f14095l.getTag(R.id.inspection_slot_table_set);
                    Set set = (tag instanceof Set) && (!(tag instanceof V3.a) || (tag instanceof V3.e)) ? (Set) tag : null;
                    C1889s c1889s = j1Var.f14095l;
                    if (set == null) {
                        Object parent = c1889s.getParent();
                        View view = parent instanceof View ? (View) parent : null;
                        Object tag2 = view != null ? view.getTag(R.id.inspection_slot_table_set) : null;
                        set = (!(tag2 instanceof Set) || ((tag2 instanceof V3.a) && !(tag2 instanceof V3.e))) ? null : (Set) tag2;
                    }
                    if (set != null) {
                        set.add(c0258p2.f3671c);
                        c0258p2.f3684p = true;
                        c0258p2.B = true;
                        c0258p2.f3671c.c();
                        c0258p2.f3660G.c();
                        I.H0 h02 = c0258p2.f3661H;
                        I.F0 f02 = h02.a;
                        h02.f3517e = f02.f3507t;
                        h02.f3518f = f02.f3508u;
                    }
                    boolean zH = c0258p2.h(j1Var);
                    Object objG = c0258p2.G();
                    I.W w5 = C0250l.a;
                    if (zH || objG == w5) {
                        objG = new g1(j1Var, null);
                        c0258p2.a0(objG);
                    }
                    C0234d.e(c0258p2, (T3.e) objG, c1889s);
                    boolean zH2 = c0258p2.h(j1Var);
                    Object objG2 = c0258p2.G();
                    if (zH2 || objG2 == w5) {
                        objG2 = new h1(j1Var, null);
                        c0258p2.a0(objG2);
                    }
                    C0234d.e(c0258p2, (T3.e) objG2, c1889s);
                    C0234d.a(T.b.a.a(set), Q.f.b(-1193460702, new i1(j1Var, this.f14090n, 0), c0258p2), c0258p2, 56);
                }
                break;
        }
        return G3.C.a;
    }
}

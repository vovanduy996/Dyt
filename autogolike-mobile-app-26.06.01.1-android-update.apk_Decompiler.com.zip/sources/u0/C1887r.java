package u0;

/* JADX INFO: renamed from: u0.r, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1887r extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public /* synthetic */ Object f14144o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ C1889s f14145p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f14146q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1887r(C1889s c1889s, M3.c cVar) {
        super(cVar);
        this.f14145p = c1889s;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f14144o = obj;
        this.f14146q |= Integer.MIN_VALUE;
        this.f14145p.H(null, this);
        return L3.a.f4629l;
    }
}

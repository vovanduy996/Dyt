package u0;

import I.C0267u;
import I.InterfaceC0260q;
import androidx.lifecycle.C0578x;
import androidx.lifecycle.EnumC0569n;
import androidx.lifecycle.InterfaceC0574t;
import androidx.lifecycle.InterfaceC0576v;
import dagger.hilt.android.R;
import m.C1366t;

/* JADX INFO: loaded from: classes.dex */
public final class j1 implements InterfaceC0260q, InterfaceC0574t {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final C1889s f14095l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final C0267u f14096m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f14097n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public C0578x f14098o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Q.a f14099p = AbstractC1860d0.a;

    public j1(C1889s c1889s, C0267u c0267u) {
        this.f14095l = c1889s;
        this.f14096m = c0267u;
    }

    public final void c() {
        if (!this.f14097n) {
            this.f14097n = true;
            this.f14095l.getView().setTag(R.id.wrapped_composition_tag, null);
            C0578x c0578x = this.f14098o;
            if (c0578x != null) {
                c0578x.f(this);
            }
        }
        this.f14096m.l();
    }

    public final void d(Q.a aVar) {
        this.f14095l.setOnViewTreeOwnersAvailable(new C1366t(this, 17, aVar));
    }

    @Override // androidx.lifecycle.InterfaceC0574t
    public final void onStateChanged(InterfaceC0576v interfaceC0576v, EnumC0569n enumC0569n) {
        if (enumC0569n == EnumC0569n.ON_DESTROY) {
            c();
        } else {
            if (enumC0569n != EnumC0569n.ON_CREATE || this.f14097n) {
                return;
            }
            d(this.f14099p);
        }
    }
}

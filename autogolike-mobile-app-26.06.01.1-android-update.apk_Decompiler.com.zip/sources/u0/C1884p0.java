package u0;

import H0.InterfaceC0180m;
import java.lang.reflect.Method;

/* JADX INFO: renamed from: u0.p0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1884p0 implements K3.g, InterfaceC0180m {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final /* synthetic */ C1884p0 f14136l = new C1884p0();

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final W0 f14137m = new W0();

    public static final boolean a() {
        Class cls = C1889s.f14147J0;
        try {
            if (C1889s.f14147J0 == null) {
                Class<?> cls2 = Class.forName("android.os.SystemProperties");
                C1889s.f14147J0 = cls2;
                C1889s.f14148K0 = cls2.getDeclaredMethod("getBoolean", String.class, Boolean.TYPE);
            }
            Method method = C1889s.f14148K0;
            Object objInvoke = method != null ? method.invoke(null, "debug.layout", Boolean.FALSE) : null;
            Boolean bool = objInvoke instanceof Boolean ? (Boolean) objInvoke : null;
            if (bool != null) {
                return bool.booleanValue();
            }
            return false;
        } catch (Exception unused) {
            return false;
        }
    }
}

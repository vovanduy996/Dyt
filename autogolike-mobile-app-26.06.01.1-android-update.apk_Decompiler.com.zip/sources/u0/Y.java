package u0;

import android.view.ViewConfiguration;

/* JADX INFO: loaded from: classes.dex */
public final class Y {
    public static final Y a = new Y();

    public final float a(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledHandwritingGestureLineMargin();
    }

    public final float b(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledHandwritingSlop();
    }
}

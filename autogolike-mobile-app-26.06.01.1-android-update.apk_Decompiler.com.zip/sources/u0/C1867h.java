package u0;

import android.content.ClipboardManager;
import android.content.Context;

/* JADX INFO: renamed from: u0.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1867h implements InterfaceC1858c0 {
    public final ClipboardManager a;

    public C1867h(Context context) {
        Object systemService = context.getSystemService("clipboard");
        U3.j.d(systemService, "null cannot be cast to non-null type android.content.ClipboardManager");
        this.a = (ClipboardManager) systemService;
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x00b4  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void a(C0.C0052g r18) {
        /*
            Method dump skipped, instruction units count: 395
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.C1867h.a(C0.g):void");
    }
}

package u0;

/* JADX INFO: renamed from: u0.i0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1870i0 implements R.k {
    public final C1872j0 a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ R.l f14087b;

    public C1870i0(R.l lVar, C1872j0 c1872j0) {
        this.a = c1872j0;
        this.f14087b = lVar;
    }

    @Override // R.k
    public final boolean b(Object obj) {
        return this.f14087b.b(obj);
    }

    @Override // R.k
    public final F.A0 c(String str, A.I i5) {
        return this.f14087b.c(str, i5);
    }

    @Override // R.k
    public final Object d(String str) {
        return this.f14087b.d(str);
    }
}

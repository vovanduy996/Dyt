package u0;

import I.C0258p;
import android.graphics.Matrix;
import android.view.View;
import com.autogolike.mobile.core.backup.ConfigBackupDto;

/* JADX INFO: renamed from: u0.C, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1838C extends U3.k implements T3.e {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final C1838C f13877m = new C1838C(2, 0);

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final C1838C f13878n = new C1838C(2, 1);

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final C1838C f13879o = new C1838C(2, 2);

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final C1838C f13880p = new C1838C(2, 3);

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f13881l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C1838C(int i5, int i6) {
        super(i5);
        this.f13881l = i6;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        switch (this.f13881l) {
            case ConfigBackupDto.$stable /* 0 */:
                A0.o oVar = (A0.o) obj2;
                A0.i iVar = ((A0.o) obj).f237d;
                A0.u uVar = A0.r.f271n;
                Object objValueOf = iVar.f226l.get(uVar);
                if (objValueOf == null) {
                    objValueOf = Float.valueOf(0.0f);
                }
                float fFloatValue = ((Number) objValueOf).floatValue();
                Object objValueOf2 = oVar.f237d.f226l.get(uVar);
                if (objValueOf2 == null) {
                    objValueOf2 = Float.valueOf(0.0f);
                }
                break;
            case 1:
                C0258p c0258p = (C0258p) obj;
                if ((((Number) obj2).intValue() & 3) == 2 && c0258p.x()) {
                    c0258p.L();
                }
                break;
            case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                ((InterfaceC1868h0) obj).J((Matrix) obj2);
                break;
            default:
                ((Matrix) obj2).set(((View) obj).getMatrix());
                break;
        }
        return G3.C.a;
    }
}

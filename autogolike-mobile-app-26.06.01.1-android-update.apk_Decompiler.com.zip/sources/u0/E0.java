package u0;

import android.view.RenderNode;

/* JADX INFO: loaded from: classes.dex */
public final class E0 {
    public static final E0 a = new E0();

    public final void a(RenderNode renderNode) {
        renderNode.discardDisplayList();
    }
}

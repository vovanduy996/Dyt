package u0;

import android.graphics.RenderNode;
import android.view.contentcapture.ContentCaptureSession;

/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class A0 {
    public static /* synthetic */ RenderNode c() {
        return new RenderNode("Compose");
    }

    public static /* bridge */ /* synthetic */ ContentCaptureSession d(Object obj) {
        return (ContentCaptureSession) obj;
    }
}

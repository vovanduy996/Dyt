package u0;

import com.autogolike.mobile.core.backup.ConfigBackupDto;
import java.text.BreakIterator;

/* JADX INFO: renamed from: u0.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1857c extends AbstractC1855b {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static C1857c f14033e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static C1857c f14034f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static C1857c f14035g;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f14036c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f14037d;

    @Override // u0.AbstractC1855b
    public final int[] a(int i5) {
        int iE;
        switch (this.f14036c) {
            case ConfigBackupDto.$stable /* 0 */:
                int length = c().length();
                if (length <= 0 || i5 >= length) {
                    return null;
                }
                if (i5 < 0) {
                    i5 = 0;
                }
                do {
                    BreakIterator breakIterator = (BreakIterator) this.f14037d;
                    if (breakIterator == null) {
                        U3.j.j("impl");
                        throw null;
                    }
                    if (breakIterator.isBoundary(i5)) {
                        BreakIterator breakIterator2 = (BreakIterator) this.f14037d;
                        if (breakIterator2 == null) {
                            U3.j.j("impl");
                            throw null;
                        }
                        int iFollowing = breakIterator2.following(i5);
                        if (iFollowing == -1) {
                            return null;
                        }
                        return b(i5, iFollowing);
                    }
                    BreakIterator breakIterator3 = (BreakIterator) this.f14037d;
                    if (breakIterator3 == null) {
                        U3.j.j("impl");
                        throw null;
                    }
                    i5 = breakIterator3.following(i5);
                } while (i5 != -1);
                return null;
            case 1:
                if (c().length() <= 0 || i5 >= c().length()) {
                    return null;
                }
                if (i5 < 0) {
                    i5 = 0;
                }
                while (!h(i5) && (!h(i5) || (i5 != 0 && h(i5 - 1)))) {
                    BreakIterator breakIterator4 = (BreakIterator) this.f14037d;
                    if (breakIterator4 == null) {
                        U3.j.j("impl");
                        throw null;
                    }
                    i5 = breakIterator4.following(i5);
                    if (i5 == -1) {
                        return null;
                    }
                }
                BreakIterator breakIterator5 = (BreakIterator) this.f14037d;
                if (breakIterator5 == null) {
                    U3.j.j("impl");
                    throw null;
                }
                int iFollowing2 = breakIterator5.following(i5);
                if (iFollowing2 == -1 || !g(iFollowing2)) {
                    return null;
                }
                return b(i5, iFollowing2);
            default:
                if (c().length() <= 0 || i5 >= c().length()) {
                    return null;
                }
                N0.h hVar = N0.h.f5028m;
                if (i5 < 0) {
                    C0.I i6 = (C0.I) this.f14037d;
                    if (i6 == null) {
                        U3.j.j("layoutResult");
                        throw null;
                    }
                    iE = i6.e(0);
                } else {
                    C0.I i7 = (C0.I) this.f14037d;
                    if (i7 == null) {
                        U3.j.j("layoutResult");
                        throw null;
                    }
                    int iE2 = i7.e(i5);
                    iE = e(iE2, hVar) == i5 ? iE2 : iE2 + 1;
                }
                C0.I i8 = (C0.I) this.f14037d;
                if (i8 == null) {
                    U3.j.j("layoutResult");
                    throw null;
                }
                if (iE >= i8.f747b.f799f) {
                    return null;
                }
                return b(e(iE, hVar), e(iE, N0.h.f5027l) + 1);
        }
    }

    @Override // u0.AbstractC1855b
    public final int[] d(int i5) {
        int iE;
        switch (this.f14036c) {
            case ConfigBackupDto.$stable /* 0 */:
                int length = c().length();
                if (length <= 0 || i5 <= 0) {
                    return null;
                }
                if (i5 > length) {
                    i5 = length;
                }
                do {
                    BreakIterator breakIterator = (BreakIterator) this.f14037d;
                    if (breakIterator == null) {
                        U3.j.j("impl");
                        throw null;
                    }
                    if (breakIterator.isBoundary(i5)) {
                        BreakIterator breakIterator2 = (BreakIterator) this.f14037d;
                        if (breakIterator2 == null) {
                            U3.j.j("impl");
                            throw null;
                        }
                        int iPreceding = breakIterator2.preceding(i5);
                        if (iPreceding == -1) {
                            return null;
                        }
                        return b(iPreceding, i5);
                    }
                    BreakIterator breakIterator3 = (BreakIterator) this.f14037d;
                    if (breakIterator3 == null) {
                        U3.j.j("impl");
                        throw null;
                    }
                    i5 = breakIterator3.preceding(i5);
                } while (i5 != -1);
                return null;
            case 1:
                int length2 = c().length();
                if (length2 <= 0 || i5 <= 0) {
                    return null;
                }
                if (i5 > length2) {
                    i5 = length2;
                }
                while (i5 > 0 && !h(i5 - 1) && !g(i5)) {
                    BreakIterator breakIterator4 = (BreakIterator) this.f14037d;
                    if (breakIterator4 == null) {
                        U3.j.j("impl");
                        throw null;
                    }
                    i5 = breakIterator4.preceding(i5);
                    if (i5 == -1) {
                        return null;
                    }
                }
                BreakIterator breakIterator5 = (BreakIterator) this.f14037d;
                if (breakIterator5 == null) {
                    U3.j.j("impl");
                    throw null;
                }
                int iPreceding2 = breakIterator5.preceding(i5);
                if (iPreceding2 == -1 || !h(iPreceding2)) {
                    return null;
                }
                if (iPreceding2 == 0 || !h(iPreceding2 - 1)) {
                    return b(iPreceding2, i5);
                }
                return null;
            default:
                if (c().length() <= 0 || i5 <= 0) {
                    return null;
                }
                int length3 = c().length();
                N0.h hVar = N0.h.f5027l;
                if (i5 > length3) {
                    C0.I i6 = (C0.I) this.f14037d;
                    if (i6 == null) {
                        U3.j.j("layoutResult");
                        throw null;
                    }
                    iE = i6.e(c().length());
                } else {
                    C0.I i7 = (C0.I) this.f14037d;
                    if (i7 == null) {
                        U3.j.j("layoutResult");
                        throw null;
                    }
                    int iE2 = i7.e(i5);
                    iE = e(iE2, hVar) + 1 == i5 ? iE2 : iE2 - 1;
                }
                if (iE < 0) {
                    return null;
                }
                return b(e(iE, N0.h.f5028m), e(iE, hVar) + 1);
        }
    }

    public int e(int i5, N0.h hVar) {
        C0.I i6 = (C0.I) this.f14037d;
        if (i6 == null) {
            U3.j.j("layoutResult");
            throw null;
        }
        int iH = i6.h(i5);
        C0.I i7 = (C0.I) this.f14037d;
        if (i7 == null) {
            U3.j.j("layoutResult");
            throw null;
        }
        if (hVar != i7.i(iH)) {
            C0.I i8 = (C0.I) this.f14037d;
            if (i8 != null) {
                return i8.h(i5);
            }
            U3.j.j("layoutResult");
            throw null;
        }
        if (((C0.I) this.f14037d) != null) {
            return r6.d(i5, false) - 1;
        }
        U3.j.j("layoutResult");
        throw null;
    }

    public void f(String str) {
        switch (this.f14036c) {
            case ConfigBackupDto.$stable /* 0 */:
                this.a = str;
                BreakIterator breakIterator = (BreakIterator) this.f14037d;
                if (breakIterator != null) {
                    breakIterator.setText(str);
                    return;
                } else {
                    U3.j.j("impl");
                    throw null;
                }
            default:
                this.a = str;
                BreakIterator breakIterator2 = (BreakIterator) this.f14037d;
                if (breakIterator2 != null) {
                    breakIterator2.setText(str);
                    return;
                } else {
                    U3.j.j("impl");
                    throw null;
                }
        }
    }

    public boolean g(int i5) {
        return i5 > 0 && h(i5 + (-1)) && (i5 == c().length() || !h(i5));
    }

    public boolean h(int i5) {
        if (i5 < 0 || i5 >= c().length()) {
            return false;
        }
        return Character.isLetterOrDigit(c().codePointAt(i5));
    }
}

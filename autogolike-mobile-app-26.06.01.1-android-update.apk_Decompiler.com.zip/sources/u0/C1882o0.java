package u0;

import C0.C0046a;
import a0.AbstractC0490a;
import a0.C0491b;
import a0.C0492c;
import a0.C0493d;
import a0.C0494e;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Build;
import b0.AbstractC0586d;
import b0.C0590h;
import b0.C0592j;
import b0.C0603v;
import d0.C0823b;
import e0.C0844b;
import e0.InterfaceC0846d;
import f.C0933a;
import i.AbstractC1095G;
import i.C1091C;
import l3.AbstractC1324b;
import s.C1703N;
import t0.C1794a;

/* JADX INFO: renamed from: u0.o0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1882o0 implements t0.f0 {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public b0.L f14119A;
    public C0592j B;
    public C0590h C;
    public boolean D;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public C0844b f14121l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final b0.D f14122m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final C1889s f14123n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public C0046a f14124o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public C1703N f14125p;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f14127r;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public float[] f14129t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f14130u;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f14134y;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public long f14126q = E4.l.u(Integer.MAX_VALUE, Integer.MAX_VALUE);

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final float[] f14128s = b0.H.a();

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public O0.b f14131v = C0933a.l();

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public O0.k f14132w = O0.k.f5351l;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final C0823b f14133x = new C0823b();

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public long f14135z = b0.X.f7952b;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final C1794a f14120E = new C1794a(3, this);

    public C1882o0(C0844b c0844b, b0.D d3, C1889s c1889s, C0046a c0046a, C1703N c1703n) {
        this.f14121l = c0844b;
        this.f14122m = d3;
        this.f14123n = c1889s;
        this.f14124o = c0046a;
        this.f14125p = c1703n;
    }

    @Override // t0.f0
    public final void a(float[] fArr) {
        float[] fArrM = m();
        if (fArrM != null) {
            b0.H.g(fArr, fArrM);
        }
    }

    @Override // t0.f0
    public final void b(C0491b c0491b, boolean z3) {
        if (!z3) {
            b0.H.c(n(), c0491b);
            return;
        }
        float[] fArrM = m();
        if (fArrM != null) {
            b0.H.c(fArrM, c0491b);
            return;
        }
        c0491b.a = 0.0f;
        c0491b.f7212b = 0.0f;
        c0491b.f7213c = 0.0f;
        c0491b.f7214d = 0.0f;
    }

    @Override // t0.f0
    public final void c() {
        this.f14124o = null;
        this.f14125p = null;
        this.f14127r = true;
        boolean z3 = this.f14130u;
        C1889s c1889s = this.f14123n;
        if (z3) {
            this.f14130u = false;
            c1889s.u(this, false);
        }
        b0.D d3 = this.f14122m;
        if (d3 != null) {
            d3.a(this.f14121l);
            c1889s.C(this);
        }
    }

    @Override // t0.f0
    public final void d(long j5) {
        C0844b c0844b = this.f14121l;
        if (!O0.h.a(c0844b.f8813s, j5)) {
            c0844b.f8813s = j5;
            long j6 = c0844b.f8814t;
            c0844b.a.w((int) (j5 >> 32), (int) (j5 & 4294967295L), j6);
        }
        int i5 = Build.VERSION.SDK_INT;
        C1889s c1889s = this.f14123n;
        if (i5 >= 26) {
            k1.a.a(c1889s);
        } else {
            c1889s.invalidate();
        }
    }

    @Override // t0.f0
    public final void e() {
        if (this.f14130u) {
            if (!b0.X.a(this.f14135z, b0.X.f7952b) && !O0.j.a(this.f14121l.f8814t, this.f14126q)) {
                C0844b c0844b = this.f14121l;
                long jL = X2.g.l(b0.X.b(this.f14135z) * ((int) (this.f14126q >> 32)), b0.X.c(this.f14135z) * ((int) (this.f14126q & 4294967295L)));
                if (!C0492c.b(c0844b.f8815u, jL)) {
                    c0844b.f8815u = jL;
                    c0844b.a.H(jL);
                }
            }
            C0844b c0844b2 = this.f14121l;
            O0.b bVar = this.f14131v;
            O0.k kVar = this.f14132w;
            long j5 = this.f14126q;
            if (!O0.j.a(c0844b2.f8814t, j5)) {
                c0844b2.f8814t = j5;
                long j6 = c0844b2.f8813s;
                c0844b2.a.w((int) (j6 >> 32), (int) (4294967295L & j6), j5);
                if (c0844b2.f8803i == 9205357640488583168L) {
                    c0844b2.f8801g = true;
                    c0844b2.a();
                }
            }
            c0844b2.f8796b = bVar;
            c0844b2.f8797c = kVar;
            c0844b2.f8798d = this.f14120E;
            c0844b2.e();
            if (this.f14130u) {
                this.f14130u = false;
                this.f14123n.u(this, false);
            }
        }
    }

    @Override // t0.f0
    public final void f(long j5) {
        if (O0.j.a(j5, this.f14126q)) {
            return;
        }
        this.f14126q = j5;
        if (this.f14130u || this.f14127r) {
            return;
        }
        C1889s c1889s = this.f14123n;
        c1889s.invalidate();
        if (true != this.f14130u) {
            this.f14130u = true;
            c1889s.u(this, true);
        }
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // t0.f0
    public final void g(b0.r rVar, C0844b c0844b) {
        boolean z3;
        C0844b c0844b2;
        int i5;
        boolean z5;
        Canvas canvasA = AbstractC0586d.a(rVar);
        if (!canvasA.isHardwareAccelerated()) {
            C0844b c0844b3 = this.f14121l;
            long j5 = c0844b3.f8813s;
            float f5 = (int) (j5 >> 32);
            float f6 = (int) (j5 & 4294967295L);
            long j6 = this.f14126q;
            float f7 = f5 + ((int) (j6 >> 32));
            float f8 = f6 + ((int) (4294967295L & j6));
            if (c0844b3.a.a() < 1.0f) {
                C0590h c0590hG = this.C;
                if (c0590hG == null) {
                    c0590hG = b0.N.g();
                    this.C = c0590hG;
                }
                c0590hG.c(this.f14121l.a.a());
                canvasA.saveLayer(f5, f6, f7, f8, (Paint) c0590hG.f7959b);
            } else {
                rVar.f();
            }
            rVar.t(f5, f6);
            rVar.o(n());
            C0844b c0844b4 = this.f14121l;
            boolean z6 = c0844b4.f8816v;
            if (z6 && z6) {
                b0.L lC = c0844b4.c();
                if (lC instanceof b0.J) {
                    b0.r.d(rVar, ((b0.J) lC).a);
                } else if (lC instanceof b0.K) {
                    C0592j c0592jH = this.B;
                    if (c0592jH == null) {
                        c0592jH = b0.N.h();
                        this.B = c0592jH;
                    }
                    c0592jH.e();
                    b0.M.a(c0592jH, ((b0.K) lC).a);
                    rVar.i(c0592jH, 1);
                } else if (lC instanceof b0.I) {
                    rVar.i(((b0.I) lC).a, 1);
                }
            }
            C0046a c0046a = this.f14124o;
            if (c0046a != null) {
                c0046a.i(rVar, null);
            }
            rVar.a();
            return;
        }
        e();
        this.D = this.f14121l.a.A() > 0.0f;
        C0823b c0823b = this.f14133x;
        F.A0 a02 = c0823b.f8740m;
        a02.y(rVar);
        a02.f1395n = c0844b;
        C0844b c0844b5 = this.f14121l;
        b0.r rVarI = c0823b.T().i();
        C0844b c0844b6 = (C0844b) c0823b.T().f1395n;
        if (c0844b5.f8812r) {
            return;
        }
        c0844b5.a();
        InterfaceC0846d interfaceC0846d = c0844b5.a;
        if (!interfaceC0846d.l()) {
            try {
                c0844b5.e();
            } catch (Throwable unused) {
            }
        }
        boolean z7 = interfaceC0846d.A() > 0.0f;
        if (z7) {
            rVarI.q();
        }
        Canvas canvasA2 = AbstractC0586d.a(rVarI);
        boolean zIsHardwareAccelerated = canvasA2.isHardwareAccelerated();
        if (zIsHardwareAccelerated) {
            z3 = z7;
            c0844b2 = c0844b6;
        } else {
            canvasA2.save();
            z3 = z7;
            long j7 = c0844b5.f8813s;
            float f9 = (int) (j7 >> 32);
            float f10 = (int) (j7 & 4294967295L);
            long j8 = c0844b5.f8814t;
            c0844b2 = c0844b6;
            float f11 = f9 + ((int) (j8 >> 32));
            float f12 = f10 + ((int) (4294967295L & j8));
            float fA = interfaceC0846d.a();
            int iG = interfaceC0846d.G();
            if (fA < 1.0f || !b0.N.p(iG, 3) || E4.d.F(interfaceC0846d.L(), 1)) {
                C0590h c0590hG2 = c0844b5.f8809o;
                if (c0590hG2 == null) {
                    c0590hG2 = b0.N.g();
                    c0844b5.f8809o = c0590hG2;
                }
                c0590hG2.c(fA);
                c0590hG2.d(iG);
                c0590hG2.f(null);
                canvasA2.saveLayer(f9, f10, f11, f12, (Paint) c0590hG2.f7959b);
            } else {
                canvasA2.save();
            }
            canvasA2.translate(f9, f10);
            canvasA2.concat(interfaceC0846d.t());
        }
        boolean z8 = !zIsHardwareAccelerated && c0844b5.f8816v;
        if (z8) {
            rVarI.f();
            b0.L lC2 = c0844b5.c();
            if (lC2 instanceof b0.J) {
                b0.r.d(rVarI, lC2.a());
            } else if (lC2 instanceof b0.K) {
                C0592j c0592jH2 = c0844b5.f8807m;
                if (c0592jH2 != null) {
                    c0592jH2.a.rewind();
                } else {
                    c0592jH2 = b0.N.h();
                    c0844b5.f8807m = c0592jH2;
                }
                b0.M.a(c0592jH2, ((b0.K) lC2).a);
                rVarI.i(c0592jH2, 1);
            } else if (lC2 instanceof b0.I) {
                rVarI.i(((b0.I) lC2).a, 1);
            }
        }
        if (c0844b2 != null) {
            A4.e eVar = c0844b2.f8811q;
            if (!eVar.a) {
                throw new IllegalArgumentException("Only add dependencies during a tracking");
            }
            C1091C c1091c = (C1091C) eVar.f372d;
            if (c1091c != null) {
                c1091c.a(c0844b5);
            } else if (((C0844b) eVar.f370b) != null) {
                int i6 = AbstractC1095G.a;
                C1091C c1091c2 = new C1091C();
                C0844b c0844b7 = (C0844b) eVar.f370b;
                U3.j.c(c0844b7);
                c1091c2.a(c0844b7);
                c1091c2.a(c0844b5);
                eVar.f372d = c1091c2;
                eVar.f370b = null;
            } else {
                eVar.f370b = c0844b5;
            }
            C1091C c1091c3 = (C1091C) eVar.f373e;
            if (c1091c3 != null) {
                boolean zJ = c1091c3.j(c0844b5);
                i5 = 1;
                z5 = !zJ;
            } else {
                i5 = 1;
                if (((C0844b) eVar.f371c) != c0844b5) {
                    z5 = true;
                } else {
                    eVar.f371c = null;
                    z5 = false;
                }
            }
            if (z5) {
                c0844b5.f8810p += i5;
            }
        }
        interfaceC0846d.r(rVarI);
        if (z8) {
            rVarI.a();
        }
        if (z3) {
            rVarI.h();
        }
        if (zIsHardwareAccelerated) {
            return;
        }
        canvasA2.restore();
    }

    @Override // t0.f0
    public final void h(float[] fArr) {
        b0.H.g(fArr, n());
    }

    @Override // t0.f0
    public final long i(boolean z3, long j5) {
        if (!z3) {
            return b0.H.b(j5, n());
        }
        float[] fArrM = m();
        if (fArrM != null) {
            return b0.H.b(j5, fArrM);
        }
        return 9187343241974906880L;
    }

    @Override // t0.f0
    public final void invalidate() {
        if (this.f14130u || this.f14127r) {
            return;
        }
        C1889s c1889s = this.f14123n;
        c1889s.invalidate();
        if (true != this.f14130u) {
            this.f14130u = true;
            c1889s.u(this, true);
        }
    }

    @Override // t0.f0
    public final boolean j(long j5) {
        float fD = C0492c.d(j5);
        float fE = C0492c.e(j5);
        C0844b c0844b = this.f14121l;
        if (c0844b.f8816v) {
            return AbstractC1846K.s(c0844b.c(), fD, fE, null, null);
        }
        return true;
    }

    @Override // t0.f0
    public final void k(b0.P p4) {
        C1703N c1703n;
        int i5;
        C1703N c1703n2;
        int i6 = p4.f7919l | this.f14134y;
        this.f14132w = p4.f7917E;
        this.f14131v = p4.D;
        int i7 = i6 & 4096;
        if (i7 != 0) {
            this.f14135z = p4.f7932y;
        }
        if ((i6 & 1) != 0) {
            C0844b c0844b = this.f14121l;
            float f5 = p4.f7920m;
            InterfaceC0846d interfaceC0846d = c0844b.a;
            if (interfaceC0846d.s() != f5) {
                interfaceC0846d.m(f5);
            }
        }
        if ((i6 & 2) != 0) {
            C0844b c0844b2 = this.f14121l;
            float f6 = p4.f7921n;
            InterfaceC0846d interfaceC0846d2 = c0844b2.a;
            if (interfaceC0846d2.D() != f6) {
                interfaceC0846d2.e(f6);
            }
        }
        if ((i6 & 4) != 0) {
            C0844b c0844b3 = this.f14121l;
            float f7 = p4.f7922o;
            InterfaceC0846d interfaceC0846d3 = c0844b3.a;
            if (interfaceC0846d3.a() != f7) {
                interfaceC0846d3.d(f7);
            }
        }
        if ((i6 & 8) != 0) {
            C0844b c0844b4 = this.f14121l;
            float f8 = p4.f7923p;
            InterfaceC0846d interfaceC0846d4 = c0844b4.a;
            if (interfaceC0846d4.J() != f8) {
                interfaceC0846d4.c(f8);
            }
        }
        if ((i6 & 16) != 0) {
            C0844b c0844b5 = this.f14121l;
            float f9 = p4.f7924q;
            InterfaceC0846d interfaceC0846d5 = c0844b5.a;
            if (interfaceC0846d5.v() != f9) {
                interfaceC0846d5.j(f9);
            }
        }
        boolean z3 = true;
        if ((i6 & 32) != 0) {
            C0844b c0844b6 = this.f14121l;
            float f10 = p4.f7925r;
            InterfaceC0846d interfaceC0846d6 = c0844b6.a;
            if (interfaceC0846d6.A() != f10) {
                interfaceC0846d6.u(f10);
                c0844b6.f8801g = true;
                c0844b6.a();
            }
            if (p4.f7925r > 0.0f && !this.D && (c1703n2 = this.f14125p) != null) {
                c1703n2.b();
            }
        }
        if ((i6 & 64) != 0) {
            C0844b c0844b7 = this.f14121l;
            long j5 = p4.f7926s;
            InterfaceC0846d interfaceC0846d7 = c0844b7.a;
            if (!C0603v.c(j5, interfaceC0846d7.I())) {
                interfaceC0846d7.z(j5);
            }
        }
        if ((i6 & 128) != 0) {
            C0844b c0844b8 = this.f14121l;
            long j6 = p4.f7927t;
            InterfaceC0846d interfaceC0846d8 = c0844b8.a;
            if (!C0603v.c(j6, interfaceC0846d8.y())) {
                interfaceC0846d8.q(j6);
            }
        }
        if ((i6 & 1024) != 0) {
            C0844b c0844b9 = this.f14121l;
            float f11 = p4.f7930w;
            InterfaceC0846d interfaceC0846d9 = c0844b9.a;
            if (interfaceC0846d9.F() != f11) {
                interfaceC0846d9.i(f11);
            }
        }
        if ((i6 & 256) != 0) {
            C0844b c0844b10 = this.f14121l;
            float f12 = p4.f7928u;
            InterfaceC0846d interfaceC0846d10 = c0844b10.a;
            if (interfaceC0846d10.M() != f12) {
                interfaceC0846d10.n(f12);
            }
        }
        if ((i6 & 512) != 0) {
            C0844b c0844b11 = this.f14121l;
            float f13 = p4.f7929v;
            InterfaceC0846d interfaceC0846d11 = c0844b11.a;
            if (interfaceC0846d11.x() != f13) {
                interfaceC0846d11.b(f13);
            }
        }
        if ((i6 & 2048) != 0) {
            C0844b c0844b12 = this.f14121l;
            float f14 = p4.f7931x;
            InterfaceC0846d interfaceC0846d12 = c0844b12.a;
            if (interfaceC0846d12.E() != f14) {
                interfaceC0846d12.k(f14);
            }
        }
        if (i7 != 0) {
            if (b0.X.a(this.f14135z, b0.X.f7952b)) {
                C0844b c0844b13 = this.f14121l;
                if (!C0492c.b(c0844b13.f8815u, 9205357640488583168L)) {
                    c0844b13.f8815u = 9205357640488583168L;
                    c0844b13.a.H(9205357640488583168L);
                }
            } else {
                C0844b c0844b14 = this.f14121l;
                long jL = X2.g.l(b0.X.b(this.f14135z) * ((int) (this.f14126q >> 32)), b0.X.c(this.f14135z) * ((int) (this.f14126q & 4294967295L)));
                if (!C0492c.b(c0844b14.f8815u, jL)) {
                    c0844b14.f8815u = jL;
                    c0844b14.a.H(jL);
                }
            }
        }
        if ((i6 & 16384) != 0) {
            C0844b c0844b15 = this.f14121l;
            boolean z5 = p4.f7916A;
            if (c0844b15.f8816v != z5) {
                c0844b15.f8816v = z5;
                c0844b15.f8801g = true;
                c0844b15.a();
            }
        }
        if ((131072 & i6) != 0) {
            InterfaceC0846d interfaceC0846d13 = this.f14121l.a;
            if (!U3.j.a(null, null)) {
                interfaceC0846d13.g();
            }
        }
        if ((32768 & i6) != 0) {
            C0844b c0844b16 = this.f14121l;
            int i8 = p4.B;
            if (b0.N.q(i8, 0)) {
                i5 = 0;
            } else if (b0.N.q(i8, 1)) {
                i5 = 1;
            } else {
                i5 = 2;
                if (!b0.N.q(i8, 2)) {
                    throw new IllegalStateException("Not supported composition strategy");
                }
            }
            InterfaceC0846d interfaceC0846d14 = c0844b16.a;
            if (!E4.d.F(interfaceC0846d14.L(), i5)) {
                interfaceC0846d14.p(i5);
            }
        }
        if (U3.j.a(this.f14119A, p4.f7918F)) {
            z3 = false;
        } else {
            b0.L l4 = p4.f7918F;
            this.f14119A = l4;
            if (l4 != null) {
                C0844b c0844b17 = this.f14121l;
                if (l4 instanceof b0.J) {
                    C0493d c0493d = ((b0.J) l4).a;
                    c0844b17.f(X2.g.l(c0493d.a, c0493d.f7216b), AbstractC1324b.d(c0493d.c(), c0493d.b()), 0.0f);
                } else if (l4 instanceof b0.I) {
                    c0844b17.f8805k = null;
                    c0844b17.f8803i = 9205357640488583168L;
                    c0844b17.f8802h = 0L;
                    c0844b17.f8804j = 0.0f;
                    c0844b17.f8801g = true;
                    c0844b17.f8808n = false;
                    c0844b17.f8806l = ((b0.I) l4).a;
                    c0844b17.a();
                } else if (l4 instanceof b0.K) {
                    b0.K k5 = (b0.K) l4;
                    C0592j c0592j = k5.f7912b;
                    if (c0592j != null) {
                        c0844b17.f8805k = null;
                        c0844b17.f8803i = 9205357640488583168L;
                        c0844b17.f8802h = 0L;
                        c0844b17.f8804j = 0.0f;
                        c0844b17.f8801g = true;
                        c0844b17.f8808n = false;
                        c0844b17.f8806l = c0592j;
                        c0844b17.a();
                    } else {
                        C0494e c0494e = k5.a;
                        c0844b17.f(X2.g.l(c0494e.a, c0494e.f7219b), AbstractC1324b.d(c0494e.b(), c0494e.a()), AbstractC0490a.b(c0494e.f7225h));
                    }
                }
                if ((l4 instanceof b0.I) && Build.VERSION.SDK_INT < 33 && (c1703n = this.f14125p) != null) {
                    c1703n.b();
                }
            }
        }
        this.f14134y = p4.f7919l;
        if (i6 != 0 || z3) {
            int i9 = Build.VERSION.SDK_INT;
            C1889s c1889s = this.f14123n;
            if (i9 >= 26) {
                k1.a.a(c1889s);
            } else {
                c1889s.invalidate();
            }
        }
    }

    @Override // t0.f0
    public final void l(C0046a c0046a, C1703N c1703n) {
        b0.D d3 = this.f14122m;
        if (d3 == null) {
            throw new IllegalArgumentException("currently reuse is only supported when we manage the layer lifecycle");
        }
        if (!this.f14121l.f8812r) {
            throw new IllegalArgumentException("layer should have been released before reuse");
        }
        this.f14121l = d3.b();
        this.f14127r = false;
        this.f14124o = c0046a;
        this.f14125p = c1703n;
        this.f14135z = b0.X.f7952b;
        this.D = false;
        this.f14126q = E4.l.u(Integer.MAX_VALUE, Integer.MAX_VALUE);
        this.f14119A = null;
        this.f14134y = 0;
    }

    public final float[] m() {
        float[] fArrN = n();
        float[] fArrA = this.f14129t;
        if (fArrA == null) {
            fArrA = b0.H.a();
            this.f14129t = fArrA;
        }
        if (AbstractC1846K.q(fArrN, fArrA)) {
            return fArrA;
        }
        return null;
    }

    public final float[] n() {
        C0844b c0844b = this.f14121l;
        long jU = X2.g.Q(c0844b.f8815u) ? AbstractC1324b.u(E4.l.M0(this.f14126q)) : c0844b.f8815u;
        float[] fArr = this.f14128s;
        b0.H.d(fArr);
        float[] fArrA = b0.H.a();
        b0.H.h(-C0492c.d(jU), -C0492c.e(jU), 0.0f, fArrA);
        b0.H.g(fArr, fArrA);
        float[] fArrA2 = b0.H.a();
        InterfaceC0846d interfaceC0846d = c0844b.a;
        b0.H.h(interfaceC0846d.J(), interfaceC0846d.v(), 0.0f, fArrA2);
        double dM = (((double) interfaceC0846d.M()) * 3.141592653589793d) / 180.0d;
        float fCos = (float) Math.cos(dM);
        float fSin = (float) Math.sin(dM);
        float f5 = fArrA2[1];
        float f6 = fArrA2[2];
        float f7 = fArrA2[5];
        float f8 = fArrA2[6];
        float f9 = fArrA2[9];
        float f10 = fArrA2[10];
        float f11 = fArrA2[13];
        float f12 = fArrA2[14];
        fArrA2[1] = (f5 * fCos) - (f6 * fSin);
        fArrA2[2] = (f6 * fCos) + (f5 * fSin);
        fArrA2[5] = (f7 * fCos) - (f8 * fSin);
        fArrA2[6] = (f8 * fCos) + (f7 * fSin);
        fArrA2[9] = (f9 * fCos) - (f10 * fSin);
        fArrA2[10] = (f10 * fCos) + (f9 * fSin);
        fArrA2[13] = (f11 * fCos) - (f12 * fSin);
        fArrA2[14] = (f12 * fCos) + (f11 * fSin);
        double dX = (((double) interfaceC0846d.x()) * 3.141592653589793d) / 180.0d;
        float fCos2 = (float) Math.cos(dX);
        float fSin2 = (float) Math.sin(dX);
        float f13 = fArrA2[0];
        float f14 = fArrA2[2];
        float f15 = fArrA2[4];
        float f16 = fArrA2[6];
        float f17 = (f16 * fSin2) + (f15 * fCos2);
        float f18 = (f16 * fCos2) + ((-f15) * fSin2);
        float f19 = fArrA2[8];
        float f20 = fArrA2[10];
        float f21 = fArrA2[12];
        float f22 = fArrA2[14];
        fArrA2[0] = (f14 * fSin2) + (f13 * fCos2);
        fArrA2[2] = (f14 * fCos2) + ((-f13) * fSin2);
        fArrA2[4] = f17;
        fArrA2[6] = f18;
        fArrA2[8] = (f20 * fSin2) + (f19 * fCos2);
        fArrA2[10] = (f20 * fCos2) + ((-f19) * fSin2);
        fArrA2[12] = (f22 * fSin2) + (f21 * fCos2);
        fArrA2[14] = (f22 * fCos2) + ((-f21) * fSin2);
        b0.H.e(fArrA2, interfaceC0846d.F());
        b0.H.f(interfaceC0846d.s(), interfaceC0846d.D(), 1.0f, fArrA2);
        b0.H.g(fArr, fArrA2);
        float[] fArrA3 = b0.H.a();
        b0.H.h(C0492c.d(jU), C0492c.e(jU), 0.0f, fArrA3);
        b0.H.g(fArr, fArrA3);
        return fArr;
    }
}

package u0;

import a0.C0493d;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import java.util.Comparator;

/* JADX INFO: renamed from: u0.y, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1901y implements Comparator {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final C1901y f14243b = new C1901y(0);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final C1901y f14244c = new C1901y(1);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final C1901y f14245d = new C1901y(2);
    public final /* synthetic */ int a;

    public /* synthetic */ C1901y(int i5) {
        this.a = i5;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        switch (this.a) {
            case ConfigBackupDto.$stable /* 0 */:
                C0493d c0493dF = ((A0.o) obj).f();
                C0493d c0493dF2 = ((A0.o) obj2).f();
                int iCompare = Float.compare(c0493dF.a, c0493dF2.a);
                if (iCompare != 0) {
                    return iCompare;
                }
                int iCompare2 = Float.compare(c0493dF.f7216b, c0493dF2.f7216b);
                if (iCompare2 != 0) {
                    return iCompare2;
                }
                int iCompare3 = Float.compare(c0493dF.f7218d, c0493dF2.f7218d);
                return iCompare3 != 0 ? iCompare3 : Float.compare(c0493dF.f7217c, c0493dF2.f7217c);
            case 1:
                C0493d c0493dF3 = ((A0.o) obj).f();
                C0493d c0493dF4 = ((A0.o) obj2).f();
                int iCompare4 = Float.compare(c0493dF4.f7217c, c0493dF3.f7217c);
                if (iCompare4 != 0) {
                    return iCompare4;
                }
                int iCompare5 = Float.compare(c0493dF3.f7216b, c0493dF4.f7216b);
                if (iCompare5 != 0) {
                    return iCompare5;
                }
                int iCompare6 = Float.compare(c0493dF3.f7218d, c0493dF4.f7218d);
                return iCompare6 != 0 ? iCompare6 : Float.compare(c0493dF4.a, c0493dF3.a);
            default:
                G3.l lVar = (G3.l) obj;
                G3.l lVar2 = (G3.l) obj2;
                int iCompare7 = Float.compare(((C0493d) lVar.f2637l).f7216b, ((C0493d) lVar2.f2637l).f7216b);
                return iCompare7 != 0 ? iCompare7 : Float.compare(((C0493d) lVar.f2637l).f7218d, ((C0493d) lVar2.f2637l).f7218d);
        }
    }
}

package u0;

import android.view.RenderNode;

/* JADX INFO: loaded from: classes.dex */
public final class F0 {
    public static final F0 a = new F0();

    public final int a(RenderNode renderNode) {
        return renderNode.getAmbientShadowColor();
    }

    public final int b(RenderNode renderNode) {
        return renderNode.getSpotShadowColor();
    }

    public final void c(RenderNode renderNode, int i5) {
        renderNode.setAmbientShadowColor(i5);
    }

    public final void d(RenderNode renderNode, int i5) {
        renderNode.setSpotShadowColor(i5);
    }
}

package u0;

import android.view.PointerIcon;
import android.view.View;
import n0.C1435a;
import n0.InterfaceC1449o;

/* JADX INFO: renamed from: u0.I, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1844I {
    public static final C1844I a = new C1844I();

    public final void a(View view, InterfaceC1449o interfaceC1449o) {
        PointerIcon systemIcon = interfaceC1449o instanceof C1435a ? PointerIcon.getSystemIcon(view.getContext(), ((C1435a) interfaceC1449o).f11933b) : PointerIcon.getSystemIcon(view.getContext(), 1000);
        if (U3.j.a(view.getPointerIcon(), systemIcon)) {
            return;
        }
        view.setPointerIcon(systemIcon);
    }
}

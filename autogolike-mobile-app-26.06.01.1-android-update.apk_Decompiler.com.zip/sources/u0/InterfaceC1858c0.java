package u0;

/* JADX INFO: renamed from: u0.c0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC1858c0 {
}

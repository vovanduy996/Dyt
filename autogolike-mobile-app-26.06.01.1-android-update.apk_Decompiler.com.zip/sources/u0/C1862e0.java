package u0;

import I.C0234d;
import I.C0247j0;
import I.C0258p;
import I.C0264s0;
import android.content.ContextWrapper;

/* JADX INFO: renamed from: u0.e0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1862e0 extends AbstractC1853a {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final C0247j0 f14054t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f14055u;

    public C1862e0(ContextWrapper contextWrapper) {
        super(contextWrapper, null, 0);
        this.f14054t = C0234d.K(null, I.W.f3598q);
    }

    @Override // u0.AbstractC1853a
    public final void a(int i5, C0258p c0258p) {
        int i6;
        c0258p.S(420213850);
        if ((i5 & 6) == 0) {
            i6 = (c0258p.h(this) ? 4 : 2) | i5;
        } else {
            i6 = i5;
        }
        if ((i6 & 3) == 2 && c0258p.x()) {
            c0258p.L();
        } else {
            T3.e eVar = (T3.e) this.f14054t.getValue();
            if (eVar == null) {
                c0258p.Q(358373017);
            } else {
                c0258p.Q(150107752);
                eVar.i(c0258p, 0);
            }
            c0258p.p(false);
        }
        C0264s0 c0264s0R = c0258p.r();
        if (c0264s0R != null) {
            c0264s0R.f3706d = new R0.u(i5, 5, this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public CharSequence getAccessibilityClassName() {
        return C1862e0.class.getName();
    }

    @Override // u0.AbstractC1853a
    public boolean getShouldCreateCompositionOnAttachedToWindow() {
        return this.f14055u;
    }

    public final void setContent(T3.e eVar) {
        this.f14055u = true;
        this.f14054t.setValue(eVar);
        if (isAttachedToWindow()) {
            if (this.f14023o == null && !isAttachedToWindow()) {
                throw new IllegalStateException("createComposition requires either a parent reference or the View to be attachedto a window. Attach the View or call setParentCompositionReference.");
            }
            c();
        }
    }

    public static /* synthetic */ void getShouldCreateCompositionOnAttachedToWindow$annotations() {
    }
}

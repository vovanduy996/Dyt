package u0;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import com.google.android.gms.internal.measurement.AbstractC0813y0;
import java.util.HashMap;
import java.util.Iterator;
import m1.AbstractC1393s;

/* JADX INFO: loaded from: classes.dex */
public final class Z extends ViewGroup {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final HashMap f14016l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final HashMap f14017m;

    public Z(Context context) {
        super(context);
        setClipChildren(false);
        this.f14016l = new HashMap();
        this.f14017m = new HashMap();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchTouchEvent(MotionEvent motionEvent) {
        return true;
    }

    public final HashMap<Object, t0.E> getHolderToLayoutNode() {
        return this.f14016l;
    }

    public final HashMap<t0.E, Object> getLayoutNodeToHolder() {
        return this.f14017m;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final /* bridge */ /* synthetic */ ViewParent invalidateChildInParent(int[] iArr, Rect rect) {
        return null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i5, int i6, int i7, int i8) {
        Iterator it = this.f14016l.keySet().iterator();
        if (it.hasNext()) {
            AbstractC0813y0.w(it.next());
            throw null;
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i5, int i6) {
        if (!(View.MeasureSpec.getMode(i5) == 1073741824)) {
            AbstractC1393s.Z("widthMeasureSpec should be EXACTLY");
            throw null;
        }
        if (!(View.MeasureSpec.getMode(i6) == 1073741824)) {
            AbstractC1393s.Z("heightMeasureSpec should be EXACTLY");
            throw null;
        }
        setMeasuredDimension(View.MeasureSpec.getSize(i5), View.MeasureSpec.getSize(i6));
        Iterator it = this.f14016l.keySet().iterator();
        if (it.hasNext()) {
            AbstractC0813y0.w(it.next());
            throw null;
        }
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        cleanupLayoutState(this);
        int childCount = getChildCount();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            t0.E e5 = (t0.E) this.f14016l.get(childAt);
            if (childAt.isLayoutRequested() && e5 != null) {
                t0.E.S(e5, false, 7);
            }
        }
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onDescendantInvalidated(View view, View view2) {
    }
}

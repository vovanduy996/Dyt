package u0;

import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: loaded from: classes.dex */
public abstract class Y0 {
    public static final AtomicReference a = new AtomicReference(C1884p0.f14137m);
}

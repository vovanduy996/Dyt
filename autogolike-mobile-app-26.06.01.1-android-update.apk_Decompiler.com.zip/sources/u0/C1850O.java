package u0;

/* JADX INFO: renamed from: u0.O, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1850O extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public /* synthetic */ Object f13969o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ C1852Q f13970p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f13971q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1850O(C1852Q c1852q, M3.c cVar) {
        super(cVar);
        this.f13970p = c1852q;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f13969o = obj;
        this.f13971q |= Integer.MIN_VALUE;
        this.f13970p.a(null, this);
        return L3.a.f4629l;
    }
}

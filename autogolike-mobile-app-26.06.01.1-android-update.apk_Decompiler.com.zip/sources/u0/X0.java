package u0;

import G3.AbstractC0164a;
import I.C0268u0;
import I.C0278z0;
import android.view.View;
import dagger.hilt.android.R;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: loaded from: classes.dex */
public final class X0 extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f14013p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ C0278z0 f14014q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ View f14015r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public X0(C0278z0 c0278z0, View view, Continuation continuation) {
        super(2, continuation);
        this.f14014q = c0278z0;
        this.f14015r = view;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((X0) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new X0(this.f14014q, this.f14015r, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f14013p;
        G3.C c5 = G3.C.a;
        C0278z0 c0278z0 = this.f14014q;
        View view = this.f14015r;
        try {
            if (i5 == 0) {
                AbstractC0164a.e(obj);
                this.f14013p = 1;
                Object objL = i4.O.l(c0278z0.f3794r, new C0268u0(2, null), this);
                if (objL != aVar) {
                    objL = c5;
                }
                if (objL == aVar) {
                    return aVar;
                }
            } else {
                if (i5 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                AbstractC0164a.e(obj);
            }
            if (f1.b(view) == c0278z0) {
                view.setTag(R.id.androidx_compose_ui_view_composition_context, null);
            }
            return c5;
        } finally {
            if (f1.b(view) == c0278z0) {
                view.setTag(R.id.androidx_compose_ui_view_composition_context, null);
            }
        }
    }
}

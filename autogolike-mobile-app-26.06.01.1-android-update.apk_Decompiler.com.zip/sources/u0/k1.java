package u0;

import android.view.ViewParent;

/* JADX INFO: loaded from: classes.dex */
public final class k1 {
    public static final k1 a = new k1();

    public final void a(C1889s c1889s) {
        ViewParent parent = c1889s.getParent();
        if (parent != null) {
            parent.onDescendantInvalidated(c1889s, c1889s);
        }
    }
}

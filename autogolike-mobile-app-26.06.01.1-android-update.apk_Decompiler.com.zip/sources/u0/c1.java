package u0;

import I.C0278z0;
import android.view.View;
import androidx.lifecycle.InterfaceC0576v;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: loaded from: classes.dex */
public final class c1 extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f14038p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f14039q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ U3.u f14040r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ C0278z0 f14041s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0576v f14042t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ d1 f14043u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ View f14044v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c1(U3.u uVar, C0278z0 c0278z0, InterfaceC0576v interfaceC0576v, d1 d1Var, View view, Continuation continuation) {
        super(2, continuation);
        this.f14040r = uVar;
        this.f14041s = c0278z0;
        this.f14042t = interfaceC0576v;
        this.f14043u = d1Var;
        this.f14044v = view;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((c1) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        c1 c1Var = new c1(this.f14040r, this.f14041s, this.f14042t, this.f14043u, this.f14044v, continuation);
        c1Var.f14039q = obj;
        return c1Var;
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x008d  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00a0  */
    @Override // M3.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object o(java.lang.Object r12) throws java.lang.Throwable {
        /*
            r11 = this;
            L3.a r0 = L3.a.f4629l
            int r1 = r11.f14038p
            androidx.lifecycle.v r2 = r11.f14042t
            G3.C r3 = G3.C.a
            r4 = 0
            u0.d1 r5 = r11.f14043u
            r6 = 1
            if (r1 == 0) goto L24
            if (r1 != r6) goto L1c
            java.lang.Object r0 = r11.f14039q
            f4.b0 r0 = (f4.b0) r0
            G3.AbstractC0164a.e(r12)     // Catch: java.lang.Throwable -> L19
            goto L8b
        L19:
            r12 = move-exception
            goto L9e
        L1c:
            java.lang.IllegalStateException r12 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r12.<init>(r0)
            throw r12
        L24:
            G3.AbstractC0164a.e(r12)
            java.lang.Object r12 = r11.f14039q
            f4.y r12 = (f4.InterfaceC0991y) r12
            U3.u r1 = r11.f14040r     // Catch: java.lang.Throwable -> L5d
            java.lang.Object r1 = r1.f6192l     // Catch: java.lang.Throwable -> L5d
            u0.t0 r1 = (u0.C1892t0) r1     // Catch: java.lang.Throwable -> L5d
            if (r1 == 0) goto L5f
            android.view.View r7 = r11.f14044v     // Catch: java.lang.Throwable -> L5d
            android.content.Context r7 = r7.getContext()     // Catch: java.lang.Throwable -> L5d
            android.content.Context r7 = r7.getApplicationContext()     // Catch: java.lang.Throwable -> L5d
            i4.a0 r7 = u0.f1.a(r7)     // Catch: java.lang.Throwable -> L5d
            java.lang.Object r8 = r7.getValue()     // Catch: java.lang.Throwable -> L5d
            java.lang.Number r8 = (java.lang.Number) r8     // Catch: java.lang.Throwable -> L5d
            float r8 = r8.floatValue()     // Catch: java.lang.Throwable -> L5d
            I.f0 r9 = r1.f14224l     // Catch: java.lang.Throwable -> L5d
            r9.i(r8)     // Catch: java.lang.Throwable -> L5d
            u0.b1 r8 = new u0.b1     // Catch: java.lang.Throwable -> L5d
            r8.<init>(r7, r1, r4)     // Catch: java.lang.Throwable -> L5d
            r1 = 3
            f4.p0 r12 = f4.AbstractC0952A.s(r12, r4, r4, r8, r1)     // Catch: java.lang.Throwable -> L5d
            goto L60
        L5b:
            r0 = r4
            goto L9e
        L5d:
            r12 = move-exception
            goto L5b
        L5f:
            r12 = r4
        L60:
            I.z0 r1 = r11.f14041s     // Catch: java.lang.Throwable -> L9c
            r11.f14039q = r12     // Catch: java.lang.Throwable -> L9c
            r11.f14038p = r6     // Catch: java.lang.Throwable -> L9c
            I.y0 r6 = new I.y0     // Catch: java.lang.Throwable -> L9c
            r6.<init>(r1, r4)     // Catch: java.lang.Throwable -> L9c
            K3.h r7 = r11.f4841m     // Catch: java.lang.Throwable -> L9c
            U3.j.c(r7)     // Catch: java.lang.Throwable -> L9c
            I.X r7 = I.C0234d.F(r7)     // Catch: java.lang.Throwable -> L9c
            I.w0 r8 = new I.w0     // Catch: java.lang.Throwable -> L9c
            r8.<init>(r1, r6, r7, r4)     // Catch: java.lang.Throwable -> L9c
            I.g r1 = r1.a     // Catch: java.lang.Throwable -> L9c
            java.lang.Object r1 = f4.AbstractC0952A.B(r1, r8, r11)     // Catch: java.lang.Throwable -> L9c
            if (r1 != r0) goto L82
            goto L83
        L82:
            r1 = r3
        L83:
            if (r1 != r0) goto L86
            goto L87
        L86:
            r1 = r3
        L87:
            if (r1 != r0) goto L8a
            return r0
        L8a:
            r0 = r12
        L8b:
            if (r0 == 0) goto L90
            r0.a(r4)
        L90:
            androidx.lifecycle.x r12 = r2.e()
            r12.f(r5)
            return r3
        L98:
            r10 = r0
            r0 = r12
            r12 = r10
            goto L9e
        L9c:
            r0 = move-exception
            goto L98
        L9e:
            if (r0 == 0) goto La3
            r0.a(r4)
        La3:
            androidx.lifecycle.x r0 = r2.e()
            r0.f(r5)
            throw r12
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.c1.o(java.lang.Object):java.lang.Object");
    }
}

package u0;

import android.view.View;
import android.view.translation.ViewTranslationCallback;
import i.C1116r;
import java.util.LinkedHashMap;

/* JADX INFO: renamed from: u0.G, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class ViewTranslationCallbackC1842G implements ViewTranslationCallback {
    public static final ViewTranslationCallbackC1842G a = new ViewTranslationCallbackC1842G();

    /* JADX WARN: Removed duplicated region for block: B:26:0x007b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean onClearTranslation(android.view.View r15) {
        /*
            r14 = this;
            java.lang.String r0 = "null cannot be cast to non-null type androidx.compose.ui.platform.AndroidComposeView"
            U3.j.d(r15, r0)
            u0.s r15 = (u0.C1889s) r15
            W.c r15 = r15.getContentCaptureManager$ui_release()
            r0 = 1
            r15.f6793r = r0
            i.r r15 = r15.d()
            java.lang.Object[] r1 = r15.f10369c
            long[] r15 = r15.a
            int r2 = r15.length
            int r2 = r2 + (-2)
            if (r2 < 0) goto L80
            r3 = 0
            r4 = r3
        L1d:
            r5 = r15[r4]
            long r7 = ~r5
            r9 = 7
            long r7 = r7 << r9
            long r7 = r7 & r5
            r9 = -9187201950435737472(0x8080808080808080, double:-2.937446524422997E-306)
            long r7 = r7 & r9
            int r7 = (r7 > r9 ? 1 : (r7 == r9 ? 0 : -1))
            if (r7 == 0) goto L7b
            int r7 = r4 - r2
            int r7 = ~r7
            int r7 = r7 >>> 31
            r8 = 8
            int r7 = 8 - r7
            r9 = r3
        L37:
            if (r9 >= r7) goto L79
            r10 = 255(0xff, double:1.26E-321)
            long r10 = r10 & r5
            r12 = 128(0x80, double:6.3E-322)
            int r10 = (r10 > r12 ? 1 : (r10 == r12 ? 0 : -1))
            if (r10 >= 0) goto L75
            int r10 = r4 << 3
            int r10 = r10 + r9
            r10 = r1[r10]
            u0.I0 r10 = (u0.I0) r10
            A0.o r10 = r10.a
            A0.i r10 = r10.f237d
            A0.u r11 = A0.r.f280w
            java.util.LinkedHashMap r10 = r10.f226l
            java.lang.Object r11 = r10.get(r11)
            r12 = 0
            if (r11 != 0) goto L59
            r11 = r12
        L59:
            if (r11 == 0) goto L75
            A0.u r11 = A0.h.f211l
            java.lang.Object r10 = r10.get(r11)
            if (r10 != 0) goto L64
            goto L65
        L64:
            r12 = r10
        L65:
            A0.a r12 = (A0.a) r12
            if (r12 == 0) goto L75
            G3.e r10 = r12.f191b
            T3.a r10 = (T3.a) r10
            if (r10 == 0) goto L75
            java.lang.Object r10 = r10.b()
            java.lang.Boolean r10 = (java.lang.Boolean) r10
        L75:
            long r5 = r5 >> r8
            int r9 = r9 + 1
            goto L37
        L79:
            if (r7 != r8) goto L80
        L7b:
            if (r4 == r2) goto L80
            int r4 = r4 + 1
            goto L1d
        L80:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.ViewTranslationCallbackC1842G.onClearTranslation(android.view.View):boolean");
    }

    /* JADX WARN: Removed duplicated region for block: B:27:0x0083  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean onHideTranslation(android.view.View r15) {
        /*
            r14 = this;
            java.lang.String r0 = "null cannot be cast to non-null type androidx.compose.ui.platform.AndroidComposeView"
            U3.j.d(r15, r0)
            u0.s r15 = (u0.C1889s) r15
            W.c r15 = r15.getContentCaptureManager$ui_release()
            r0 = 1
            r15.f6793r = r0
            i.r r15 = r15.d()
            java.lang.Object[] r1 = r15.f10369c
            long[] r15 = r15.a
            int r2 = r15.length
            int r2 = r2 + (-2)
            if (r2 < 0) goto L88
            r3 = 0
            r4 = r3
        L1d:
            r5 = r15[r4]
            long r7 = ~r5
            r9 = 7
            long r7 = r7 << r9
            long r7 = r7 & r5
            r9 = -9187201950435737472(0x8080808080808080, double:-2.937446524422997E-306)
            long r7 = r7 & r9
            int r7 = (r7 > r9 ? 1 : (r7 == r9 ? 0 : -1))
            if (r7 == 0) goto L83
            int r7 = r4 - r2
            int r7 = ~r7
            int r7 = r7 >>> 31
            r8 = 8
            int r7 = 8 - r7
            r9 = r3
        L37:
            if (r9 >= r7) goto L81
            r10 = 255(0xff, double:1.26E-321)
            long r10 = r10 & r5
            r12 = 128(0x80, double:6.3E-322)
            int r10 = (r10 > r12 ? 1 : (r10 == r12 ? 0 : -1))
            if (r10 >= 0) goto L7d
            int r10 = r4 << 3
            int r10 = r10 + r9
            r10 = r1[r10]
            u0.I0 r10 = (u0.I0) r10
            A0.o r10 = r10.a
            A0.i r10 = r10.f237d
            A0.u r11 = A0.r.f280w
            java.util.LinkedHashMap r10 = r10.f226l
            java.lang.Object r11 = r10.get(r11)
            r12 = 0
            if (r11 != 0) goto L59
            r11 = r12
        L59:
            java.lang.Boolean r13 = java.lang.Boolean.TRUE
            boolean r11 = U3.j.a(r11, r13)
            if (r11 == 0) goto L7d
            A0.u r11 = A0.h.f210k
            java.lang.Object r10 = r10.get(r11)
            if (r10 != 0) goto L6a
            goto L6b
        L6a:
            r12 = r10
        L6b:
            A0.a r12 = (A0.a) r12
            if (r12 == 0) goto L7d
            G3.e r10 = r12.f191b
            T3.c r10 = (T3.c) r10
            if (r10 == 0) goto L7d
            java.lang.Boolean r11 = java.lang.Boolean.FALSE
            java.lang.Object r10 = r10.invoke(r11)
            java.lang.Boolean r10 = (java.lang.Boolean) r10
        L7d:
            long r5 = r5 >> r8
            int r9 = r9 + 1
            goto L37
        L81:
            if (r7 != r8) goto L88
        L83:
            if (r4 == r2) goto L88
            int r4 = r4 + 1
            goto L1d
        L88:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.ViewTranslationCallbackC1842G.onHideTranslation(android.view.View):boolean");
    }

    public final boolean onShowTranslation(View view) {
        T3.c cVar;
        U3.j.d(view, "null cannot be cast to non-null type androidx.compose.ui.platform.AndroidComposeView");
        W.c contentCaptureManager$ui_release = ((C1889s) view).getContentCaptureManager$ui_release();
        contentCaptureManager$ui_release.f6793r = 2;
        C1116r c1116rD = contentCaptureManager$ui_release.d();
        Object[] objArr = c1116rD.f10369c;
        long[] jArr = c1116rD.a;
        int length = jArr.length - 2;
        if (length < 0) {
            return true;
        }
        int i5 = 0;
        while (true) {
            long j5 = jArr[i5];
            if ((((~j5) << 7) & j5 & (-9187201950435737472L)) != -9187201950435737472L) {
                int i6 = 8 - ((~(i5 - length)) >>> 31);
                for (int i7 = 0; i7 < i6; i7++) {
                    if ((255 & j5) < 128) {
                        A0.i iVar = ((I0) objArr[(i5 << 3) + i7]).a.f237d;
                        A0.u uVar = A0.r.f280w;
                        LinkedHashMap linkedHashMap = iVar.f226l;
                        Object obj = linkedHashMap.get(uVar);
                        if (obj == null) {
                            obj = null;
                        }
                        if (U3.j.a(obj, Boolean.FALSE)) {
                            Object obj2 = linkedHashMap.get(A0.h.f210k);
                            A0.a aVar = (A0.a) (obj2 != null ? obj2 : null);
                            if (aVar != null && (cVar = (T3.c) aVar.f191b) != null) {
                            }
                        }
                    }
                    j5 >>= 8;
                }
                if (i6 != 8) {
                    return true;
                }
            }
            if (i5 == length) {
                return true;
            }
            i5++;
        }
    }
}

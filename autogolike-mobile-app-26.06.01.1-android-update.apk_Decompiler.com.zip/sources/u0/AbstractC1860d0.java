package u0;

/* JADX INFO: renamed from: u0.d0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1860d0 {
    public static final Q.a a = new Q.a(-1759434350, C1838C.f13878n, false);
}

package u0;

import android.graphics.Canvas;

/* JADX INFO: loaded from: classes.dex */
public final class R0 extends C1876l0 {
    public final void dispatchGetDisplayList() {
    }

    @Override // u0.C1876l0, android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
    }
}

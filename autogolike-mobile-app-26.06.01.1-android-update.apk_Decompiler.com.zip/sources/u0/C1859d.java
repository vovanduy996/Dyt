package u0;

/* JADX INFO: renamed from: u0.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1859d extends AbstractC1855b {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static C1859d f14045e;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public C0.I f14046c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public A0.o f14047d;

    @Override // u0.AbstractC1855b
    public final int[] a(int i5) {
        int iC;
        if (c().length() <= 0 || i5 >= c().length()) {
            return null;
        }
        try {
            A0.o oVar = this.f14047d;
            if (oVar == null) {
                U3.j.j("node");
                throw null;
            }
            int iRound = Math.round(oVar.e().b());
            if (i5 <= 0) {
                i5 = 0;
            }
            C0.I i6 = this.f14046c;
            if (i6 == null) {
                U3.j.j("layoutResult");
                throw null;
            }
            int iE = i6.e(i5);
            C0.I i7 = this.f14046c;
            if (i7 == null) {
                U3.j.j("layoutResult");
                throw null;
            }
            float fD = i7.f747b.d(iE) + iRound;
            C0.I i8 = this.f14046c;
            if (i8 == null) {
                U3.j.j("layoutResult");
                throw null;
            }
            if (i8 == null) {
                U3.j.j("layoutResult");
                throw null;
            }
            if (fD < i8.f747b.d(r0.f799f - 1)) {
                C0.I i9 = this.f14046c;
                if (i9 == null) {
                    U3.j.j("layoutResult");
                    throw null;
                }
                iC = i9.f747b.c(fD);
            } else {
                C0.I i10 = this.f14046c;
                if (i10 == null) {
                    U3.j.j("layoutResult");
                    throw null;
                }
                iC = i10.f747b.f799f;
            }
            return b(i5, e(iC - 1, N0.h.f5027l) + 1);
        } catch (IllegalStateException unused) {
            return null;
        }
    }

    @Override // u0.AbstractC1855b
    public final int[] d(int i5) {
        int iC;
        if (c().length() <= 0 || i5 <= 0) {
            return null;
        }
        try {
            A0.o oVar = this.f14047d;
            if (oVar == null) {
                U3.j.j("node");
                throw null;
            }
            int iRound = Math.round(oVar.e().b());
            int length = c().length();
            if (length <= i5) {
                i5 = length;
            }
            C0.I i6 = this.f14046c;
            if (i6 == null) {
                U3.j.j("layoutResult");
                throw null;
            }
            int iE = i6.e(i5);
            C0.I i7 = this.f14046c;
            if (i7 == null) {
                U3.j.j("layoutResult");
                throw null;
            }
            float fD = i7.f747b.d(iE) - iRound;
            if (fD > 0.0f) {
                C0.I i8 = this.f14046c;
                if (i8 == null) {
                    U3.j.j("layoutResult");
                    throw null;
                }
                iC = i8.f747b.c(fD);
            } else {
                iC = 0;
            }
            if (i5 == c().length() && iC < iE) {
                iC++;
            }
            return b(e(iC, N0.h.f5028m), i5);
        } catch (IllegalStateException unused) {
            return null;
        }
    }

    public final int e(int i5, N0.h hVar) {
        C0.I i6 = this.f14046c;
        if (i6 == null) {
            U3.j.j("layoutResult");
            throw null;
        }
        int iH = i6.h(i5);
        C0.I i7 = this.f14046c;
        if (i7 == null) {
            U3.j.j("layoutResult");
            throw null;
        }
        if (hVar != i7.i(iH)) {
            C0.I i8 = this.f14046c;
            if (i8 != null) {
                return i8.h(i5);
            }
            U3.j.j("layoutResult");
            throw null;
        }
        if (this.f14046c != null) {
            return r6.d(i5, false) - 1;
        }
        U3.j.j("layoutResult");
        throw null;
    }
}

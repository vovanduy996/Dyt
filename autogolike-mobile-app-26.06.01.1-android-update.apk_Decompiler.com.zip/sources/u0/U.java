package u0;

import android.view.Choreographer;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class U implements Choreographer.FrameCallback, Runnable {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ V f13999l;

    public U(V v5) {
        this.f13999l = v5;
    }

    @Override // android.view.Choreographer.FrameCallback
    public final void doFrame(long j5) {
        this.f13999l.f14003o.removeCallbacks(this);
        V.b0(this.f13999l);
        V v5 = this.f13999l;
        synchronized (v5.f14004p) {
            if (v5.f14009u) {
                v5.f14009u = false;
                ArrayList arrayList = v5.f14006r;
                v5.f14006r = v5.f14007s;
                v5.f14007s = arrayList;
                int size = arrayList.size();
                for (int i5 = 0; i5 < size; i5++) {
                    ((Choreographer.FrameCallback) arrayList.get(i5)).doFrame(j5);
                }
                arrayList.clear();
            }
        }
    }

    @Override // java.lang.Runnable
    public final void run() {
        V.b0(this.f13999l);
        V v5 = this.f13999l;
        synchronized (v5.f14004p) {
            if (v5.f14006r.isEmpty()) {
                v5.f14002n.removeFrameCallback(this);
                v5.f14009u = false;
            }
        }
    }
}

package u0;

/* JADX INFO: renamed from: u0.x0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1900x0 extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public /* synthetic */ Object f14241o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f14242p;

    @Override // M3.a
    public final Object o(Object obj) {
        this.f14241o = obj;
        this.f14242p |= Integer.MIN_VALUE;
        AbstractC1902y0.b(null, null, this);
        return L3.a.f4629l;
    }
}

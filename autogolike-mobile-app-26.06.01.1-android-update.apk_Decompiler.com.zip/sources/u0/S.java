package u0;

import android.view.ActionMode;
import s.C1703N;

/* JADX INFO: loaded from: classes.dex */
public final class S implements L0 {
    public final C1889s a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ActionMode f13996b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final D4.g f13997c = new D4.g(new C1703N(9, this));

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f13998d = 2;

    public S(C1889s c1889s) {
        this.a = c1889s;
    }
}

package u0;

/* JADX INFO: renamed from: u0.g0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1866g0 implements J0 {
    public final I0.B a;

    public C1866g0(I0.B b3) {
        this.a = b3;
    }

    public final void a() {
        this.a.a.d();
    }

    public final void b() {
        I0.B b3 = this.a;
        if (((I0.F) b3.f3800b.get()) != null) {
            b3.a.a();
        }
    }
}

package u0;

import android.os.SystemClock;
import android.view.MotionEvent;
import com.autogolike.mobile.core.backup.ConfigBackupDto;

/* JADX INFO: renamed from: u0.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1885q extends U3.k implements T3.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f14138l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ C1889s f14139m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C1885q(C1889s c1889s, int i5) {
        super(0);
        this.f14138l = i5;
        this.f14139m = c1889s;
    }

    @Override // T3.a
    public final Object b() {
        int actionMasked;
        switch (this.f14138l) {
            case ConfigBackupDto.$stable /* 0 */:
                C1889s c1889s = this.f14139m;
                MotionEvent motionEvent = c1889s.f14212x0;
                if (motionEvent != null && ((actionMasked = motionEvent.getActionMasked()) == 7 || actionMasked == 9)) {
                    c1889s.f14214y0 = SystemClock.uptimeMillis();
                    c1889s.post(c1889s.f14151B0);
                }
                return G3.C.a;
            default:
                return this.f14139m.get_viewTreeOwners();
        }
    }
}

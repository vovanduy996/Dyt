package u0;

import android.graphics.RenderNode;

/* JADX INFO: loaded from: classes.dex */
public final class C0 {
    public static final C0 a = new C0();

    public final void a(RenderNode renderNode, b0.O o3) {
        renderNode.setRenderEffect(null);
    }
}

package u0;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public abstract class P0 {
    public static final long a(View view) {
        return view.getUniqueDrawingId();
    }
}

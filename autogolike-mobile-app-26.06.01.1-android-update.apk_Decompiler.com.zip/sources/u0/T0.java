package u0;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class T0 {
    public static final T0 a = new T0();

    public final void a(View view, b0.O o3) {
        view.setRenderEffect(null);
    }
}

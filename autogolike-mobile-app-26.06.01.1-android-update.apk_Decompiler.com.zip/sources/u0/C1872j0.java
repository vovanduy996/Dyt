package u0;

import com.autogolike.mobile.core.backup.ConfigBackupDto;

/* JADX INFO: renamed from: u0.j0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1872j0 extends U3.k implements T3.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f14091l = 1;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ boolean f14092m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ Object f14093n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ Object f14094o;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1872j0(w.S s3, Z.n nVar, boolean z3) {
        super(0);
        this.f14093n = s3;
        this.f14094o = nVar;
        this.f14092m = z3;
    }

    @Override // T3.a
    public final Object b() {
        J0 j02;
        switch (this.f14091l) {
            case ConfigBackupDto.$stable /* 0 */:
                if (this.f14092m) {
                    F1.e eVar = (F1.e) this.f14093n;
                    eVar.getClass();
                    String str = (String) this.f14094o;
                    U3.j.f(str, "key");
                    eVar.a.c(str);
                }
                return G3.C.a;
            default:
                w.S s3 = (w.S) this.f14093n;
                if (!s3.b()) {
                    ((Z.n) this.f14094o).a(Z.h.f7146p);
                } else if (!this.f14092m && (j02 = s3.f14619c) != null) {
                    ((C1866g0) j02).b();
                }
                return Boolean.TRUE;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1872j0(boolean z3, F1.e eVar, String str) {
        super(0);
        this.f14092m = z3;
        this.f14093n = eVar;
        this.f14094o = str;
    }
}

package u0;

import G3.AbstractC0164a;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;

/* JADX INFO: loaded from: classes.dex */
public final class h1 extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f14085p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ j1 f14086q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public h1(j1 j1Var, Continuation continuation) {
        super(2, continuation);
        this.f14086q = j1Var;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((h1) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new h1(this.f14086q, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) throws Throwable {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f14085p;
        G3.C c5 = G3.C.a;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            C1889s c1889s = this.f14086q.f14095l;
            this.f14085p = 1;
            Object objC = c1889s.f14213y.c(this);
            if (objC != aVar) {
                objC = c5;
            }
            if (objC == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return c5;
    }
}

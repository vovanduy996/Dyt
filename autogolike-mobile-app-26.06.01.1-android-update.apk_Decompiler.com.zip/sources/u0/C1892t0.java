package u0;

import I.C0234d;
import I.C0239f0;

/* JADX INFO: renamed from: u0.t0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1892t0 implements U.r {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final C0239f0 f14224l = C0234d.I(1.0f);

    @Override // K3.h
    public final Object B(Object obj, T3.e eVar) {
        return eVar.i(obj, this);
    }

    @Override // U.r
    public final float C() {
        return this.f14224l.h();
    }

    @Override // K3.h
    public final K3.h F(K3.h hVar) {
        return l0.c.q0(this, hVar);
    }

    @Override // K3.h
    public final K3.f m(K3.g gVar) {
        return l0.c.h0(this, gVar);
    }

    @Override // K3.h
    public final K3.h u(K3.g gVar) {
        return l0.c.p0(this, gVar);
    }
}

package u0;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.os.Build;
import android.view.DisplayListCanvas;
import android.view.RenderNode;
import b0.C0585c;
import b0.C0600s;
import t0.C1794a;

/* JADX INFO: renamed from: u0.z0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1904z0 implements InterfaceC1868h0 {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static boolean f14252g = true;
    public final RenderNode a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f14253b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f14254c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f14255d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f14256e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f14257f;

    public C1904z0(C1889s c1889s) {
        RenderNode renderNodeCreate = RenderNode.create("Compose", c1889s);
        this.a = renderNodeCreate;
        if (f14252g) {
            renderNodeCreate.setScaleX(renderNodeCreate.getScaleX());
            renderNodeCreate.setScaleY(renderNodeCreate.getScaleY());
            renderNodeCreate.setTranslationX(renderNodeCreate.getTranslationX());
            renderNodeCreate.setTranslationY(renderNodeCreate.getTranslationY());
            renderNodeCreate.setElevation(renderNodeCreate.getElevation());
            renderNodeCreate.setRotation(renderNodeCreate.getRotation());
            renderNodeCreate.setRotationX(renderNodeCreate.getRotationX());
            renderNodeCreate.setRotationY(renderNodeCreate.getRotationY());
            renderNodeCreate.setCameraDistance(renderNodeCreate.getCameraDistance());
            renderNodeCreate.setPivotX(renderNodeCreate.getPivotX());
            renderNodeCreate.setPivotY(renderNodeCreate.getPivotY());
            renderNodeCreate.setClipToOutline(renderNodeCreate.getClipToOutline());
            renderNodeCreate.setClipToBounds(false);
            renderNodeCreate.setAlpha(renderNodeCreate.getAlpha());
            renderNodeCreate.isValid();
            renderNodeCreate.setLeftTopRightBottom(0, 0, 0, 0);
            renderNodeCreate.offsetLeftAndRight(0);
            renderNodeCreate.offsetTopAndBottom(0);
            if (Build.VERSION.SDK_INT >= 28) {
                F0 f02 = F0.a;
                f02.c(renderNodeCreate, f02.a(renderNodeCreate));
                f02.d(renderNodeCreate, f02.b(renderNodeCreate));
            }
            E0.a.a(renderNodeCreate);
            renderNodeCreate.setLayerType(0);
            renderNodeCreate.setHasOverlappingRendering(renderNodeCreate.hasOverlappingRendering());
            f14252g = false;
        }
    }

    @Override // u0.InterfaceC1868h0
    public final int A() {
        return this.f14253b;
    }

    @Override // u0.InterfaceC1868h0
    public final void B(boolean z3) {
        this.a.setClipToOutline(z3);
    }

    @Override // u0.InterfaceC1868h0
    public final void C(int i5) {
        if (b0.N.q(i5, 1)) {
            this.a.setLayerType(2);
            this.a.setHasOverlappingRendering(true);
        } else if (b0.N.q(i5, 2)) {
            this.a.setLayerType(0);
            this.a.setHasOverlappingRendering(false);
        } else {
            this.a.setLayerType(0);
            this.a.setHasOverlappingRendering(true);
        }
    }

    @Override // u0.InterfaceC1868h0
    public final void D(float f5) {
        this.a.setPivotX(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void E(boolean z3) {
        this.f14257f = z3;
        this.a.setClipToBounds(z3);
    }

    @Override // u0.InterfaceC1868h0
    public final void F(Outline outline) {
        this.a.setOutline(outline);
    }

    @Override // u0.InterfaceC1868h0
    public final void G(int i5) {
        if (Build.VERSION.SDK_INT >= 28) {
            F0.a.d(this.a, i5);
        }
    }

    @Override // u0.InterfaceC1868h0
    public final boolean H(int i5, int i6, int i7, int i8) {
        this.f14253b = i5;
        this.f14254c = i6;
        this.f14255d = i7;
        this.f14256e = i8;
        return this.a.setLeftTopRightBottom(i5, i6, i7, i8);
    }

    @Override // u0.InterfaceC1868h0
    public final boolean I() {
        return this.a.setHasOverlappingRendering(true);
    }

    @Override // u0.InterfaceC1868h0
    public final void J(Matrix matrix) {
        this.a.getMatrix(matrix);
    }

    @Override // u0.InterfaceC1868h0
    public final float K() {
        return this.a.getElevation();
    }

    @Override // u0.InterfaceC1868h0
    public final void L(int i5) {
        if (Build.VERSION.SDK_INT >= 28) {
            F0.a.c(this.a, i5);
        }
    }

    @Override // u0.InterfaceC1868h0
    public final float a() {
        return this.a.getAlpha();
    }

    @Override // u0.InterfaceC1868h0
    public final void b(float f5) {
        this.a.setRotationY(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void c(float f5) {
        this.a.setTranslationX(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void d(float f5) {
        this.a.setAlpha(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void e(float f5) {
        this.a.setScaleY(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final int f() {
        return this.f14255d - this.f14253b;
    }

    @Override // u0.InterfaceC1868h0
    public final int h() {
        return this.f14256e - this.f14254c;
    }

    @Override // u0.InterfaceC1868h0
    public final void i(float f5) {
        this.a.setRotation(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void j(float f5) {
        this.a.setTranslationY(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void k(float f5) {
        this.a.setCameraDistance(-f5);
    }

    @Override // u0.InterfaceC1868h0
    public final boolean l() {
        return this.a.isValid();
    }

    @Override // u0.InterfaceC1868h0
    public final void m(float f5) {
        this.a.setScaleX(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void n(float f5) {
        this.a.setRotationX(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void o() {
        E0.a.a(this.a);
    }

    @Override // u0.InterfaceC1868h0
    public final void p(float f5) {
        this.a.setPivotY(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void q(float f5) {
        this.a.setElevation(f5);
    }

    @Override // u0.InterfaceC1868h0
    public final void r(int i5) {
        this.f14253b += i5;
        this.f14255d += i5;
        this.a.offsetLeftAndRight(i5);
    }

    @Override // u0.InterfaceC1868h0
    public final int s() {
        return this.f14256e;
    }

    @Override // u0.InterfaceC1868h0
    public final int t() {
        return this.f14255d;
    }

    @Override // u0.InterfaceC1868h0
    public final boolean u() {
        return this.a.getClipToOutline();
    }

    @Override // u0.InterfaceC1868h0
    public final void v(int i5) {
        this.f14254c += i5;
        this.f14256e += i5;
        this.a.offsetTopAndBottom(i5);
    }

    @Override // u0.InterfaceC1868h0
    public final boolean w() {
        return this.f14257f;
    }

    @Override // u0.InterfaceC1868h0
    public final void x(C0600s c0600s, b0.M m5, C1794a c1794a) {
        DisplayListCanvas displayListCanvasStart = this.a.start(f(), h());
        Canvas canvasV = c0600s.a().v();
        c0600s.a().w((Canvas) displayListCanvasStart);
        C0585c c0585cA = c0600s.a();
        if (m5 != null) {
            c0585cA.f();
            c0585cA.i(m5, 1);
        }
        c1794a.invoke(c0585cA);
        if (m5 != null) {
            c0585cA.a();
        }
        c0600s.a().w(canvasV);
        this.a.end(displayListCanvasStart);
    }

    @Override // u0.InterfaceC1868h0
    public final void y(Canvas canvas) {
        ((DisplayListCanvas) canvas).drawRenderNode(this.a);
    }

    @Override // u0.InterfaceC1868h0
    public final int z() {
        return this.f14254c;
    }

    @Override // u0.InterfaceC1868h0
    public final void g() {
    }
}

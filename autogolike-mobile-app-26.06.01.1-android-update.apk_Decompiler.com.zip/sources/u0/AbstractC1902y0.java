package u0;

/* JADX INFO: renamed from: u0.y0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1902y0 {
    public static final I.Z0 a = new I.Z0(C1847L.f13950O);

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final void a(y.v r4, y.C2069e r5, M3.c r6) {
        /*
            boolean r0 = r6 instanceof u0.C1898w0
            if (r0 == 0) goto L13
            r0 = r6
            u0.w0 r0 = (u0.C1898w0) r0
            int r1 = r0.f14240p
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f14240p = r1
            goto L18
        L13:
            u0.w0 r0 = new u0.w0
            r0.<init>(r6)
        L18:
            java.lang.Object r6 = r0.f14239o
            int r1 = r0.f14240p
            r2 = 1
            if (r1 == 0) goto L32
            if (r1 == r2) goto L29
            java.lang.IllegalStateException r4 = new java.lang.IllegalStateException
            java.lang.String r5 = "call to 'resume' before 'invoke' with coroutine"
            r4.<init>(r5)
            throw r4
        L29:
            G3.AbstractC0164a.e(r6)
            G3.f r4 = new G3.f
            r4.<init>()
            throw r4
        L32:
            G3.AbstractC0164a.e(r6)
            r6 = r4
            U.p r6 = (U.p) r6
            U.p r6 = r6.f6127l
            boolean r6 = r6.f6139x
            if (r6 == 0) goto L61
            t0.g0 r6 = t0.AbstractC1800g.w(r4)
            t0.E r4 = t0.AbstractC1800g.v(r4)
            I.w r4 = r4.f13434E
            Q.d r4 = (Q.d) r4
            r4.getClass()
            I.Z0 r1 = u0.AbstractC1902y0.a
            java.lang.Object r4 = I.C0234d.L(r4, r1)
            if (r4 != 0) goto L5b
            r0.f14240p = r2
            b(r6, r5, r0)
            return
        L5b:
            java.lang.ClassCastException r4 = new java.lang.ClassCastException
            r4.<init>()
            throw r4
        L61:
            java.lang.IllegalArgumentException r4 = new java.lang.IllegalArgumentException
            java.lang.String r5 = "establishTextInputSession called from an unattached node"
            r4.<init>(r5)
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.AbstractC1902y0.a(y.v, y.e, M3.c):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final void b(t0.g0 r4, y.C2069e r5, M3.c r6) {
        /*
            boolean r0 = r6 instanceof u0.C1900x0
            if (r0 == 0) goto L13
            r0 = r6
            u0.x0 r0 = (u0.C1900x0) r0
            int r1 = r0.f14242p
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f14242p = r1
            goto L18
        L13:
            u0.x0 r0 = new u0.x0
            r0.<init>(r6)
        L18:
            java.lang.Object r6 = r0.f14241o
            int r1 = r0.f14242p
            r2 = 1
            if (r1 == 0) goto L3e
            if (r1 == r2) goto L35
            r4 = 2
            if (r1 == r4) goto L2c
            java.lang.IllegalStateException r4 = new java.lang.IllegalStateException
            java.lang.String r5 = "call to 'resume' before 'invoke' with coroutine"
            r4.<init>(r5)
            throw r4
        L2c:
            G3.AbstractC0164a.e(r6)
            G3.f r4 = new G3.f
            r4.<init>()
            throw r4
        L35:
            G3.AbstractC0164a.e(r6)
            G3.f r4 = new G3.f
            r4.<init>()
            throw r4
        L3e:
            G3.AbstractC0164a.e(r6)
            r0.f14242p = r2
            u0.s r4 = (u0.C1889s) r4
            r4.H(r5, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.AbstractC1902y0.b(t0.g0, y.e, M3.c):void");
    }
}

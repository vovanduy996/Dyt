package u0;

import C0.C0046a;
import a0.C0491b;
import a0.C0492c;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.view.View;
import b0.C0585c;
import b0.C0600s;
import e0.C0844b;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import s.C1703N;

/* JADX INFO: loaded from: classes.dex */
public final class Q0 extends View implements t0.f0 {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public static final R0.x f13979A = new R0.x(3);
    public static Method B;
    public static Field C;
    public static boolean D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public static boolean f13980E;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final C1889s f13981l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final C1876l0 f13982m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public C0046a f13983n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public C1703N f13984o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final C1896v0 f13985p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f13986q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public Rect f13987r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f13988s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f13989t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final C0600s f13990u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final C1890s0 f13991v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public long f13992w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f13993x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final long f13994y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public int f13995z;

    public Q0(C1889s c1889s, C1876l0 c1876l0, C0046a c0046a, C1703N c1703n) {
        super(c1889s.getContext());
        this.f13981l = c1889s;
        this.f13982m = c1876l0;
        this.f13983n = c0046a;
        this.f13984o = c1703n;
        this.f13985p = new C1896v0();
        this.f13990u = new C0600s();
        this.f13991v = new C1890s0(C1838C.f13880p);
        this.f13992w = b0.X.f7952b;
        this.f13993x = true;
        setWillNotDraw(false);
        c1876l0.addView(this);
        this.f13994y = View.generateViewId();
    }

    private final b0.M getManualClipPath() {
        if (getClipToOutline()) {
            C1896v0 c1896v0 = this.f13985p;
            if (c1896v0.f14232g) {
                c1896v0.d();
                return c1896v0.f14230e;
            }
        }
        return null;
    }

    private final void setInvalidated(boolean z3) {
        if (z3 != this.f13988s) {
            this.f13988s = z3;
            this.f13981l.u(this, z3);
        }
    }

    @Override // t0.f0
    public final void a(float[] fArr) {
        float[] fArrA = this.f13991v.a(this);
        if (fArrA != null) {
            b0.H.g(fArr, fArrA);
        }
    }

    @Override // t0.f0
    public final void b(C0491b c0491b, boolean z3) {
        C1890s0 c1890s0 = this.f13991v;
        if (!z3) {
            b0.H.c(c1890s0.b(this), c0491b);
            return;
        }
        float[] fArrA = c1890s0.a(this);
        if (fArrA != null) {
            b0.H.c(fArrA, c0491b);
            return;
        }
        c0491b.a = 0.0f;
        c0491b.f7212b = 0.0f;
        c0491b.f7213c = 0.0f;
        c0491b.f7214d = 0.0f;
    }

    @Override // t0.f0
    public final void c() {
        setInvalidated(false);
        C1889s c1889s = this.f13981l;
        c1889s.f14164J = true;
        this.f13983n = null;
        this.f13984o = null;
        c1889s.C(this);
        this.f13982m.removeViewInLayout(this);
    }

    @Override // t0.f0
    public final void d(long j5) {
        int i5 = (int) (j5 >> 32);
        int left = getLeft();
        C1890s0 c1890s0 = this.f13991v;
        if (i5 != left) {
            offsetLeftAndRight(i5 - getLeft());
            c1890s0.c();
        }
        int i6 = (int) (j5 & 4294967295L);
        if (i6 != getTop()) {
            offsetTopAndBottom(i6 - getTop());
            c1890s0.c();
        }
    }

    @Override // android.view.View
    public final void dispatchDraw(Canvas canvas) {
        boolean z3;
        C0600s c0600s = this.f13990u;
        C0585c c0585c = c0600s.a;
        Canvas canvas2 = c0585c.a;
        c0585c.a = canvas;
        if (getManualClipPath() == null && canvas.isHardwareAccelerated()) {
            z3 = false;
        } else {
            c0585c.f();
            this.f13985p.a(c0585c);
            z3 = true;
        }
        C0046a c0046a = this.f13983n;
        if (c0046a != null) {
            c0046a.i(c0585c, null);
        }
        if (z3) {
            c0585c.a();
        }
        c0600s.a.a = canvas2;
        setInvalidated(false);
    }

    @Override // t0.f0
    public final void e() {
        if (!this.f13988s || f13980E) {
            return;
        }
        AbstractC1846K.z(this);
        setInvalidated(false);
    }

    @Override // t0.f0
    public final void f(long j5) {
        int i5 = (int) (j5 >> 32);
        int i6 = (int) (j5 & 4294967295L);
        if (i5 == getWidth() && i6 == getHeight()) {
            return;
        }
        setPivotX(b0.X.b(this.f13992w) * i5);
        setPivotY(b0.X.c(this.f13992w) * i6);
        setOutlineProvider(this.f13985p.b() != null ? f13979A : null);
        layout(getLeft(), getTop(), getLeft() + i5, getTop() + i6);
        m();
        this.f13991v.c();
    }

    @Override // t0.f0
    public final void g(b0.r rVar, C0844b c0844b) {
        boolean z3 = getElevation() > 0.0f;
        this.f13989t = z3;
        if (z3) {
            rVar.q();
        }
        this.f13982m.a(rVar, this, getDrawingTime());
        if (this.f13989t) {
            rVar.h();
        }
    }

    public final float getCameraDistancePx() {
        return getCameraDistance() / getResources().getDisplayMetrics().densityDpi;
    }

    public final C1876l0 getContainer() {
        return this.f13982m;
    }

    public long getLayerId() {
        return this.f13994y;
    }

    public final C1889s getOwnerView() {
        return this.f13981l;
    }

    public long getOwnerViewId() {
        if (Build.VERSION.SDK_INT >= 29) {
            return P0.a(this.f13981l);
        }
        return -1L;
    }

    @Override // t0.f0
    public final void h(float[] fArr) {
        b0.H.g(fArr, this.f13991v.b(this));
    }

    @Override // android.view.View
    public final boolean hasOverlappingRendering() {
        return this.f13993x;
    }

    @Override // t0.f0
    public final long i(boolean z3, long j5) {
        C1890s0 c1890s0 = this.f13991v;
        if (!z3) {
            return b0.H.b(j5, c1890s0.b(this));
        }
        float[] fArrA = c1890s0.a(this);
        if (fArrA != null) {
            return b0.H.b(j5, fArrA);
        }
        return 9187343241974906880L;
    }

    @Override // android.view.View, t0.f0
    public final void invalidate() {
        if (this.f13988s) {
            return;
        }
        setInvalidated(true);
        super.invalidate();
        this.f13981l.invalidate();
    }

    @Override // t0.f0
    public final boolean j(long j5) {
        b0.L l4;
        float fD = C0492c.d(j5);
        float fE = C0492c.e(j5);
        if (this.f13986q) {
            return 0.0f <= fD && fD < ((float) getWidth()) && 0.0f <= fE && fE < ((float) getHeight());
        }
        if (!getClipToOutline()) {
            return true;
        }
        C1896v0 c1896v0 = this.f13985p;
        if (c1896v0.f14238m && (l4 = c1896v0.f14228c) != null) {
            return AbstractC1846K.s(l4, C0492c.d(j5), C0492c.e(j5), null, null);
        }
        return true;
    }

    @Override // t0.f0
    public final void k(b0.P p4) {
        C1703N c1703n;
        int i5 = p4.f7919l | this.f13995z;
        if ((i5 & 4096) != 0) {
            long j5 = p4.f7932y;
            this.f13992w = j5;
            setPivotX(b0.X.b(j5) * getWidth());
            setPivotY(b0.X.c(this.f13992w) * getHeight());
        }
        if ((i5 & 1) != 0) {
            setScaleX(p4.f7920m);
        }
        if ((i5 & 2) != 0) {
            setScaleY(p4.f7921n);
        }
        if ((i5 & 4) != 0) {
            setAlpha(p4.f7922o);
        }
        if ((i5 & 8) != 0) {
            setTranslationX(p4.f7923p);
        }
        if ((i5 & 16) != 0) {
            setTranslationY(p4.f7924q);
        }
        if ((i5 & 32) != 0) {
            setElevation(p4.f7925r);
        }
        if ((i5 & 1024) != 0) {
            setRotation(p4.f7930w);
        }
        if ((i5 & 256) != 0) {
            setRotationX(p4.f7928u);
        }
        if ((i5 & 512) != 0) {
            setRotationY(p4.f7929v);
        }
        if ((i5 & 2048) != 0) {
            setCameraDistancePx(p4.f7931x);
        }
        boolean z3 = true;
        boolean z5 = getManualClipPath() != null;
        boolean z6 = p4.f7916A;
        Q2.j jVar = b0.N.a;
        boolean z7 = z6 && p4.f7933z != jVar;
        if ((i5 & 24576) != 0) {
            this.f13986q = z6 && p4.f7933z == jVar;
            m();
            setClipToOutline(z7);
        }
        boolean zC = this.f13985p.c(p4.f7918F, p4.f7922o, z7, p4.f7925r, p4.C);
        C1896v0 c1896v0 = this.f13985p;
        if (c1896v0.f14231f) {
            setOutlineProvider(c1896v0.b() != null ? f13979A : null);
        }
        boolean z8 = getManualClipPath() != null;
        if (z5 != z8 || (z8 && zC)) {
            invalidate();
        }
        if (!this.f13989t && getElevation() > 0.0f && (c1703n = this.f13984o) != null) {
            c1703n.b();
        }
        if ((i5 & 7963) != 0) {
            this.f13991v.c();
        }
        int i6 = Build.VERSION.SDK_INT;
        if (i6 >= 28) {
            int i7 = i5 & 64;
            S0 s02 = S0.a;
            if (i7 != 0) {
                s02.a(this, b0.N.E(p4.f7926s));
            }
            if ((i5 & 128) != 0) {
                s02.b(this, b0.N.E(p4.f7927t));
            }
        }
        if (i6 >= 31 && (131072 & i5) != 0) {
            T0.a.a(this, null);
        }
        if ((i5 & 32768) != 0) {
            int i8 = p4.B;
            if (b0.N.q(i8, 1)) {
                setLayerType(2, null);
            } else if (b0.N.q(i8, 2)) {
                setLayerType(0, null);
                z3 = false;
            } else {
                setLayerType(0, null);
            }
            this.f13993x = z3;
        }
        this.f13995z = p4.f7919l;
    }

    @Override // t0.f0
    public final void l(C0046a c0046a, C1703N c1703n) {
        this.f13982m.addView(this);
        this.f13986q = false;
        this.f13989t = false;
        this.f13992w = b0.X.f7952b;
        this.f13983n = c0046a;
        this.f13984o = c1703n;
    }

    public final void m() {
        Rect rect;
        if (this.f13986q) {
            Rect rect2 = this.f13987r;
            if (rect2 == null) {
                this.f13987r = new Rect(0, 0, getWidth(), getHeight());
            } else {
                U3.j.c(rect2);
                rect2.set(0, 0, getWidth(), getHeight());
            }
            rect = this.f13987r;
        } else {
            rect = null;
        }
        setClipBounds(rect);
    }

    public final void setCameraDistancePx(float f5) {
        setCameraDistance(f5 * getResources().getDisplayMetrics().densityDpi);
    }

    @Override // android.view.View
    public final void forceLayout() {
    }

    @Override // android.view.View
    public final void onLayout(boolean z3, int i5, int i6, int i7, int i8) {
    }
}

package u0;

import android.view.View;
import android.view.ViewStructure;

/* JADX INFO: renamed from: u0.E, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1840E {
    public static final C1840E a = new C1840E();

    public final void a(ViewStructure viewStructure, View view) {
        viewStructure.setClassName(view.getAccessibilityClassName().toString());
    }
}

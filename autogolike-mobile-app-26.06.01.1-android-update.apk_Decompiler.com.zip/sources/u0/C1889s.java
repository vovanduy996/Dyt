package u0;

import D0.AbstractC0066g;
import G3.InterfaceC0166c;
import H0.InterfaceC0180m;
import H0.InterfaceC0181n;
import I.C0234d;
import I.C0247j0;
import I.C0265t;
import a0.C0492c;
import a0.C0493d;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build;
import android.os.Trace;
import android.util.LongSparseArray;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStructure;
import android.view.ViewTreeObserver;
import android.view.animation.AnimationUtils;
import android.view.autofill.AutofillId;
import android.view.autofill.AutofillValue;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import androidx.compose.ui.semantics.EmptySemanticsElement;
import androidx.lifecycle.C0578x;
import androidx.lifecycle.InterfaceC0560e;
import androidx.lifecycle.InterfaceC0576v;
import b0.C0588f;
import b0.C0600s;
import c1.AbstractC0680s;
import c1.AbstractC0681t;
import com.google.android.gms.internal.measurement.K1;
import e3.C0867C;
import j0.C1204b;
import j0.InterfaceC1203a;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import k0.C1239a;
import k0.C1241c;
import k0.InterfaceC1240b;
import l.AbstractC1297i;
import m1.AbstractC1393s;
import m1.C1384j;
import n0.C1434C;
import n0.C1439e;
import n0.C1442h;
import n0.InterfaceC1450p;
import p0.C1554a;
import r0.AbstractC1649N;
import r0.AbstractC1652Q;
import r0.C1639D;
import r0.C1653S;
import s0.C1736c;
import s2.C1759j;
import t0.AbstractC1800g;
import t0.AbstractC1808o;
import t0.C1794a;
import t0.C1811s;
import t0.C1813u;
import y.InputConnectionC2062B;

/* JADX INFO: renamed from: u0.s, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1889s extends ViewGroup implements t0.g0, t0.m0, InterfaceC0560e {

    /* JADX INFO: renamed from: J0, reason: collision with root package name */
    public static Class f14147J0;

    /* JADX INFO: renamed from: K0, reason: collision with root package name */
    public static Method f14148K0;

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final C0588f f14149A;

    /* JADX INFO: renamed from: A0, reason: collision with root package name */
    public final K.d f14150A0;
    public final V.g B;

    /* JADX INFO: renamed from: B0, reason: collision with root package name */
    public final P2.j f14151B0;
    public final ArrayList C;

    /* JADX INFO: renamed from: C0, reason: collision with root package name */
    public final E.t f14152C0;
    public ArrayList D;

    /* JADX INFO: renamed from: D0, reason: collision with root package name */
    public boolean f14153D0;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public boolean f14154E;

    /* JADX INFO: renamed from: E0, reason: collision with root package name */
    public final C1885q f14155E0;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public final C1439e f14156F;

    /* JADX INFO: renamed from: F0, reason: collision with root package name */
    public final InterfaceC1854a0 f14157F0;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public final A4.e f14158G;

    /* JADX INFO: renamed from: G0, reason: collision with root package name */
    public boolean f14159G0;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public T3.c f14160H;

    /* JADX INFO: renamed from: H0, reason: collision with root package name */
    public final z0.j f14161H0;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public final V.a f14162I;

    /* JADX INFO: renamed from: I0, reason: collision with root package name */
    public final C1883p f14163I0;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public boolean f14164J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public final C1867h f14165K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public final t0.i0 f14166L;

    /* JADX INFO: renamed from: M, reason: collision with root package name */
    public boolean f14167M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public Z f14168N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public C1876l0 f14169O;

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public O0.a f14170P;

    /* JADX INFO: renamed from: Q, reason: collision with root package name */
    public boolean f14171Q;

    /* JADX INFO: renamed from: R, reason: collision with root package name */
    public final t0.S f14172R;

    /* JADX INFO: renamed from: S, reason: collision with root package name */
    public final X f14173S;

    /* JADX INFO: renamed from: T, reason: collision with root package name */
    public long f14174T;

    /* JADX INFO: renamed from: U, reason: collision with root package name */
    public final int[] f14175U;

    /* JADX INFO: renamed from: V, reason: collision with root package name */
    public final float[] f14176V;

    /* JADX INFO: renamed from: W, reason: collision with root package name */
    public final float[] f14177W;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public final float[] f14178a0;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public long f14179b0;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public boolean f14180c0;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public long f14181d0;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public boolean f14182e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public final C0247j0 f14183f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public final I.F f14184g0;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    public T3.c f14185h0;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    public final ViewTreeObserverOnGlobalLayoutListenerC1869i f14186i0;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    public final ViewTreeObserverOnScrollChangedListenerC1871j f14187j0;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    public final ViewTreeObserverOnTouchModeChangeListenerC1873k f14188k0;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public long f14189l;

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    public final I0.D f14190l0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final boolean f14191m;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    public final I0.B f14192m0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final t0.G f14193n;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    public final AtomicReference f14194n0;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final C0247j0 f14195o;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    public final C1866g0 f14196o0;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final androidx.compose.ui.focus.b f14197p;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    public final C1884p0 f14198p0;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public K3.h f14199q;
    public final C0247j0 q0;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final ViewOnDragListenerC1874k0 f14200r;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public int f14201r0;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final V0 f14202s;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public final C0247j0 f14203s0;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final C0600s f14204t;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public final C1204b f14205t0;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final t0.E f14206u;

    /* JADX INFO: renamed from: u0, reason: collision with root package name */
    public final C1241c f14207u0;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final C1889s f14208v;
    public final C1736c v0;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final A0.p f14209w;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public final S f14210w0;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final C1839D f14211x;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public MotionEvent f14212x0;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public W.c f14213y;

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    public long f14214y0;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final C1865g f14215z;

    /* JADX INFO: renamed from: z0, reason: collision with root package name */
    public final K1 f14216z0;

    /* JADX WARN: Type inference failed for: r3v14, types: [u0.i] */
    /* JADX WARN: Type inference failed for: r3v15, types: [u0.j] */
    /* JADX WARN: Type inference failed for: r3v16, types: [u0.k] */
    public C1889s(Context context, K3.h hVar) {
        super(context);
        this.f14189l = 9205357640488583168L;
        int i5 = 1;
        this.f14191m = true;
        this.f14193n = new t0.G();
        O0.d dVarC = W3.a.c(context);
        I.W w5 = I.W.f3596o;
        this.f14195o = C0234d.K(dVarC, w5);
        A0.d dVar = new A0.d();
        EmptySemanticsElement emptySemanticsElement = new EmptySemanticsElement(dVar);
        this.f14197p = new androidx.compose.ui.focus.b(new C1759j(1, this, C1889s.class, "registerOnEndApplyChangesListener", "registerOnEndApplyChangesListener(Lkotlin/jvm/functions/Function0;)V", 0, 14), new B2.N(2, this, C1889s.class, "onRequestFocusForOwner", "onRequestFocusForOwner-7o62pno(Landroidx/compose/ui/focus/FocusDirection;Landroidx/compose/ui/geometry/Rect;)Z", 0, 17), new C1759j(1, this, C1889s.class, "onMoveFocusInChildren", "onMoveFocusInChildren-3ESFkO8(I)Z", 0, 15), new K2.g(0, this, C1889s.class, "onClearFocusForOwner", "onClearFocusForOwner()V", 0, 18), new K2.g(0, this, C1889s.class, "onFetchFocusRect", "onFetchFocusRect()Landroidx/compose/ui/geometry/Rect;", 0, 19), new G.p(0, 1, C1889s.class, this, "layoutDirection", "getLayoutDirection()Landroidx/compose/ui/unit/LayoutDirection;"));
        ViewOnDragListenerC1874k0 viewOnDragListenerC1874k0 = new ViewOnDragListenerC1874k0();
        this.f14199q = hVar;
        this.f14200r = viewOnDragListenerC1874k0;
        this.f14202s = new V0();
        U.q qVarA = androidx.compose.ui.input.key.a.a(new C1881o(this, 0));
        U.q qVarA2 = androidx.compose.ui.input.rotary.a.a();
        this.f14204t = new C0600s();
        t0.E e5 = new t0.E(3, 0, false);
        e5.X(C1653S.f12953b);
        e5.V(getDensity());
        e5.Y(emptySemanticsElement.i(qVarA2).i(qVarA).i(((androidx.compose.ui.focus.b) getFocusOwner()).f7480i).i(viewOnDragListenerC1874k0.f14101c));
        this.f14206u = e5;
        this.f14208v = this;
        this.f14209w = new A0.p(getRoot(), dVar);
        C1839D c1839d = new C1839D(this);
        this.f14211x = c1839d;
        this.f14213y = new W.c(this, new K2.g(0, this, AbstractC1846K.class, "getContentCaptureSessionCompat", "getContentCaptureSessionCompat(Landroid/view/View;)Landroidx/compose/ui/platform/coreshims/ContentCaptureSessionCompat;", 1, 17));
        C1865g c1865g = new C1865g();
        Object systemService = context.getSystemService("accessibility");
        U3.j.d(systemService, "null cannot be cast to non-null type android.view.accessibility.AccessibilityManager");
        this.f14215z = c1865g;
        this.f14149A = new C0588f(this);
        this.B = new V.g();
        this.C = new ArrayList();
        this.f14156F = new C1439e();
        t0.E root = getRoot();
        A4.e eVar = new A4.e();
        eVar.f370b = root;
        eVar.f371c = new F.A0((C1813u) root.f13436G.f3711c);
        eVar.f372d = new C0867C(15);
        eVar.f373e = new C1811s();
        this.f14158G = eVar;
        this.f14160H = C1877m.f14104m;
        this.f14162I = g() ? new V.a(this, getAutofillTree()) : null;
        this.f14165K = new C1867h(context);
        this.f14166L = new t0.i0(new C1881o(this, i5));
        this.f14172R = new t0.S(getRoot());
        this.f14173S = new X(ViewConfiguration.get(context));
        this.f14174T = E4.d.h(Integer.MAX_VALUE, Integer.MAX_VALUE);
        this.f14175U = new int[]{0, 0};
        float[] fArrA = b0.H.a();
        this.f14176V = fArrA;
        this.f14177W = b0.H.a();
        this.f14178a0 = b0.H.a();
        this.f14179b0 = -1L;
        this.f14181d0 = 9187343241974906880L;
        this.f14182e0 = true;
        I.W w6 = I.W.f3598q;
        this.f14183f0 = C0234d.K(null, w6);
        this.f14184g0 = C0234d.D(new C1885q(this, i5));
        this.f14186i0 = new ViewTreeObserver.OnGlobalLayoutListener() { // from class: u0.i
            @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
            public final void onGlobalLayout() {
                this.a.I();
            }
        };
        this.f14187j0 = new ViewTreeObserver.OnScrollChangedListener() { // from class: u0.j
            @Override // android.view.ViewTreeObserver.OnScrollChangedListener
            public final void onScrollChanged() {
                this.a.I();
            }
        };
        this.f14188k0 = new ViewTreeObserver.OnTouchModeChangeListener() { // from class: u0.k
            @Override // android.view.ViewTreeObserver.OnTouchModeChangeListener
            public final void onTouchModeChanged(boolean z3) {
                C1241c c1241c = this.a.f14207u0;
                int i6 = z3 ? 1 : 2;
                c1241c.getClass();
                c1241c.a.setValue(new C1239a(i6));
            }
        };
        I0.D d3 = new I0.D(getView(), this);
        this.f14190l0 = d3;
        this.f14192m0 = new I0.B(d3);
        this.f14194n0 = new AtomicReference(null);
        this.f14196o0 = new C1866g0(getTextInputService());
        this.f14198p0 = new C1884p0();
        this.q0 = C0234d.K(E4.d.C(context), w5);
        Configuration configuration = context.getResources().getConfiguration();
        int i6 = Build.VERSION.SDK_INT;
        this.f14201r0 = i6 >= 31 ? configuration.fontWeightAdjustment : 0;
        int layoutDirection = context.getResources().getConfiguration().getLayoutDirection();
        O0.k kVar = O0.k.f5351l;
        O0.k kVar2 = layoutDirection != 0 ? layoutDirection != 1 ? null : O0.k.f5352m : kVar;
        this.f14203s0 = C0234d.K(kVar2 != null ? kVar2 : kVar, w6);
        this.f14205t0 = new C1204b(this);
        this.f14207u0 = new C1241c(isInTouchMode() ? 1 : 2);
        this.v0 = new C1736c(this);
        this.f14210w0 = new S(this);
        this.f14216z0 = new K1(23);
        this.f14150A0 = new K.d(new T3.a[16]);
        this.f14151B0 = new P2.j(11, this);
        this.f14152C0 = new E.t(8, this);
        this.f14155E0 = new C1885q(this, 0);
        this.f14157F0 = i6 < 29 ? new W0.i(fArrA) : new C1856b0();
        addOnAttachStateChangeListener(this.f14213y);
        setWillNotDraw(false);
        setFocusable(true);
        if (i6 >= 26) {
            C1845J.a.a(this, 1, false);
        }
        setFocusableInTouchMode(true);
        setClipChildren(false);
        int i7 = AbstractC0680s.a;
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
        setAccessibilityDelegate(c1839d.f8138b);
        setOnDragListener(viewOnDragListenerC1874k0);
        getRoot().e(this);
        if (i6 >= 29) {
            C1841F.a.a(this);
        }
        this.f14161H0 = i6 >= 31 ? new z0.j() : null;
        this.f14163I0 = new C1883p(this);
    }

    public static final boolean e(C1889s c1889s, Z.b bVar, C0493d c0493d) {
        Integer numJ;
        if (c1889s.isFocused() || c1889s.hasFocus()) {
            return true;
        }
        return super.requestFocus((bVar == null || (numJ = Z.d.J(bVar.a)) == null) ? 130 : numJ.intValue(), c0493d != null ? b0.N.C(c0493d) : null);
    }

    public static boolean g() {
        return Build.VERSION.SDK_INT >= 26;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final C1875l get_viewTreeOwners() {
        return (C1875l) this.f14183f0.getValue();
    }

    public static void h(ViewGroup viewGroup) {
        int childCount = viewGroup.getChildCount();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = viewGroup.getChildAt(i5);
            if (childAt instanceof C1889s) {
                ((C1889s) childAt).v();
            } else if (childAt instanceof ViewGroup) {
                h((ViewGroup) childAt);
            }
        }
    }

    public static long i(int i5) {
        long j5;
        long j6;
        int mode = View.MeasureSpec.getMode(i5);
        int size = View.MeasureSpec.getSize(i5);
        if (mode == Integer.MIN_VALUE) {
            j5 = ((long) 0) << 32;
        } else {
            if (mode != 0) {
                if (mode != 1073741824) {
                    throw new IllegalStateException();
                }
                j6 = size;
                j5 = j6 << 32;
                return j5 | j6;
            }
            j5 = ((long) 0) << 32;
            size = Integer.MAX_VALUE;
        }
        j6 = size;
        return j5 | j6;
    }

    public static View j(View view, int i5) throws NoSuchMethodException {
        if (Build.VERSION.SDK_INT < 29) {
            Method declaredMethod = View.class.getDeclaredMethod("getAccessibilityViewId", null);
            declaredMethod.setAccessible(true);
            if (U3.j.a(declaredMethod.invoke(view, null), Integer.valueOf(i5))) {
                return view;
            }
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                int childCount = viewGroup.getChildCount();
                for (int i6 = 0; i6 < childCount; i6++) {
                    View viewJ = j(viewGroup.getChildAt(i6), i5);
                    if (viewJ != null) {
                        return viewJ;
                    }
                }
            }
        }
        return null;
    }

    public static void m(t0.E e5) {
        e5.z();
        K.d dVarV = e5.v();
        int i5 = dVarV.f4405n;
        if (i5 > 0) {
            Object[] objArr = dVarV.f4403l;
            int i6 = 0;
            do {
                m((t0.E) objArr[i6]);
                i6++;
            } while (i6 < i5);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x0044  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x007f  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0082 A[LOOP:0: B:22:0x004c->B:39:0x0082, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0085 A[EDGE_INSN: B:41:0x0085->B:40:0x0085 BREAK  A[LOOP:0: B:22:0x004c->B:39:0x0082], SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean o(android.view.MotionEvent r6) {
        /*
            float r0 = r6.getX()
            boolean r1 = java.lang.Float.isInfinite(r0)
            r2 = 0
            r3 = 1
            if (r1 != 0) goto L44
            boolean r0 = java.lang.Float.isNaN(r0)
            if (r0 != 0) goto L44
            float r0 = r6.getY()
            boolean r1 = java.lang.Float.isInfinite(r0)
            if (r1 != 0) goto L44
            boolean r0 = java.lang.Float.isNaN(r0)
            if (r0 != 0) goto L44
            float r0 = r6.getRawX()
            boolean r1 = java.lang.Float.isInfinite(r0)
            if (r1 != 0) goto L44
            boolean r0 = java.lang.Float.isNaN(r0)
            if (r0 != 0) goto L44
            float r0 = r6.getRawY()
            boolean r1 = java.lang.Float.isInfinite(r0)
            if (r1 != 0) goto L44
            boolean r0 = java.lang.Float.isNaN(r0)
            if (r0 != 0) goto L44
            r0 = r2
            goto L45
        L44:
            r0 = r3
        L45:
            if (r0 != 0) goto L85
            int r1 = r6.getPointerCount()
            r4 = r3
        L4c:
            if (r4 >= r1) goto L85
            float r0 = r6.getX(r4)
            boolean r5 = java.lang.Float.isInfinite(r0)
            if (r5 != 0) goto L7f
            boolean r0 = java.lang.Float.isNaN(r0)
            if (r0 != 0) goto L7f
            float r0 = r6.getY(r4)
            boolean r5 = java.lang.Float.isInfinite(r0)
            if (r5 != 0) goto L7f
            boolean r0 = java.lang.Float.isNaN(r0)
            if (r0 != 0) goto L7f
            int r0 = android.os.Build.VERSION.SDK_INT
            r5 = 29
            if (r0 < r5) goto L7d
            u0.u0 r0 = u0.C1894u0.a
            boolean r0 = r0.a(r6, r4)
            if (r0 != 0) goto L7d
            goto L7f
        L7d:
            r0 = r2
            goto L80
        L7f:
            r0 = r3
        L80:
            if (r0 != 0) goto L85
            int r4 = r4 + 1
            goto L4c
        L85:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.C1889s.o(android.view.MotionEvent):boolean");
    }

    private void setDensity(O0.b bVar) {
        this.f14195o.setValue(bVar);
    }

    private void setFontFamilyResolver(InterfaceC0181n interfaceC0181n) {
        this.q0.setValue(interfaceC0181n);
    }

    private void setLayoutDirection(O0.k kVar) {
        this.f14203s0.setValue(kVar);
    }

    private final void set_viewTreeOwners(C1875l c1875l) {
        this.f14183f0.setValue(c1875l);
    }

    public final void A() {
        C1839D c1839d = this.f14211x;
        c1839d.f13914y = true;
        if (c1839d.q() && !c1839d.f13889J) {
            c1839d.f13889J = true;
            c1839d.f13901l.post(c1839d.f13890K);
        }
        W.c cVar = this.f14213y;
        cVar.f6794s = true;
        if (!cVar.e() || cVar.f6786A) {
            return;
        }
        cVar.f6786A = true;
        cVar.f6797v.post(cVar.B);
    }

    public final void B() {
        if (this.f14180c0) {
            return;
        }
        long jCurrentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
        if (jCurrentAnimationTimeMillis != this.f14179b0) {
            this.f14179b0 = jCurrentAnimationTimeMillis;
            InterfaceC1854a0 interfaceC1854a0 = this.f14157F0;
            float[] fArr = this.f14177W;
            interfaceC1854a0.a(this, fArr);
            AbstractC1846K.q(fArr, this.f14178a0);
            ViewParent parent = getParent();
            View view = this;
            while (parent instanceof ViewGroup) {
                view = (View) parent;
                parent = ((ViewGroup) view).getParent();
            }
            int[] iArr = this.f14175U;
            view.getLocationOnScreen(iArr);
            float f5 = iArr[0];
            float f6 = iArr[1];
            view.getLocationInWindow(iArr);
            this.f14181d0 = X2.g.l(f5 - iArr[0], f6 - iArr[1]);
        }
    }

    public final void C(t0.f0 f0Var) {
        K1 k12;
        Reference referencePoll;
        K.d dVar;
        if (this.f14169O != null) {
            R0.x xVar = Q0.f13979A;
        }
        do {
            k12 = this.f14216z0;
            referencePoll = ((ReferenceQueue) k12.f8411n).poll();
            dVar = (K.d) k12.f8410m;
            if (referencePoll != null) {
                dVar.o(referencePoll);
            }
        } while (referencePoll != null);
        dVar.b(new WeakReference(f0Var, (ReferenceQueue) k12.f8411n));
    }

    public final void D(t0.E e5) {
        if (isLayoutRequested() || !isAttachedToWindow()) {
            return;
        }
        if (e5 != null) {
            while (e5 != null && e5.f13437H.f13528r.f13507v == 1) {
                if (!this.f14171Q) {
                    t0.E eS = e5.s();
                    if (eS == null) {
                        break;
                    }
                    long j5 = ((C1813u) eS.f13436G.f3711c).f12947o;
                    if (O0.a.f(j5) && O0.a.e(j5)) {
                        break;
                    }
                }
                e5 = e5.s();
            }
            if (e5 == getRoot()) {
                requestLayout();
                return;
            }
        }
        if (getWidth() == 0 || getHeight() == 0) {
            requestLayout();
        } else {
            invalidate();
        }
    }

    public final long E(long j5) {
        B();
        float fD = C0492c.d(j5) - C0492c.d(this.f14181d0);
        float fE = C0492c.e(j5) - C0492c.e(this.f14181d0);
        return b0.H.b(X2.g.l(fD, fE), this.f14178a0);
    }

    /* JADX WARN: Removed duplicated region for block: B:18:0x0048  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final int F(android.view.MotionEvent r8) {
        /*
            r7 = this;
            boolean r0 = r7.f14159G0
            r1 = 0
            if (r0 == 0) goto L1a
            r7.f14159G0 = r1
            int r0 = r8.getMetaState()
            u0.V0 r2 = r7.f14202s
            r2.getClass()
            n0.v r2 = new n0.v
            r2.<init>(r0)
            I.j0 r0 = u0.V0.f14012b
            r0.setValue(r2)
        L1a:
            n0.e r0 = r7.f14156F
            y.t r2 = r0.a(r8, r7)
            A4.e r3 = r7.f14158G
            if (r2 == 0) goto L75
            java.lang.Object r1 = r2.f15535m
            java.util.ArrayList r1 = (java.util.ArrayList) r1
            int r4 = r1.size()
            int r4 = r4 + (-1)
            if (r4 < 0) goto L43
        L30:
            int r5 = r4 + (-1)
            java.lang.Object r4 = r1.get(r4)
            r6 = r4
            n0.u r6 = (n0.u) r6
            boolean r6 = r6.f11979e
            if (r6 == 0) goto L3e
            goto L44
        L3e:
            if (r5 >= 0) goto L41
            goto L43
        L41:
            r4 = r5
            goto L30
        L43:
            r4 = 0
        L44:
            n0.u r4 = (n0.u) r4
            if (r4 == 0) goto L4c
            long r4 = r4.f11978d
            r7.f14189l = r4
        L4c:
            boolean r1 = r7.p(r8)
            int r1 = r3.h(r2, r7, r1)
            int r2 = r8.getActionMasked()
            if (r2 == 0) goto L5d
            r3 = 5
            if (r2 != r3) goto L78
        L5d:
            r2 = r1 & 1
            if (r2 == 0) goto L62
            goto L78
        L62:
            int r2 = r8.getActionIndex()
            int r8 = r8.getPointerId(r2)
            android.util.SparseBooleanArray r2 = r0.f11939c
            r2.delete(r8)
            android.util.SparseLongArray r0 = r0.f11938b
            r0.delete(r8)
            goto L78
        L75:
            r3.i()
        L78:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.C1889s.F(android.view.MotionEvent):int");
    }

    public final void G(MotionEvent motionEvent, int i5, long j5, boolean z3) {
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = -1;
        if (actionMasked != 1) {
            if (actionMasked == 6) {
                actionIndex = motionEvent.getActionIndex();
            }
        } else if (i5 != 9 && i5 != 10) {
            actionIndex = 0;
        }
        int pointerCount = motionEvent.getPointerCount() - (actionIndex >= 0 ? 1 : 0);
        if (pointerCount == 0) {
            return;
        }
        MotionEvent.PointerProperties[] pointerPropertiesArr = new MotionEvent.PointerProperties[pointerCount];
        for (int i6 = 0; i6 < pointerCount; i6++) {
            pointerPropertiesArr[i6] = new MotionEvent.PointerProperties();
        }
        MotionEvent.PointerCoords[] pointerCoordsArr = new MotionEvent.PointerCoords[pointerCount];
        for (int i7 = 0; i7 < pointerCount; i7++) {
            pointerCoordsArr[i7] = new MotionEvent.PointerCoords();
        }
        int i8 = 0;
        while (i8 < pointerCount) {
            int i9 = ((actionIndex < 0 || i8 < actionIndex) ? 0 : 1) + i8;
            motionEvent.getPointerProperties(i9, pointerPropertiesArr[i8]);
            MotionEvent.PointerCoords pointerCoords = pointerCoordsArr[i8];
            motionEvent.getPointerCoords(i9, pointerCoords);
            long jR = r(X2.g.l(pointerCoords.x, pointerCoords.y));
            pointerCoords.x = C0492c.d(jR);
            pointerCoords.y = C0492c.e(jR);
            i8++;
        }
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent.getDownTime() == motionEvent.getEventTime() ? j5 : motionEvent.getDownTime(), j5, i5, pointerCount, pointerPropertiesArr, pointerCoordsArr, motionEvent.getMetaState(), z3 ? 0 : motionEvent.getButtonState(), motionEvent.getXPrecision(), motionEvent.getYPrecision(), motionEvent.getDeviceId(), motionEvent.getEdgeFlags(), motionEvent.getSource(), motionEvent.getFlags());
        y.t tVarA = this.f14156F.a(motionEventObtain, this);
        U3.j.c(tVarA);
        this.f14158G.h(tVarA, this, true);
        motionEventObtain.recycle();
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void H(y.C2069e r6, M3.c r7) {
        /*
            r5 = this;
            boolean r0 = r7 instanceof u0.C1887r
            if (r0 == 0) goto L13
            r0 = r7
            u0.r r0 = (u0.C1887r) r0
            int r1 = r0.f14146q
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f14146q = r1
            goto L18
        L13:
            u0.r r0 = new u0.r
            r0.<init>(r5, r7)
        L18:
            java.lang.Object r7 = r0.f14144o
            L3.a r1 = L3.a.f4629l
            int r2 = r0.f14146q
            r3 = 1
            if (r2 == 0) goto L2f
            if (r2 == r3) goto L2b
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r7)
            throw r6
        L2b:
            G3.AbstractC0164a.e(r7)
            goto L49
        L2f:
            G3.AbstractC0164a.e(r7)
            java.util.concurrent.atomic.AtomicReference r7 = r5.f14194n0
            u0.o r2 = new u0.o
            r4 = 2
            r2.<init>(r5, r4)
            r0.f14146q = r3
            U.t r3 = new U.t
            r4 = 0
            r3.<init>(r2, r7, r6, r4)
            java.lang.Object r6 = f4.AbstractC0952A.f(r3, r0)
            if (r6 != r1) goto L49
            return
        L49:
            G3.f r6 = new G3.f
            r6.<init>()
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.C1889s.H(y.e, M3.c):void");
    }

    public final void I() {
        int[] iArr = this.f14175U;
        getLocationOnScreen(iArr);
        long j5 = this.f14174T;
        int i5 = (int) (j5 >> 32);
        int i6 = (int) (j5 & 4294967295L);
        boolean z3 = false;
        int i7 = iArr[0];
        if (i5 != i7 || i6 != iArr[1]) {
            this.f14174T = E4.d.h(i7, iArr[1]);
            if (i5 != Integer.MAX_VALUE && i6 != Integer.MAX_VALUE) {
                getRoot().f13437H.f13528r.s0();
                z3 = true;
            }
        }
        this.f14172R.a(z3);
    }

    @Override // androidx.lifecycle.InterfaceC0560e
    public final void a(InterfaceC0576v interfaceC0576v) {
        setShowLayoutBounds(C1884p0.a());
    }

    @Override // android.view.ViewGroup
    public final void addView(View view) {
        addView(view, -1);
    }

    @Override // android.view.View
    public final void autofill(SparseArray sparseArray) {
        V.a aVar;
        if (!g() || (aVar = this.f14162I) == null) {
            return;
        }
        int size = sparseArray.size();
        for (int i5 = 0; i5 < size; i5++) {
            int iKeyAt = sparseArray.keyAt(i5);
            AutofillValue autofillValueE = AbstractC0066g.e(sparseArray.get(iKeyAt));
            V.e eVar = V.e.a;
            if (eVar.d(autofillValueE)) {
                eVar.i(autofillValueE).toString();
                if (aVar.f6193b.a.get(Integer.valueOf(iKeyAt)) != null) {
                    throw new ClassCastException();
                }
            } else {
                if (eVar.b(autofillValueE)) {
                    throw new G3.k("An operation is not implemented: b/138604541: Add onFill() callback for date");
                }
                if (eVar.c(autofillValueE)) {
                    throw new G3.k("An operation is not implemented: b/138604541: Add onFill() callback for list");
                }
                if (eVar.e(autofillValueE)) {
                    throw new G3.k("An operation is not implemented: b/138604541:  Add onFill() callback for toggle");
                }
            }
        }
    }

    @Override // android.view.View
    public final boolean canScrollHorizontally(int i5) {
        return this.f14211x.e(i5, this.f14189l, false);
    }

    @Override // android.view.View
    public final boolean canScrollVertically(int i5) {
        return this.f14211x.e(i5, this.f14189l, true);
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0029  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void dispatchDraw(android.graphics.Canvas r7) {
        /*
            r6 = this;
            boolean r0 = r6.isAttachedToWindow()
            if (r0 != 0) goto Ld
            t0.E r0 = r6.getRoot()
            m(r0)
        Ld:
            r0 = 1
            r6.s(r0)
            java.lang.Object r1 = S.p.f5938b
            monitor-enter(r1)
            java.util.concurrent.atomic.AtomicReference r2 = S.p.f5945i     // Catch: java.lang.Throwable -> L2b
            java.lang.Object r2 = r2.get()     // Catch: java.lang.Throwable -> L2b
            S.c r2 = (S.C0425c) r2     // Catch: java.lang.Throwable -> L2b
            i.C r2 = r2.f5902h     // Catch: java.lang.Throwable -> L2b
            r3 = 0
            if (r2 == 0) goto L29
            boolean r2 = r2.h()     // Catch: java.lang.Throwable -> L2b
            if (r2 != r0) goto L29
            r2 = r0
            goto L2d
        L29:
            r2 = r3
            goto L2d
        L2b:
            r7 = move-exception
            goto L8e
        L2d:
            monitor-exit(r1)
            if (r2 == 0) goto L33
            S.p.a()
        L33:
            r6.f14154E = r0
            b0.s r0 = r6.f14204t
            b0.c r1 = r0.a
            android.graphics.Canvas r2 = r1.a
            r1.a = r7
            t0.E r4 = r6.getRoot()
            r5 = 0
            r4.j(r1, r5)
            b0.c r0 = r0.a
            r0.a = r2
            java.util.ArrayList r0 = r6.C
            boolean r0 = r0.isEmpty()
            if (r0 != 0) goto L68
            java.util.ArrayList r0 = r6.C
            int r0 = r0.size()
            r1 = r3
        L58:
            if (r1 >= r0) goto L68
            java.util.ArrayList r2 = r6.C
            java.lang.Object r2 = r2.get(r1)
            t0.f0 r2 = (t0.f0) r2
            r2.e()
            int r1 = r1 + 1
            goto L58
        L68:
            boolean r0 = u0.Q0.f13980E
            if (r0 == 0) goto L7a
            int r0 = r7.save()
            r1 = 0
            r7.clipRect(r1, r1, r1, r1)
            super.dispatchDraw(r7)
            r7.restoreToCount(r0)
        L7a:
            java.util.ArrayList r7 = r6.C
            r7.clear()
            r6.f14154E = r3
            java.util.ArrayList r7 = r6.D
            if (r7 == 0) goto L8d
            java.util.ArrayList r0 = r6.C
            r0.addAll(r7)
            r7.clear()
        L8d:
            return
        L8e:
            monitor-exit(r1)
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.C1889s.dispatchDraw(android.graphics.Canvas):void");
    }

    @Override // android.view.View
    public final boolean dispatchGenericMotionEvent(MotionEvent motionEvent) {
        C1554a c1554a;
        int size;
        C0265t c0265t;
        U.p pVarF;
        C0265t c0265t2;
        if (this.f14153D0) {
            E.t tVar = this.f14152C0;
            removeCallbacks(tVar);
            if (motionEvent.getActionMasked() == 8) {
                this.f14153D0 = false;
            } else {
                tVar.run();
            }
        }
        if (motionEvent.getActionMasked() != 8) {
            return super.dispatchGenericMotionEvent(motionEvent);
        }
        if (o(motionEvent) || !isAttachedToWindow()) {
            return super.dispatchGenericMotionEvent(motionEvent);
        }
        if (!motionEvent.isFromSource(4194304)) {
            return (l(motionEvent) & 1) != 0;
        }
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        motionEvent.getAxisValue(26);
        Context context = getContext();
        int i5 = Build.VERSION.SDK_INT;
        if (i5 >= 26) {
            Method method = c1.u.a;
            AbstractC0681t.b(viewConfiguration);
        } else {
            c1.u.a(viewConfiguration, context);
        }
        Context context2 = getContext();
        if (i5 >= 26) {
            AbstractC0681t.a(viewConfiguration);
        } else {
            c1.u.a(viewConfiguration, context2);
        }
        motionEvent.getEventTime();
        motionEvent.getDeviceId();
        androidx.compose.ui.focus.b bVar = (androidx.compose.ui.focus.b) getFocusOwner();
        if (bVar.f7478g.a()) {
            throw new IllegalStateException("Dispatching rotary event while focus system is invalidated.");
        }
        Z.r rVarG = Z.d.g(bVar.f7477f);
        if (rVarG != null) {
            U.p pVar = rVarG.f6127l;
            if (!pVar.f6139x) {
                throw new IllegalStateException("visitAncestors called on an unattached node");
            }
            t0.E eV = AbstractC1800g.v(rVarG);
            loop0: while (true) {
                if (eV == null) {
                    pVarF = null;
                    break;
                }
                if ((((U.p) eV.f13436G.f3714f).f6130o & 16384) != 0) {
                    while (pVar != null) {
                        if ((pVar.f6129n & 16384) != 0) {
                            K.d dVar = null;
                            pVarF = pVar;
                            while (pVarF != null) {
                                if (pVarF instanceof C1554a) {
                                    break loop0;
                                }
                                if ((pVarF.f6129n & 16384) != 0 && (pVarF instanceof AbstractC1808o)) {
                                    int i6 = 0;
                                    for (U.p pVar2 = ((AbstractC1808o) pVarF).f13651z; pVar2 != null; pVar2 = pVar2.f6132q) {
                                        if ((pVar2.f6129n & 16384) != 0) {
                                            i6++;
                                            if (i6 == 1) {
                                                pVarF = pVar2;
                                            } else {
                                                if (dVar == null) {
                                                    dVar = new K.d(new U.p[16]);
                                                }
                                                if (pVarF != null) {
                                                    dVar.b(pVarF);
                                                    pVarF = null;
                                                }
                                                dVar.b(pVar2);
                                            }
                                        }
                                    }
                                    if (i6 == 1) {
                                    }
                                }
                                pVarF = AbstractC1800g.f(dVar);
                            }
                        }
                        pVar = pVar.f6131p;
                    }
                }
                eV = eV.s();
                pVar = (eV == null || (c0265t2 = eV.f13436G) == null) ? null : (t0.o0) c0265t2.f3713e;
            }
            c1554a = (C1554a) pVarF;
        } else {
            c1554a = null;
        }
        if (c1554a == null) {
            return false;
        }
        C1554a c1554a2 = c1554a;
        U.p pVar3 = c1554a2.f6127l;
        if (!pVar3.f6139x) {
            throw new IllegalStateException("visitAncestors called on an unattached node");
        }
        U.p pVar4 = pVar3.f6131p;
        t0.E eV2 = AbstractC1800g.v(c1554a);
        ArrayList arrayList = null;
        while (eV2 != null) {
            if ((((U.p) eV2.f13436G.f3714f).f6130o & 16384) != 0) {
                while (pVar4 != null) {
                    if ((pVar4.f6129n & 16384) != 0) {
                        U.p pVarF2 = pVar4;
                        K.d dVar2 = null;
                        while (pVarF2 != null) {
                            if (pVarF2 instanceof C1554a) {
                                if (arrayList == null) {
                                    arrayList = new ArrayList();
                                }
                                arrayList.add(pVarF2);
                            } else if ((pVarF2.f6129n & 16384) != 0 && (pVarF2 instanceof AbstractC1808o)) {
                                int i7 = 0;
                                for (U.p pVar5 = ((AbstractC1808o) pVarF2).f13651z; pVar5 != null; pVar5 = pVar5.f6132q) {
                                    if ((pVar5.f6129n & 16384) != 0) {
                                        i7++;
                                        if (i7 == 1) {
                                            pVarF2 = pVar5;
                                        } else {
                                            if (dVar2 == null) {
                                                dVar2 = new K.d(new U.p[16]);
                                            }
                                            if (pVarF2 != null) {
                                                dVar2.b(pVarF2);
                                                pVarF2 = null;
                                            }
                                            dVar2.b(pVar5);
                                        }
                                    }
                                }
                                if (i7 == 1) {
                                }
                            }
                            pVarF2 = AbstractC1800g.f(dVar2);
                        }
                    }
                    pVar4 = pVar4.f6131p;
                }
            }
            eV2 = eV2.s();
            pVar4 = (eV2 == null || (c0265t = eV2.f13436G) == null) ? null : (t0.o0) c0265t.f3713e;
        }
        if (arrayList != null && arrayList.size() - 1 >= 0) {
            while (true) {
                int i8 = size - 1;
                ((C1554a) arrayList.get(size)).getClass();
                if (i8 < 0) {
                    break;
                }
                size = i8;
            }
        }
        U.p pVarF3 = c1554a2.f6127l;
        K.d dVar3 = null;
        while (pVarF3 != null) {
            if (pVarF3 instanceof C1554a) {
            } else if ((pVarF3.f6129n & 16384) != 0 && (pVarF3 instanceof AbstractC1808o)) {
                int i9 = 0;
                for (U.p pVar6 = ((AbstractC1808o) pVarF3).f13651z; pVar6 != null; pVar6 = pVar6.f6132q) {
                    if ((pVar6.f6129n & 16384) != 0) {
                        i9++;
                        if (i9 == 1) {
                            pVarF3 = pVar6;
                        } else {
                            if (dVar3 == null) {
                                dVar3 = new K.d(new U.p[16]);
                            }
                            if (pVarF3 != null) {
                                dVar3.b(pVarF3);
                                pVarF3 = null;
                            }
                            dVar3.b(pVar6);
                        }
                    }
                }
                if (i9 == 1) {
                }
            }
            pVarF3 = AbstractC1800g.f(dVar3);
        }
        U.p pVarF4 = c1554a2.f6127l;
        K.d dVar4 = null;
        while (pVarF4 != null) {
            if (pVarF4 instanceof C1554a) {
            } else if ((pVarF4.f6129n & 16384) != 0 && (pVarF4 instanceof AbstractC1808o)) {
                int i10 = 0;
                for (U.p pVar7 = ((AbstractC1808o) pVarF4).f13651z; pVar7 != null; pVar7 = pVar7.f6132q) {
                    if ((pVar7.f6129n & 16384) != 0) {
                        i10++;
                        if (i10 == 1) {
                            pVarF4 = pVar7;
                        } else {
                            if (dVar4 == null) {
                                dVar4 = new K.d(new U.p[16]);
                            }
                            if (pVarF4 != null) {
                                dVar4.b(pVarF4);
                                pVarF4 = null;
                            }
                            dVar4.b(pVar7);
                        }
                    }
                }
                if (i10 == 1) {
                }
            }
            pVarF4 = AbstractC1800g.f(dVar4);
        }
        if (arrayList == null) {
            return false;
        }
        int size2 = arrayList.size();
        for (int i11 = 0; i11 < size2; i11++) {
            C1877m c1877m = ((C1554a) arrayList.get(i11)).f12470y;
        }
        return false;
    }

    /* JADX WARN: Removed duplicated region for block: B:48:0x00df  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x00fd  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x010b  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean dispatchHoverEvent(android.view.MotionEvent r25) {
        /*
            Method dump skipped, instruction units count: 344
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.C1889s.dispatchHoverEvent(android.view.MotionEvent):boolean");
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (!isFocused()) {
            return ((androidx.compose.ui.focus.b) getFocusOwner()).b(keyEvent, new A.d0(this, 11, keyEvent));
        }
        int metaState = keyEvent.getMetaState();
        this.f14202s.getClass();
        V0.f14012b.setValue(new n0.v(metaState));
        return ((androidx.compose.ui.focus.b) getFocusOwner()).b(keyEvent, Z.f.f7140m) || super.dispatchKeyEvent(keyEvent);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEventPreIme(KeyEvent keyEvent) {
        C0265t c0265t;
        if (isFocused()) {
            androidx.compose.ui.focus.b bVar = (androidx.compose.ui.focus.b) getFocusOwner();
            if (bVar.f7478g.a()) {
                throw new IllegalStateException("Dispatching intercepted soft keyboard event while focus system is invalidated.");
            }
            Z.r rVarG = Z.d.g(bVar.f7477f);
            if (rVarG != null) {
                U.p pVar = rVarG.f6127l;
                if (!pVar.f6139x) {
                    throw new IllegalStateException("visitAncestors called on an unattached node");
                }
                t0.E eV = AbstractC1800g.v(rVarG);
                while (eV != null) {
                    if ((((U.p) eV.f13436G.f3714f).f6130o & 131072) != 0) {
                        while (pVar != null) {
                            if ((pVar.f6129n & 131072) != 0) {
                                U.p pVarF = pVar;
                                K.d dVar = null;
                                while (pVarF != null) {
                                    if ((pVarF.f6129n & 131072) != 0 && (pVarF instanceof AbstractC1808o)) {
                                        int i5 = 0;
                                        for (U.p pVar2 = ((AbstractC1808o) pVarF).f13651z; pVar2 != null; pVar2 = pVar2.f6132q) {
                                            if ((pVar2.f6129n & 131072) != 0) {
                                                i5++;
                                                if (i5 == 1) {
                                                    pVarF = pVar2;
                                                } else {
                                                    if (dVar == null) {
                                                        dVar = new K.d(new U.p[16]);
                                                    }
                                                    if (pVarF != null) {
                                                        dVar.b(pVarF);
                                                        pVarF = null;
                                                    }
                                                    dVar.b(pVar2);
                                                }
                                            }
                                        }
                                        if (i5 == 1) {
                                        }
                                    }
                                    pVarF = AbstractC1800g.f(dVar);
                                }
                            }
                            pVar = pVar.f6131p;
                        }
                    }
                    eV = eV.s();
                    pVar = (eV == null || (c0265t = eV.f13436G) == null) ? null : (t0.o0) c0265t.f3713e;
                }
            }
        }
        return super.dispatchKeyEventPreIme(keyEvent);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchProvideStructure(ViewStructure viewStructure) {
        if (Build.VERSION.SDK_INT < 28) {
            C1840E.a.a(viewStructure, getView());
        } else {
            super.dispatchProvideStructure(viewStructure);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (this.f14153D0) {
            E.t tVar = this.f14152C0;
            removeCallbacks(tVar);
            MotionEvent motionEvent2 = this.f14212x0;
            U3.j.c(motionEvent2);
            if (motionEvent.getActionMasked() == 0 && motionEvent2.getSource() == motionEvent.getSource() && motionEvent2.getToolType(0) == motionEvent.getToolType(0)) {
                this.f14153D0 = false;
            } else {
                tVar.run();
            }
        }
        if (o(motionEvent) || !isAttachedToWindow()) {
            return false;
        }
        if (motionEvent.getActionMasked() == 2 && !q(motionEvent)) {
            return false;
        }
        int iL = l(motionEvent);
        if ((iL & 2) != 0) {
            getParent().requestDisallowInterceptTouchEvent(true);
        }
        return (iL & 1) != 0;
    }

    public final View findViewByAccessibilityIdTraversal(int i5) throws IllegalAccessException, InvocationTargetException {
        View viewJ = null;
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                Method declaredMethod = View.class.getDeclaredMethod("findViewByAccessibilityIdTraversal", Integer.TYPE);
                declaredMethod.setAccessible(true);
                Object objInvoke = declaredMethod.invoke(this, Integer.valueOf(i5));
                if (objInvoke instanceof View) {
                    viewJ = (View) objInvoke;
                }
            } else {
                viewJ = j(this, i5);
            }
        } catch (NoSuchMethodException unused) {
        }
        return viewJ;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final View focusSearch(View view, int i5) {
        if (view != null) {
            C0493d c0493dD = Z.d.d(view);
            Z.b bVarK = Z.d.K(i5);
            if (U3.j.a(((androidx.compose.ui.focus.b) getFocusOwner()).c(bVarK != null ? bVarK.a : 6, c0493dD, C1877m.f14105n), Boolean.TRUE)) {
                return this;
            }
        }
        return super.focusSearch(view, i5);
    }

    public final Z getAndroidViewsHandler$ui_release() {
        if (this.f14168N == null) {
            Z z3 = new Z(getContext());
            this.f14168N = z3;
            addView(z3, -1);
            requestLayout();
        }
        Z z5 = this.f14168N;
        U3.j.c(z5);
        return z5;
    }

    public V.b getAutofill() {
        return this.f14162I;
    }

    public V.g getAutofillTree() {
        return this.B;
    }

    public final T3.c getConfigurationChangeObserver() {
        return this.f14160H;
    }

    public final W.c getContentCaptureManager$ui_release() {
        return this.f14213y;
    }

    public K3.h getCoroutineContext() {
        return this.f14199q;
    }

    public O0.b getDensity() {
        return (O0.b) this.f14195o.getValue();
    }

    public X.a getDragAndDropManager() {
        return this.f14200r;
    }

    public Z.g getFocusOwner() {
        return this.f14197p;
    }

    @Override // android.view.View
    public final void getFocusedRect(Rect rect) {
        G3.C c5;
        C0493d c0493dW = w();
        if (c0493dW != null) {
            rect.left = Math.round(c0493dW.a);
            rect.top = Math.round(c0493dW.f7216b);
            rect.right = Math.round(c0493dW.f7217c);
            rect.bottom = Math.round(c0493dW.f7218d);
            c5 = G3.C.a;
        } else {
            c5 = null;
        }
        if (c5 == null) {
            super.getFocusedRect(rect);
        }
    }

    public InterfaceC0181n getFontFamilyResolver() {
        return (InterfaceC0181n) this.q0.getValue();
    }

    public InterfaceC0180m getFontLoader() {
        return this.f14198p0;
    }

    public b0.D getGraphicsContext() {
        return this.f14149A;
    }

    public InterfaceC1203a getHapticFeedBack() {
        return this.f14205t0;
    }

    public boolean getHasPendingMeasureOrLayout() {
        return this.f14172R.f13550b.p();
    }

    public InterfaceC1240b getInputModeManager() {
        return this.f14207u0;
    }

    public final long getLastMatrixRecalculationAnimationTime$ui_release() {
        return this.f14179b0;
    }

    @Override // android.view.View, android.view.ViewParent
    public O0.k getLayoutDirection() {
        return (O0.k) this.f14203s0.getValue();
    }

    public long getMeasureIteration() {
        t0.S s3 = this.f14172R;
        if (s3.f13551c) {
            return s3.f13555g;
        }
        AbstractC1393s.Z("measureIteration should be only used during the measure/layout pass");
        throw null;
    }

    public C1736c getModifierLocalManager() {
        return this.v0;
    }

    public AbstractC1649N getPlacementScope() {
        int i5 = AbstractC1652Q.f12952b;
        return new C1639D(1, this);
    }

    public InterfaceC1450p getPointerIconService() {
        return this.f14163I0;
    }

    public t0.E getRoot() {
        return this.f14206u;
    }

    public t0.m0 getRootForTest() {
        return this.f14208v;
    }

    public final boolean getScrollCaptureInProgress$ui_release() {
        z0.j jVar;
        if (Build.VERSION.SDK_INT < 31 || (jVar = this.f14161H0) == null) {
            return false;
        }
        return ((Boolean) jVar.a.getValue()).booleanValue();
    }

    public A0.p getSemanticsOwner() {
        return this.f14209w;
    }

    public t0.G getSharedDrawScope() {
        return this.f14193n;
    }

    public boolean getShowLayoutBounds() {
        return this.f14167M;
    }

    public t0.i0 getSnapshotObserver() {
        return this.f14166L;
    }

    public J0 getSoftwareKeyboardController() {
        return this.f14196o0;
    }

    public I0.B getTextInputService() {
        return this.f14192m0;
    }

    public L0 getTextToolbar() {
        return this.f14210w0;
    }

    public O0 getViewConfiguration() {
        return this.f14173S;
    }

    public final C1875l getViewTreeOwners() {
        return (C1875l) this.f14184g0.getValue();
    }

    public U0 getWindowInfo() {
        return this.f14202s;
    }

    public final void k(t0.E e5, boolean z3) {
        this.f14172R.f(e5, z3);
    }

    public final int l(MotionEvent motionEvent) {
        int i5;
        int actionMasked;
        float[] fArr = this.f14177W;
        removeCallbacks(this.f14151B0);
        try {
            this.f14179b0 = AnimationUtils.currentAnimationTimeMillis();
            this.f14157F0.a(this, fArr);
            AbstractC1846K.q(fArr, this.f14178a0);
            long jB = b0.H.b(X2.g.l(motionEvent.getX(), motionEvent.getY()), fArr);
            this.f14181d0 = X2.g.l(motionEvent.getRawX() - C0492c.d(jB), motionEvent.getRawY() - C0492c.e(jB));
            boolean z3 = true;
            this.f14180c0 = true;
            s(false);
            Trace.beginSection("AndroidOwner:onTouch");
            try {
                int actionMasked2 = motionEvent.getActionMasked();
                MotionEvent motionEvent2 = this.f14212x0;
                boolean z5 = motionEvent2 != null && motionEvent2.getToolType(0) == 3;
                A4.e eVar = this.f14158G;
                if (motionEvent2 != null) {
                    if ((motionEvent2.getSource() == motionEvent.getSource() && motionEvent2.getToolType(0) == motionEvent.getToolType(0)) ? false : true) {
                        if (motionEvent2.getButtonState() != 0 || (actionMasked = motionEvent2.getActionMasked()) == 0 || actionMasked == 2 || actionMasked == 6) {
                            eVar.i();
                        } else if (motionEvent2.getActionMasked() != 10 && z5) {
                            G(motionEvent2, 10, motionEvent2.getEventTime(), true);
                        }
                    }
                }
                boolean z6 = motionEvent.getToolType(0) == 3;
                if (z5 || !z6 || actionMasked2 == 3 || actionMasked2 == 9 || !p(motionEvent)) {
                    i5 = 9;
                } else {
                    i5 = 9;
                    G(motionEvent, 9, motionEvent.getEventTime(), true);
                }
                if (motionEvent2 != null) {
                    motionEvent2.recycle();
                }
                MotionEvent motionEvent3 = this.f14212x0;
                if (motionEvent3 != null && motionEvent3.getAction() == 10) {
                    MotionEvent motionEvent4 = this.f14212x0;
                    int pointerId = motionEvent4 != null ? motionEvent4.getPointerId(0) : -1;
                    int action = motionEvent.getAction();
                    C1439e c1439e = this.f14156F;
                    if (action == i5 && motionEvent.getHistorySize() == 0) {
                        if (pointerId >= 0) {
                            c1439e.f11939c.delete(pointerId);
                            c1439e.f11938b.delete(pointerId);
                        }
                    } else if (motionEvent.getAction() == 0 && motionEvent.getHistorySize() == 0) {
                        MotionEvent motionEvent5 = this.f14212x0;
                        float x5 = motionEvent5 != null ? motionEvent5.getX() : Float.NaN;
                        MotionEvent motionEvent6 = this.f14212x0;
                        boolean z7 = (x5 == motionEvent.getX() && (motionEvent6 != null ? motionEvent6.getY() : Float.NaN) == motionEvent.getY()) ? false : true;
                        MotionEvent motionEvent7 = this.f14212x0;
                        if ((motionEvent7 != null ? motionEvent7.getEventTime() : -1L) == motionEvent.getEventTime()) {
                            z3 = false;
                        }
                        if (z7 || z3) {
                            if (pointerId >= 0) {
                                c1439e.f11939c.delete(pointerId);
                                c1439e.f11938b.delete(pointerId);
                            }
                            ((C1442h) ((F.A0) eVar.f371c).f1395n).a.h();
                        }
                    }
                }
                this.f14212x0 = MotionEvent.obtainNoHistory(motionEvent);
                return F(motionEvent);
            } finally {
                Trace.endSection();
            }
        } finally {
            this.f14180c0 = false;
        }
    }

    public final void n(t0.E e5) {
        int i5 = 0;
        this.f14172R.p(e5, false);
        K.d dVarV = e5.v();
        int i6 = dVarV.f4405n;
        if (i6 > 0) {
            Object[] objArr = dVarV.f4403l;
            do {
                n((t0.E) objArr[i5]);
                i5++;
            } while (i5 < i6);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        C0578x c0578xE;
        InterfaceC0576v interfaceC0576v;
        V.a aVar;
        super.onAttachedToWindow();
        this.f14202s.a.setValue(Boolean.valueOf(hasWindowFocus()));
        n(getRoot());
        m(getRoot());
        getSnapshotObserver().a.d();
        if (g() && (aVar = this.f14162I) != null) {
            V.f.a.a(aVar);
        }
        InterfaceC0576v interfaceC0576vG = androidx.lifecycle.U.g(this);
        F1.f fVarC = W3.a.C(this);
        C1875l viewTreeOwners = getViewTreeOwners();
        if (viewTreeOwners == null || (interfaceC0576vG != null && fVarC != null && (interfaceC0576vG != (interfaceC0576v = viewTreeOwners.a) || fVarC != interfaceC0576v))) {
            if (interfaceC0576vG == null) {
                throw new IllegalStateException("Composed into the View which doesn't propagate ViewTreeLifecycleOwner!");
            }
            if (fVarC == null) {
                throw new IllegalStateException("Composed into the View which doesn't propagateViewTreeSavedStateRegistryOwner!");
            }
            if (viewTreeOwners != null && (c0578xE = viewTreeOwners.a.e()) != null) {
                c0578xE.f(this);
            }
            interfaceC0576vG.e().a(this);
            C1875l c1875l = new C1875l(interfaceC0576vG, fVarC);
            set_viewTreeOwners(c1875l);
            T3.c cVar = this.f14185h0;
            if (cVar != null) {
                cVar.invoke(c1875l);
            }
            this.f14185h0 = null;
        }
        int i5 = isInTouchMode() ? 1 : 2;
        C1241c c1241c = this.f14207u0;
        c1241c.getClass();
        c1241c.a.setValue(new C1239a(i5));
        C1875l viewTreeOwners2 = getViewTreeOwners();
        C0578x c0578xE2 = viewTreeOwners2 != null ? viewTreeOwners2.a.e() : null;
        if (c0578xE2 == null) {
            AbstractC1393s.b0("No lifecycle owner exists");
            throw null;
        }
        c0578xE2.a(this);
        c0578xE2.a(this.f14213y);
        getViewTreeObserver().addOnGlobalLayoutListener(this.f14186i0);
        getViewTreeObserver().addOnScrollChangedListener(this.f14187j0);
        getViewTreeObserver().addOnTouchModeChangeListener(this.f14188k0);
        if (Build.VERSION.SDK_INT >= 31) {
            C1843H.a.b(this);
        }
    }

    @Override // android.view.View
    public final boolean onCheckIsTextEditor() {
        U.s sVar = (U.s) this.f14194n0.get();
        C1852Q c1852q = (C1852Q) (sVar != null ? sVar.f6140b : null);
        if (c1852q == null) {
            return this.f14190l0.f3808d;
        }
        U.s sVar2 = (U.s) c1852q.f13978o.get();
        C1886q0 c1886q0 = (C1886q0) (sVar2 != null ? sVar2.f6140b : null);
        return c1886q0 != null && (c1886q0.f14143e ^ true);
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        setDensity(W3.a.c(getContext()));
        int i5 = Build.VERSION.SDK_INT;
        if ((i5 >= 31 ? configuration.fontWeightAdjustment : 0) != this.f14201r0) {
            this.f14201r0 = i5 >= 31 ? configuration.fontWeightAdjustment : 0;
            setFontFamilyResolver(E4.d.C(getContext()));
        }
        this.f14160H.invoke(configuration);
    }

    @Override // android.view.View
    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        int i5 = 7;
        int i6 = 4;
        U.s sVar = (U.s) this.f14194n0.get();
        InputConnection rVar = null;
        C1852Q c1852q = (C1852Q) (sVar != null ? sVar.f6140b : null);
        if (c1852q != null) {
            U.s sVar2 = (U.s) c1852q.f13978o.get();
            C1886q0 c1886q0 = (C1886q0) (sVar2 != null ? sVar2.f6140b : null);
            if (c1886q0 != null) {
                synchronized (c1886q0.f14141c) {
                    if (!c1886q0.f14143e) {
                        InputConnectionC2062B inputConnectionC2062BA = c1886q0.a.a(editorInfo);
                        C1794a c1794a = new C1794a(i6, c1886q0);
                        int i7 = Build.VERSION.SDK_INT;
                        rVar = i7 >= 34 ? new I0.r(inputConnectionC2062BA, c1794a) : i7 >= 25 ? new I0.q(inputConnectionC2062BA, c1794a) : new I0.p(inputConnectionC2062BA, c1794a);
                        c1886q0.f14142d.b(new WeakReference(rVar));
                    }
                }
            }
            return rVar;
        }
        I0.D d3 = this.f14190l0;
        if (!d3.f3808d) {
            return null;
        }
        I0.m mVar = d3.f3812h;
        I0.A a = d3.f3811g;
        int i8 = mVar.f3858e;
        boolean zA = I0.l.a(i8, 1);
        boolean z3 = mVar.a;
        int i9 = 0;
        if (zA) {
            if (z3) {
                i9 = 6;
            }
        } else if (I0.l.a(i8, 0)) {
            i9 = 1;
        } else if (I0.l.a(i8, 2)) {
            i9 = 2;
        } else if (I0.l.a(i8, 6)) {
            i9 = 5;
        } else if (I0.l.a(i8, 5)) {
            i9 = 7;
        } else if (I0.l.a(i8, 3)) {
            i9 = 3;
        } else if (I0.l.a(i8, 4)) {
            i9 = 4;
        } else {
            if (!I0.l.a(i8, 7)) {
                throw new IllegalStateException("invalid ImeAction");
            }
            i9 = 6;
        }
        editorInfo.imeOptions = i9;
        int i10 = mVar.f3857d;
        if (I0.o.a(i10, 1)) {
            editorInfo.inputType = 1;
        } else if (I0.o.a(i10, 2)) {
            editorInfo.inputType = 1;
            editorInfo.imeOptions |= Integer.MIN_VALUE;
        } else if (I0.o.a(i10, 3)) {
            editorInfo.inputType = 2;
        } else if (I0.o.a(i10, 4)) {
            editorInfo.inputType = 3;
        } else if (I0.o.a(i10, 5)) {
            editorInfo.inputType = 17;
        } else if (I0.o.a(i10, 6)) {
            editorInfo.inputType = 33;
        } else if (I0.o.a(i10, 7)) {
            editorInfo.inputType = 129;
        } else if (I0.o.a(i10, 8)) {
            editorInfo.inputType = 18;
        } else {
            if (!I0.o.a(i10, 9)) {
                throw new IllegalStateException("Invalid Keyboard Type");
            }
            editorInfo.inputType = 8194;
        }
        if (!z3) {
            int i11 = editorInfo.inputType;
            if ((i11 & 1) == 1) {
                editorInfo.inputType = i11 | 131072;
                if (I0.l.a(mVar.f3858e, 1)) {
                    editorInfo.imeOptions |= 1073741824;
                }
            }
        }
        if ((editorInfo.inputType & 1) == 1) {
            int i12 = mVar.f3855b;
            if (I0.n.a(i12, 1)) {
                editorInfo.inputType |= 4096;
            } else if (I0.n.a(i12, 2)) {
                editorInfo.inputType |= 8192;
            } else if (I0.n.a(i12, 3)) {
                editorInfo.inputType |= 16384;
            }
            if (mVar.f3856c) {
                editorInfo.inputType |= 32768;
            }
        }
        long j5 = a.f3798b;
        int i13 = C0.K.f756c;
        editorInfo.initialSelStart = (int) (j5 >> 32);
        editorInfo.initialSelEnd = (int) (j5 & 4294967295L);
        l0.c.r0(editorInfo, a.a.a);
        editorInfo.imeOptions |= 33554432;
        if (C1384j.c()) {
            C1384j.a().f(editorInfo);
        }
        I0.w wVar = new I0.w(d3.f3811g, new C3.c(i5, d3), d3.f3812h.f3856c);
        d3.f3813i.add(new WeakReference(wVar));
        return wVar;
    }

    @Override // android.view.View
    public final void onCreateVirtualViewTranslationRequests(long[] jArr, int[] iArr, Consumer consumer) {
        W.c cVar = this.f14213y;
        cVar.getClass();
        W.a.a.b(cVar, jArr, iArr, consumer);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        V.a aVar;
        super.onDetachedFromWindow();
        S.w wVar = getSnapshotObserver().a;
        S.h hVar = wVar.f5971g;
        if (hVar != null) {
            hVar.a();
        }
        wVar.b();
        C1875l viewTreeOwners = getViewTreeOwners();
        C0578x c0578xE = viewTreeOwners != null ? viewTreeOwners.a.e() : null;
        if (c0578xE == null) {
            AbstractC1393s.b0("No lifecycle owner exists");
            throw null;
        }
        c0578xE.f(this.f14213y);
        c0578xE.f(this);
        if (g() && (aVar = this.f14162I) != null) {
            V.f.a.b(aVar);
        }
        getViewTreeObserver().removeOnGlobalLayoutListener(this.f14186i0);
        getViewTreeObserver().removeOnScrollChangedListener(this.f14187j0);
        getViewTreeObserver().removeOnTouchModeChangeListener(this.f14188k0);
        if (Build.VERSION.SDK_INT >= 31) {
            C1843H.a.a(this);
        }
    }

    @Override // android.view.View
    public final void onFocusChanged(boolean z3, int i5, Rect rect) {
        super.onFocusChanged(z3, i5, rect);
        if (z3 || hasFocus()) {
            return;
        }
        androidx.compose.ui.focus.b bVar = (androidx.compose.ui.focus.b) getFocusOwner();
        A.T t5 = bVar.f7479h;
        boolean z5 = t5.f46b;
        Z.r rVar = bVar.f7477f;
        if (z5) {
            Z.d.e(rVar, true, true);
            return;
        }
        try {
            t5.f46b = true;
            Z.d.e(rVar, true, true);
        } finally {
            A.T.b(t5);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i5, int i6, int i7, int i8) {
        this.f14172R.j(this.f14155E0);
        this.f14170P = null;
        I();
        if (this.f14168N != null) {
            getAndroidViewsHandler$ui_release().layout(0, 0, i7 - i5, i8 - i6);
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i5, int i6) {
        t0.S s3 = this.f14172R;
        Trace.beginSection("AndroidOwner:onMeasure");
        try {
            if (!isAttachedToWindow()) {
                n(getRoot());
            }
            long jI = i(i5);
            int i7 = (int) (jI >>> 32);
            int i8 = (int) (jI & 4294967295L);
            long jI2 = i(i6);
            int i9 = (int) (4294967295L & jI2);
            int iMin = Math.min((int) (jI2 >>> 32), 262142);
            int iMin2 = Integer.MAX_VALUE;
            int iMin3 = i9 == Integer.MAX_VALUE ? Integer.MAX_VALUE : Math.min(i9, 262142);
            int iP = X2.g.p(iMin3 == Integer.MAX_VALUE ? iMin : iMin3);
            if (i8 != Integer.MAX_VALUE) {
                iMin2 = Math.min(iP, i8);
            }
            long jD = X2.g.d(Math.min(iP, i7), iMin2, iMin, iMin3);
            O0.a aVar = this.f14170P;
            if (aVar == null) {
                this.f14170P = new O0.a(jD);
                this.f14171Q = false;
            } else if (!O0.a.b(aVar.a, jD)) {
                this.f14171Q = true;
            }
            s3.q(jD);
            s3.l();
            setMeasuredDimension(getRoot().f13437H.f13528r.f12944l, getRoot().f13437H.f13528r.f12945m);
            if (this.f14168N != null) {
                getAndroidViewsHandler$ui_release().measure(View.MeasureSpec.makeMeasureSpec(getRoot().f13437H.f13528r.f12944l, 1073741824), View.MeasureSpec.makeMeasureSpec(getRoot().f13437H.f13528r.f12945m, 1073741824));
            }
            Trace.endSection();
        } catch (Throwable th) {
            Trace.endSection();
            throw th;
        }
    }

    @Override // android.view.View
    public final void onProvideAutofillVirtualStructure(ViewStructure viewStructure, int i5) {
        V.a aVar;
        if (!g() || viewStructure == null || (aVar = this.f14162I) == null) {
            return;
        }
        V.c cVar = V.c.a;
        V.g gVar = aVar.f6193b;
        int iA = cVar.a(viewStructure, gVar.a.size());
        for (Map.Entry entry : gVar.a.entrySet()) {
            int iIntValue = ((Number) entry.getKey()).intValue();
            if (entry.getValue() != null) {
                throw new ClassCastException();
            }
            ViewStructure viewStructureB = cVar.b(viewStructure, iA);
            if (viewStructureB != null) {
                V.e eVar = V.e.a;
                AutofillId autofillIdA = eVar.a(viewStructure);
                U3.j.c(autofillIdA);
                eVar.g(viewStructureB, autofillIdA, iIntValue);
                cVar.d(viewStructureB, iIntValue, aVar.a.getContext().getPackageName(), null, null);
                eVar.h(viewStructureB, 1);
                throw null;
            }
            iA++;
        }
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i5) {
        if (this.f14191m) {
            O0.k kVar = O0.k.f5351l;
            O0.k kVar2 = i5 != 0 ? i5 != 1 ? null : O0.k.f5352m : kVar;
            if (kVar2 != null) {
                kVar = kVar2;
            }
            setLayoutDirection(kVar);
        }
    }

    @Override // android.view.View
    public final void onScrollCaptureSearch(Rect rect, Point point, Consumer consumer) {
        z0.j jVar;
        if (Build.VERSION.SDK_INT < 31 || (jVar = this.f14161H0) == null) {
            return;
        }
        jVar.a(this, getSemanticsOwner(), getCoroutineContext(), consumer);
    }

    @Override // android.view.View
    public final void onVirtualViewTranslationResponses(LongSparseArray longSparseArray) {
        W.c cVar = this.f14213y;
        cVar.getClass();
        W.a.a.c(cVar, longSparseArray);
    }

    @Override // android.view.View
    public final void onWindowFocusChanged(boolean z3) {
        boolean zA;
        this.f14202s.a.setValue(Boolean.valueOf(z3));
        this.f14159G0 = true;
        super.onWindowFocusChanged(z3);
        if (!z3 || getShowLayoutBounds() == (zA = C1884p0.a())) {
            return;
        }
        setShowLayoutBounds(zA);
        m(getRoot());
    }

    public final boolean p(MotionEvent motionEvent) {
        float x5 = motionEvent.getX();
        float y5 = motionEvent.getY();
        return 0.0f <= x5 && x5 <= ((float) getWidth()) && 0.0f <= y5 && y5 <= ((float) getHeight());
    }

    public final boolean q(MotionEvent motionEvent) {
        MotionEvent motionEvent2;
        return (motionEvent.getPointerCount() == 1 && (motionEvent2 = this.f14212x0) != null && motionEvent2.getPointerCount() == motionEvent.getPointerCount() && motionEvent.getRawX() == motionEvent2.getRawX() && motionEvent.getRawY() == motionEvent2.getRawY()) ? false : true;
    }

    public final long r(long j5) {
        B();
        long jB = b0.H.b(j5, this.f14177W);
        return X2.g.l(C0492c.d(this.f14181d0) + C0492c.d(jB), C0492c.e(this.f14181d0) + C0492c.e(jB));
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean requestFocus(int i5, Rect rect) {
        if (isFocused()) {
            return true;
        }
        int iOrdinal = ((androidx.compose.ui.focus.b) getFocusOwner()).f7477f.B0().ordinal();
        if (iOrdinal == 0 || iOrdinal == 1 || iOrdinal == 2) {
            return super.requestFocus(i5, rect);
        }
        if (iOrdinal != 3) {
            throw new G3.f();
        }
        Z.b bVarK = Z.d.K(i5);
        int i6 = bVarK != null ? bVarK.a : 7;
        Boolean boolC = ((androidx.compose.ui.focus.b) getFocusOwner()).c(i6, rect != null ? new C0493d(rect.left, rect.top, rect.right, rect.bottom) : null, new H3.u(i6, 2));
        if (boolC != null) {
            return boolC.booleanValue();
        }
        return false;
    }

    public final void s(boolean z3) {
        C1885q c1885q;
        t0.S s3 = this.f14172R;
        if (s3.f13550b.p() || ((K.d) s3.f13553e.f15535m).n()) {
            Trace.beginSection("AndroidOwner:measureAndLayout");
            if (z3) {
                try {
                    c1885q = this.f14155E0;
                } catch (Throwable th) {
                    Trace.endSection();
                    throw th;
                }
            } else {
                c1885q = null;
            }
            if (s3.j(c1885q)) {
                requestLayout();
            }
            s3.a(false);
            Trace.endSection();
        }
    }

    public void setAccessibilityEventBatchIntervalMillis(long j5) {
        this.f14211x.f13897h = j5;
    }

    public final void setConfigurationChangeObserver(T3.c cVar) {
        this.f14160H = cVar;
    }

    public final void setContentCaptureManager$ui_release(W.c cVar) {
        this.f14213y = cVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v5 */
    /* JADX WARN: Type inference failed for: r7v11 */
    /* JADX WARN: Type inference failed for: r7v12, types: [U.p] */
    /* JADX WARN: Type inference failed for: r7v13, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r7v14 */
    /* JADX WARN: Type inference failed for: r7v15 */
    /* JADX WARN: Type inference failed for: r7v16 */
    /* JADX WARN: Type inference failed for: r7v17 */
    /* JADX WARN: Type inference failed for: r7v18 */
    /* JADX WARN: Type inference failed for: r7v19 */
    /* JADX WARN: Type inference failed for: r7v7 */
    /* JADX WARN: Type inference failed for: r7v8, types: [U.p] */
    /* JADX WARN: Type inference failed for: r9v0 */
    /* JADX WARN: Type inference failed for: r9v1 */
    /* JADX WARN: Type inference failed for: r9v10 */
    /* JADX WARN: Type inference failed for: r9v11 */
    /* JADX WARN: Type inference failed for: r9v2 */
    /* JADX WARN: Type inference failed for: r9v3, types: [K.d] */
    /* JADX WARN: Type inference failed for: r9v4 */
    /* JADX WARN: Type inference failed for: r9v5 */
    /* JADX WARN: Type inference failed for: r9v6, types: [K.d] */
    /* JADX WARN: Type inference failed for: r9v8 */
    /* JADX WARN: Type inference failed for: r9v9 */
    public void setCoroutineContext(K3.h hVar) {
        int i5;
        int i6;
        this.f14199q = hVar;
        U.p pVar = (U.p) getRoot().f13436G.f3714f;
        if (pVar instanceof C1434C) {
            ((C1434C) pVar).C0();
        }
        U.p pVar2 = pVar.f6127l;
        if (!pVar2.f6139x) {
            AbstractC1393s.a0("visitSubtree called on an unattached node");
            throw null;
        }
        U.p pVar3 = pVar2.f6132q;
        t0.E eV = AbstractC1800g.v(pVar);
        int[] iArrCopyOf = new int[16];
        K.d[] dVarArr = new K.d[16];
        int i7 = 0;
        while (eV != null) {
            if (pVar3 == null) {
                pVar3 = (U.p) eV.f13436G.f3714f;
            }
            if ((pVar3.f6130o & 16) != 0) {
                while (pVar3 != null) {
                    if ((pVar3.f6129n & 16) != 0) {
                        ?? F5 = pVar3;
                        ?? dVar = 0;
                        while (F5 != 0) {
                            if (F5 instanceof t0.l0) {
                                t0.l0 l0Var = (t0.l0) F5;
                                if (l0Var instanceof C1434C) {
                                    ((C1434C) l0Var).C0();
                                }
                            } else if ((F5.f6129n & 16) != 0 && (F5 instanceof AbstractC1808o)) {
                                U.p pVar4 = ((AbstractC1808o) F5).f13651z;
                                int i8 = 0;
                                F5 = F5;
                                dVar = dVar;
                                while (pVar4 != null) {
                                    if ((pVar4.f6129n & 16) != 0) {
                                        i8++;
                                        dVar = dVar;
                                        if (i8 == 1) {
                                            F5 = pVar4;
                                        } else {
                                            if (dVar == 0) {
                                                dVar = new K.d(new U.p[16]);
                                            }
                                            if (F5 != 0) {
                                                dVar.b(F5);
                                                F5 = 0;
                                            }
                                            dVar.b(pVar4);
                                        }
                                    }
                                    pVar4 = pVar4.f6132q;
                                    F5 = F5;
                                    dVar = dVar;
                                }
                                if (i8 == 1) {
                                }
                            }
                            F5 = AbstractC1800g.f(dVar);
                        }
                    }
                    pVar3 = pVar3.f6132q;
                }
            }
            K.d dVarV = eV.v();
            if (!dVarV.m()) {
                if (i7 >= iArrCopyOf.length) {
                    iArrCopyOf = Arrays.copyOf(iArrCopyOf, iArrCopyOf.length * 2);
                    U3.j.e(iArrCopyOf, "copyOf(this, newSize)");
                    Object[] objArrCopyOf = Arrays.copyOf(dVarArr, dVarArr.length * 2);
                    U3.j.e(objArrCopyOf, "copyOf(this, newSize)");
                    dVarArr = (K.d[]) objArrCopyOf;
                }
                iArrCopyOf[i7] = dVarV.f4405n - 1;
                dVarArr[i7] = dVarV;
                i7++;
            }
            if (i7 <= 0 || (i6 = iArrCopyOf[i7 - 1]) < 0) {
                eV = null;
            } else {
                if (i7 <= 0) {
                    throw new IllegalStateException("Cannot call pop() on an empty stack. Guard with a call to isNotEmpty()");
                }
                K.d dVar2 = dVarArr[i5];
                U3.j.c(dVar2);
                if (i6 > 0) {
                    iArrCopyOf[i5] = iArrCopyOf[i5] - 1;
                } else if (i6 == 0) {
                    dVarArr[i5] = null;
                    i7--;
                }
                eV = (t0.E) dVar2.f4403l[i6];
            }
            pVar3 = null;
        }
    }

    public final void setLastMatrixRecalculationAnimationTime$ui_release(long j5) {
        this.f14179b0 = j5;
    }

    public final void setOnViewTreeOwnersAvailable(T3.c cVar) {
        C1875l viewTreeOwners = getViewTreeOwners();
        if (viewTreeOwners != null) {
            cVar.invoke(viewTreeOwners);
        }
        if (isAttachedToWindow()) {
            return;
        }
        this.f14185h0 = cVar;
    }

    public void setShowLayoutBounds(boolean z3) {
        this.f14167M = z3;
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public final void t(t0.E e5, long j5) {
        t0.S s3 = this.f14172R;
        Trace.beginSection("AndroidOwner:measureAndLayout");
        try {
            s3.k(e5, j5);
            if (!s3.f13550b.p()) {
                s3.a(false);
            }
        } finally {
            Trace.endSection();
        }
    }

    public final void u(t0.f0 f0Var, boolean z3) {
        ArrayList arrayList = this.C;
        if (!z3) {
            if (this.f14154E) {
                return;
            }
            arrayList.remove(f0Var);
            ArrayList arrayList2 = this.D;
            if (arrayList2 != null) {
                arrayList2.remove(f0Var);
                return;
            }
            return;
        }
        if (!this.f14154E) {
            arrayList.add(f0Var);
            return;
        }
        ArrayList arrayList3 = this.D;
        if (arrayList3 == null) {
            arrayList3 = new ArrayList();
            this.D = arrayList3;
        }
        arrayList3.add(f0Var);
    }

    public final void v() {
        if (this.f14164J) {
            S.w wVar = getSnapshotObserver().a;
            synchronized (wVar.f5970f) {
                try {
                    K.d dVar = wVar.f5970f;
                    int i5 = dVar.f4405n;
                    int i6 = 0;
                    for (int i7 = 0; i7 < i5; i7++) {
                        S.v vVar = (S.v) dVar.f4403l[i7];
                        vVar.e();
                        if (!(vVar.f5959f.f10405e != 0)) {
                            i6++;
                        } else if (i6 > 0) {
                            Object[] objArr = dVar.f4403l;
                            objArr[i7 - i6] = objArr[i7];
                        }
                    }
                    int i8 = i5 - i6;
                    Arrays.fill(dVar.f4403l, i8, i5, (Object) null);
                    dVar.f4405n = i8;
                } catch (Throwable th) {
                    throw th;
                }
            }
            this.f14164J = false;
        }
        Z z3 = this.f14168N;
        if (z3 != null) {
            h(z3);
        }
        while (this.f14150A0.n()) {
            int i9 = this.f14150A0.f4405n;
            for (int i10 = 0; i10 < i9; i10++) {
                Object[] objArr2 = this.f14150A0.f4403l;
                T3.a aVar = (T3.a) objArr2[i10];
                objArr2[i10] = null;
                if (aVar != null) {
                    aVar.b();
                }
            }
            this.f14150A0.q(0, i9);
        }
    }

    public final C0493d w() {
        if (isFocused()) {
            Z.r rVarG = Z.d.g(((androidx.compose.ui.focus.b) getFocusOwner()).f7477f);
            if (rVarG != null) {
                return Z.d.j(rVarG);
            }
            return null;
        }
        View viewFindFocus = findFocus();
        if (viewFindFocus != null) {
            return Z.d.d(viewFindFocus);
        }
        return null;
    }

    public final void x(t0.E e5) {
        C1839D c1839d = this.f14211x;
        c1839d.f13914y = true;
        if (c1839d.q()) {
            c1839d.s(e5);
        }
        W.c cVar = this.f14213y;
        cVar.f6794s = true;
        if (cVar.e() && cVar.f6795t.add(e5)) {
            cVar.f6796u.n(G3.C.a);
        }
    }

    public final void y(t0.E e5, boolean z3, boolean z5, boolean z6) {
        t0.E eS;
        t0.E eS2;
        t0.J j5;
        t0.F f5;
        t0.S s3 = this.f14172R;
        if (!z3) {
            if (s3.p(e5, z5) && z6) {
                D(e5);
                return;
            }
            return;
        }
        s3.getClass();
        if (e5.f13449n == null) {
            AbstractC1393s.a0("Error: requestLookaheadRemeasure cannot be called on a node outside LookaheadScope");
            throw null;
        }
        t0.L l4 = e5.f13437H;
        int iC = AbstractC1297i.c(l4.f13513c);
        if (iC != 0) {
            if (iC == 1) {
                return;
            }
            if (iC != 2 && iC != 3) {
                if (iC != 4) {
                    throw new G3.f();
                }
                if (!l4.f13517g || z5) {
                    l4.f13517g = true;
                    l4.f13514d = true;
                    if (e5.f13444O) {
                        return;
                    }
                    boolean zA = U3.j.a(e5.F(), Boolean.TRUE);
                    K1 k12 = s3.f13550b;
                    if ((zA || (l4.f13517g && (e5.q() == 1 || !((j5 = l4.f13529s) == null || (f5 = j5.f13474A) == null || !f5.e())))) && ((eS = e5.s()) == null || !eS.f13437H.f13517g)) {
                        k12.h(e5, true);
                    } else if ((e5.E() || t0.S.h(e5)) && ((eS2 = e5.s()) == null || !eS2.f13437H.f13514d)) {
                        k12.h(e5, false);
                    }
                    if (s3.f13552d || !z6) {
                        return;
                    }
                    D(e5);
                    return;
                }
                return;
            }
        }
        s3.f13556h.b(new t0.Q(e5, true, z5));
    }

    public final void z(t0.E e5, boolean z3, boolean z5) {
        t0.S s3 = this.f14172R;
        if (!z3) {
            s3.getClass();
            int iC = AbstractC1297i.c(e5.f13437H.f13513c);
            if (iC == 0 || iC == 1 || iC == 2 || iC == 3) {
                return;
            }
            if (iC != 4) {
                throw new G3.f();
            }
            t0.L l4 = e5.f13437H;
            if (!z5 && e5.E() == l4.f13528r.C && (l4.f13514d || l4.f13515e)) {
                return;
            }
            l4.f13515e = true;
            l4.f13516f = true;
            if (!e5.f13444O && l4.f13528r.C) {
                t0.E eS = e5.s();
                if ((eS == null || !eS.f13437H.f13515e) && (eS == null || !eS.f13437H.f13514d)) {
                    s3.f13550b.h(e5, false);
                }
                if (s3.f13552d) {
                    return;
                }
                D(null);
                return;
            }
            return;
        }
        s3.getClass();
        int iC2 = AbstractC1297i.c(e5.f13437H.f13513c);
        if (iC2 != 0) {
            if (iC2 == 1) {
                return;
            }
            if (iC2 != 2) {
                if (iC2 == 3) {
                    return;
                }
                if (iC2 != 4) {
                    throw new G3.f();
                }
            }
        }
        t0.L l5 = e5.f13437H;
        if ((l5.f13517g || l5.f13518h) && !z5) {
            return;
        }
        l5.f13518h = true;
        l5.f13519i = true;
        l5.f13515e = true;
        l5.f13516f = true;
        if (e5.f13444O) {
            return;
        }
        t0.E eS2 = e5.s();
        boolean zA = U3.j.a(e5.F(), Boolean.TRUE);
        K1 k12 = s3.f13550b;
        if (zA && ((eS2 == null || !eS2.f13437H.f13517g) && (eS2 == null || !eS2.f13437H.f13518h))) {
            k12.h(e5, true);
        } else if (e5.E() && ((eS2 == null || !eS2.f13437H.f13515e) && (eS2 == null || !eS2.f13437H.f13514d))) {
            k12.h(e5, false);
        }
        if (s3.f13552d) {
            return;
        }
        D(null);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i5) {
        U3.j.c(view);
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            layoutParams = generateDefaultLayoutParams();
        }
        addViewInLayout(view, i5, layoutParams, true);
    }

    public C1865g getAccessibilityManager() {
        return this.f14215z;
    }

    public C1867h getClipboardManager() {
        return this.f14165K;
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i5, int i6) {
        ViewGroup.LayoutParams layoutParamsGenerateDefaultLayoutParams = generateDefaultLayoutParams();
        layoutParamsGenerateDefaultLayoutParams.width = i5;
        layoutParamsGenerateDefaultLayoutParams.height = i6;
        addViewInLayout(view, -1, layoutParamsGenerateDefaultLayoutParams, true);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i5, ViewGroup.LayoutParams layoutParams) {
        addViewInLayout(view, i5, layoutParams, true);
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        addViewInLayout(view, -1, layoutParams, true);
    }

    @InterfaceC0166c
    public static /* synthetic */ void getFontLoader$annotations() {
    }

    public static /* synthetic */ void getLastMatrixRecalculationAnimationTime$ui_release$annotations() {
    }

    public static /* synthetic */ void getShowLayoutBounds$annotations() {
    }

    public View getView() {
        return this;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
    }
}

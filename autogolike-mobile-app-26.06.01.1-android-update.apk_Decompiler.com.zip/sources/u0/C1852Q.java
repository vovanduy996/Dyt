package u0;

import android.view.View;
import f4.InterfaceC0991y;
import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: renamed from: u0.Q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1852Q implements InterfaceC0991y {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final View f13975l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final I0.B f13976m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final InterfaceC0991y f13977n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final AtomicReference f13978o = new AtomicReference(null);

    public C1852Q(View view, I0.B b3, InterfaceC0991y interfaceC0991y) {
        this.f13975l = view;
        this.f13976m = b3;
        this.f13977n = interfaceC0991y;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void a(y.z r6, M3.c r7) {
        /*
            r5 = this;
            boolean r0 = r7 instanceof u0.C1850O
            if (r0 == 0) goto L13
            r0 = r7
            u0.O r0 = (u0.C1850O) r0
            int r1 = r0.f13971q
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f13971q = r1
            goto L18
        L13:
            u0.O r0 = new u0.O
            r0.<init>(r5, r7)
        L18:
            java.lang.Object r7 = r0.f13969o
            L3.a r1 = L3.a.f4629l
            int r2 = r0.f13971q
            r3 = 1
            if (r2 == 0) goto L2f
            if (r2 == r3) goto L2b
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r7)
            throw r6
        L2b:
            G3.AbstractC0164a.e(r7)
            goto L4f
        L2f:
            G3.AbstractC0164a.e(r7)
            java.util.concurrent.atomic.AtomicReference r7 = r5.f13978o
            m.t r2 = new m.t
            r4 = 13
            r2.<init>(r6, r4, r5)
            u0.P r6 = new u0.P
            r4 = 0
            r6.<init>(r5, r4)
            r0.f13971q = r3
            U.t r3 = new U.t
            r3.<init>(r2, r7, r6, r4)
            java.lang.Object r6 = f4.AbstractC0952A.f(r3, r0)
            if (r6 != r1) goto L4f
            return
        L4f:
            G3.f r6 = new G3.f
            r6.<init>()
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.C1852Q.a(y.z, M3.c):void");
    }

    @Override // f4.InterfaceC0991y
    public final K3.h w() {
        return this.f13977n.w();
    }
}

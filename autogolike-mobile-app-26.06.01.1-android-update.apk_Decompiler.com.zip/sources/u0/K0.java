package u0;

import a4.InterfaceC0523e;

/* JADX INFO: loaded from: classes.dex */
public final class K0 extends U.p implements t0.n0 {

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public String f13938y;

    @Override // t0.n0
    public final void j(A0.i iVar) {
        String str = this.f13938y;
        InterfaceC0523e[] interfaceC0523eArr = A0.t.a;
        A0.u uVar = A0.r.f277t;
        InterfaceC0523e interfaceC0523e = A0.t.a[13];
        uVar.getClass();
        iVar.e(uVar, str);
    }
}

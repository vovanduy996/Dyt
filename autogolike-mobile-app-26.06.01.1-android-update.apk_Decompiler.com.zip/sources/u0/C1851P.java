package u0;

import G3.AbstractC0164a;
import f.C0933a;
import f4.C0978k;
import kotlin.coroutines.Continuation;
import m.C1366t;

/* JADX INFO: renamed from: u0.P, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1851P extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f13972p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f13973q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ C1852Q f13974r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1851P(C1852Q c1852q, Continuation continuation) {
        super(2, continuation);
        this.f13974r = c1852q;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        ((C1851P) m((C1886q0) obj, (Continuation) obj2)).o(G3.C.a);
        return L3.a.f4629l;
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C1851P c1851p = new C1851P(this.f13974r, continuation);
        c1851p.f13973q = obj;
        return c1851p;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f13972p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            C1886q0 c1886q0 = (C1886q0) this.f13973q;
            this.f13973q = c1886q0;
            C1852Q c1852q = this.f13974r;
            this.f13972p = 1;
            C0978k c0978k = new C0978k(1, C0933a.X(this));
            c0978k.u();
            I0.B b3 = c1852q.f13976m;
            I0.v vVar = b3.a;
            vVar.g();
            b3.f3800b.set(new I0.F(b3, vVar));
            c0978k.x(new C1366t(c1886q0, 14, c1852q));
            if (c0978k.s() == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        throw new G3.f();
    }
}

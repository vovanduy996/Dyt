package u0;

/* JADX INFO: renamed from: u0.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1861e extends AbstractC1855b {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static C1861e f14053c;

    @Override // u0.AbstractC1855b
    public final int[] a(int i5) {
        int length = c().length();
        if (length <= 0 || i5 >= length) {
            return null;
        }
        if (i5 < 0) {
            i5 = 0;
        }
        while (i5 < length && c().charAt(i5) == '\n' && !f(i5)) {
            i5++;
        }
        if (i5 >= length) {
            return null;
        }
        int i6 = i5 + 1;
        while (i6 < length && !e(i6)) {
            i6++;
        }
        return b(i5, i6);
    }

    @Override // u0.AbstractC1855b
    public final int[] d(int i5) {
        int length = c().length();
        if (length <= 0 || i5 <= 0) {
            return null;
        }
        if (i5 > length) {
            i5 = length;
        }
        while (i5 > 0 && c().charAt(i5 - 1) == '\n' && !e(i5)) {
            i5--;
        }
        if (i5 <= 0) {
            return null;
        }
        int i6 = i5 - 1;
        while (i6 > 0 && !f(i6)) {
            i6--;
        }
        return b(i6, i5);
    }

    public final boolean e(int i5) {
        return i5 > 0 && c().charAt(i5 + (-1)) != '\n' && (i5 == c().length() || c().charAt(i5) == '\n');
    }

    public final boolean f(int i5) {
        return c().charAt(i5) != '\n' && (i5 == 0 || c().charAt(i5 - 1) == '\n');
    }
}

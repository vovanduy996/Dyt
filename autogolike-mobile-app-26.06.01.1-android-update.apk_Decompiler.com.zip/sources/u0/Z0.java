package u0;

import I.C0278z0;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class Z0 implements View.OnAttachStateChangeListener {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ View f14018l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ C0278z0 f14019m;

    public Z0(View view, C0278z0 c0278z0) {
        this.f14018l = view;
        this.f14019m = c0278z0;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
        this.f14018l.removeOnAttachStateChangeListener(this);
        this.f14019m.s();
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
    }
}

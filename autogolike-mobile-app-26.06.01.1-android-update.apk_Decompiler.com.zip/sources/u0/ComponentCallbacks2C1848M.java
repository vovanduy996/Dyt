package u0;

import android.content.ComponentCallbacks2;
import android.content.res.Configuration;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.Map;
import y0.C2073a;
import y0.C2075c;

/* JADX INFO: renamed from: u0.M, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class ComponentCallbacks2C1848M implements ComponentCallbacks2 {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ Configuration f13966l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ C2075c f13967m;

    public ComponentCallbacks2C1848M(Configuration configuration, C2075c c2075c) {
        this.f13966l = configuration;
        this.f13967m = c2075c;
    }

    @Override // android.content.ComponentCallbacks
    public final void onConfigurationChanged(Configuration configuration) {
        Configuration configuration2 = this.f13966l;
        int iUpdateFrom = configuration2.updateFrom(configuration);
        Iterator it = this.f13967m.a.entrySet().iterator();
        while (it.hasNext()) {
            C2073a c2073a = (C2073a) ((WeakReference) ((Map.Entry) it.next()).getValue()).get();
            if (c2073a == null || Configuration.needNewResources(iUpdateFrom, c2073a.f15572b)) {
                it.remove();
            }
        }
        configuration2.setTo(configuration);
    }

    @Override // android.content.ComponentCallbacks
    public final void onLowMemory() {
        this.f13967m.a.clear();
    }

    @Override // android.content.ComponentCallbacks2
    public final void onTrimMemory(int i5) {
        this.f13967m.a.clear();
    }
}

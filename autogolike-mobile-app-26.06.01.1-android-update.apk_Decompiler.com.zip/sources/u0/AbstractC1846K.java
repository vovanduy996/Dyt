package u0;

import a0.AbstractC0490a;
import a0.C0491b;
import a0.C0493d;
import a0.C0494e;
import a0.C0495f;
import android.graphics.Rect;
import android.graphics.Region;
import android.os.Binder;
import android.os.Build;
import android.os.Parcelable;
import android.util.Size;
import android.util.SizeF;
import android.util.SparseArray;
import android.view.View;
import b0.C0592j;
import i.AbstractC1108j;
import i.C1116r;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import r0.AbstractC1655U;
import r0.InterfaceC1677q;
import t0.AbstractC1800g;
import t0.InterfaceC1807n;

/* JADX INFO: renamed from: u0.K, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1846K implements N0 {
    public static final Class[] a = {Serializable.class, Parcelable.class, String.class, SparseArray.class, Binder.class, Size.class, SizeF.class};

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final C0493d f13937b = new C0493d(0.0f, 0.0f, 10.0f, 10.0f);

    public static final boolean j(A0.o oVar) {
        A0.i iVarI = oVar.i();
        return !iVarI.f226l.containsKey(A0.r.f266i);
    }

    public static final boolean k(A0.o oVar) {
        return oVar.f236c.C == O0.k.f5352m;
    }

    public static final boolean l(Object obj) {
        if (obj instanceof S.q) {
            S.q qVar = (S.q) obj;
            if (qVar.d() != I.W.f3595n && qVar.d() != I.W.f3598q && qVar.d() != I.W.f3596o) {
                return false;
            }
            Object value = qVar.getValue();
            if (value == null) {
                return true;
            }
            return l(value);
        }
        if ((obj instanceof G3.e) && (obj instanceof Serializable)) {
            return false;
        }
        Class[] clsArr = a;
        for (int i5 = 0; i5 < 7; i5++) {
            if (clsArr[i5].isInstance(obj)) {
                return true;
            }
        }
        return false;
    }

    public static final float m(float[] fArr, int i5, float[] fArr2, int i6) {
        int i7 = i5 * 4;
        return (fArr[i7 + 3] * fArr2[12 + i6]) + (fArr[i7 + 2] * fArr2[8 + i6]) + (fArr[i7 + 1] * fArr2[4 + i6]) + (fArr[i7] * fArr2[i6]);
    }

    public static final C1116r n(A0.p pVar) {
        A0.o oVarA = pVar.a();
        C1116r c1116r = AbstractC1108j.a;
        C1116r c1116r2 = new C1116r();
        t0.E e5 = oVarA.f236c;
        if (e5.E() && e5.D()) {
            C0493d c0493dE = oVarA.e();
            o(new Region(Math.round(c0493dE.a), Math.round(c0493dE.f7216b), Math.round(c0493dE.f7217c), Math.round(c0493dE.f7218d)), oVarA, c1116r2, oVarA, new Region());
        }
        return c1116r2;
    }

    public static final void o(Region region, A0.o oVar, C1116r c1116r, A0.o oVar2, Region region2) {
        t0.E e5;
        InterfaceC1807n interfaceC1807nK;
        boolean zE = oVar2.f236c.E();
        t0.E e6 = oVar2.f236c;
        boolean z3 = (zE && e6.D()) ? false : true;
        boolean zIsEmpty = region.isEmpty();
        int i5 = oVar.f240g;
        int i6 = oVar2.f240g;
        if (!zIsEmpty || i6 == i5) {
            if (!z3 || oVar2.f238e) {
                A0.i iVar = oVar2.f237d;
                boolean z5 = iVar.f227m;
                InterfaceC1807n interfaceC1807n = oVar2.a;
                if (z5 && (interfaceC1807nK = V2.a.K(e6)) != null) {
                    interfaceC1807n = interfaceC1807nK;
                }
                U.p pVar = ((U.p) interfaceC1807n).f6127l;
                Object obj = iVar.f226l.get(A0.h.f201b);
                if (obj == null) {
                    obj = null;
                }
                boolean z6 = obj != null;
                boolean z7 = pVar.f6127l.f6139x;
                C0493d c0493d = C0493d.f7215e;
                if (z7) {
                    if (z6) {
                        t0.a0 a0VarT = AbstractC1800g.t(pVar, 8);
                        if (a0VarT.N0().f6139x) {
                            InterfaceC1677q interfaceC1677qF = AbstractC1655U.f(a0VarT);
                            C0491b c0491b = a0VarT.f13592J;
                            if (c0491b == null) {
                                c0491b = new C0491b();
                                c0491b.a = 0.0f;
                                c0491b.f7212b = 0.0f;
                                c0491b.f7213c = 0.0f;
                                c0491b.f7214d = 0.0f;
                                a0VarT.f13592J = c0491b;
                            }
                            long jD0 = a0VarT.D0(a0VarT.M0());
                            c0491b.a = -C0495f.d(jD0);
                            c0491b.f7212b = -C0495f.b(jD0);
                            c0491b.f7213c = C0495f.d(jD0) + a0VarT.g0();
                            c0491b.f7214d = C0495f.b(jD0) + a0VarT.Z();
                            while (true) {
                                if (a0VarT == interfaceC1677qF) {
                                    c0493d = new C0493d(c0491b.a, c0491b.f7212b, c0491b.f7213c, c0491b.f7214d);
                                    break;
                                }
                                a0VarT.b1(c0491b, false, true);
                                if (c0491b.b()) {
                                    break;
                                }
                                a0VarT = a0VarT.f13600y;
                                U3.j.c(a0VarT);
                            }
                        }
                    } else {
                        t0.a0 a0VarT2 = AbstractC1800g.t(pVar, 8);
                        c0493d = AbstractC1655U.f(a0VarT2).A(a0VarT2, true);
                    }
                }
                int iRound = Math.round(c0493d.a);
                int iRound2 = Math.round(c0493d.f7216b);
                int iRound3 = Math.round(c0493d.f7217c);
                int iRound4 = Math.round(c0493d.f7218d);
                region2.set(iRound, iRound2, iRound3, iRound4);
                if (i6 == i5) {
                    i6 = -1;
                }
                if (!region2.op(region, Region.Op.INTERSECT)) {
                    if (oVar2.f238e) {
                        A0.o oVarJ = oVar2.j();
                        C0493d c0493dE = (oVarJ == null || (e5 = oVarJ.f236c) == null || !e5.E()) ? f13937b : oVarJ.e();
                        c1116r.i(i6, new I0(oVar2, new Rect(Math.round(c0493dE.a), Math.round(c0493dE.f7216b), Math.round(c0493dE.f7217c), Math.round(c0493dE.f7218d))));
                        return;
                    } else {
                        if (i6 == -1) {
                            c1116r.i(i6, new I0(oVar2, region2.getBounds()));
                            return;
                        }
                        return;
                    }
                }
                c1116r.i(i6, new I0(oVar2, region2.getBounds()));
                List listH = A0.o.h(oVar2, true, 4);
                for (int size = listH.size() - 1; -1 < size; size--) {
                    o(region, oVar, c1116r, (A0.o) listH.get(size), region2);
                }
                if (r(oVar2)) {
                    region.op(iRound, iRound2, iRound3, iRound4, Region.Op.DIFFERENCE);
                }
            }
        }
    }

    public static final C0.I p(A0.i iVar) {
        T3.c cVar;
        ArrayList arrayList = new ArrayList();
        Object obj = iVar.f226l.get(A0.h.a);
        if (obj == null) {
            obj = null;
        }
        A0.a aVar = (A0.a) obj;
        if (aVar == null || (cVar = (T3.c) aVar.f191b) == null || !((Boolean) cVar.invoke(arrayList)).booleanValue()) {
            return null;
        }
        return (C0.I) arrayList.get(0);
    }

    public static final boolean q(float[] fArr, float[] fArr2) {
        float f5 = fArr[0];
        float f6 = fArr[1];
        float f7 = fArr[2];
        float f8 = fArr[3];
        float f9 = fArr[4];
        float f10 = fArr[5];
        float f11 = fArr[6];
        float f12 = fArr[7];
        float f13 = fArr[8];
        float f14 = fArr[9];
        float f15 = fArr[10];
        float f16 = fArr[11];
        float f17 = fArr[12];
        float f18 = fArr[13];
        float f19 = fArr[14];
        float f20 = fArr[15];
        float f21 = (f5 * f10) - (f6 * f9);
        float f22 = (f5 * f11) - (f7 * f9);
        float f23 = (f5 * f12) - (f8 * f9);
        float f24 = (f6 * f11) - (f7 * f10);
        float f25 = (f6 * f12) - (f8 * f10);
        float f26 = (f7 * f12) - (f8 * f11);
        float f27 = (f13 * f18) - (f14 * f17);
        float f28 = (f13 * f19) - (f15 * f17);
        float f29 = (f13 * f20) - (f16 * f17);
        float f30 = (f14 * f19) - (f15 * f18);
        float f31 = (f14 * f20) - (f16 * f18);
        float f32 = (f15 * f20) - (f16 * f19);
        float f33 = (f26 * f27) + (((f24 * f29) + ((f23 * f30) + ((f21 * f32) - (f22 * f31)))) - (f25 * f28));
        if (f33 == 0.0f) {
            return false;
        }
        float f34 = 1.0f / f33;
        fArr2[0] = ((f12 * f30) + ((f10 * f32) - (f11 * f31))) * f34;
        fArr2[1] = (((f7 * f31) + ((-f6) * f32)) - (f8 * f30)) * f34;
        fArr2[2] = ((f20 * f24) + ((f18 * f26) - (f19 * f25))) * f34;
        fArr2[3] = (((f15 * f25) + ((-f14) * f26)) - (f16 * f24)) * f34;
        float f35 = -f9;
        fArr2[4] = (((f11 * f29) + (f35 * f32)) - (f12 * f28)) * f34;
        fArr2[5] = ((f8 * f28) + ((f32 * f5) - (f7 * f29))) * f34;
        float f36 = -f17;
        fArr2[6] = (((f19 * f23) + (f36 * f26)) - (f20 * f22)) * f34;
        fArr2[7] = ((f16 * f22) + ((f26 * f13) - (f15 * f23))) * f34;
        fArr2[8] = ((f12 * f27) + ((f9 * f31) - (f10 * f29))) * f34;
        fArr2[9] = (((f29 * f6) + ((-f5) * f31)) - (f8 * f27)) * f34;
        fArr2[10] = ((f20 * f21) + ((f17 * f25) - (f18 * f23))) * f34;
        fArr2[11] = (((f23 * f14) + ((-f13) * f25)) - (f16 * f21)) * f34;
        fArr2[12] = (((f10 * f28) + (f35 * f30)) - (f11 * f27)) * f34;
        fArr2[13] = ((f7 * f27) + ((f5 * f30) - (f6 * f28))) * f34;
        fArr2[14] = (((f18 * f22) + (f36 * f24)) - (f19 * f21)) * f34;
        fArr2[15] = ((f15 * f21) + ((f13 * f24) - (f14 * f22))) * f34;
        return true;
    }

    public static final boolean r(A0.o oVar) {
        A0.i iVar = oVar.f237d;
        if (!iVar.f227m) {
            Set setKeySet = iVar.f226l.keySet();
            if (!(setKeySet instanceof Collection) || !setKeySet.isEmpty()) {
                Iterator it = setKeySet.iterator();
                while (it.hasNext()) {
                    if (((A0.u) it.next()).f285c) {
                    }
                }
            }
            return false;
        }
        return true;
    }

    public static final boolean s(b0.L l4, float f5, float f6, b0.M m5, b0.M m6) {
        boolean zU;
        if (!(l4 instanceof b0.J)) {
            if (!(l4 instanceof b0.K)) {
                if (l4 instanceof b0.I) {
                    return t(((b0.I) l4).a, f5, f6, m5, m6);
                }
                throw new G3.f();
            }
            C0494e c0494e = ((b0.K) l4).a;
            float f7 = c0494e.a;
            if (f5 < f7) {
                return false;
            }
            float f8 = c0494e.f7220c;
            if (f5 >= f8) {
                return false;
            }
            float f9 = c0494e.f7219b;
            if (f6 < f9) {
                return false;
            }
            float f10 = c0494e.f7221d;
            if (f6 >= f10) {
                return false;
            }
            long j5 = c0494e.f7222e;
            float fB = AbstractC0490a.b(j5);
            long j6 = c0494e.f7223f;
            if (AbstractC0490a.b(j6) + fB <= c0494e.b()) {
                long j7 = c0494e.f7225h;
                float fB2 = AbstractC0490a.b(j7);
                long j8 = c0494e.f7224g;
                if (AbstractC0490a.b(j8) + fB2 <= c0494e.b()) {
                    if (AbstractC0490a.c(j7) + AbstractC0490a.c(j5) <= c0494e.a()) {
                        if (AbstractC0490a.c(j8) + AbstractC0490a.c(j6) <= c0494e.a()) {
                            float fB3 = AbstractC0490a.b(j5) + f7;
                            float fC = AbstractC0490a.c(j5) + f9;
                            float fB4 = f8 - AbstractC0490a.b(j6);
                            float fC2 = f9 + AbstractC0490a.c(j6);
                            float fB5 = f8 - AbstractC0490a.b(j8);
                            float fC3 = f10 - AbstractC0490a.c(j8);
                            float fC4 = f10 - AbstractC0490a.c(j7);
                            float fB6 = AbstractC0490a.b(j7) + f7;
                            if (f5 < fB3 && f6 < fC) {
                                zU = u(f5, f6, c0494e.f7222e, fB3, fC);
                            } else if (f5 < fB6 && f6 > fC4) {
                                zU = u(f5, f6, c0494e.f7225h, fB6, fC4);
                            } else if (f5 > fB4 && f6 < fC2) {
                                zU = u(f5, f6, c0494e.f7223f, fB4, fC2);
                            } else if (f5 > fB5 && f6 > fC3) {
                                zU = u(f5, f6, c0494e.f7224g, fB5, fC3);
                            }
                            return zU;
                        }
                    }
                }
            }
            b0.M mH = m6 == null ? b0.N.h() : m6;
            b0.M.a(mH, c0494e);
            return t(mH, f5, f6, m5, m6);
        }
        C0493d c0493d = ((b0.J) l4).a;
        if (c0493d.a > f5 || f5 >= c0493d.f7217c || c0493d.f7216b > f6 || f6 >= c0493d.f7218d) {
            return false;
        }
        return true;
    }

    public static final boolean t(b0.M m5, float f5, float f6, b0.M m6, b0.M m7) {
        C0493d c0493d = new C0493d(f5 - 0.005f, f6 - 0.005f, f5 + 0.005f, f6 + 0.005f);
        if (m6 == null) {
            m6 = b0.N.h();
        }
        b0.M.b(m6, c0493d);
        if (m7 == null) {
            m7 = b0.N.h();
        }
        C0592j c0592j = (C0592j) m7;
        c0592j.d(m5, m6, 1);
        boolean zIsEmpty = c0592j.a.isEmpty();
        c0592j.e();
        ((C0592j) m6).e();
        return !zIsEmpty;
    }

    public static final boolean u(float f5, float f6, long j5, float f7, float f8) {
        float f9 = f5 - f7;
        float f10 = f6 - f8;
        float fB = AbstractC0490a.b(j5);
        float fC = AbstractC0490a.c(j5);
        return ((f10 * f10) / (fC * fC)) + ((f9 * f9) / (fB * fB)) <= 1.0f;
    }

    public static final void v(float[] fArr, float[] fArr2) {
        float fM = m(fArr2, 0, fArr, 0);
        float fM2 = m(fArr2, 0, fArr, 1);
        float fM3 = m(fArr2, 0, fArr, 2);
        float fM4 = m(fArr2, 0, fArr, 3);
        float fM5 = m(fArr2, 1, fArr, 0);
        float fM6 = m(fArr2, 1, fArr, 1);
        float fM7 = m(fArr2, 1, fArr, 2);
        float fM8 = m(fArr2, 1, fArr, 3);
        float fM9 = m(fArr2, 2, fArr, 0);
        float fM10 = m(fArr2, 2, fArr, 1);
        float fM11 = m(fArr2, 2, fArr, 2);
        float fM12 = m(fArr2, 2, fArr, 3);
        float fM13 = m(fArr2, 3, fArr, 0);
        float fM14 = m(fArr2, 3, fArr, 1);
        float fM15 = m(fArr2, 3, fArr, 2);
        float fM16 = m(fArr2, 3, fArr, 3);
        fArr[0] = fM;
        fArr[1] = fM2;
        fArr[2] = fM3;
        fArr[3] = fM4;
        fArr[4] = fM5;
        fArr[5] = fM6;
        fArr[6] = fM7;
        fArr[7] = fM8;
        fArr[8] = fM9;
        fArr[9] = fM10;
        fArr[10] = fM11;
        fArr[11] = fM12;
        fArr[12] = fM13;
        fArr[13] = fM14;
        fArr[14] = fM15;
        fArr[15] = fM16;
    }

    public static final void w(Z z3, int i5) {
        Object next;
        Iterator<T> it = z3.getLayoutNodeToHolder().entrySet().iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            } else {
                next = it.next();
                if (((t0.E) ((Map.Entry) next).getKey()).f13448m == i5) {
                    break;
                }
            }
        }
        Map.Entry entry = (Map.Entry) next;
        if (entry != null && entry.getValue() != null) {
            throw new ClassCastException();
        }
    }

    public static final String x(Object obj) {
        return (obj.getClass().isAnonymousClass() ? obj.getClass().getName() : obj.getClass().getSimpleName()) + '@' + String.format("%07x", Arrays.copyOf(new Object[]{Integer.valueOf(System.identityHashCode(obj))}, 1));
    }

    public static final String y(int i5) {
        if (A0.f.a(i5, 0)) {
            return "android.widget.Button";
        }
        if (A0.f.a(i5, 1)) {
            return "android.widget.CheckBox";
        }
        if (A0.f.a(i5, 3)) {
            return "android.widget.RadioButton";
        }
        if (A0.f.a(i5, 5)) {
            return "android.widget.ImageView";
        }
        if (A0.f.a(i5, 6)) {
            return "android.widget.Spinner";
        }
        return null;
    }

    public static void z(View view) {
        try {
            if (!Q0.D) {
                Q0.D = true;
                if (Build.VERSION.SDK_INT < 28) {
                    Q0.B = View.class.getDeclaredMethod("updateDisplayListIfDirty", null);
                    Q0.C = View.class.getDeclaredField("mRecreateDisplayList");
                } else {
                    Q0.B = (Method) Class.class.getDeclaredMethod("getDeclaredMethod", String.class, new Class[0].getClass()).invoke(View.class, "updateDisplayListIfDirty", new Class[0]);
                    Q0.C = (Field) Class.class.getDeclaredMethod("getDeclaredField", String.class).invoke(View.class, "mRecreateDisplayList");
                }
                Method method = Q0.B;
                if (method != null) {
                    method.setAccessible(true);
                }
                Field field = Q0.C;
                if (field != null) {
                    field.setAccessible(true);
                }
            }
            Field field2 = Q0.C;
            if (field2 != null) {
                field2.setBoolean(view, true);
            }
            Method method2 = Q0.B;
            if (method2 != null) {
                method2.invoke(view, null);
            }
        } catch (Throwable unused) {
            Q0.f13980E = true;
        }
    }
}

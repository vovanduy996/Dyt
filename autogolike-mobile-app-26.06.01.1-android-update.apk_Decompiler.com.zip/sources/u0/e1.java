package u0;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import com.google.android.gms.internal.measurement.D1;
import i4.InterfaceC1184h;
import kotlin.coroutines.Continuation;

/* JADX INFO: loaded from: classes.dex */
public final class e1 extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public h4.c f14056p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f14057q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f14058r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ ContentResolver f14059s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ Uri f14060t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ D1 f14061u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ h4.g f14062v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ Context f14063w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e1(ContentResolver contentResolver, Uri uri, D1 d12, h4.g gVar, Context context, Continuation continuation) {
        super(2, continuation);
        this.f14059s = contentResolver;
        this.f14060t = uri;
        this.f14061u = d12;
        this.f14062v = gVar;
        this.f14063w = context;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((e1) m((InterfaceC1184h) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        h4.g gVar = this.f14062v;
        e1 e1Var = new e1(this.f14059s, this.f14060t, this.f14061u, gVar, this.f14063w, continuation);
        e1Var.f14058r = obj;
        return e1Var;
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x0050 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0051  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x005d A[Catch: all -> 0x001c, TRY_LEAVE, TryCatch #0 {all -> 0x001c, blocks: (B:7:0x0016, B:18:0x0044, B:22:0x0055, B:24:0x005d, B:14:0x002c, B:17:0x003d), top: B:31:0x000a }] */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0080  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:25:0x007d -> B:8:0x0019). Please report as a decompilation issue!!! */
    @Override // M3.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object o(java.lang.Object r11) {
        /*
            r10 = this;
            L3.a r0 = L3.a.f4629l
            int r1 = r10.f14057q
            com.google.android.gms.internal.measurement.D1 r2 = r10.f14061u
            r3 = 2
            r4 = 1
            android.content.ContentResolver r5 = r10.f14059s
            if (r1 == 0) goto L30
            if (r1 == r4) goto L26
            if (r1 != r3) goto L1e
            h4.c r1 = r10.f14056p
            java.lang.Object r6 = r10.f14058r
            i4.h r6 = (i4.InterfaceC1184h) r6
            G3.AbstractC0164a.e(r11)     // Catch: java.lang.Throwable -> L1c
        L19:
            r11 = r6
            r6 = r1
            goto L44
        L1c:
            r11 = move-exception
            goto L86
        L1e:
            java.lang.IllegalStateException r11 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r11.<init>(r0)
            throw r11
        L26:
            h4.c r1 = r10.f14056p
            java.lang.Object r6 = r10.f14058r
            i4.h r6 = (i4.InterfaceC1184h) r6
            G3.AbstractC0164a.e(r11)     // Catch: java.lang.Throwable -> L1c
            goto L55
        L30:
            G3.AbstractC0164a.e(r11)
            java.lang.Object r11 = r10.f14058r
            i4.h r11 = (i4.InterfaceC1184h) r11
            android.net.Uri r1 = r10.f14060t
            r6 = 0
            r5.registerContentObserver(r1, r6, r2)
            h4.g r1 = r10.f14062v     // Catch: java.lang.Throwable -> L1c
            h4.c r6 = new h4.c     // Catch: java.lang.Throwable -> L1c
            r6.<init>(r1)     // Catch: java.lang.Throwable -> L1c
        L44:
            r10.f14058r = r11     // Catch: java.lang.Throwable -> L1c
            r10.f14056p = r6     // Catch: java.lang.Throwable -> L1c
            r10.f14057q = r4     // Catch: java.lang.Throwable -> L1c
            java.lang.Object r1 = r6.b(r10)     // Catch: java.lang.Throwable -> L1c
            if (r1 != r0) goto L51
            return r0
        L51:
            r9 = r6
            r6 = r11
            r11 = r1
            r1 = r9
        L55:
            java.lang.Boolean r11 = (java.lang.Boolean) r11     // Catch: java.lang.Throwable -> L1c
            boolean r11 = r11.booleanValue()     // Catch: java.lang.Throwable -> L1c
            if (r11 == 0) goto L80
            r1.c()     // Catch: java.lang.Throwable -> L1c
            android.content.Context r11 = r10.f14063w     // Catch: java.lang.Throwable -> L1c
            android.content.ContentResolver r11 = r11.getContentResolver()     // Catch: java.lang.Throwable -> L1c
            java.lang.String r7 = "animator_duration_scale"
            r8 = 1065353216(0x3f800000, float:1.0)
            float r11 = android.provider.Settings.Global.getFloat(r11, r7, r8)     // Catch: java.lang.Throwable -> L1c
            java.lang.Float r7 = new java.lang.Float     // Catch: java.lang.Throwable -> L1c
            r7.<init>(r11)     // Catch: java.lang.Throwable -> L1c
            r10.f14058r = r6     // Catch: java.lang.Throwable -> L1c
            r10.f14056p = r1     // Catch: java.lang.Throwable -> L1c
            r10.f14057q = r3     // Catch: java.lang.Throwable -> L1c
            java.lang.Object r11 = r6.k(r7, r10)     // Catch: java.lang.Throwable -> L1c
            if (r11 != r0) goto L19
            return r0
        L80:
            r5.unregisterContentObserver(r2)
            G3.C r11 = G3.C.a
            return r11
        L86:
            r5.unregisterContentObserver(r2)
            throw r11
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.e1.o(java.lang.Object):java.lang.Object");
    }
}

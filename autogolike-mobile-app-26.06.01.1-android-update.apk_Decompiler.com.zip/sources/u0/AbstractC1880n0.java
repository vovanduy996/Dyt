package u0;

import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: renamed from: u0.n0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1880n0 {
    public static final AtomicBoolean a = new AtomicBoolean(false);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final AtomicBoolean f14116b = new AtomicBoolean(false);
}

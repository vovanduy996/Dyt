package u0;

import android.view.View;

/* JADX INFO: renamed from: u0.F, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1841F {
    public static final C1841F a = new C1841F();

    public final void a(View view) {
        view.setForceDarkAllowed(false);
    }
}

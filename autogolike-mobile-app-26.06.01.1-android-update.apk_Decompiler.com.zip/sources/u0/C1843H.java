package u0;

import android.view.View;

/* JADX INFO: renamed from: u0.H, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1843H {
    public static final C1843H a = new C1843H();

    public final void a(View view) {
        view.clearViewTranslationCallback();
    }

    public final void b(View view) {
        ViewTranslationCallbackC1842G viewTranslationCallbackC1842G = ViewTranslationCallbackC1842G.a;
        ViewTranslationCallbackC1842G viewTranslationCallbackC1842G2 = ViewTranslationCallbackC1842G.a;
        view.setViewTranslationCallback(ViewTranslationCallbackC1842G.a);
    }
}

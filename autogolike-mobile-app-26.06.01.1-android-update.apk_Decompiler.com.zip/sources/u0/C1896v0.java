package u0;

import a0.AbstractC0490a;
import a0.C0493d;
import a0.C0494e;
import a0.C0495f;
import android.graphics.Outline;
import android.os.Build;
import b0.C0592j;
import l3.AbstractC1324b;

/* JADX INFO: renamed from: u0.v0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1896v0 {
    public boolean a = true;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Outline f14227b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public b0.L f14228c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public C0592j f14229d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public b0.M f14230e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f14231f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f14232g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public b0.M f14233h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public C0494e f14234i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public float f14235j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public long f14236k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public long f14237l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f14238m;

    public C1896v0() {
        Outline outline = new Outline();
        outline.setAlpha(1.0f);
        this.f14227b = outline;
        this.f14236k = 0L;
        this.f14237l = 0L;
    }

    /* JADX WARN: Removed duplicated region for block: B:25:0x0068  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void a(b0.r r21) {
        /*
            Method dump skipped, instruction units count: 243
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.C1896v0.a(b0.r):void");
    }

    public final Outline b() {
        d();
        if (this.f14238m && this.a) {
            return this.f14227b;
        }
        return null;
    }

    public final boolean c(b0.L l4, float f5, boolean z3, float f6, long j5) {
        this.f14227b.setAlpha(f5);
        boolean zA = U3.j.a(this.f14228c, l4);
        boolean z5 = !zA;
        if (!zA) {
            this.f14228c = l4;
            this.f14231f = true;
        }
        this.f14237l = j5;
        boolean z6 = l4 != null && (z3 || f6 > 0.0f);
        if (this.f14238m != z6) {
            this.f14238m = z6;
            this.f14231f = true;
        }
        return z5;
    }

    public final void d() {
        if (this.f14231f) {
            this.f14236k = 0L;
            this.f14235j = 0.0f;
            this.f14230e = null;
            this.f14231f = false;
            this.f14232g = false;
            b0.L l4 = this.f14228c;
            Outline outline = this.f14227b;
            if (l4 == null || !this.f14238m || C0495f.d(this.f14237l) <= 0.0f || C0495f.b(this.f14237l) <= 0.0f) {
                outline.setEmpty();
                return;
            }
            this.a = true;
            if (l4 instanceof b0.J) {
                C0493d c0493d = ((b0.J) l4).a;
                float f5 = c0493d.a;
                float f6 = c0493d.f7216b;
                this.f14236k = X2.g.l(f5, f6);
                this.f14237l = AbstractC1324b.d(c0493d.c(), c0493d.b());
                outline.setRect(Math.round(f5), Math.round(f6), Math.round(c0493d.f7217c), Math.round(c0493d.f7218d));
                return;
            }
            if (!(l4 instanceof b0.K)) {
                if (l4 instanceof b0.I) {
                    e(((b0.I) l4).a);
                    return;
                }
                return;
            }
            C0494e c0494e = ((b0.K) l4).a;
            float fB = AbstractC0490a.b(c0494e.f7222e);
            float f7 = c0494e.a;
            float f8 = c0494e.f7219b;
            this.f14236k = X2.g.l(f7, f8);
            this.f14237l = AbstractC1324b.d(c0494e.b(), c0494e.a());
            if (l0.c.o0(c0494e)) {
                this.f14227b.setRoundRect(Math.round(f7), Math.round(f8), Math.round(c0494e.f7220c), Math.round(c0494e.f7221d), fB);
                this.f14235j = fB;
                return;
            }
            C0592j c0592jH = this.f14229d;
            if (c0592jH == null) {
                c0592jH = b0.N.h();
                this.f14229d = c0592jH;
            }
            c0592jH.e();
            b0.M.a(c0592jH, c0494e);
            e(c0592jH);
        }
    }

    public final void e(b0.M m5) {
        int i5 = Build.VERSION.SDK_INT;
        Outline outline = this.f14227b;
        if (i5 <= 28 && !((C0592j) m5).a.isConvex()) {
            this.a = false;
            outline.setEmpty();
            this.f14232g = true;
        } else {
            if (!(m5 instanceof C0592j)) {
                throw new UnsupportedOperationException("Unable to obtain android.graphics.Path");
            }
            outline.setConvexPath(((C0592j) m5).a);
            this.f14232g = !outline.canClip();
        }
        this.f14230e = m5;
    }
}

package u0;

import i.C1117s;

/* JADX INFO: renamed from: u0.z, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1903z extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public C1839D f14246o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public C1117s f14247p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public h4.c f14248q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f14249r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ C1839D f14250s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f14251t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C1903z(C1839D c1839d, M3.c cVar) {
        super(cVar);
        this.f14250s = c1839d;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        this.f14249r = obj;
        this.f14251t |= Integer.MIN_VALUE;
        return this.f14250s.d(this);
    }
}

package u0;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Outline;
import b0.C0600s;
import t0.C1794a;

/* JADX INFO: renamed from: u0.h0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC1868h0 {
    int A();

    void B(boolean z3);

    void C(int i5);

    void D(float f5);

    void E(boolean z3);

    void F(Outline outline);

    void G(int i5);

    boolean H(int i5, int i6, int i7, int i8);

    boolean I();

    void J(Matrix matrix);

    float K();

    void L(int i5);

    float a();

    void b(float f5);

    void c(float f5);

    void d(float f5);

    void e(float f5);

    int f();

    void g();

    int h();

    void i(float f5);

    void j(float f5);

    void k(float f5);

    boolean l();

    void m(float f5);

    void n(float f5);

    void o();

    void p(float f5);

    void q(float f5);

    void r(int i5);

    int s();

    int t();

    boolean u();

    void v(int i5);

    boolean w();

    void x(C0600s c0600s, b0.M m5, C1794a c1794a);

    void y(Canvas canvas);

    int z();
}

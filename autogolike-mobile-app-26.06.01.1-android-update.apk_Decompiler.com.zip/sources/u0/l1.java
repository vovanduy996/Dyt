package u0;

import android.view.ViewGroup;

/* JADX INFO: loaded from: classes.dex */
public abstract class l1 {
    public static final ViewGroup.LayoutParams a = new ViewGroup.LayoutParams(-2, -2);

    /* JADX WARN: Removed duplicated region for block: B:20:0x0059  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x008c  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0091  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x00ae  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final u0.j1 a(u0.AbstractC1853a r6, I.r r7, Q.a r8) {
        /*
            java.util.concurrent.atomic.AtomicBoolean r0 = u0.AbstractC1880n0.a
            r1 = 0
            r2 = 1
            boolean r0 = r0.compareAndSet(r1, r2)
            r3 = 0
            if (r0 == 0) goto L40
            r0 = 6
            h4.g r0 = f.C0933a.i(r2, r0, r3)
            G3.q r2 = u0.V.f14000x
            java.lang.Object r2 = r2.getValue()
            K3.h r2 = (K3.h) r2
            k4.c r2 = f4.AbstractC0952A.a(r2)
            u0.m0 r4 = new u0.m0
            r4.<init>(r0, r3)
            r5 = 3
            f4.AbstractC0952A.s(r2, r3, r3, r4, r5)
            t0.a r2 = new t0.a
            r4 = 2
            r2.<init>(r4, r0)
            java.lang.Object r0 = S.p.f5938b
            monitor-enter(r0)
            java.lang.Object r4 = S.p.f5944h     // Catch: java.lang.Throwable -> L3d
            java.util.Collection r4 = (java.util.Collection) r4     // Catch: java.lang.Throwable -> L3d
            java.util.ArrayList r2 = H3.m.u1(r4, r2)     // Catch: java.lang.Throwable -> L3d
            S.p.f5944h = r2     // Catch: java.lang.Throwable -> L3d
            monitor-exit(r0)
            S.p.a()
            goto L40
        L3d:
            r6 = move-exception
            monitor-exit(r0)
            throw r6
        L40:
            int r0 = r6.getChildCount()
            if (r0 <= 0) goto L53
            android.view.View r0 = r6.getChildAt(r1)
            boolean r1 = r0 instanceof u0.C1889s
            if (r1 == 0) goto L51
            u0.s r0 = (u0.C1889s) r0
            goto L57
        L51:
            r0 = r3
            goto L57
        L53:
            r6.removeAllViews()
            goto L51
        L57:
            if (r0 != 0) goto L6f
            u0.s r0 = new u0.s
            android.content.Context r1 = r6.getContext()
            K3.h r2 = r7.h()
            r0.<init>(r1, r2)
            android.view.View r1 = r0.getView()
            android.view.ViewGroup$LayoutParams r2 = u0.l1.a
            r6.addView(r1, r2)
        L6f:
            F.A0 r6 = new F.A0
            t0.E r1 = r0.getRoot()
            r6.<init>(r1)
            I.u r1 = new I.u
            r1.<init>(r7, r6)
            android.view.View r6 = r0.getView()
            r2 = 2131230820(0x7f080064, float:1.8077704E38)
            java.lang.Object r6 = r6.getTag(r2)
            boolean r4 = r6 instanceof u0.j1
            if (r4 == 0) goto L8f
            r3 = r6
            u0.j1 r3 = (u0.j1) r3
        L8f:
            if (r3 != 0) goto L9d
            u0.j1 r3 = new u0.j1
            r3.<init>(r0, r1)
            android.view.View r6 = r0.getView()
            r6.setTag(r2, r3)
        L9d:
            r3.d(r8)
            K3.h r6 = r0.getCoroutineContext()
            K3.h r8 = r7.h()
            boolean r6 = U3.j.a(r6, r8)
            if (r6 != 0) goto Lb5
            K3.h r6 = r7.h()
            r0.setCoroutineContext(r6)
        Lb5:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: u0.l1.a(u0.a, I.r, Q.a):u0.j1");
    }
}

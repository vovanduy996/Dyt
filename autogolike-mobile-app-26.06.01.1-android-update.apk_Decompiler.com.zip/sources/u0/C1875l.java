package u0;

import androidx.lifecycle.InterfaceC0576v;

/* JADX INFO: renamed from: u0.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1875l {
    public final InterfaceC0576v a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final F1.f f14102b;

    public C1875l(InterfaceC0576v interfaceC0576v, F1.f fVar) {
        this.a = interfaceC0576v;
        this.f14102b = fVar;
    }
}

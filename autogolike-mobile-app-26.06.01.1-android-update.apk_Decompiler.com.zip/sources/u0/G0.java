package u0;

import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class G0 implements t0.h0 {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final int f13929l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final ArrayList f13930m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public Float f13931n = null;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public Float f13932o = null;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public A0.g f13933p = null;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public A0.g f13934q = null;

    public G0(int i5, ArrayList arrayList) {
        this.f13929l = i5;
        this.f13930m = arrayList;
    }

    @Override // t0.h0
    public final boolean L() {
        return this.f13930m.contains(this);
    }
}

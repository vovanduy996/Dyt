package u0;

import android.os.Build;
import android.view.ViewConfiguration;

/* JADX INFO: loaded from: classes.dex */
public final class X implements O0 {
    public final ViewConfiguration a;

    public X(ViewConfiguration viewConfiguration) {
        this.a = viewConfiguration;
    }

    @Override // u0.O0
    public final float a() {
        return this.a.getScaledTouchSlop();
    }

    @Override // u0.O0
    public final float b() {
        if (Build.VERSION.SDK_INT >= 34) {
            return Y.a.b(this.a);
        }
        return 2.0f;
    }

    @Override // u0.O0
    public final float c() {
        if (Build.VERSION.SDK_INT >= 34) {
            return Y.a.a(this.a);
        }
        return 16.0f;
    }

    @Override // u0.O0
    public final float d() {
        return this.a.getScaledMaximumFlingVelocity();
    }

    @Override // u0.O0
    public final long e() {
        return ViewConfiguration.getDoubleTapTimeout();
    }

    @Override // u0.O0
    public final long f() {
        return ViewConfiguration.getLongPressTimeout();
    }
}

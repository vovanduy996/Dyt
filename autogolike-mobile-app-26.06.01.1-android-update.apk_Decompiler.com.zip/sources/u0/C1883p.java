package u0;

import n0.InterfaceC1449o;
import n0.InterfaceC1450p;

/* JADX INFO: renamed from: u0.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1883p implements InterfaceC1450p {
    public final /* synthetic */ C1889s a;

    public C1883p(C1889s c1889s) {
        this.a = c1889s;
        InterfaceC1449o.a.getClass();
    }
}

package u0;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;
import android.view.ViewGroup;
import b0.AbstractC0586d;
import dagger.hilt.android.R;

/* JADX INFO: renamed from: u0.l0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C1876l0 extends ViewGroup {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f14103l;

    public C1876l0(Context context) {
        super(context);
        setClipChildren(false);
        setTag(R.id.hide_in_inspector_tag, Boolean.TRUE);
    }

    public final void a(b0.r rVar, Q0 q0, long j5) {
        super.drawChild(AbstractC0586d.a(rVar), q0, j5);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchDraw(Canvas canvas) {
        int childCount = super.getChildCount();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            U3.j.d(childAt, "null cannot be cast to non-null type androidx.compose.ui.platform.ViewLayer");
            if (((Q0) childAt).f13988s) {
                this.f14103l = true;
                try {
                    super.dispatchDraw(canvas);
                    return;
                } finally {
                    this.f14103l = false;
                }
            }
        }
    }

    @Override // android.view.ViewGroup
    public int getChildCount() {
        if (this.f14103l) {
            return super.getChildCount();
        }
        return 0;
    }

    @Override // android.view.View
    public final void onMeasure(int i5, int i6) {
        setMeasuredDimension(0, 0);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i5, int i6, int i7, int i8) {
    }
}

package u0;

import android.view.accessibility.AccessibilityEvent;
import com.autogolike.mobile.core.backup.ConfigBackupDto;

/* JADX INFO: renamed from: u0.A, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C1836A extends U3.k implements T3.c {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f13874l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ C1839D f13875m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C1836A(C1839D c1839d, int i5) {
        super(1);
        this.f13874l = i5;
        this.f13875m = c1839d;
    }

    @Override // T3.c
    public final Object invoke(Object obj) {
        switch (this.f13874l) {
            case ConfigBackupDto.$stable /* 0 */:
                C1839D c1839d = this.f13875m;
                return Boolean.valueOf(c1839d.f13893d.getParent().requestSendAccessibilityEvent(c1839d.f13893d, (AccessibilityEvent) obj));
            default:
                G0 g02 = (G0) obj;
                C1839D c1839d2 = this.f13875m;
                c1839d2.getClass();
                if (g02.f13930m.contains(g02)) {
                    c1839d2.f13893d.getSnapshotObserver().a(g02, c1839d2.f13892M, new A.d0(g02, 12, c1839d2));
                }
                return G3.C.a;
        }
    }
}

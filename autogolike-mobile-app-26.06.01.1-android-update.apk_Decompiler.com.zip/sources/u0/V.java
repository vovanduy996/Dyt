package u0;

import G3.AbstractC0164a;
import H3.C0227k;
import I.C0251l0;
import android.os.Handler;
import android.view.Choreographer;
import f4.AbstractC0987u;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class V extends AbstractC0987u {

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final G3.q f14000x = AbstractC0164a.d(C1847L.f13957s);

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public static final B4.c f14001y = new B4.c(3);

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Choreographer f14002n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final Handler f14003o;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f14008t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f14009u;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final C0251l0 f14011w;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final Object f14004p = new Object();

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final C0227k f14005q = new C0227k();

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public ArrayList f14006r = new ArrayList();

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public ArrayList f14007s = new ArrayList();

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final U f14010v = new U(this);

    public V(Choreographer choreographer, Handler handler) {
        this.f14002n = choreographer;
        this.f14003o = handler;
        this.f14011w = new C0251l0(choreographer, this);
    }

    public static final void b0(V v5) {
        Runnable runnable;
        boolean z3;
        do {
            synchronized (v5.f14004p) {
                C0227k c0227k = v5.f14005q;
                runnable = (Runnable) (c0227k.isEmpty() ? null : c0227k.removeFirst());
            }
            while (runnable != null) {
                runnable.run();
                synchronized (v5.f14004p) {
                    C0227k c0227k2 = v5.f14005q;
                    runnable = (Runnable) (c0227k2.isEmpty() ? null : c0227k2.removeFirst());
                }
            }
            synchronized (v5.f14004p) {
                if (v5.f14005q.isEmpty()) {
                    z3 = false;
                    v5.f14008t = false;
                } else {
                    z3 = true;
                }
            }
        } while (z3);
    }

    @Override // f4.AbstractC0987u
    public final void X(K3.h hVar, Runnable runnable) {
        synchronized (this.f14004p) {
            this.f14005q.addLast(runnable);
            if (!this.f14008t) {
                this.f14008t = true;
                this.f14003o.post(this.f14010v);
                if (!this.f14009u) {
                    this.f14009u = true;
                    this.f14002n.postFrameCallback(this.f14010v);
                }
            }
        }
    }
}

package u0;

/* JADX INFO: renamed from: u0.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC1855b {
    public String a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int[] f14028b = new int[2];

    public abstract int[] a(int i5);

    public final int[] b(int i5, int i6) {
        if (i5 < 0 || i6 < 0 || i5 == i6) {
            return null;
        }
        int[] iArr = this.f14028b;
        iArr[0] = i5;
        iArr[1] = i6;
        return iArr;
    }

    public final String c() {
        String str = this.a;
        if (str != null) {
            return str;
        }
        U3.j.j("text");
        throw null;
    }

    public abstract int[] d(int i5);
}

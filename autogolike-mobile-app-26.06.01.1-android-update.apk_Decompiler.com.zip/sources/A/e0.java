package A;

import a0.C0492c;
import com.autogolike.mobile.core.backup.ConfigBackupDto;

/* JADX INFO: loaded from: classes.dex */
public final class e0 extends U3.k implements T3.c {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f115l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ T3.a f116m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ e0(T3.a aVar, int i5) {
        super(1);
        this.f115l = i5;
        this.f116m = aVar;
    }

    @Override // T3.c
    public final Object invoke(Object obj) {
        switch (this.f115l) {
            case ConfigBackupDto.$stable /* 0 */:
                return new C0492c(((C0492c) this.f116m.b()).a);
            default:
                this.f116m.b();
                return G3.C.a;
        }
    }
}

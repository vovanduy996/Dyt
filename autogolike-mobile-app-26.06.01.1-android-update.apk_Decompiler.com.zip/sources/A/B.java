package A;

import kotlin.coroutines.Continuation;
import n0.C1432A;

/* JADX INFO: loaded from: classes.dex */
public final class B extends M3.h implements T3.e {

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f2n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public /* synthetic */ Object f3o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ T3.c f4p;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public B(T3.c cVar, Continuation continuation) {
        super(2, continuation);
        this.f4p = cVar;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        ((B) m((C1432A) obj, (Continuation) obj2)).o(G3.C.a);
        return L3.a.f4629l;
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        B b3 = new B(this.f4p, continuation);
        b3.f3o = obj;
        return b3;
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x002d A[RETURN] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x002b -> B:12:0x002e). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    @Override // M3.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object o(java.lang.Object r5) {
        /*
            r4 = this;
            L3.a r0 = L3.a.f4629l
            int r1 = r4.f2n
            r2 = 1
            if (r1 == 0) goto L19
            if (r1 != r2) goto L11
            java.lang.Object r1 = r4.f3o
            n0.A r1 = (n0.C1432A) r1
            G3.AbstractC0164a.e(r5)
            goto L2e
        L11:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r0)
            throw r5
        L19:
            G3.AbstractC0164a.e(r5)
            java.lang.Object r5 = r4.f3o
            n0.A r5 = (n0.C1432A) r5
            r1 = r5
        L21:
            n0.j r5 = n0.EnumC1444j.f11953l
            r4.f3o = r1
            r4.f2n = r2
            java.lang.Object r5 = r1.b(r5, r4)
            if (r5 != r0) goto L2e
            return r0
        L2e:
            n0.i r5 = (n0.C1443i) r5
            boolean r5 = W3.a.H(r5)
            r5 = r5 ^ r2
            java.lang.Boolean r5 = java.lang.Boolean.valueOf(r5)
            T3.c r3 = r4.f4p
            r3.invoke(r5)
            goto L21
        */
        throw new UnsupportedOperationException("Method not decompiled: A.B.o(java.lang.Object):java.lang.Object");
    }
}

package A;

import com.autogolike.mobile.core.backup.ConfigBackupDto;

/* JADX INFO: loaded from: classes.dex */
public final class X extends U3.k implements T3.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f59l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Y f60m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ X(Y y5, int i5) {
        super(0);
        this.f59l = i5;
        this.f60m = y5;
    }

    @Override // T3.a
    public final Object b() {
        switch (this.f59l) {
            case ConfigBackupDto.$stable /* 0 */:
                Y y5 = this.f60m;
                y5.b(true);
                y5.k();
                break;
            case 1:
                Y y6 = this.f60m;
                y6.d();
                y6.k();
                break;
            case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                Y y7 = this.f60m;
                y7.l();
                y7.k();
                break;
            case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                this.f60m.m();
                break;
            case k1.h.LONG_FIELD_NUMBER /* 4 */:
                this.f60m.l();
                break;
            case k1.h.STRING_FIELD_NUMBER /* 5 */:
                this.f60m.f(true);
                break;
            case k1.h.STRING_SET_FIELD_NUMBER /* 6 */:
                this.f60m.b(true);
                break;
            default:
                this.f60m.d();
                break;
        }
        return Boolean.TRUE;
    }
}

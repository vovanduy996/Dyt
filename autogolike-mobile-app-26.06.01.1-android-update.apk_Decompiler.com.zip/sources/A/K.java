package A;

import i4.InterfaceC1184h;

/* JADX INFO: loaded from: classes.dex */
public final class K implements InterfaceC1184h {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f27l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Object f28m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ Object f29n;

    /* JADX WARN: Multi-variable type inference failed */
    public K(InterfaceC1184h interfaceC1184h, T3.e eVar) {
        this.f27l = 10;
        this.f29n = interfaceC1184h;
        this.f28m = (M3.i) eVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.lang.Object b(int r6, kotlin.coroutines.Continuation r7) {
        /*
            r5 = this;
            boolean r0 = r7 instanceof i4.V
            if (r0 == 0) goto L13
            r0 = r7
            i4.V r0 = (i4.V) r0
            int r1 = r0.f10622q
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f10622q = r1
            goto L18
        L13:
            i4.V r0 = new i4.V
            r0.<init>(r5, r7)
        L18:
            java.lang.Object r7 = r0.f10620o
            L3.a r1 = L3.a.f4629l
            int r2 = r0.f10622q
            G3.C r3 = G3.C.a
            r4 = 1
            if (r2 == 0) goto L31
            if (r2 != r4) goto L29
            G3.AbstractC0164a.e(r7)
            goto L4f
        L29:
            java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            r6.<init>(r7)
            throw r6
        L31:
            G3.AbstractC0164a.e(r7)
            if (r6 <= 0) goto L4f
            java.lang.Object r6 = r5.f29n
            U3.q r6 = (U3.q) r6
            boolean r7 = r6.f6188l
            if (r7 != 0) goto L4f
            r6.f6188l = r4
            i4.Q r6 = i4.Q.f10615l
            r0.f10622q = r4
            java.lang.Object r7 = r5.f28m
            i4.h r7 = (i4.InterfaceC1184h) r7
            java.lang.Object r6 = r7.k(r6, r0)
            if (r6 != r1) goto L4f
            return r1
        L4f:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: A.K.b(int, kotlin.coroutines.Continuation):java.lang.Object");
    }

    /* JADX WARN: Removed duplicated region for block: B:106:0x01ec  */
    /* JADX WARN: Removed duplicated region for block: B:132:0x023d  */
    /* JADX WARN: Removed duplicated region for block: B:151:0x02aa  */
    /* JADX WARN: Removed duplicated region for block: B:162:0x02d6  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x00ae  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0113  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x0172  */
    /* JADX WARN: Removed duplicated region for block: B:97:0x01d0  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x01d3  */
    /* JADX WARN: Type inference failed for: r2v58, types: [M3.i, T3.e] */
    /* JADX WARN: Type inference failed for: r5v42, types: [M3.i, T3.e] */
    @Override // i4.InterfaceC1184h
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object k(java.lang.Object r22, kotlin.coroutines.Continuation r23) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 1312
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: A.K.k(java.lang.Object, kotlin.coroutines.Continuation):java.lang.Object");
    }

    public /* synthetic */ K(Object obj, int i5, Object obj2) {
        this.f27l = i5;
        this.f29n = obj;
        this.f28m = obj2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public K(T3.e eVar, U3.u uVar) {
        this.f27l = 9;
        this.f29n = (M3.i) eVar;
        this.f28m = uVar;
    }
}

package A;

import android.os.Bundle;
import android.os.Parcel;
import androidx.lifecycle.C0578x;
import androidx.lifecycle.EnumC0570o;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import f.C0933a;
import f4.AbstractC0952A;
import f4.p0;
import h.C1008d;
import h.C1010f;
import h3.C1083c;
import h3.InterfaceC1087g;
import i.AbstractC1094F;
import i.C1124z;
import java.util.ArrayDeque;
import java.util.Map;
import java.util.concurrent.CancellationException;
import k4.C1258c;

/* JADX INFO: loaded from: classes.dex */
public final class T {
    public final /* synthetic */ int a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f46b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f47c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f48d;

    public T(C3.c cVar, N2.d[] dVarArr, boolean z3) {
        this.a = 2;
        this.f48d = cVar;
        this.f47c = dVarArr;
        boolean z5 = false;
        if (dVarArr != null && z3) {
            z5 = true;
        }
        this.f46b = z5;
    }

    public static final void a(T t5) {
        ((C1124z) t5.f47c).a();
        int i5 = 0;
        t5.f46b = false;
        K.d dVar = (K.d) t5.f48d;
        int i6 = dVar.f4405n;
        if (i6 > 0) {
            Object[] objArr = dVar.f4403l;
            do {
                ((T3.a) objArr[i5]).b();
                i5++;
            } while (i5 < i6);
        }
        dVar.h();
    }

    /* JADX WARN: Removed duplicated region for block: B:18:0x005e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final void b(A.T r15) {
        /*
            java.lang.Object r0 = r15.f47c
            i.z r0 = (i.C1124z) r0
            java.lang.Object[] r1 = r0.f10402b
            long[] r2 = r0.a
            int r3 = r2.length
            int r3 = r3 + (-2)
            r4 = 0
            if (r3 < 0) goto L63
            r5 = r4
        Lf:
            r6 = r2[r5]
            long r8 = ~r6
            r10 = 7
            long r8 = r8 << r10
            long r8 = r8 & r6
            r10 = -9187201950435737472(0x8080808080808080, double:-2.937446524422997E-306)
            long r8 = r8 & r10
            int r8 = (r8 > r10 ? 1 : (r8 == r10 ? 0 : -1))
            if (r8 == 0) goto L5e
            int r8 = r5 - r3
            int r8 = ~r8
            int r8 = r8 >>> 31
            r9 = 8
            int r8 = 8 - r8
            r10 = r4
        L29:
            if (r10 >= r8) goto L5c
            r11 = 255(0xff, double:1.26E-321)
            long r11 = r11 & r6
            r13 = 128(0x80, double:6.3E-322)
            int r11 = (r11 > r13 ? 1 : (r11 == r13 ? 0 : -1))
            if (r11 >= 0) goto L58
            int r11 = r5 << 3
            int r11 = r11 + r10
            r11 = r1[r11]
            Z.r r11 = (Z.r) r11
            r11.getClass()
            A.T r12 = Z.d.F(r11)
            java.lang.Object r12 = r12.f47c
            i.z r12 = (i.C1124z) r12
            java.lang.Object r12 = r12.e(r11)
            Z.q r12 = (Z.q) r12
            if (r12 == 0) goto L51
            r11.f7167A = r12
            goto L58
        L51:
            java.lang.String r15 = "committing a node that was not updated in the current transaction"
            m1.AbstractC1393s.b0(r15)
            r15 = 0
            throw r15
        L58:
            long r6 = r6 >> r9
            int r10 = r10 + 1
            goto L29
        L5c:
            if (r8 != r9) goto L63
        L5e:
            if (r5 == r3) goto L63
            int r5 = r5 + 1
            goto Lf
        L63:
            r0.a()
            r15.f46b = r4
            java.lang.Object r15 = r15.f48d
            K.d r15 = (K.d) r15
            r15.h()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: A.T.b(A.T):void");
    }

    public void c() {
        ((h4.g) this.f47c).k(new CancellationException("onBack cancelled"), true);
        ((p0) this.f48d).a(null);
    }

    public void d(O2.a aVar, C1083c c1083c) {
        C3.c cVar = (C3.c) ((C3.c) this.f48d).f966m;
        cVar.getClass();
        S2.a aVar2 = (S2.a) ((S2.d) aVar).u();
        Parcel parcelObtain = Parcel.obtain();
        parcelObtain.writeInterfaceToken(aVar2.f6066d);
        int i5 = Z2.b.a;
        Q2.l lVar = (Q2.l) cVar.f966m;
        if (lVar == null) {
            parcelObtain.writeInt(0);
        } else {
            parcelObtain.writeInt(1);
            lVar.writeToParcel(parcelObtain, 0);
        }
        try {
            aVar2.f6065c.transact(1, parcelObtain, null, 1);
            parcelObtain.recycle();
            c1083c.a.n(null);
        } catch (Throwable th) {
            parcelObtain.recycle();
            throw th;
        }
    }

    public int e() {
        C0013n c0013n = (C0013n) this.f48d;
        int i5 = c0013n.f145b;
        int i6 = c0013n.f146c;
        if (i5 < i6) {
            return 2;
        }
        return i5 > i6 ? 1 : 3;
    }

    public void f() {
        F1.f fVar = (F1.f) this.f47c;
        C0578x c0578xE = fVar.e();
        if (c0578xE.f7765d != EnumC0570o.f7753m) {
            throw new IllegalStateException("Restarter must be created only during owner's initialization stage");
        }
        c0578xE.a(new F1.b(0, fVar));
        F1.e eVar = (F1.e) this.f48d;
        eVar.getClass();
        if (eVar.f2260b) {
            throw new IllegalStateException("SavedStateRegistry was already attached.");
        }
        c0578xE.a(new D2.g(1, eVar));
        eVar.f2260b = true;
        this.f46b = true;
    }

    public void g(Bundle bundle) {
        if (!this.f46b) {
            f();
        }
        C0578x c0578xE = ((F1.f) this.f47c).e();
        if (c0578xE.f7765d.compareTo(EnumC0570o.f7755o) >= 0) {
            throw new IllegalStateException(("performRestore cannot be called when owner is " + c0578xE.f7765d).toString());
        }
        F1.e eVar = (F1.e) this.f48d;
        if (!eVar.f2260b) {
            throw new IllegalStateException("You must call performAttach() before calling performRestore(Bundle).");
        }
        if (eVar.f2262d) {
            throw new IllegalStateException("SavedStateRegistry was already restored.");
        }
        eVar.f2261c = bundle != null ? bundle.getBundle("androidx.lifecycle.BundlableSavedStateRegistry.key") : null;
        eVar.f2262d = true;
    }

    public void h(Bundle bundle) {
        U3.j.f(bundle, "outBundle");
        F1.e eVar = (F1.e) this.f48d;
        eVar.getClass();
        Bundle bundle2 = new Bundle();
        Bundle bundle3 = eVar.f2261c;
        if (bundle3 != null) {
            bundle2.putAll(bundle3);
        }
        C1010f c1010f = eVar.a;
        c1010f.getClass();
        C1008d c1008d = new C1008d(c1010f);
        c1010f.f9897n.put(c1008d, Boolean.FALSE);
        while (c1008d.hasNext()) {
            Map.Entry entry = (Map.Entry) c1008d.next();
            bundle2.putBundle((String) entry.getKey(), ((F1.d) entry.getValue()).a());
        }
        if (bundle2.isEmpty()) {
            return;
        }
        bundle.putBundle("androidx.lifecycle.BundlableSavedStateRegistry.key", bundle2);
    }

    public void i(InterfaceC1087g interfaceC1087g) {
        synchronized (this.f47c) {
            try {
                if (((ArrayDeque) this.f48d) == null) {
                    this.f48d = new ArrayDeque();
                }
                ((ArrayDeque) this.f48d).add(interfaceC1087g);
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public void j(A4.e eVar) {
        InterfaceC1087g interfaceC1087g;
        synchronized (this.f47c) {
            if (((ArrayDeque) this.f48d) != null && !this.f46b) {
                this.f46b = true;
                while (true) {
                    synchronized (this.f47c) {
                        try {
                            interfaceC1087g = (InterfaceC1087g) ((ArrayDeque) this.f48d).poll();
                            if (interfaceC1087g == null) {
                                this.f46b = false;
                                return;
                            }
                        } finally {
                        }
                    }
                    interfaceC1087g.a(eVar);
                }
            }
        }
    }

    public String toString() {
        switch (this.a) {
            case ConfigBackupDto.$stable /* 0 */:
                StringBuilder sb = new StringBuilder("SingleSelectionLayout(isStartHandle=");
                sb.append(this.f46b);
                sb.append(", crossed=");
                int iE = e();
                sb.append(iE != 1 ? iE != 2 ? iE != 3 ? "null" : "COLLAPSED" : "NOT_CROSSED" : "CROSSED");
                sb.append(", info=\n\t");
                sb.append((C0013n) this.f48d);
                sb.append(')');
                return sb.toString();
            default:
                return super.toString();
        }
    }

    public T(F1.f fVar) {
        this.a = 1;
        this.f47c = fVar;
        this.f48d = new F1.e();
    }

    public T(int i5) {
        this.a = i5;
        switch (i5) {
            case k1.h.STRING_FIELD_NUMBER /* 5 */:
                this.f47c = new Object();
                break;
            default:
                long[] jArr = AbstractC1094F.a;
                this.f47c = new C1124z();
                this.f48d = new K.d(new T3.a[16]);
                break;
        }
    }

    public T(C1258c c1258c, boolean z3, T3.e eVar, c.h hVar) {
        this.a = 4;
        this.f46b = z3;
        this.f47c = C0933a.i(-2, 4, h4.a.f10252l);
        this.f48d = AbstractC0952A.s(c1258c, null, null, new c.g(hVar, eVar, this, null), 3);
    }

    public T(boolean z3, C0015p c0015p, C0013n c0013n) {
        this.a = 0;
        this.f46b = z3;
        this.f47c = c0015p;
        this.f48d = c0013n;
    }
}

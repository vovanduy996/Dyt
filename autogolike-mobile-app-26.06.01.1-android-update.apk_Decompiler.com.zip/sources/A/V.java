package A;

import I.C0247j0;
import a0.C0492c;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import j0.C1204b;
import j0.InterfaceC1203a;
import l3.AbstractC1324b;
import w.p0;

/* JADX INFO: loaded from: classes.dex */
public final class V implements w.a0 {
    public final /* synthetic */ int a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Y f57b;

    public /* synthetic */ V(Y y5, int i5) {
        this.a = i5;
        this.f57b = y5;
    }

    @Override // w.a0
    public final void a() {
        switch (this.a) {
            case ConfigBackupDto.$stable /* 0 */:
                Y y5 = this.f57b;
                y5.f75p.setValue(null);
                y5.f76q.setValue(null);
                break;
            default:
                i();
                break;
        }
    }

    @Override // w.a0
    public final void b() {
        switch (this.a) {
            case ConfigBackupDto.$stable /* 0 */:
                Y y5 = this.f57b;
                y5.f75p.setValue(null);
                y5.f76q.setValue(null);
                break;
        }
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [T3.c, U3.k] */
    @Override // w.a0
    public final void c(long j5) {
        p0 p0VarD;
        p0 p0VarD2;
        p0 p0VarD3;
        switch (this.a) {
            case ConfigBackupDto.$stable /* 0 */:
                Y y5 = this.f57b;
                long jI = y5.i(true);
                float f5 = E.a;
                long jL = X2.g.l(C0492c.d(jI), C0492c.e(jI) - 1.0f);
                w.S s3 = y5.f63d;
                if (s3 != null && (p0VarD = s3.d()) != null) {
                    long jE = p0VarD.e(jL);
                    y5.f72m = jE;
                    y5.f76q.setValue(new C0492c(jE));
                    y5.f74o = 0L;
                    y5.f75p.setValue(w.G.f14589l);
                    y5.p(false);
                    break;
                }
                break;
            default:
                Y y6 = this.f57b;
                if (y6.h()) {
                    C0247j0 c0247j0 = y6.f75p;
                    if (((w.G) c0247j0.getValue()) == null) {
                        c0247j0.setValue(w.G.f14591n);
                        y6.f77r = -1;
                        y6.k();
                        w.S s5 = y6.f63d;
                        if (s5 == null || (p0VarD3 = s5.d()) == null || !p0VarD3.c(j5)) {
                            w.S s6 = y6.f63d;
                            if (s6 != null && (p0VarD2 = s6.d()) != null) {
                                int iC = y6.f61b.c(p0VarD2.b(true, j5));
                                I0.A aC = Y.c(y6.j().a, AbstractC1324b.f(iC, iC));
                                y6.f(false);
                                InterfaceC1203a interfaceC1203a = y6.f68i;
                                if (interfaceC1203a != null) {
                                    ((C1204b) interfaceC1203a).a();
                                }
                                y6.f62c.invoke(aC);
                            }
                        } else if (y6.j().a.a.length() != 0) {
                            y6.f(false);
                            y6.f73n = Integer.valueOf((int) (Y.a(y6, I0.A.a(y6.j(), null, C0.K.f755b, 5), j5, true, false, r.f157e, true) >> 32));
                        }
                        y6.n(w.H.f14593l);
                        y6.f72m = j5;
                        y6.f76q.setValue(new C0492c(j5));
                        y6.f74o = 0L;
                        break;
                    }
                }
                break;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x0091  */
    /* JADX WARN: Type inference failed for: r0v6, types: [T3.c, U3.k] */
    @Override // w.a0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void d(long r11) {
        /*
            Method dump skipped, instruction units count: 330
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: A.V.d(long):void");
    }

    @Override // w.a0
    public final void e() {
        int i5 = this.a;
    }

    public void i() {
        Y y5 = this.f57b;
        y5.f75p.setValue(null);
        y5.f76q.setValue(null);
        y5.p(true);
        y5.f73n = null;
        boolean zB = C0.K.b(y5.j().f3798b);
        y5.n(zB ? w.H.f14595n : w.H.f14594m);
        w.S s3 = y5.f63d;
        if (s3 != null) {
            s3.f14629m.setValue(Boolean.valueOf(!zB && AbstractC1324b.C(y5, true)));
        }
        w.S s5 = y5.f63d;
        if (s5 != null) {
            s5.f14630n.setValue(Boolean.valueOf(!zB && AbstractC1324b.C(y5, false)));
        }
        w.S s6 = y5.f63d;
        if (s6 == null) {
            return;
        }
        s6.f14631o.setValue(Boolean.valueOf(zB && AbstractC1324b.C(y5, true)));
    }

    @Override // w.a0
    public final void onCancel() {
        switch (this.a) {
            case ConfigBackupDto.$stable /* 0 */:
                break;
            default:
                i();
                break;
        }
    }

    private final void f() {
    }

    private final void g() {
    }

    private final void h() {
    }

    private final void j() {
    }
}

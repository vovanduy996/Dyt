package A;

import I.C0234d;
import I.C0258p;

/* JADX INFO: renamed from: A.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0004e extends U3.k implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0012m f108l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ boolean f109m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ N0.h f110n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ boolean f111o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ long f112p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ U.q f113q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ int f114r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0004e(InterfaceC0012m interfaceC0012m, boolean z3, N0.h hVar, boolean z5, long j5, U.q qVar, int i5) {
        super(2);
        this.f108l = interfaceC0012m;
        this.f109m = z3;
        this.f110n = hVar;
        this.f111o = z5;
        this.f112p = j5;
        this.f113q = qVar;
        this.f114r = i5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        ((Number) obj2).intValue();
        int iU = C0234d.U(this.f114r | 1);
        N0.h hVar = this.f110n;
        boolean z3 = this.f111o;
        E4.d.n(this.f108l, this.f109m, hVar, z3, this.f112p, this.f113q, (C0258p) obj, iU);
        return G3.C.a;
    }
}

package A;

import F.A0;
import H0.AbstractC0182o;
import I.C0234d;
import I.C0250l;
import I.C0258p;
import I.C0275y;
import I.InterfaceC0233c0;
import I.Y0;
import a0.C0492c;
import android.graphics.Typeface;
import android.text.Spannable;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import e3.C0898k;
import f.C0933a;
import f4.AbstractC0952A;
import k4.C1258c;
import l.C1285c;
import l.C1304m;
import m.AbstractC1369w;
import m.C1348e0;
import m.C1366t;
import m.InterfaceC1342b0;
import m.InterfaceC1344c0;
import n.C1418b;
import n.C1425i;
import o.C1513t;

/* JADX INFO: loaded from: classes.dex */
public final class H extends U3.k implements T3.f {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f19l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Object f20m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ Object f21n;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public H(T3.c cVar, p.k kVar) {
        super(3);
        this.f19l = 5;
        this.f21n = cVar;
        this.f20m = kVar;
    }

    /* JADX WARN: Type inference failed for: r2v7, types: [T3.c, U3.k] */
    @Override // T3.f
    public final Object h(Object obj, Object obj2, Object obj3) {
        Typeface typeface;
        switch (this.f19l) {
            case ConfigBackupDto.$stable /* 0 */:
                C0258p c0258p = (C0258p) obj2;
                ((Number) obj3).intValue();
                c0258p.Q(759876635);
                Object objG = c0258p.G();
                I.W w5 = C0250l.a;
                if (objG == w5) {
                    objG = C0234d.D((T3.a) this.f20m);
                    c0258p.a0(objG);
                }
                Y0 y02 = (Y0) objG;
                Object objG2 = c0258p.G();
                if (objG2 == w5) {
                    objG2 = new C1285c(new C0492c(((C0492c) y02.getValue()).a), M.f34b, new C0492c(M.f35c), 8);
                    c0258p.a0(objG2);
                }
                C1285c c1285c = (C1285c) objG2;
                G3.C c5 = G3.C.a;
                boolean zH = c0258p.h(c1285c);
                Object objG3 = c0258p.G();
                if (zH || objG3 == w5) {
                    objG3 = new L(y02, c1285c, null);
                    c0258p.a0(objG3);
                }
                C0234d.e(c0258p, (T3.e) objG3, c5);
                C1304m c1304m = c1285c.f11222c;
                boolean zF = c0258p.f(c1304m);
                Object objG4 = c0258p.G();
                if (zF || objG4 == w5) {
                    objG4 = new G(0, c1304m);
                    c0258p.a0(objG4);
                }
                U.q qVar = (U.q) ((T3.c) this.f21n).invoke((T3.a) objG4);
                c0258p.p(false);
                return qVar;
            case 1:
                C0.D d3 = (C0.D) obj;
                int iIntValue = ((Number) obj2).intValue();
                int iIntValue2 = ((Number) obj3).intValue();
                AbstractC0182o abstractC0182o = d3.f722f;
                H0.z zVar = d3.f719c;
                if (zVar == null) {
                    zVar = H0.z.f2956p;
                }
                H0.v vVar = d3.f720d;
                int i5 = vVar != null ? vVar.a : 0;
                H0.w wVar = d3.f721e;
                int i6 = wVar != null ? wVar.a : 1;
                K0.c cVar = (K0.c) ((H1.b) this.f21n).f2964m;
                H0.O oB = ((H0.p) cVar.f4420e).b(abstractC0182o, zVar, i5, i6);
                if (oB instanceof H0.N) {
                    Object obj4 = ((H0.N) oB).f2901l;
                    U3.j.d(obj4, "null cannot be cast to non-null type android.graphics.Typeface");
                    typeface = (Typeface) obj4;
                } else {
                    A0 a02 = new A0(oB, cVar.f4425j);
                    cVar.f4425j = a02;
                    Object obj5 = a02.f1396o;
                    U3.j.d(obj5, "null cannot be cast to non-null type android.graphics.Typeface");
                    typeface = (Typeface) obj5;
                }
                ((Spannable) this.f20m).setSpan(new F0.b(1, typeface), iIntValue, iIntValue2, 33);
                return G3.C.a;
            case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                C0258p c0258p2 = (C0258p) obj2;
                ((Number) obj3).intValue();
                c0258p2.Q(-353972293);
                InterfaceC1344c0 interfaceC1344c0B = ((InterfaceC1342b0) this.f20m).b((p.k) this.f21n, c0258p2);
                boolean zF2 = c0258p2.f(interfaceC1344c0B);
                Object objG5 = c0258p2.G();
                if (zF2 || objG5 == C0250l.a) {
                    objG5 = new C1348e0(interfaceC1344c0B);
                    c0258p2.a0(objG5);
                }
                C1348e0 c1348e0 = (C1348e0) objG5;
                c0258p2.p(false);
                return c1348e0;
            case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                C0258p c0258p3 = (C0258p) obj2;
                if ((((Number) obj3).intValue() & 17) == 16 && c0258p3.x()) {
                    c0258p3.L();
                } else {
                    Object objG6 = c0258p3.G();
                    if (objG6 == C0250l.a) {
                        objG6 = new C1425i();
                        c0258p3.a0(objG6);
                    }
                    C1425i c1425i = (C1425i) objG6;
                    c1425i.a.clear();
                    ((C0021w) this.f20m).invoke(c1425i);
                    c1425i.a((C1418b) this.f21n, c0258p3, 0);
                }
                return G3.C.a;
            case k1.h.LONG_FIELD_NUMBER /* 4 */:
                n0.s sVar = (n0.s) obj;
                n0.s sVar2 = (n0.s) obj2;
                long j5 = ((C0492c) obj3).a;
                o.M m5 = (o.M) this.f20m;
                if (((Boolean) m5.B.invoke(sVar)).booleanValue()) {
                    if (!m5.f12161G) {
                        if (m5.f12159E == null) {
                            m5.f12159E = C0933a.i(Integer.MAX_VALUE, 6, null);
                        }
                        m5.f12161G = true;
                        AbstractC0952A.s(m5.o0(), null, null, new o.L(m5, null), 3);
                    }
                    AbstractC1369w.e((C0898k) this.f21n, sVar);
                    long jG = C0492c.g(sVar2.f11963c, j5);
                    h4.g gVar = m5.f12159E;
                    if (gVar != null) {
                        gVar.n(new C1513t(jG));
                    }
                }
                return G3.C.a;
            default:
                C0258p c0258p4 = (C0258p) obj2;
                ((Number) obj3).intValue();
                c0258p4.Q(-102778667);
                Object objG7 = c0258p4.G();
                I.W w6 = C0250l.a;
                if (objG7 == w6) {
                    C0275y c0275y = new C0275y(C0234d.z(c0258p4));
                    c0258p4.a0(c0275y);
                    objG7 = c0275y;
                }
                C1258c c1258c = ((C0275y) objG7).f3762l;
                Object objG8 = c0258p4.G();
                if (objG8 == w6) {
                    objG8 = C0234d.K(null, I.W.f3598q);
                    c0258p4.a0(objG8);
                }
                InterfaceC0233c0 interfaceC0233c0 = (InterfaceC0233c0) objG8;
                InterfaceC0233c0 interfaceC0233c0N = C0234d.N((T3.c) this.f21n, c0258p4);
                p.k kVar = (p.k) this.f20m;
                boolean zF3 = c0258p4.f(kVar);
                Object objG9 = c0258p4.G();
                if (zF3 || objG9 == w6) {
                    objG9 = new C1366t(interfaceC0233c0, 23, kVar);
                    c0258p4.a0(objG9);
                }
                C0234d.c(kVar, (T3.c) objG9, c0258p4);
                U.n nVar = U.n.a;
                boolean zH2 = c0258p4.h(c1258c) | c0258p4.f(kVar) | c0258p4.f(interfaceC0233c0N);
                Object objG10 = c0258p4.G();
                if (zH2 || objG10 == w6) {
                    w.j0 j0Var = new w.j0(c1258c, interfaceC0233c0, (p.k) this.f20m, interfaceC0233c0N, null);
                    c0258p4.a0(j0Var);
                    objG10 = j0Var;
                }
                U.q qVarA = n0.w.a(nVar, kVar, (T3.e) objG10);
                c0258p4.p(false);
                return qVarA;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ H(Object obj, int i5, Object obj2) {
        super(3);
        this.f19l = i5;
        this.f20m = obj;
        this.f21n = obj2;
    }
}

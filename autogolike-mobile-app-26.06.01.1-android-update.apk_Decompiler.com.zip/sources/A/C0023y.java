package A;

import G3.AbstractC0164a;
import kotlin.coroutines.Continuation;
import m1.AbstractC1388n;
import n0.C1434C;
import t0.AbstractC1800g;

/* JADX INFO: renamed from: A.y, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0023y extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f182p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f183q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ C3.c f184r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ w.a0 f185s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0023y(C3.c cVar, w.a0 a0Var, Continuation continuation) {
        super(2, continuation);
        this.f184r = cVar;
        this.f185s = a0Var;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C0023y) m((C1434C) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C0023y c0023y = new C0023y(this.f184r, this.f185s, continuation);
        c0023y.f183q = obj;
        return c0023y;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f182p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            C1434C c1434c = (C1434C) this.f183q;
            c1434c.getClass();
            C0022x c0022x = new C0022x(this.f184r, new C0010k(AbstractC1800g.v(c1434c).D), this.f185s, null);
            this.f182p = 1;
            if (AbstractC1388n.v(c1434c, c0022x, this) == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return G3.C.a;
    }
}

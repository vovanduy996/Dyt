package A;

import F.A0;
import com.google.android.gms.internal.measurement.AbstractC0813y0;
import i.AbstractC1092D;
import i.C1121w;
import java.util.Arrays;
import k.C1231f;
import kotlinx.serialization.descriptors.SerialDescriptor;
import m.AbstractC1369w;
import r.C1628h;
import s.C1715h;
import s.InterfaceC1731x;
import u0.O0;

/* JADX INFO: renamed from: A.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0010k implements InterfaceC1731x {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f139l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f140m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public Object f141n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public Object f142o;

    public /* synthetic */ C0010k(int i5, byte b3) {
        this.f139l = i5;
    }

    public void a(int i5, A0 a02) {
        if (i5 < 0) {
            throw new IllegalArgumentException(AbstractC0813y0.l("size should be >=0, but was ", i5).toString());
        }
        if (i5 == 0) {
            return;
        }
        C1715h c1715h = new C1715h(this.f140m, i5, a02);
        this.f140m += i5;
        ((K.d) this.f141n).b(c1715h);
    }

    @Override // s.InterfaceC1731x
    public int b(Object obj) {
        C1121w c1121w = (C1121w) this.f141n;
        int iC = c1121w.c(obj);
        if (iC >= 0) {
            return c1121w.f10392c[iC];
        }
        return -1;
    }

    public y3.b c() {
        String str = ((Long) this.f142o) == null ? " tokenExpirationTimestamp" : "";
        if (str.isEmpty()) {
            return new y3.b(((Long) this.f142o).longValue(), (String) this.f141n, this.f140m);
        }
        throw new IllegalStateException("Missing required properties:".concat(str));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:71:0x0188  */
    /* JADX WARN: Type inference failed for: r15v0 */
    /* JADX WARN: Type inference failed for: r3v10, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r3v2, types: [int[]] */
    /* JADX WARN: Type inference failed for: r3v8 */
    /* JADX WARN: Type inference failed for: r4v14 */
    /* JADX WARN: Type inference failed for: r4v15, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r4v18 */
    /* JADX WARN: Type inference failed for: r4v19 */
    /* JADX WARN: Type inference failed for: r4v2 */
    /* JADX WARN: Type inference failed for: r4v22 */
    /* JADX WARN: Type inference failed for: r4v25 */
    /* JADX WARN: Type inference failed for: r4v26 */
    /* JADX WARN: Type inference failed for: r4v8 */
    /* JADX WARN: Type inference failed for: r4v9 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v5, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r6v9, types: [java.lang.Object[]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public j3.m d() {
        /*
            Method dump skipped, instruction units count: 442
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: A.C0010k.d():j3.m");
    }

    public void e(int i5) {
        if (i5 < 0 || i5 >= this.f140m) {
            StringBuilder sbO = AbstractC0813y0.o(i5, "Index ", ", size ");
            sbO.append(this.f140m);
            throw new IndexOutOfBoundsException(sbO.toString());
        }
    }

    public C1715h f(int i5) {
        e(i5);
        C1715h c1715h = (C1715h) this.f142o;
        if (c1715h != null) {
            int i6 = c1715h.f13093b;
            int i7 = c1715h.a;
            if (i5 < i6 + i7 && i7 <= i5) {
                return c1715h;
            }
        }
        K.d dVar = (K.d) this.f141n;
        C1715h c1715h2 = (C1715h) dVar.f4403l[AbstractC1369w.b(i5, dVar)];
        this.f142o = c1715h2;
        return c1715h2;
    }

    public String g() {
        StringBuilder sb = new StringBuilder("$");
        int i5 = this.f140m + 1;
        for (int i6 = 0; i6 < i5; i6++) {
            Object obj = ((Object[]) this.f141n)[i6];
            if (obj instanceof SerialDescriptor) {
                SerialDescriptor serialDescriptor = (SerialDescriptor) obj;
                if (!U3.j.a(serialDescriptor.i(), q4.i.f12763c)) {
                    int i7 = ((int[]) this.f142o)[i6];
                    if (i7 >= 0) {
                        sb.append(".");
                        sb.append(serialDescriptor.a(i7));
                    }
                } else if (((int[]) this.f142o)[i6] != -1) {
                    sb.append("[");
                    sb.append(((int[]) this.f142o)[i6]);
                    sb.append("]");
                }
            } else if (obj != u4.m.a) {
                sb.append("['");
                sb.append(obj);
                sb.append("']");
            }
        }
        String string = sb.toString();
        U3.j.e(string, "toString(...)");
        return string;
    }

    public void h(Object obj, Object obj2) {
        int i5 = (this.f140m + 1) * 2;
        Object[] objArr = (Object[]) this.f141n;
        if (i5 > objArr.length) {
            int length = objArr.length;
            if (i5 < 0) {
                throw new AssertionError("cannot store more than MAX_VALUE elements");
            }
            int iHighestOneBit = length + (length >> 1) + 1;
            if (iHighestOneBit < i5) {
                iHighestOneBit = Integer.highestOneBit(i5 - 1) << 1;
            }
            if (iHighestOneBit < 0) {
                iHighestOneBit = Integer.MAX_VALUE;
            }
            this.f141n = Arrays.copyOf(objArr, iHighestOneBit);
        }
        if (obj == null) {
            String strValueOf = String.valueOf(obj2);
            StringBuilder sb = new StringBuilder(strValueOf.length() + 24);
            sb.append("null key in entry: null=");
            sb.append(strValueOf);
            throw new NullPointerException(sb.toString());
        }
        if (obj2 == null) {
            String strValueOf2 = String.valueOf(obj);
            StringBuilder sb2 = new StringBuilder(strValueOf2.length() + 26);
            sb2.append("null value in entry: ");
            sb2.append(strValueOf2);
            sb2.append("=null");
            throw new NullPointerException(sb2.toString());
        }
        Object[] objArr2 = (Object[]) this.f141n;
        int i6 = this.f140m;
        int i7 = i6 * 2;
        objArr2[i7] = obj;
        objArr2[i7 + 1] = obj2;
        this.f140m = i6 + 1;
    }

    public String toString() {
        switch (this.f139l) {
            case 1:
                StringBuilder sb = new StringBuilder();
                if (((w4.w) this.f141n) == w4.w.f15306m) {
                    sb.append("HTTP/1.0");
                } else {
                    sb.append("HTTP/1.1");
                }
                sb.append(' ');
                sb.append(this.f140m);
                sb.append(' ');
                sb.append((String) this.f142o);
                String string = sb.toString();
                U3.j.e(string, "StringBuilder().apply(builderAction).toString()");
                return string;
            case k1.h.STRING_SET_FIELD_NUMBER /* 6 */:
                return g();
            default:
                return super.toString();
        }
    }

    public C0010k(w4.w wVar, int i5, String str) {
        this.f139l = 1;
        this.f141n = wVar;
        this.f140m = i5;
        this.f142o = str;
    }

    public C0010k(Z3.d dVar, C1628h c1628h) {
        this.f139l = 5;
        C0010k c0010k = c1628h.a;
        int i5 = dVar.f7196l;
        if (i5 >= 0) {
            int iMin = Math.min(dVar.f7197m, c0010k.f140m - 1);
            if (iMin < i5) {
                C1121w c1121w = AbstractC1092D.a;
                U3.j.d(c1121w, "null cannot be cast to non-null type androidx.collection.ObjectIntMap<K of androidx.collection.ObjectIntMapKt.emptyObjectIntMap>");
                this.f141n = c1121w;
                this.f142o = new Object[0];
                this.f140m = 0;
                return;
            }
            int i6 = (iMin - i5) + 1;
            this.f142o = new Object[i6];
            this.f140m = i5;
            C1121w c1121w2 = new C1121w(i6);
            C1231f c1231f = new C1231f(i5, iMin, c1121w2, this);
            c0010k.e(i5);
            c0010k.e(iMin);
            if (iMin >= i5) {
                K.d dVar2 = (K.d) c0010k.f141n;
                int iB = AbstractC1369w.b(i5, dVar2);
                int i7 = ((C1715h) dVar2.f4403l[iB]).a;
                while (i7 <= iMin) {
                    C1715h c1715h = (C1715h) dVar2.f4403l[iB];
                    c1231f.invoke(c1715h);
                    i7 += c1715h.f13093b;
                    iB++;
                }
                this.f141n = c1121w2;
                return;
            }
            throw new IllegalArgumentException(("toIndex (" + iMin + ") should be not smaller than fromIndex (" + i5 + ')').toString());
        }
        throw new IllegalStateException("negative nearestRange.first");
    }

    public C0010k() {
        this.f139l = 4;
        this.f141n = new K.d(new C1715h[16]);
    }

    public C0010k(O0 o02) {
        this.f139l = 0;
        this.f141n = o02;
    }

    public C0010k(int i5) {
        this.f139l = 3;
        this.f141n = new Object[i5 * 2];
        this.f140m = 0;
    }
}

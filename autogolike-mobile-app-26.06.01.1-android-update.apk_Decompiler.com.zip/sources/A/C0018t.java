package A;

/* JADX INFO: renamed from: A.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0018t extends U3.k implements T3.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ C0013n f165l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ int f166m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0018t(C0013n c0013n, int i5) {
        super(0);
        this.f165l = c0013n;
        this.f166m = i5;
    }

    @Override // T3.a
    public final Object b() {
        return Integer.valueOf(((C0.I) this.f165l.f148e).e(this.f166m));
    }
}

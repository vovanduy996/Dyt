package A;

/* JADX INFO: renamed from: A.s, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0017s extends U3.k implements T3.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ C0013n f160l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ int f161m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ int f162n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ T f163o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ Object f164p;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0017s(C0013n c0013n, int i5, int i6, T t5, G3.i iVar) {
        super(0);
        this.f160l = c0013n;
        this.f161m = i5;
        this.f162n = i6;
        this.f163o = t5;
        this.f164p = iVar;
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [G3.i, java.lang.Object] */
    @Override // T3.a
    public final Object b() {
        int iIntValue = ((Number) this.f164p.getValue()).intValue();
        T t5 = this.f163o;
        boolean z3 = t5.e() == 1;
        C0013n c0013n = this.f160l;
        C0.I i5 = (C0.I) c0013n.f148e;
        int i6 = this.f161m;
        long jK = i5.k(i6);
        int i7 = C0.K.f756c;
        int iH = (int) (jK >> 32);
        int iE = i5.e(iH);
        int i8 = i5.f747b.f799f;
        if (iE != iIntValue) {
            iH = iIntValue >= i8 ? i5.h(i8 - 1) : i5.h(iIntValue);
        }
        int iD = (int) (jK & 4294967295L);
        if (i5.e(iD) != iIntValue) {
            iD = iIntValue >= i8 ? i5.d(i8 - 1, false) : i5.d(iIntValue, false);
        }
        int i9 = this.f162n;
        if (iH == i9) {
            return c0013n.a(iD);
        }
        if (iD == i9) {
            return c0013n.a(iH);
        }
        if (!(t5.f46b ^ z3) ? i6 >= iH : i6 > iD) {
            iH = iD;
        }
        return c0013n.a(iH);
    }
}

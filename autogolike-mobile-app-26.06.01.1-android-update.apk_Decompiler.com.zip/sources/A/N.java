package A;

import com.autogolike.mobile.core.backup.ConfigBackupDto;

/* JADX INFO: loaded from: classes.dex */
public final class N extends U3.k implements T3.a {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final N f37m = new N(0, 0);

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final N f38n = new N(0, 1);

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f39l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ N(int i5, int i6) {
        super(i5);
        this.f39l = i6;
    }

    @Override // T3.a
    public final Object b() {
        switch (this.f39l) {
            case ConfigBackupDto.$stable /* 0 */:
                return null;
            default:
                return j0.f138b;
        }
    }
}

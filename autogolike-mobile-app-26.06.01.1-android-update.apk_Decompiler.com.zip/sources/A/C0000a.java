package A;

import I.C0234d;
import I.C0258p;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import m.B0;
import n.C1418b;
import r0.AbstractC1655U;
import r0.C1658X;
import s.C1702M;
import u0.AbstractC1864f0;
import w1.C2006k;

/* JADX INFO: renamed from: A.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0000a extends U3.k implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f83l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ T3.e f84m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ int f85n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ Object f86o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ Object f87p;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0000a(Q.a aVar, Object obj, Object obj2, int i5) {
        super(2);
        this.f83l = 1;
        this.f84m = aVar;
        this.f86o = obj;
        this.f87p = obj2;
        this.f85n = i5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        switch (this.f83l) {
            case ConfigBackupDto.$stable /* 0 */:
                ((Number) obj2).intValue();
                int iU = C0234d.U(this.f85n | 1);
                U.d dVar = (U.d) this.f87p;
                Q.a aVar = (Q.a) this.f84m;
                E4.d.g((InterfaceC0012m) this.f86o, dVar, aVar, (C0258p) obj, iU);
                break;
            case 1:
                ((Number) obj2).intValue();
                int iU2 = C0234d.U(this.f85n) | 1;
                Object obj3 = this.f86o;
                Object obj4 = this.f87p;
                ((Q.a) this.f84m).c(obj3, obj4, (C0258p) obj, iU2);
                break;
            case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                ((Number) obj2).intValue();
                int iU3 = C0234d.U(this.f85n | 1);
                Q.a aVar2 = (Q.a) this.f84m;
                ((R.i) this.f86o).e(this.f87p, aVar2, (C0258p) obj, iU3);
                break;
            case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                ((Number) obj2).intValue();
                int iU4 = C0234d.U(this.f85n | 1);
                Q.a aVar3 = (Q.a) this.f84m;
                X2.g.f((T3.a) this.f86o, (R0.w) this.f87p, aVar3, (C0258p) obj, iU4);
                break;
            case k1.h.LONG_FIELD_NUMBER /* 4 */:
                ((Number) obj2).intValue();
                int iU5 = C0234d.U(this.f85n | 1);
                Q.a aVar4 = (Q.a) this.f84m;
                n.q.a((C1418b) this.f86o, (U.q) this.f87p, aVar4, (C0258p) obj, iU5);
                break;
            case k1.h.STRING_FIELD_NUMBER /* 5 */:
                ((Number) obj2).intValue();
                int iU6 = C0234d.U(this.f85n | 1);
                T3.e eVar = this.f84m;
                AbstractC1655U.b((C1658X) this.f86o, (U.q) this.f87p, eVar, (C0258p) obj, iU6);
                break;
            case k1.h.STRING_SET_FIELD_NUMBER /* 6 */:
                ((Number) obj2).intValue();
                int iU7 = C0234d.U(this.f85n | 1);
                Q.a aVar5 = (Q.a) this.f84m;
                ((C1702M) this.f86o).e(this.f87p, aVar5, (C0258p) obj, iU7);
                break;
            case k1.h.DOUBLE_FIELD_NUMBER /* 7 */:
                ((Number) obj2).intValue();
                int iU8 = C0234d.U(this.f85n | 1);
                AbstractC1864f0.a((t0.g0) this.f86o, (u0.W) this.f87p, (Q.a) this.f84m, (C0258p) obj, iU8);
                break;
            case 8:
                ((Number) obj2).intValue();
                int iU9 = C0234d.U(this.f85n | 1);
                Y y5 = (Y) this.f87p;
                Q.a aVar6 = (Q.a) this.f84m;
                w.O.d((U.q) this.f86o, y5, aVar6, (C0258p) obj, iU9);
                break;
            default:
                ((Number) obj2).intValue();
                int iU10 = C0234d.U(this.f85n | 1);
                Q.a aVar7 = (Q.a) this.f84m;
                B0.e((C2006k) this.f86o, (R.i) this.f87p, aVar7, (C0258p) obj, iU10);
                break;
        }
        return G3.C.a;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0000a(Object obj, Object obj2, T3.e eVar, int i5, int i6) {
        super(2);
        this.f83l = i6;
        this.f86o = obj;
        this.f87p = obj2;
        this.f84m = eVar;
        this.f85n = i5;
    }
}

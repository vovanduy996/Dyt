package A;

import a0.C0492c;
import com.google.android.gms.internal.measurement.AbstractC0813y0;
import l.AbstractC1297i;

/* JADX INFO: loaded from: classes.dex */
public final class D {
    public final w.G a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f8b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f9c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f10d;

    public D(w.G g3, long j5, int i5, boolean z3) {
        this.a = g3;
        this.f8b = j5;
        this.f9c = i5;
        this.f10d = z3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof D)) {
            return false;
        }
        D d3 = (D) obj;
        return this.a == d3.a && C0492c.b(this.f8b, d3.f8b) && this.f9c == d3.f9c && this.f10d == d3.f10d;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f10d) + ((AbstractC1297i.c(this.f9c) + AbstractC0813y0.e(this.a.hashCode() * 31, 31, this.f8b)) * 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("SelectionHandleInfo(handle=");
        sb.append(this.a);
        sb.append(", position=");
        sb.append((Object) C0492c.j(this.f8b));
        sb.append(", anchor=");
        int i5 = this.f9c;
        sb.append(i5 != 1 ? i5 != 2 ? i5 != 3 ? "null" : "Right" : "Middle" : "Left");
        sb.append(", visible=");
        sb.append(this.f10d);
        sb.append(')');
        return sb.toString();
    }
}

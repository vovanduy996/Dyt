package A;

import a0.C0495f;
import android.graphics.PorterDuffColorFilter;
import android.os.Build;
import b0.C0589g;
import b0.C0595m;
import b0.C0596n;

/* JADX INFO: renamed from: A.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0008i extends U3.k implements T3.c {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ long f134l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ T3.a f135m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ boolean f136n;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0008i(long j5, T3.a aVar, boolean z3) {
        super(1);
        this.f134l = j5;
        this.f135m = aVar;
        this.f136n = z3;
    }

    @Override // T3.c
    public final Object invoke(Object obj) {
        Y.c cVar = (Y.c) obj;
        C0589g c0589gD = E4.d.D(cVar, C0495f.d(cVar.f7034l.f()) / 2.0f);
        int i5 = Build.VERSION.SDK_INT;
        long j5 = this.f134l;
        return cVar.b(new C0007h(this.f135m, this.f136n, c0589gD, new C0595m(j5, 5, i5 >= 29 ? C0596n.a.a(j5, 5) : new PorterDuffColorFilter(b0.N.E(j5), b0.N.H(5)))));
    }
}

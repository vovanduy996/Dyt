package A;

import H0.AbstractC0182o;
import H0.InterfaceC0181n;
import I.C0234d;
import I.C0250l;
import I.C0258p;
import I.InterfaceC0233c0;
import I.Y0;
import a0.C0492c;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import l.C1306o;
import r0.AbstractC1650O;
import r0.InterfaceC1641F;
import r0.InterfaceC1644I;
import u0.AbstractC1864f0;
import w.o0;

/* JADX INFO: loaded from: classes.dex */
public final class g0 extends U3.k implements T3.f {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f128l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Object f129m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ g0(int i5, Object obj) {
        super(3);
        this.f128l = i5;
        this.f129m = obj;
    }

    @Override // T3.f
    public final Object h(Object obj, Object obj2, Object obj3) {
        H3.x xVar = H3.x.f3465l;
        I.W w5 = C0250l.a;
        int i5 = 0;
        Object obj4 = this.f129m;
        switch (this.f128l) {
            case ConfigBackupDto.$stable /* 0 */:
                U.q qVar = (U.q) obj;
                C0258p c0258p = (C0258p) obj2;
                ((Number) obj3).intValue();
                c0258p.Q(1980580247);
                O0.b bVar = (O0.b) c0258p.k(AbstractC1864f0.f14068f);
                Object objG = c0258p.G();
                if (objG == w5) {
                    objG = C0234d.K(new O0.j(0L), I.W.f3598q);
                    c0258p.a0(objG);
                }
                InterfaceC0233c0 interfaceC0233c0 = (InterfaceC0233c0) objG;
                Y y5 = (Y) obj4;
                boolean zH = c0258p.h(y5);
                Object objG2 = c0258p.G();
                if (zH || objG2 == w5) {
                    objG2 = new d0(y5, 0, interfaceC0233c0);
                    c0258p.a0(objG2);
                }
                T3.a aVar = (T3.a) objG2;
                boolean zF = c0258p.f(bVar);
                Object objG3 = c0258p.G();
                if (zF || objG3 == w5) {
                    objG3 = new f0(bVar, interfaceC0233c0, i);
                    c0258p.a0(objG3);
                }
                C1306o c1306o = M.a;
                U.q qVarB = U.a.b(qVar, new H(aVar, i5, (T3.c) objG3));
                c0258p.p(false);
                return qVarB;
            case 1:
                AbstractC1650O abstractC1650OB = ((InterfaceC1641F) obj2).b(((O0.a) obj3).a);
                return ((InterfaceC1644I) obj).M(abstractC1650OB.f12944l, abstractC1650OB.f12945m, xVar, new C0021w(abstractC1650OB, 22, (k.u) obj4));
            case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                long j5 = ((C0492c) obj3).a;
                ((T3.c) obj4).invoke(new C0492c(((n0.s) obj2).f11963c));
                return G3.C.a;
            case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                long j6 = ((O0.a) obj3).a;
                long j7 = ((o0) obj4).f14820f;
                AbstractC1650O abstractC1650OB2 = ((InterfaceC1641F) obj2).b(O0.a.a(j6, E4.l.o0((int) (j7 >> 32), O0.a.j(j6), O0.a.h(j6)), 0, E4.l.o0((int) (j7 & 4294967295L), O0.a.i(j6), O0.a.g(j6)), 0, 10));
                return ((InterfaceC1644I) obj).M(abstractC1650OB2.f12944l, abstractC1650OB2.f12945m, xVar, new R0.n(abstractC1650OB2, 9));
            default:
                C0258p c0258p2 = (C0258p) obj2;
                ((Number) obj3).intValue();
                c0258p2.Q(1582736677);
                O0.b bVar2 = (O0.b) c0258p2.k(AbstractC1864f0.f14068f);
                InterfaceC0181n interfaceC0181n = (InterfaceC0181n) c0258p2.k(AbstractC1864f0.f14071i);
                O0.k kVar = (O0.k) c0258p2.k(AbstractC1864f0.f14074l);
                C0.L l4 = (C0.L) obj4;
                boolean zF2 = c0258p2.f(l4) | c0258p2.f(kVar);
                Object objG4 = c0258p2.G();
                if (zF2 || objG4 == w5) {
                    objG4 = E4.d.R(l4, kVar);
                    c0258p2.a0(objG4);
                }
                C0.L l5 = (C0.L) objG4;
                boolean zF3 = c0258p2.f(interfaceC0181n) | c0258p2.f(l5);
                Object objG5 = c0258p2.G();
                if (zF3 || objG5 == w5) {
                    C0.D d3 = l5.a;
                    AbstractC0182o abstractC0182o = d3.f722f;
                    H0.z zVar = d3.f719c;
                    if (zVar == null) {
                        zVar = H0.z.f2956p;
                    }
                    H0.v vVar = d3.f720d;
                    int i6 = vVar != null ? vVar.a : 0;
                    H0.w wVar = d3.f721e;
                    objG5 = ((H0.p) interfaceC0181n).b(abstractC0182o, zVar, i6, wVar != null ? wVar.a : 1);
                    c0258p2.a0(objG5);
                }
                Y0 y02 = (Y0) objG5;
                Object objG6 = c0258p2.G();
                Object obj5 = objG6;
                if (objG6 == w5) {
                    Object value = y02.getValue();
                    o0 o0Var = new o0();
                    o0Var.a = kVar;
                    o0Var.f14816b = bVar2;
                    o0Var.f14817c = interfaceC0181n;
                    o0Var.f14818d = l4;
                    o0Var.f14819e = value;
                    o0Var.f14820f = w.d0.a(l4, bVar2, interfaceC0181n, w.d0.a, 1);
                    c0258p2.a0(o0Var);
                    obj5 = o0Var;
                }
                o0 o0Var2 = (o0) obj5;
                Object value2 = y02.getValue();
                if (kVar != o0Var2.a || !U3.j.a(bVar2, o0Var2.f14816b) || !U3.j.a(interfaceC0181n, o0Var2.f14817c) || !U3.j.a(l5, o0Var2.f14818d) || !U3.j.a(value2, o0Var2.f14819e)) {
                    o0Var2.a = kVar;
                    o0Var2.f14816b = bVar2;
                    o0Var2.f14817c = interfaceC0181n;
                    o0Var2.f14818d = l5;
                    o0Var2.f14819e = value2;
                    o0Var2.f14820f = w.d0.a(l5, bVar2, interfaceC0181n, w.d0.a, 1);
                }
                boolean zH2 = c0258p2.h(o0Var2);
                Object objG7 = c0258p2.G();
                if (zH2 || objG7 == w5) {
                    objG7 = new g0(3, o0Var2);
                    c0258p2.a0(objG7);
                }
                U.q qVarB2 = androidx.compose.ui.layout.a.b((T3.f) objG7);
                c0258p2.p(false);
                return qVarB2;
        }
    }
}

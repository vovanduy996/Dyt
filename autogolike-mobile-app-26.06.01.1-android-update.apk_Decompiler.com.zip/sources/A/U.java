package A;

import C0.C0052g;
import I0.C0279a;
import I0.InterfaceC0287i;
import java.util.List;
import l3.AbstractC1324b;
import w.p0;

/* JADX INFO: loaded from: classes.dex */
public final class U {
    public final C0052g a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f49b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final C0.I f50c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final I0.t f51d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final h0 f52e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public long f53f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final C0052g f54g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final I0.A f55h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final p0 f56i;

    public U(I0.A a, I0.t tVar, p0 p0Var, h0 h0Var) {
        C0052g c0052g = a.a;
        C0.I i5 = p0Var != null ? p0Var.a : null;
        long j5 = a.f3798b;
        this.a = c0052g;
        this.f49b = j5;
        this.f50c = i5;
        this.f51d = tVar;
        this.f52e = h0Var;
        this.f53f = j5;
        this.f54g = c0052g;
        this.f55h = a;
        this.f56i = p0Var;
    }

    public final List a(T3.c cVar) {
        if (!C0.K.b(this.f53f)) {
            return H3.n.S0(new C0279a("", 0), new I0.z(C0.K.e(this.f53f), C0.K.e(this.f53f)));
        }
        InterfaceC0287i interfaceC0287i = (InterfaceC0287i) cVar.invoke(this);
        if (interfaceC0287i != null) {
            return E4.l.E0(interfaceC0287i);
        }
        return null;
    }

    public final Integer b() {
        C0.I i5 = this.f50c;
        if (i5 == null) {
            return null;
        }
        int iD = C0.K.d(this.f53f);
        I0.t tVar = this.f51d;
        return Integer.valueOf(tVar.c(i5.d(i5.e(tVar.h(iD)), true)));
    }

    public final Integer c() {
        C0.I i5 = this.f50c;
        if (i5 == null) {
            return null;
        }
        int iE = C0.K.e(this.f53f);
        I0.t tVar = this.f51d;
        return Integer.valueOf(tVar.c(i5.h(i5.e(tVar.h(iE)))));
    }

    public final Integer d() {
        int length;
        C0.I i5 = this.f50c;
        if (i5 == null) {
            return null;
        }
        int iQ = q();
        while (true) {
            C0052g c0052g = this.a;
            if (iQ < c0052g.a.length()) {
                int length2 = this.f54g.a.length() - 1;
                if (iQ <= length2) {
                    length2 = iQ;
                }
                long jK = i5.k(length2);
                int i6 = C0.K.f756c;
                int i7 = (int) (jK & 4294967295L);
                if (i7 > iQ) {
                    length = this.f51d.c(i7);
                    break;
                }
                iQ++;
            } else {
                length = c0052g.a.length();
                break;
            }
        }
        return Integer.valueOf(length);
    }

    public final Integer e() {
        int iC;
        C0.I i5 = this.f50c;
        if (i5 == null) {
            return null;
        }
        int iQ = q();
        while (true) {
            if (iQ <= 0) {
                iC = 0;
                break;
            }
            int length = this.f54g.a.length() - 1;
            if (iQ <= length) {
                length = iQ;
            }
            long jK = i5.k(length);
            int i6 = C0.K.f756c;
            int i7 = (int) (jK >> 32);
            if (i7 < iQ) {
                iC = this.f51d.c(i7);
                break;
            }
            iQ--;
        }
        return Integer.valueOf(iC);
    }

    public final boolean f() {
        C0.I i5 = this.f50c;
        return (i5 != null ? i5.i(q()) : null) != N0.h.f5028m;
    }

    public final int g(C0.I i5, int i6) {
        int iQ = q();
        h0 h0Var = this.f52e;
        if (h0Var.a == null) {
            h0Var.a = Float.valueOf(i5.c(iQ).a);
        }
        int iE = i5.e(iQ) + i6;
        if (iE < 0) {
            return 0;
        }
        C0.o oVar = i5.f747b;
        if (iE >= oVar.f799f) {
            return this.f54g.a.length();
        }
        float fB = oVar.b(iE) - 1;
        Float f5 = h0Var.a;
        U3.j.c(f5);
        float fFloatValue = f5.floatValue();
        if ((f() && fFloatValue >= i5.g(iE)) || (!f() && fFloatValue <= i5.f(iE))) {
            return i5.d(iE, true);
        }
        return this.f51d.c(oVar.e(X2.g.l(f5.floatValue(), fB)));
    }

    /* JADX WARN: Removed duplicated region for block: B:9:0x0011  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final int h(w.p0 r6, int r7) {
        /*
            r5 = this;
            r0.q r0 = r6.f14837b
            if (r0 == 0) goto L11
            r0.q r1 = r6.f14838c
            if (r1 == 0) goto Le
            r2 = 1
            a0.d r0 = r1.A(r0, r2)
            goto Lf
        Le:
            r0 = 0
        Lf:
            if (r0 != 0) goto L13
        L11:
            a0.d r0 = a0.C0493d.f7215e
        L13:
            I0.A r1 = r5.f55h
            long r1 = r1.f3798b
            int r3 = C0.K.f756c
            r3 = 4294967295(0xffffffff, double:2.1219957905E-314)
            long r1 = r1 & r3
            int r1 = (int) r1
            I0.t r2 = r5.f51d
            int r1 = r2.h(r1)
            C0.I r6 = r6.a
            a0.d r1 = r6.c(r1)
            float r3 = r0.c()
            float r0 = r0.b()
            long r3 = l3.AbstractC1324b.d(r3, r0)
            float r0 = a0.C0495f.b(r3)
            float r7 = (float) r7
            float r0 = r0 * r7
            float r7 = r1.f7216b
            float r0 = r0 + r7
            float r7 = r1.a
            long r0 = X2.g.l(r7, r0)
            C0.o r6 = r6.f747b
            int r6 = r6.e(r0)
            int r6 = r2.c(r6)
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: A.U.h(w.p0, int):int");
    }

    public final void i() {
        C0052g c0052g = this.f54g;
        h0 h0Var = this.f52e;
        h0Var.a = null;
        if (c0052g.a.length() > 0) {
            if (f()) {
                h0Var.a = null;
                if (c0052g.a.length() > 0) {
                    String str = c0052g.a;
                    long j5 = this.f53f;
                    int i5 = C0.K.f756c;
                    int iO = w.O.o(str, (int) (j5 & 4294967295L));
                    if (iO != -1) {
                        p(iO, iO);
                        return;
                    }
                    return;
                }
                return;
            }
            h0Var.a = null;
            if (c0052g.a.length() > 0) {
                String str2 = c0052g.a;
                long j6 = this.f53f;
                int i6 = C0.K.f756c;
                int iL = w.O.l(str2, (int) (j6 & 4294967295L));
                if (iL != -1) {
                    p(iL, iL);
                }
            }
        }
    }

    public final void j() {
        this.f52e.a = null;
        C0052g c0052g = this.f54g;
        if (c0052g.a.length() > 0) {
            int iD = C0.K.d(this.f53f);
            String str = c0052g.a;
            int iM = w.O.m(str, iD);
            if (iM == C0.K.d(this.f53f) && iM != str.length()) {
                iM = w.O.m(str, iM + 1);
            }
            p(iM, iM);
        }
    }

    public final void k() {
        this.f52e.a = null;
        C0052g c0052g = this.f54g;
        if (c0052g.a.length() > 0) {
            int iE = C0.K.e(this.f53f);
            String str = c0052g.a;
            int iN = w.O.n(str, iE);
            if (iN == C0.K.e(this.f53f) && iN != 0) {
                iN = w.O.n(str, iN - 1);
            }
            p(iN, iN);
        }
    }

    public final void l() {
        C0052g c0052g = this.f54g;
        h0 h0Var = this.f52e;
        h0Var.a = null;
        if (c0052g.a.length() > 0) {
            if (f()) {
                h0Var.a = null;
                if (c0052g.a.length() > 0) {
                    String str = c0052g.a;
                    long j5 = this.f53f;
                    int i5 = C0.K.f756c;
                    int iL = w.O.l(str, (int) (j5 & 4294967295L));
                    if (iL != -1) {
                        p(iL, iL);
                        return;
                    }
                    return;
                }
                return;
            }
            h0Var.a = null;
            if (c0052g.a.length() > 0) {
                String str2 = c0052g.a;
                long j6 = this.f53f;
                int i6 = C0.K.f756c;
                int iO = w.O.o(str2, (int) (j6 & 4294967295L));
                if (iO != -1) {
                    p(iO, iO);
                }
            }
        }
    }

    public final void m() {
        Integer numB;
        this.f52e.a = null;
        if (this.f54g.a.length() <= 0 || (numB = b()) == null) {
            return;
        }
        int iIntValue = numB.intValue();
        p(iIntValue, iIntValue);
    }

    public final void n() {
        Integer numC;
        this.f52e.a = null;
        if (this.f54g.a.length() <= 0 || (numC = c()) == null) {
            return;
        }
        int iIntValue = numC.intValue();
        p(iIntValue, iIntValue);
    }

    public final void o() {
        if (this.f54g.a.length() > 0) {
            int i5 = C0.K.f756c;
            this.f53f = AbstractC1324b.f((int) (this.f49b >> 32), (int) (this.f53f & 4294967295L));
        }
    }

    public final void p(int i5, int i6) {
        this.f53f = AbstractC1324b.f(i5, i6);
    }

    public final int q() {
        long j5 = this.f53f;
        int i5 = C0.K.f756c;
        return this.f51d.h((int) (j5 & 4294967295L));
    }
}

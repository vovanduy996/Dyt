package A;

import com.autogolike.mobile.core.backup.ConfigBackupDto;
import l3.AbstractC1324b;

/* JADX INFO: loaded from: classes.dex */
public final class r implements InterfaceC0009j {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final r f154b = new r(0);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final r f155c = new r(1);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final C0016q f156d = new C0016q(0);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final C0016q f157e = new C0016q(1);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final C0016q f158f = new C0016q(2);

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final C0016q f159g = new C0016q(3);
    public final /* synthetic */ int a;

    public /* synthetic */ r(int i5) {
        this.a = i5;
    }

    @Override // A.InterfaceC0009j
    public long a(C0013n c0013n, int i5) {
        switch (this.a) {
            case ConfigBackupDto.$stable /* 0 */:
                String str = ((C0.I) c0013n.f148e).a.a.a;
                return AbstractC1324b.f(w.O.n(str, i5), w.O.m(str, i5));
            default:
                return ((C0.I) c0013n.f148e).k(i5);
        }
    }
}

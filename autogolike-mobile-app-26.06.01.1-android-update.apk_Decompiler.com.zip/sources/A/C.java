package A;

import G3.AbstractC0164a;
import kotlin.coroutines.Continuation;
import n0.C1434C;

/* JADX INFO: loaded from: classes.dex */
public final class C extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f5p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f6q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ T3.c f7r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C(T3.c cVar, Continuation continuation) {
        super(2, continuation);
        this.f7r = cVar;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C) m((C1434C) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C c5 = new C(this.f7r, continuation);
        c5.f6q = obj;
        return c5;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f5p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            C1434C c1434c = (C1434C) this.f6q;
            B b3 = new B(this.f7r, null);
            this.f5p = 1;
            if (c1434c.A0(b3, this) == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return G3.C.a;
    }
}

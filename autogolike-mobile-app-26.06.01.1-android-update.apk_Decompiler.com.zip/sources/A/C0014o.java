package A;

import l.AbstractC1297i;

/* JADX INFO: renamed from: A.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0014o {
    public final N0.h a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f149b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f150c;

    public C0014o(N0.h hVar, int i5, long j5) {
        this.a = hVar;
        this.f149b = i5;
        this.f150c = j5;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0014o)) {
            return false;
        }
        C0014o c0014o = (C0014o) obj;
        return this.a == c0014o.a && this.f149b == c0014o.f149b && this.f150c == c0014o.f150c;
    }

    public final int hashCode() {
        return Long.hashCode(this.f150c) + AbstractC1297i.b(this.f149b, this.a.hashCode() * 31, 31);
    }

    public final String toString() {
        return "AnchorInfo(direction=" + this.a + ", offset=" + this.f149b + ", selectableId=" + this.f150c + ')';
    }
}

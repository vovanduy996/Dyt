package A;

import a0.C0492c;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import n0.AbstractC1451q;

/* JADX INFO: loaded from: classes.dex */
public final class A extends U3.k implements T3.c {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f0l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ w.a0 f1m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ A(w.a0 a0Var, int i5) {
        super(1);
        this.f0l = i5;
        this.f1m = a0Var;
    }

    @Override // T3.c
    public final Object invoke(Object obj) {
        switch (this.f0l) {
            case ConfigBackupDto.$stable /* 0 */:
                n0.s sVar = (n0.s) obj;
                this.f1m.d(AbstractC1451q.h(sVar, false));
                sVar.a();
                break;
            default:
                this.f1m.c(((C0492c) obj).a);
                break;
        }
        return G3.C.a;
    }
}

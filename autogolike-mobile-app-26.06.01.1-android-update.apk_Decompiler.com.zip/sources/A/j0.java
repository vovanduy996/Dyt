package A;

import I.C0277z;
import b0.C0603v;

/* JADX INFO: loaded from: classes.dex */
public abstract class j0 {
    public static final C0277z a = new C0277z(I.W.f3598q, N.f38n);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final i0 f138b;

    static {
        long jD = b0.N.d(4282550004L);
        f138b = new i0(jD, C0603v.b(0.4f, jD));
    }
}

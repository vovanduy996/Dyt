package A;

/* JADX INFO: renamed from: A.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0011l implements R0.E {
    public final U.d a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final InterfaceC0012m f143b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public long f144c = 0;

    public C0011l(U.d dVar, InterfaceC0012m interfaceC0012m) {
        this.a = dVar;
        this.f143b = interfaceC0012m;
    }

    @Override // R0.E
    public final long a(O0.i iVar, long j5, O0.k kVar, long j6) {
        long jA = this.f143b.a();
        if (!X2.g.P(jA)) {
            jA = this.f144c;
        }
        this.f144c = jA;
        return O0.h.c(O0.h.c(E4.d.h(iVar.a, iVar.f5348b), E4.d.S(jA)), this.a.a(j6, 0L, kVar));
    }
}

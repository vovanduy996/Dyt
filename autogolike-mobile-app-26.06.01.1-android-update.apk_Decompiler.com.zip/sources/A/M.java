package A;

import a0.C0492c;
import l.C0;
import l.C1294g0;
import l.C1306o;
import l.D0;

/* JADX INFO: loaded from: classes.dex */
public abstract class M {
    public static final C1306o a = new C1306o(Float.NaN, Float.NaN);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final C0 f34b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final long f35c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final C1294g0 f36d;

    static {
        F f5 = F.f13m;
        F f6 = F.f14n;
        C0 c02 = D0.a;
        f34b = new C0(f5, f6);
        long jL = X2.g.l(0.01f, 0.01f);
        f35c = jL;
        f36d = new C1294g0(new C0492c(jL));
    }
}

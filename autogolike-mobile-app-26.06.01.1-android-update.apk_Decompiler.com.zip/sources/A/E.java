package A;

/* JADX INFO: loaded from: classes.dex */
public abstract class E {
    public static final float a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final float f11b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final A0.u f12c = new A0.u("SelectionHandleInfo");

    static {
        float f5 = 25;
        a = f5;
        f11b = f5;
    }
}

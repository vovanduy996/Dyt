package A;

import com.autogolike.mobile.core.backup.ConfigBackupDto;
import l.C1304m;

/* JADX INFO: loaded from: classes.dex */
public final class G extends U3.k implements T3.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f17l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ C1304m f18m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ G(int i5, C1304m c1304m) {
        super(0);
        this.f17l = i5;
        this.f18m = c1304m;
    }

    @Override // T3.a
    public final Object b() {
        switch (this.f17l) {
            case ConfigBackupDto.$stable /* 0 */:
                break;
            case 1:
                this.f18m.f11312q = false;
                break;
            default:
                this.f18m.f11312q = false;
                break;
        }
        return G3.C.a;
    }
}

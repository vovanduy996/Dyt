package A;

import com.autogolike.mobile.core.backup.ConfigBackupDto;
import java.util.ArrayList;
import r0.AbstractC1649N;
import r0.AbstractC1650O;

/* JADX INFO: loaded from: classes.dex */
public final class P extends U3.k implements T3.c {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f40l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ ArrayList f41m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ P(int i5, ArrayList arrayList) {
        super(1);
        this.f40l = i5;
        this.f41m = arrayList;
    }

    @Override // T3.c
    public final Object invoke(Object obj) {
        switch (this.f40l) {
            case ConfigBackupDto.$stable /* 0 */:
                AbstractC1649N abstractC1649N = (AbstractC1649N) obj;
                ArrayList arrayList = this.f41m;
                int size = arrayList.size();
                for (int i5 = 0; i5 < size; i5++) {
                    AbstractC1649N.d(abstractC1649N, (AbstractC1650O) arrayList.get(i5), 0, 0);
                }
                break;
            case 1:
                AbstractC1649N abstractC1649N2 = (AbstractC1649N) obj;
                ArrayList arrayList2 = this.f41m;
                int size2 = arrayList2.size();
                for (int i6 = 0; i6 < size2; i6++) {
                    AbstractC1649N.f(abstractC1649N2, (AbstractC1650O) arrayList2.get(i6), 0, 0);
                }
                break;
            case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                AbstractC1649N abstractC1649N3 = (AbstractC1649N) obj;
                ArrayList arrayList3 = this.f41m;
                int iR0 = H3.n.R0(arrayList3);
                if (iR0 >= 0) {
                    int i7 = 0;
                    while (true) {
                        AbstractC1649N.f(abstractC1649N3, (AbstractC1650O) arrayList3.get(i7), 0, 0);
                        if (i7 != iR0) {
                            i7++;
                        }
                    }
                }
                break;
            case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                AbstractC1649N abstractC1649N4 = (AbstractC1649N) obj;
                ArrayList arrayList4 = this.f41m;
                int size3 = arrayList4.size();
                for (int i8 = 0; i8 < size3; i8++) {
                    AbstractC1649N.d(abstractC1649N4, (AbstractC1650O) arrayList4.get(i8), 0, 0);
                }
                break;
            default:
                AbstractC1649N abstractC1649N5 = (AbstractC1649N) obj;
                ArrayList arrayList5 = this.f41m;
                int size4 = arrayList5.size();
                for (int i9 = 0; i9 < size4; i9++) {
                    AbstractC1649N.g(abstractC1649N5, (AbstractC1650O) arrayList5.get(i9), 0, 0);
                }
                break;
        }
        return G3.C.a;
    }
}

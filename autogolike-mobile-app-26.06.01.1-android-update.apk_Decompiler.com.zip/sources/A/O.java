package A;

import I.C0277z;

/* JADX INFO: loaded from: classes.dex */
public abstract class O {
    public static final C0277z a = new C0277z(I.W.f3598q, N.f37m);
}

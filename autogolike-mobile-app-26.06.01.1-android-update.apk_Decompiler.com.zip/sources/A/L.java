package A;

import G3.AbstractC0164a;
import I.V0;
import I.Y0;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;
import l.C1285c;

/* JADX INFO: loaded from: classes.dex */
public final class L extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f30p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f31q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ Y0 f32r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ C1285c f33s;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public L(Y0 y02, C1285c c1285c, Continuation continuation) {
        super(2, continuation);
        this.f32r = y02;
        this.f33s = c1285c;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((L) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        L l4 = new L(this.f32r, this.f33s, continuation);
        l4.f31q = obj;
        return l4;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f30p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            InterfaceC0991y interfaceC0991y = (InterfaceC0991y) this.f31q;
            O1.B b3 = new O1.B(new V0(new I(0, this.f32r), null));
            K k5 = new K(this.f33s, 0, interfaceC0991y);
            this.f30p = 1;
            if (b3.d(k5, this) == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return G3.C.a;
    }
}

package A;

import C0.C0052g;
import c0.InterfaceC0638i;
import com.google.firebase.concurrent.ExecutorsRegistrar;
import com.google.firebase.installations.FirebaseInstallationsRegistrar;
import java.util.Set;
import java.util.concurrent.ScheduledExecutorService;
import l.InterfaceC1316z;

/* JADX INFO: renamed from: A.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0016q implements q3.e, I0.I, InterfaceC0638i, InterfaceC1316z {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f153l;

    public /* synthetic */ C0016q(int i5) {
        this.f153l = i5;
    }

    @Override // l.InterfaceC1316z
    public float a(float f5) {
        float f6;
        float f7;
        switch (this.f153l) {
            case 11:
                if (f5 < 0.36363637f) {
                    return 7.5625f * f5 * f5;
                }
                if (f5 < 0.72727275f) {
                    float f8 = f5 - 0.54545456f;
                    f6 = 7.5625f * f8 * f8;
                    f7 = 0.75f;
                } else if (f5 < 0.90909094f) {
                    float f9 = f5 - 0.8181818f;
                    f6 = 7.5625f * f9 * f9;
                    f7 = 0.9375f;
                } else {
                    float f10 = f5 - 0.95454544f;
                    f6 = 7.5625f * f10 * f10;
                    f7 = 0.984375f;
                }
                return f6 + f7;
            default:
                return f5;
        }
    }

    @Override // I0.I
    public I0.G b(C0052g c0052g) {
        return new I0.G(c0052g, I0.s.a);
    }

    @Override // q3.e
    public Object c(C0.q qVar) {
        switch (this.f153l) {
            case k1.h.STRING_SET_FIELD_NUMBER /* 6 */:
                Set setC = qVar.c(q3.r.a(C3.a.class));
                C3.c cVar = C3.c.f964n;
                if (cVar == null) {
                    synchronized (C3.c.class) {
                        try {
                            cVar = C3.c.f964n;
                            if (cVar == null) {
                                cVar = new C3.c(0);
                                C3.c.f964n = cVar;
                            }
                        } finally {
                        }
                        break;
                    }
                }
                return new C3.b(setC, cVar);
            case 17:
                return (ScheduledExecutorService) ExecutorsRegistrar.a.get();
            case 18:
                return (ScheduledExecutorService) ExecutorsRegistrar.f8732c.get();
            case 19:
                return (ScheduledExecutorService) ExecutorsRegistrar.f8731b.get();
            case 20:
                q3.n nVar = ExecutorsRegistrar.a;
                return r3.k.f13035l;
            default:
                return FirebaseInstallationsRegistrar.lambda$getComponents$0(qVar);
        }
    }

    @Override // c0.InterfaceC0638i
    public double d(double d3) {
        double d5;
        switch (this.f153l) {
            case 8:
                double dPow = d3 < 0.0d ? -d3 : d3;
                if (dPow >= 0.0031308049535603718d) {
                    dPow = Math.pow(dPow, 0.4166666666666667d) - 0.05213270142180095d;
                    d5 = 0.9478672985781991d;
                } else {
                    d5 = 0.07739938080495357d;
                }
                return Math.copySign(dPow / d5, d3);
            case 9:
                double d6 = d3 < 0.0d ? -d3 : d3;
                return Math.copySign(d6 >= 0.04045d ? Math.pow((0.9478672985781991d * d6) + 0.05213270142180095d, 2.4d) : d6 * 0.07739938080495357d, d3);
            default:
                return d3;
        }
    }
}

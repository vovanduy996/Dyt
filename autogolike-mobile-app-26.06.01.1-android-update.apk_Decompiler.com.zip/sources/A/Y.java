package A;

import C0.C0047b;
import C0.C0049d;
import C0.C0052g;
import I.C0234d;
import I.C0247j0;
import a0.C0492c;
import android.view.ActionMode;
import f.C0933a;
import j0.InterfaceC1203a;
import java.util.ArrayList;
import l3.AbstractC1324b;
import u0.C1867h;
import u0.InterfaceC1858c0;
import u0.L0;
import w.p0;
import w.q0;
import w.r0;

/* JADX INFO: loaded from: classes.dex */
public final class Y {
    public final q0 a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public I0.t f61b = r0.a;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public U3.k f62c = F.f15o;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public w.S f63d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final C0247j0 f64e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public I0.I f65f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public InterfaceC1858c0 f66g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public L0 f67h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public InterfaceC1203a f68i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public Z.n f69j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final C0247j0 f70k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final C0247j0 f71l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public long f72m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public Integer f73n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public long f74o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final C0247j0 f75p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final C0247j0 f76q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f77r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public I0.A f78s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public T f79t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final V f80u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final C3.c f81v;

    public Y(q0 q0Var) {
        this.a = q0Var;
        I0.A a = new I0.A(0L, (String) null, 7);
        I.W w5 = I.W.f3598q;
        this.f64e = C0234d.K(a, w5);
        this.f65f = I0.H.f3822l;
        Boolean bool = Boolean.TRUE;
        this.f70k = C0234d.K(bool, w5);
        this.f71l = C0234d.K(bool, w5);
        this.f72m = 0L;
        this.f74o = 0L;
        this.f75p = C0234d.K(null, w5);
        this.f76q = C0234d.K(null, w5);
        this.f77r = -1;
        this.f78s = new I0.A(0L, (String) null, 7);
        int i5 = 1;
        this.f80u = new V(this, i5);
        this.f81v = new C3.c(i5, this);
    }

    /* JADX WARN: Removed duplicated region for block: B:64:0x0133  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x013a  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x015d  */
    /* JADX WARN: Removed duplicated region for block: B:80:0x0160  */
    /* JADX WARN: Type inference failed for: r4v5, types: [T3.c, U3.k] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final long a(A.Y r23, I0.A r24, long r25, boolean r27, boolean r28, A.C0016q r29, boolean r30) {
        /*
            Method dump skipped, instruction units count: 798
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: A.Y.a(A.Y, I0.A, long, boolean, boolean, A.q, boolean):long");
    }

    public static I0.A c(C0052g c0052g, long j5) {
        return new I0.A(c0052g, j5, (C0.K) null);
    }

    /* JADX WARN: Type inference failed for: r0v7, types: [T3.c, U3.k] */
    public final void b(boolean z3) {
        if (C0.K.b(j().f3798b)) {
            return;
        }
        InterfaceC1858c0 interfaceC1858c0 = this.f66g;
        if (interfaceC1858c0 != null) {
            ((C1867h) interfaceC1858c0).a(AbstractC1324b.x(j()));
        }
        if (z3) {
            int iD = C0.K.d(j().f3798b);
            this.f62c.invoke(c(j().a, AbstractC1324b.f(iD, iD)));
            n(w.H.f14593l);
        }
    }

    /* JADX WARN: Type inference failed for: r1v10, types: [T3.c, U3.k] */
    public final void d() {
        if (C0.K.b(j().f3798b)) {
            return;
        }
        InterfaceC1858c0 interfaceC1858c0 = this.f66g;
        if (interfaceC1858c0 != null) {
            ((C1867h) interfaceC1858c0).a(AbstractC1324b.x(j()));
        }
        C0052g c0052gZ = AbstractC1324b.z(j(), j().a.a.length());
        C0052g c0052gY = AbstractC1324b.y(j(), j().a.a.length());
        C0049d c0049d = new C0049d(c0052gZ);
        c0049d.b(c0052gY);
        C0052g c0052gC = c0049d.c();
        int iE = C0.K.e(j().f3798b);
        this.f62c.invoke(c(c0052gC, AbstractC1324b.f(iE, iE)));
        n(w.H.f14593l);
        this.a.f14859f = true;
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [T3.c, U3.k] */
    public final void e(C0492c c0492c) {
        if (!C0.K.b(j().f3798b)) {
            w.S s3 = this.f63d;
            p0 p0VarD = s3 != null ? s3.d() : null;
            int iD = (c0492c == null || p0VarD == null) ? C0.K.d(j().f3798b) : this.f61b.c(p0VarD.b(true, c0492c.a));
            this.f62c.invoke(I0.A.a(j(), null, AbstractC1324b.f(iD, iD), 5));
        }
        n((c0492c == null || j().a.a.length() <= 0) ? w.H.f14593l : w.H.f14595n);
        p(false);
    }

    public final void f(boolean z3) {
        Z.n nVar;
        w.S s3 = this.f63d;
        if (s3 != null && !s3.b() && (nVar = this.f69j) != null) {
            nVar.a(Z.h.f7146p);
        }
        this.f78s = j();
        p(z3);
        n(w.H.f14594m);
    }

    public final C0492c g() {
        return (C0492c) this.f76q.getValue();
    }

    public final boolean h() {
        return ((Boolean) this.f71l.getValue()).booleanValue();
    }

    public final long i(boolean z3) {
        p0 p0VarD;
        long j5;
        w.S s3 = this.f63d;
        if (s3 == null || (p0VarD = s3.d()) == null) {
            return 9205357640488583168L;
        }
        C0.I i5 = p0VarD.a;
        w.S s5 = this.f63d;
        C0052g c0052g = s5 != null ? s5.a.a : null;
        if (c0052g == null) {
            return 9205357640488583168L;
        }
        if (!U3.j.a(c0052g.a, i5.a.a.a)) {
            return 9205357640488583168L;
        }
        I0.A aJ = j();
        if (z3) {
            long j6 = aJ.f3798b;
            int i6 = C0.K.f756c;
            j5 = j6 >> 32;
        } else {
            long j7 = aJ.f3798b;
            int i7 = C0.K.f756c;
            j5 = j7 & 4294967295L;
        }
        int iH = this.f61b.h((int) j5);
        boolean zF = C0.K.f(j().f3798b);
        int iE = i5.e(iH);
        C0.o oVar = i5.f747b;
        if (iE >= oVar.f799f) {
            return 9205357640488583168L;
        }
        boolean z5 = i5.a(((!z3 || zF) && (z3 || !zF)) ? Math.max(iH + (-1), 0) : iH) == i5.i(iH);
        oVar.j(iH);
        int length = ((C0052g) oVar.a.f805c).a.length();
        ArrayList arrayList = oVar.f801h;
        C0.r rVar = (C0.r) arrayList.get(iH == length ? H3.n.R0(arrayList) : C0933a.O(iH, arrayList));
        C0047b c0047b = rVar.a;
        int iB = rVar.b(iH);
        D0.F f5 = c0047b.f764d;
        float fH = z5 ? f5.h(iB, false) : f5.i(iB, false);
        long j8 = i5.f748c;
        return X2.g.l(E4.l.n0(fH, 0.0f, (int) (j8 >> 32)), E4.l.n0(oVar.b(iE), 0.0f, (int) (j8 & 4294967295L)));
    }

    public final I0.A j() {
        return (I0.A) this.f64e.getValue();
    }

    public final void k() {
        L0 l02 = this.f67h;
        if ((l02 != null ? ((u0.S) l02).f13998d : 0) != 1 || l02 == null) {
            return;
        }
        u0.S s3 = (u0.S) l02;
        s3.f13998d = 2;
        ActionMode actionMode = s3.f13996b;
        if (actionMode != null) {
            actionMode.finish();
        }
        s3.f13996b = null;
    }

    /* JADX WARN: Removed duplicated region for block: B:70:0x014a  */
    /* JADX WARN: Type inference failed for: r2v12, types: [T3.c, U3.k] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void l() {
        /*
            Method dump skipped, instruction units count: 790
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: A.Y.l():void");
    }

    /* JADX WARN: Type inference failed for: r1v5, types: [T3.c, U3.k] */
    public final void m() {
        I0.A aC = c(j().a, AbstractC1324b.f(0, j().a.a.length()));
        this.f62c.invoke(aC);
        this.f78s = I0.A.a(this.f78s, null, aC.f3798b, 5);
        f(true);
    }

    public final void n(w.H h2) {
        w.S s3 = this.f63d;
        if (s3 != null) {
            if (s3.a() == h2) {
                s3 = null;
            }
            if (s3 != null) {
                s3.f14627k.setValue(h2);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x0088  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x0190  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void o() {
        /*
            Method dump skipped, instruction units count: 444
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: A.Y.o():void");
    }

    public final void p(boolean z3) {
        w.S s3 = this.f63d;
        if (s3 != null) {
            s3.f14628l.setValue(Boolean.valueOf(z3));
        }
        if (z3) {
            o();
        } else {
            k();
        }
    }
}

package A;

import I.C0234d;
import I.C0258p;
import com.autogolike.mobile.core.backup.ConfigBackupDto;

/* JADX INFO: loaded from: classes.dex */
public final class S extends U3.k implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f42l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ U.q f43m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ Q.a f44n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ int f45o;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ S(U.q qVar, Q.a aVar, int i5, int i6) {
        super(2);
        this.f42l = i6;
        this.f43m = qVar;
        this.f44n = aVar;
        this.f45o = i5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        int i5 = this.f42l;
        C0258p c0258p = (C0258p) obj;
        ((Number) obj2).intValue();
        switch (i5) {
            case ConfigBackupDto.$stable /* 0 */:
                int iU = C0234d.U(this.f45o | 1);
                l0.c.J(this.f43m, this.f44n, c0258p, iU);
                break;
            default:
                int iU2 = C0234d.U(this.f45o | 1);
                X2.g.o(this.f43m, this.f44n, c0258p, iU2);
                break;
        }
        return G3.C.a;
    }
}

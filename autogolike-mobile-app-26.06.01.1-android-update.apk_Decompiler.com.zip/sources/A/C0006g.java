package A;

import I.C0234d;
import I.C0258p;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import l3.AbstractC1324b;

/* JADX INFO: renamed from: A.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0006g extends U3.k implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f123l = 0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ boolean f124m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ int f125n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ Object f126o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ Object f127p;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0006g(U.q qVar, T3.a aVar, boolean z3, int i5) {
        super(2);
        this.f126o = qVar;
        this.f127p = aVar;
        this.f124m = z3;
        this.f125n = i5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        int i5 = this.f123l;
        C0258p c0258p = (C0258p) obj;
        ((Number) obj2).intValue();
        switch (i5) {
            case ConfigBackupDto.$stable /* 0 */:
                int iU = C0234d.U(this.f125n | 1);
                E4.d.o((U.q) this.f126o, (T3.a) this.f127p, this.f124m, c0258p, iU);
                break;
            default:
                int iU2 = C0234d.U(this.f125n | 1);
                AbstractC1324b.e(this.f124m, (N0.h) this.f126o, (Y) this.f127p, c0258p, iU2);
                break;
        }
        return G3.C.a;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0006g(boolean z3, N0.h hVar, Y y5, int i5) {
        super(2);
        this.f124m = z3;
        this.f126o = hVar;
        this.f127p = y5;
        this.f125n = i5;
    }
}

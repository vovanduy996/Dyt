package A;

import G3.AbstractC0164a;
import f4.AbstractC0952A;
import kotlin.coroutines.Continuation;
import n0.C1434C;

/* JADX INFO: loaded from: classes.dex */
public final class a0 extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f88p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f89q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ w.a0 f90r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a0(w.a0 a0Var, Continuation continuation) {
        super(2, continuation);
        this.f90r = a0Var;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((a0) m((C1434C) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        a0 a0Var = new a0(this.f90r, continuation);
        a0Var.f89q = obj;
        return a0Var;
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f88p;
        G3.C c5 = G3.C.a;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            C1434C c1434c = (C1434C) this.f89q;
            this.f88p = 1;
            Object objF = AbstractC0952A.f(new w.V(c1434c, this.f90r, null), this);
            if (objF != aVar) {
                objF = c5;
            }
            if (objF == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return c5;
    }
}

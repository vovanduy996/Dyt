package A;

import F.A0;
import b0.C0589g;
import b0.C0595m;
import com.google.android.gms.internal.measurement.AbstractC0813y0;
import d0.C0823b;
import d0.InterfaceC0825d;

/* JADX INFO: renamed from: A.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0007h extends U3.k implements T3.c {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ T3.a f130l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ boolean f131m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ C0589g f132n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ C0595m f133o;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0007h(T3.a aVar, boolean z3, C0589g c0589g, C0595m c0595m) {
        super(1);
        this.f130l = aVar;
        this.f131m = z3;
        this.f132n = c0589g;
        this.f133o = c0595m;
    }

    @Override // T3.c
    public final Object invoke(Object obj) {
        t0.G g3 = (t0.G) obj;
        g3.b();
        if (((Boolean) this.f130l.b()).booleanValue()) {
            boolean z3 = this.f131m;
            C0595m c0595m = this.f133o;
            C0589g c0589g = this.f132n;
            if (z3) {
                C0823b c0823b = g3.f13469l;
                long jX = c0823b.x();
                A0 a02 = c0823b.f8740m;
                long jO = a02.o();
                a02.i().f();
                try {
                    ((C3.c) a02.f1394m).p(-1.0f, 1.0f, jX);
                    InterfaceC0825d.w(g3, c0589g, c0595m);
                } finally {
                    AbstractC0813y0.t(a02, jO);
                }
            } else {
                InterfaceC0825d.w(g3, c0589g, c0595m);
            }
        }
        return G3.C.a;
    }
}

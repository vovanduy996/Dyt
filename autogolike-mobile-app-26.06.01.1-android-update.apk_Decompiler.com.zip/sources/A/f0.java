package A;

import I.InterfaceC0233c0;
import android.os.Build;
import androidx.compose.foundation.MagnifierElement;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import m.k0;
import m.w0;
import m.y0;

/* JADX INFO: loaded from: classes.dex */
public final class f0 extends U3.k implements T3.c {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f120l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ O0.b f121m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0233c0 f122n;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ f0(O0.b bVar, InterfaceC0233c0 interfaceC0233c0, int i5) {
        super(1);
        this.f120l = i5;
        this.f121m = bVar;
        this.f122n = interfaceC0233c0;
    }

    @Override // T3.c
    public final Object invoke(Object obj) {
        switch (this.f120l) {
            case ConfigBackupDto.$stable /* 0 */:
                long j5 = ((O0.g) obj).a;
                float fB = O0.g.b(j5);
                O0.b bVar = this.f121m;
                this.f122n.setValue(new O0.j(E4.l.u(bVar.m(fB), bVar.m(O0.g.a(j5)))));
                return G3.C.a;
            default:
                U.n nVar = U.n.a;
                e0 e0Var = new e0((T3.a) obj, 0);
                f0 f0Var = new f0(this.f121m, this.f122n, 0);
                if (k0.a()) {
                    return k0.a() ? new MagnifierElement(e0Var, null, f0Var, Float.NaN, true, 9205357640488583168L, Float.NaN, Float.NaN, true, Build.VERSION.SDK_INT == 28 ? w0.a : y0.a) : nVar;
                }
                throw new UnsupportedOperationException("Magnifier is only supported on API level 28 and higher.");
        }
    }
}

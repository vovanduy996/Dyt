package A;

/* JADX INFO: loaded from: classes.dex */
public final class h0 {
    public Float a;
}

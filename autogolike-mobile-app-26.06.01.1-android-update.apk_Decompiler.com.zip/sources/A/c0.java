package A;

import com.autogolike.mobile.core.backup.ConfigBackupDto;
import n.C1427k;
import n.C1430n;

/* JADX INFO: loaded from: classes.dex */
public final class c0 extends U3.k implements T3.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f97l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ C1430n f98m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ Y f99n;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ c0(C1430n c1430n, Y y5, int i5) {
        super(0);
        this.f97l = i5;
        this.f98m = c1430n;
        this.f99n = y5;
    }

    @Override // T3.a
    public final Object b() {
        switch (this.f97l) {
            case ConfigBackupDto.$stable /* 0 */:
                this.f99n.d();
                this.f98m.a.setValue(C1427k.a);
                break;
            case 1:
                this.f99n.b(false);
                this.f98m.a.setValue(C1427k.a);
                break;
            case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                this.f99n.l();
                this.f98m.a.setValue(C1427k.a);
                break;
            default:
                this.f99n.m();
                this.f98m.a.setValue(C1427k.a);
                break;
        }
        return G3.C.a;
    }
}

package A;

import a0.C0492c;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import l.C1306o;

/* JADX INFO: loaded from: classes.dex */
public final class F extends U3.k implements T3.c {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final F f13m = new F(1, 0);

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final F f14n = new F(1, 1);

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final F f15o = new F(1, 2);

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f16l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ F(int i5, int i6) {
        super(i5);
        this.f16l = i6;
    }

    @Override // T3.c
    public final Object invoke(Object obj) {
        switch (this.f16l) {
            case ConfigBackupDto.$stable /* 0 */:
                long j5 = ((C0492c) obj).a;
                return X2.g.P(j5) ? new C1306o(C0492c.d(j5), C0492c.e(j5)) : M.a;
            case 1:
                C1306o c1306o = (C1306o) obj;
                return new C0492c(X2.g.l(c1306o.a, c1306o.f11340b));
            default:
                return G3.C.a;
        }
    }
}

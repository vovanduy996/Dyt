package A;

import G3.AbstractC0164a;
import a0.C0492c;
import f4.InterfaceC0991y;
import kotlin.coroutines.Continuation;
import l.C1285c;
import l.C1294g0;

/* JADX INFO: loaded from: classes.dex */
public final class J extends M3.i implements T3.e {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f24p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ C1285c f25q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ long f26r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public J(C1285c c1285c, long j5, Continuation continuation) {
        super(2, continuation);
        this.f25q = c1285c;
        this.f26r = j5;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((J) m((InterfaceC0991y) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        return new J(this.f25q, this.f26r, continuation);
    }

    @Override // M3.a
    public final Object o(Object obj) {
        L3.a aVar = L3.a.f4629l;
        int i5 = this.f24p;
        if (i5 == 0) {
            AbstractC0164a.e(obj);
            C0492c c0492c = new C0492c(this.f26r);
            C1294g0 c1294g0 = M.f36d;
            this.f24p = 1;
            if (C1285c.c(this.f25q, c0492c, c1294g0, null, this, 12) == aVar) {
                return aVar;
            }
        } else {
            if (i5 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0164a.e(obj);
        }
        return G3.C.a;
    }
}

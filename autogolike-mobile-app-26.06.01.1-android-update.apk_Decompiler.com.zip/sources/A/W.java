package A;

import a0.C0492c;
import w.p0;

/* JADX INFO: loaded from: classes.dex */
public final class W implements w.a0 {
    public final /* synthetic */ Y a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ boolean f58b;

    public W(Y y5, boolean z3) {
        this.a = y5;
        this.f58b = z3;
    }

    @Override // w.a0
    public final void a() {
        Y y5 = this.a;
        y5.f75p.setValue(null);
        y5.f76q.setValue(null);
        y5.p(true);
    }

    @Override // w.a0
    public final void b() {
        Y y5 = this.a;
        y5.f75p.setValue(null);
        y5.f76q.setValue(null);
        y5.p(true);
    }

    @Override // w.a0
    public final void d(long j5) {
        Y y5 = this.a;
        long jH = C0492c.h(y5.f74o, j5);
        y5.f74o = jH;
        y5.f76q.setValue(new C0492c(C0492c.h(y5.f72m, jH)));
        I0.A aJ = y5.j();
        C0492c c0492cG = y5.g();
        U3.j.c(c0492cG);
        C0016q c0016q = r.f159g;
        Y.a(y5, aJ, c0492cG.a, false, this.f58b, c0016q, true);
        y5.p(false);
    }

    @Override // w.a0
    public final void e() {
        p0 p0VarD;
        boolean z3 = this.f58b;
        w.G g3 = z3 ? w.G.f14590m : w.G.f14591n;
        Y y5 = this.a;
        y5.f75p.setValue(g3);
        long jI = y5.i(z3);
        float f5 = E.a;
        long jL = X2.g.l(C0492c.d(jI), C0492c.e(jI) - 1.0f);
        w.S s3 = y5.f63d;
        if (s3 == null || (p0VarD = s3.d()) == null) {
            return;
        }
        long jE = p0VarD.e(jL);
        y5.f72m = jE;
        y5.f76q.setValue(new C0492c(jE));
        y5.f74o = 0L;
        y5.f77r = -1;
        w.S s5 = y5.f63d;
        if (s5 != null) {
            s5.f14633q.setValue(Boolean.TRUE);
        }
        y5.p(false);
    }

    @Override // w.a0
    public final void onCancel() {
    }

    @Override // w.a0
    public final void c(long j5) {
    }
}

package A;

/* JADX INFO: renamed from: A.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0005f extends U3.k implements T3.c {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0012m f117l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ boolean f118m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ boolean f119n;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0005f(InterfaceC0012m interfaceC0012m, boolean z3, boolean z5) {
        super(1);
        this.f117l = interfaceC0012m;
        this.f118m = z3;
        this.f119n = z5;
    }

    @Override // T3.c
    public final Object invoke(Object obj) {
        A0.i iVar = (A0.i) obj;
        long jA = this.f117l.a();
        iVar.e(E.f12c, new D(this.f118m ? w.G.f14590m : w.G.f14591n, jA, this.f119n ? 1 : 3, X2.g.P(jA)));
        return G3.C.a;
    }
}

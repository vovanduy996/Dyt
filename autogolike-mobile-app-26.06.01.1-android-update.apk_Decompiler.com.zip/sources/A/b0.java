package A;

/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class b0 {
    public static final /* synthetic */ int[] a;

    static {
        int[] iArr = new int[w.G.values().length];
        try {
            iArr[0] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr[1] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr[2] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        a = iArr;
    }
}

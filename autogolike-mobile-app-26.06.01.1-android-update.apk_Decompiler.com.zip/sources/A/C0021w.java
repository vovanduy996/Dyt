package A;

import G3.AbstractC0164a;
import I.C0238f;
import I.C0240g;
import I.C0278z0;
import I.EnumC0266t0;
import f4.C0978k;
import java.util.ArrayList;
import java.util.concurrent.CancellationException;

/* JADX INFO: renamed from: A.w, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0021w extends U3.k implements T3.c {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f174l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ Object f175m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ Object f176n;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0021w(Object obj, int i5, Object obj2) {
        super(1);
        this.f174l = i5;
        this.f175m = obj;
        this.f176n = obj2;
    }

    private final Object a(Object obj) {
        C0240g c0240g = (C0240g) this.f175m;
        Object obj2 = c0240g.f3620m;
        C0238f c0238f = (C0238f) this.f176n;
        synchronized (obj2) {
            c0240g.f3622o.remove(c0238f);
            if (c0240g.f3622o.isEmpty()) {
                c0240g.f3624q.set(0);
            }
        }
        return G3.C.a;
    }

    private final Object c(Object obj) {
        I.S s3 = (I.S) this.f175m;
        Object obj2 = s3.f3570b;
        C0978k c0978k = (C0978k) this.f176n;
        synchronized (obj2) {
            ((ArrayList) s3.f3571c).remove(c0978k);
        }
        return G3.C.a;
    }

    private final Object d(Object obj) {
        Throwable th = (Throwable) obj;
        C0278z0 c0278z0 = (C0278z0) this.f175m;
        Object obj2 = c0278z0.f3778b;
        Throwable th2 = (Throwable) this.f176n;
        synchronized (obj2) {
            if (th2 == null) {
                th2 = null;
            } else if (th != null) {
                try {
                    if (th instanceof CancellationException) {
                        th = null;
                    }
                    if (th != null) {
                        AbstractC0164a.a(th2, th);
                    }
                } catch (Throwable th3) {
                    throw th3;
                }
            }
            c0278z0.f3780d = th2;
            i4.c0 c0Var = c0278z0.f3794r;
            EnumC0266t0 enumC0266t0 = EnumC0266t0.f3718l;
            c0Var.getClass();
            c0Var.m(null, enumC0266t0);
        }
        return G3.C.a;
    }

    /* JADX WARN: Removed duplicated region for block: B:327:0x06c9  */
    /* JADX WARN: Removed duplicated region for block: B:340:0x0701  */
    /* JADX WARN: Removed duplicated region for block: B:341:0x0703  */
    /* JADX WARN: Removed duplicated region for block: B:343:0x070b A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:398:0x08c5  */
    @Override // T3.c
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object invoke(java.lang.Object r19) {
        /*
            Method dump skipped, instruction units count: 2434
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: A.C0021w.invoke(java.lang.Object):java.lang.Object");
    }
}

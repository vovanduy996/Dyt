package A;

import androidx.datastore.preferences.protobuf.AbstractC0530d;
import androidx.datastore.preferences.protobuf.AbstractC0541k;
import androidx.datastore.preferences.protobuf.AbstractC0544n;
import androidx.datastore.preferences.protobuf.AbstractC0550u;
import androidx.datastore.preferences.protobuf.AbstractC0554y;
import androidx.datastore.preferences.protobuf.AbstractC0555z;
import androidx.datastore.preferences.protobuf.C0527b0;
import androidx.datastore.preferences.protobuf.C0538h;
import androidx.datastore.preferences.protobuf.C0546p;
import androidx.datastore.preferences.protobuf.F0;
import androidx.datastore.preferences.protobuf.InterfaceC0533e0;
import com.autogolike.mobile.core.backup.ConfigBackupDto;
import java.nio.charset.Charset;
import java.util.List;
import z1.AbstractC2128a;

/* JADX INFO: renamed from: A.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0013n {
    public final /* synthetic */ int a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f145b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f146c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f147d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f148e;

    public /* synthetic */ C0013n() {
        this.a = 1;
    }

    public static void C(int i5) throws androidx.datastore.preferences.protobuf.D {
        if ((i5 & 3) != 0) {
            throw new androidx.datastore.preferences.protobuf.D("Failed to parse the message.");
        }
    }

    public static void D(int i5) throws androidx.datastore.preferences.protobuf.D {
        if ((i5 & 7) != 0) {
            throw new androidx.datastore.preferences.protobuf.D("Failed to parse the message.");
        }
    }

    public void A(int i5) throws androidx.datastore.preferences.protobuf.C {
        if ((this.f145b & 7) != i5) {
            throw androidx.datastore.preferences.protobuf.D.b();
        }
    }

    public boolean B() {
        int i5;
        AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
        if (abstractC0541k.c() || (i5 = this.f145b) == this.f146c) {
            return false;
        }
        return abstractC0541k.x(i5);
    }

    public C0014o a(int i5) {
        return new C0014o(X2.g.K((C0.I) this.f148e, i5), i5, 1L);
    }

    public int b() {
        return this.f147d - this.f146c;
    }

    public int c() {
        int i5 = this.f147d;
        if (i5 != 0) {
            this.f145b = i5;
            this.f147d = 0;
        } else {
            this.f145b = ((AbstractC0541k) this.f148e).u();
        }
        int i6 = this.f145b;
        if (i6 == 0 || i6 == this.f146c) {
            return Integer.MAX_VALUE;
        }
        return i6 >>> 3;
    }

    public int d(int i5) {
        return ((J.D) this.f148e).f4334i[this.f146c + i5];
    }

    public Object e(int i5) {
        return ((J.D) this.f148e).f4336k[this.f147d + i5];
    }

    public void f(Object obj, InterfaceC0533e0 interfaceC0533e0, C0546p c0546p) {
        int i5 = this.f146c;
        this.f146c = ((this.f145b >>> 3) << 3) | 4;
        try {
            interfaceC0533e0.e(obj, this, c0546p);
            if (this.f145b == this.f146c) {
            } else {
                throw new androidx.datastore.preferences.protobuf.D("Failed to parse the message.");
            }
        } finally {
            this.f146c = i5;
        }
    }

    public void g(Object obj, InterfaceC0533e0 interfaceC0533e0, C0546p c0546p) throws androidx.datastore.preferences.protobuf.D {
        AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
        int iV = abstractC0541k.v();
        if (abstractC0541k.a >= 100) {
            throw new androidx.datastore.preferences.protobuf.D("Protocol message had too many levels of nesting.  May be malicious.  Use CodedInputStream.setRecursionLimit() to increase the depth limit.");
        }
        int iE = abstractC0541k.e(iV);
        abstractC0541k.a++;
        interfaceC0533e0.e(obj, this, c0546p);
        abstractC0541k.a(0);
        abstractC0541k.a--;
        abstractC0541k.d(iE);
    }

    public void h(List list) throws androidx.datastore.preferences.protobuf.D {
        int iU;
        boolean z3 = list instanceof AbstractC0530d;
        AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
        if (z3) {
            if (list != null) {
                throw new ClassCastException();
            }
            int i5 = this.f145b & 7;
            if (i5 == 0) {
                abstractC0541k.f();
                throw null;
            }
            if (i5 != 2) {
                throw androidx.datastore.preferences.protobuf.D.b();
            }
            abstractC0541k.v();
            abstractC0541k.f();
            throw null;
        }
        int i6 = this.f145b & 7;
        if (i6 == 0) {
            do {
                list.add(Boolean.valueOf(abstractC0541k.f()));
                if (abstractC0541k.c()) {
                    return;
                } else {
                    iU = abstractC0541k.u();
                }
            } while (iU == this.f145b);
            this.f147d = iU;
            return;
        }
        if (i6 != 2) {
            throw androidx.datastore.preferences.protobuf.D.b();
        }
        int iB = abstractC0541k.b() + abstractC0541k.v();
        do {
            list.add(Boolean.valueOf(abstractC0541k.f()));
        } while (abstractC0541k.b() < iB);
        z(iB);
    }

    public C0538h i() throws androidx.datastore.preferences.protobuf.C {
        A(2);
        return ((AbstractC0541k) this.f148e).g();
    }

    public void j(List list) throws androidx.datastore.preferences.protobuf.C {
        int iU;
        if ((this.f145b & 7) != 2) {
            throw androidx.datastore.preferences.protobuf.D.b();
        }
        do {
            list.add(i());
            AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
            if (abstractC0541k.c()) {
                return;
            } else {
                iU = abstractC0541k.u();
            }
        } while (iU == this.f145b);
        this.f147d = iU;
    }

    public void k(List list) throws androidx.datastore.preferences.protobuf.D {
        int iU;
        boolean z3 = list instanceof AbstractC0544n;
        AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
        if (z3) {
            if (list != null) {
                throw new ClassCastException();
            }
            int i5 = this.f145b & 7;
            if (i5 == 1) {
                abstractC0541k.h();
                throw null;
            }
            if (i5 != 2) {
                throw androidx.datastore.preferences.protobuf.D.b();
            }
            D(abstractC0541k.v());
            abstractC0541k.h();
            throw null;
        }
        int i6 = this.f145b & 7;
        if (i6 == 1) {
            do {
                list.add(Double.valueOf(abstractC0541k.h()));
                if (abstractC0541k.c()) {
                    return;
                } else {
                    iU = abstractC0541k.u();
                }
            } while (iU == this.f145b);
            this.f147d = iU;
            return;
        }
        if (i6 != 2) {
            throw androidx.datastore.preferences.protobuf.D.b();
        }
        int iV = abstractC0541k.v();
        D(iV);
        int iB = abstractC0541k.b() + iV;
        do {
            list.add(Double.valueOf(abstractC0541k.h()));
        } while (abstractC0541k.b() < iB);
    }

    public void l(List list) throws androidx.datastore.preferences.protobuf.D {
        int iU;
        boolean z3 = list instanceof AbstractC0555z;
        AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
        if (z3) {
            if (list != null) {
                throw new ClassCastException();
            }
            int i5 = this.f145b & 7;
            if (i5 == 0) {
                abstractC0541k.i();
                throw null;
            }
            if (i5 != 2) {
                throw androidx.datastore.preferences.protobuf.D.b();
            }
            abstractC0541k.v();
            abstractC0541k.i();
            throw null;
        }
        int i6 = this.f145b & 7;
        if (i6 == 0) {
            do {
                list.add(Integer.valueOf(abstractC0541k.i()));
                if (abstractC0541k.c()) {
                    return;
                } else {
                    iU = abstractC0541k.u();
                }
            } while (iU == this.f145b);
            this.f147d = iU;
            return;
        }
        if (i6 != 2) {
            throw androidx.datastore.preferences.protobuf.D.b();
        }
        int iB = abstractC0541k.b() + abstractC0541k.v();
        do {
            list.add(Integer.valueOf(abstractC0541k.i()));
        } while (abstractC0541k.b() < iB);
        z(iB);
    }

    public Object m(F0 f02, Class cls, C0546p c0546p) throws androidx.datastore.preferences.protobuf.D {
        int iOrdinal = f02.ordinal();
        AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
        switch (iOrdinal) {
            case ConfigBackupDto.$stable /* 0 */:
                A(1);
                return Double.valueOf(abstractC0541k.h());
            case 1:
                A(5);
                return Float.valueOf(abstractC0541k.l());
            case k1.h.FLOAT_FIELD_NUMBER /* 2 */:
                A(0);
                return Long.valueOf(abstractC0541k.n());
            case k1.h.INTEGER_FIELD_NUMBER /* 3 */:
                A(0);
                return Long.valueOf(abstractC0541k.w());
            case k1.h.LONG_FIELD_NUMBER /* 4 */:
                A(0);
                return Integer.valueOf(abstractC0541k.m());
            case k1.h.STRING_FIELD_NUMBER /* 5 */:
                A(1);
                return Long.valueOf(abstractC0541k.k());
            case k1.h.STRING_SET_FIELD_NUMBER /* 6 */:
                A(5);
                return Integer.valueOf(abstractC0541k.j());
            case k1.h.DOUBLE_FIELD_NUMBER /* 7 */:
                A(0);
                return Boolean.valueOf(abstractC0541k.f());
            case 8:
                A(2);
                return abstractC0541k.t();
            case 9:
            default:
                throw new IllegalArgumentException("unsupported field type.");
            case 10:
                A(2);
                InterfaceC0533e0 interfaceC0533e0A = C0527b0.f7579c.a(cls);
                AbstractC0554y abstractC0554yG = interfaceC0533e0A.g();
                g(abstractC0554yG, interfaceC0533e0A, c0546p);
                interfaceC0533e0A.h(abstractC0554yG);
                return abstractC0554yG;
            case 11:
                return i();
            case 12:
                A(0);
                return Integer.valueOf(abstractC0541k.v());
            case 13:
                A(0);
                return Integer.valueOf(abstractC0541k.i());
            case 14:
                A(5);
                return Integer.valueOf(abstractC0541k.o());
            case 15:
                A(1);
                return Long.valueOf(abstractC0541k.p());
            case 16:
                A(0);
                return Integer.valueOf(abstractC0541k.q());
            case 17:
                A(0);
                return Long.valueOf(abstractC0541k.r());
        }
    }

    public void n(List list) throws androidx.datastore.preferences.protobuf.D {
        int iU;
        boolean z3 = list instanceof AbstractC0555z;
        AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
        if (z3) {
            if (list != null) {
                throw new ClassCastException();
            }
            int i5 = this.f145b & 7;
            if (i5 == 2) {
                C(abstractC0541k.v());
                abstractC0541k.j();
                throw null;
            }
            if (i5 != 5) {
                throw androidx.datastore.preferences.protobuf.D.b();
            }
            abstractC0541k.j();
            throw null;
        }
        int i6 = this.f145b & 7;
        if (i6 == 2) {
            int iV = abstractC0541k.v();
            C(iV);
            int iB = abstractC0541k.b() + iV;
            do {
                list.add(Integer.valueOf(abstractC0541k.j()));
            } while (abstractC0541k.b() < iB);
            return;
        }
        if (i6 != 5) {
            throw androidx.datastore.preferences.protobuf.D.b();
        }
        do {
            list.add(Integer.valueOf(abstractC0541k.j()));
            if (abstractC0541k.c()) {
                return;
            } else {
                iU = abstractC0541k.u();
            }
        } while (iU == this.f145b);
        this.f147d = iU;
    }

    public void o(List list) throws androidx.datastore.preferences.protobuf.D {
        int iU;
        boolean z3 = list instanceof androidx.datastore.preferences.protobuf.K;
        AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
        if (z3) {
            if (list != null) {
                throw new ClassCastException();
            }
            int i5 = this.f145b & 7;
            if (i5 == 1) {
                abstractC0541k.k();
                throw null;
            }
            if (i5 != 2) {
                throw androidx.datastore.preferences.protobuf.D.b();
            }
            D(abstractC0541k.v());
            abstractC0541k.k();
            throw null;
        }
        int i6 = this.f145b & 7;
        if (i6 == 1) {
            do {
                list.add(Long.valueOf(abstractC0541k.k()));
                if (abstractC0541k.c()) {
                    return;
                } else {
                    iU = abstractC0541k.u();
                }
            } while (iU == this.f145b);
            this.f147d = iU;
            return;
        }
        if (i6 != 2) {
            throw androidx.datastore.preferences.protobuf.D.b();
        }
        int iV = abstractC0541k.v();
        D(iV);
        int iB = abstractC0541k.b() + iV;
        do {
            list.add(Long.valueOf(abstractC0541k.k()));
        } while (abstractC0541k.b() < iB);
    }

    public void p(List list) throws androidx.datastore.preferences.protobuf.D {
        int iU;
        boolean z3 = list instanceof AbstractC0550u;
        AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
        if (z3) {
            if (list != null) {
                throw new ClassCastException();
            }
            int i5 = this.f145b & 7;
            if (i5 == 2) {
                C(abstractC0541k.v());
                abstractC0541k.l();
                throw null;
            }
            if (i5 != 5) {
                throw androidx.datastore.preferences.protobuf.D.b();
            }
            abstractC0541k.l();
            throw null;
        }
        int i6 = this.f145b & 7;
        if (i6 == 2) {
            int iV = abstractC0541k.v();
            C(iV);
            int iB = abstractC0541k.b() + iV;
            do {
                list.add(Float.valueOf(abstractC0541k.l()));
            } while (abstractC0541k.b() < iB);
            return;
        }
        if (i6 != 5) {
            throw androidx.datastore.preferences.protobuf.D.b();
        }
        do {
            list.add(Float.valueOf(abstractC0541k.l()));
            if (abstractC0541k.c()) {
                return;
            } else {
                iU = abstractC0541k.u();
            }
        } while (iU == this.f145b);
        this.f147d = iU;
    }

    public void q(List list) throws androidx.datastore.preferences.protobuf.D {
        int iU;
        boolean z3 = list instanceof AbstractC0555z;
        AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
        if (z3) {
            if (list != null) {
                throw new ClassCastException();
            }
            int i5 = this.f145b & 7;
            if (i5 == 0) {
                abstractC0541k.m();
                throw null;
            }
            if (i5 != 2) {
                throw androidx.datastore.preferences.protobuf.D.b();
            }
            abstractC0541k.v();
            abstractC0541k.m();
            throw null;
        }
        int i6 = this.f145b & 7;
        if (i6 == 0) {
            do {
                list.add(Integer.valueOf(abstractC0541k.m()));
                if (abstractC0541k.c()) {
                    return;
                } else {
                    iU = abstractC0541k.u();
                }
            } while (iU == this.f145b);
            this.f147d = iU;
            return;
        }
        if (i6 != 2) {
            throw androidx.datastore.preferences.protobuf.D.b();
        }
        int iB = abstractC0541k.b() + abstractC0541k.v();
        do {
            list.add(Integer.valueOf(abstractC0541k.m()));
        } while (abstractC0541k.b() < iB);
        z(iB);
    }

    public void r(List list) throws androidx.datastore.preferences.protobuf.D {
        int iU;
        boolean z3 = list instanceof androidx.datastore.preferences.protobuf.K;
        AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
        if (z3) {
            if (list != null) {
                throw new ClassCastException();
            }
            int i5 = this.f145b & 7;
            if (i5 == 0) {
                abstractC0541k.n();
                throw null;
            }
            if (i5 != 2) {
                throw androidx.datastore.preferences.protobuf.D.b();
            }
            abstractC0541k.v();
            abstractC0541k.n();
            throw null;
        }
        int i6 = this.f145b & 7;
        if (i6 == 0) {
            do {
                list.add(Long.valueOf(abstractC0541k.n()));
                if (abstractC0541k.c()) {
                    return;
                } else {
                    iU = abstractC0541k.u();
                }
            } while (iU == this.f145b);
            this.f147d = iU;
            return;
        }
        if (i6 != 2) {
            throw androidx.datastore.preferences.protobuf.D.b();
        }
        int iB = abstractC0541k.b() + abstractC0541k.v();
        do {
            list.add(Long.valueOf(abstractC0541k.n()));
        } while (abstractC0541k.b() < iB);
        z(iB);
    }

    public void s(List list) throws androidx.datastore.preferences.protobuf.D {
        int iU;
        boolean z3 = list instanceof AbstractC0555z;
        AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
        if (z3) {
            if (list != null) {
                throw new ClassCastException();
            }
            int i5 = this.f145b & 7;
            if (i5 == 2) {
                C(abstractC0541k.v());
                abstractC0541k.o();
                throw null;
            }
            if (i5 != 5) {
                throw androidx.datastore.preferences.protobuf.D.b();
            }
            abstractC0541k.o();
            throw null;
        }
        int i6 = this.f145b & 7;
        if (i6 == 2) {
            int iV = abstractC0541k.v();
            C(iV);
            int iB = abstractC0541k.b() + iV;
            do {
                list.add(Integer.valueOf(abstractC0541k.o()));
            } while (abstractC0541k.b() < iB);
            return;
        }
        if (i6 != 5) {
            throw androidx.datastore.preferences.protobuf.D.b();
        }
        do {
            list.add(Integer.valueOf(abstractC0541k.o()));
            if (abstractC0541k.c()) {
                return;
            } else {
                iU = abstractC0541k.u();
            }
        } while (iU == this.f145b);
        this.f147d = iU;
    }

    public void t(List list) throws androidx.datastore.preferences.protobuf.D {
        int iU;
        boolean z3 = list instanceof androidx.datastore.preferences.protobuf.K;
        AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
        if (z3) {
            if (list != null) {
                throw new ClassCastException();
            }
            int i5 = this.f145b & 7;
            if (i5 == 1) {
                abstractC0541k.p();
                throw null;
            }
            if (i5 != 2) {
                throw androidx.datastore.preferences.protobuf.D.b();
            }
            D(abstractC0541k.v());
            abstractC0541k.p();
            throw null;
        }
        int i6 = this.f145b & 7;
        if (i6 == 1) {
            do {
                list.add(Long.valueOf(abstractC0541k.p()));
                if (abstractC0541k.c()) {
                    return;
                } else {
                    iU = abstractC0541k.u();
                }
            } while (iU == this.f145b);
            this.f147d = iU;
            return;
        }
        if (i6 != 2) {
            throw androidx.datastore.preferences.protobuf.D.b();
        }
        int iV = abstractC0541k.v();
        D(iV);
        int iB = abstractC0541k.b() + iV;
        do {
            list.add(Long.valueOf(abstractC0541k.p()));
        } while (abstractC0541k.b() < iB);
    }

    public String toString() {
        switch (this.a) {
            case ConfigBackupDto.$stable /* 0 */:
                StringBuilder sb = new StringBuilder("SelectionInfo(id=1, range=(");
                int i5 = this.f145b;
                sb.append(i5);
                sb.append('-');
                C0.I i6 = (C0.I) this.f148e;
                sb.append(X2.g.K(i6, i5));
                sb.append(',');
                int i7 = this.f146c;
                sb.append(i7);
                sb.append('-');
                sb.append(X2.g.K(i6, i7));
                sb.append("), prevOffset=");
                return AbstractC2128a.h(sb, this.f147d, ')');
            case 1:
                return "";
            default:
                return super.toString();
        }
    }

    public void u(List list) throws androidx.datastore.preferences.protobuf.D {
        int iU;
        boolean z3 = list instanceof AbstractC0555z;
        AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
        if (z3) {
            if (list != null) {
                throw new ClassCastException();
            }
            int i5 = this.f145b & 7;
            if (i5 == 0) {
                abstractC0541k.q();
                throw null;
            }
            if (i5 != 2) {
                throw androidx.datastore.preferences.protobuf.D.b();
            }
            abstractC0541k.v();
            abstractC0541k.q();
            throw null;
        }
        int i6 = this.f145b & 7;
        if (i6 == 0) {
            do {
                list.add(Integer.valueOf(abstractC0541k.q()));
                if (abstractC0541k.c()) {
                    return;
                } else {
                    iU = abstractC0541k.u();
                }
            } while (iU == this.f145b);
            this.f147d = iU;
            return;
        }
        if (i6 != 2) {
            throw androidx.datastore.preferences.protobuf.D.b();
        }
        int iB = abstractC0541k.b() + abstractC0541k.v();
        do {
            list.add(Integer.valueOf(abstractC0541k.q()));
        } while (abstractC0541k.b() < iB);
        z(iB);
    }

    public void v(List list) throws androidx.datastore.preferences.protobuf.D {
        int iU;
        boolean z3 = list instanceof androidx.datastore.preferences.protobuf.K;
        AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
        if (z3) {
            if (list != null) {
                throw new ClassCastException();
            }
            int i5 = this.f145b & 7;
            if (i5 == 0) {
                abstractC0541k.r();
                throw null;
            }
            if (i5 != 2) {
                throw androidx.datastore.preferences.protobuf.D.b();
            }
            abstractC0541k.v();
            abstractC0541k.r();
            throw null;
        }
        int i6 = this.f145b & 7;
        if (i6 == 0) {
            do {
                list.add(Long.valueOf(abstractC0541k.r()));
                if (abstractC0541k.c()) {
                    return;
                } else {
                    iU = abstractC0541k.u();
                }
            } while (iU == this.f145b);
            this.f147d = iU;
            return;
        }
        if (i6 != 2) {
            throw androidx.datastore.preferences.protobuf.D.b();
        }
        int iB = abstractC0541k.b() + abstractC0541k.v();
        do {
            list.add(Long.valueOf(abstractC0541k.r()));
        } while (abstractC0541k.b() < iB);
        z(iB);
    }

    public void w(List list, boolean z3) throws androidx.datastore.preferences.protobuf.C {
        String strS;
        int iU;
        int iU2;
        if ((this.f145b & 7) != 2) {
            throw androidx.datastore.preferences.protobuf.D.b();
        }
        boolean z5 = list instanceof androidx.datastore.preferences.protobuf.G;
        AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
        if (z5 && !z3) {
            androidx.datastore.preferences.protobuf.G g3 = (androidx.datastore.preferences.protobuf.G) list;
            do {
                g3.p(i());
                if (abstractC0541k.c()) {
                    return;
                } else {
                    iU2 = abstractC0541k.u();
                }
            } while (iU2 == this.f145b);
            this.f147d = iU2;
            return;
        }
        do {
            if (z3) {
                A(2);
                strS = abstractC0541k.t();
            } else {
                A(2);
                strS = abstractC0541k.s();
            }
            list.add(strS);
            if (abstractC0541k.c()) {
                return;
            } else {
                iU = abstractC0541k.u();
            }
        } while (iU == this.f145b);
        this.f147d = iU;
    }

    public void x(List list) throws androidx.datastore.preferences.protobuf.D {
        int iU;
        boolean z3 = list instanceof AbstractC0555z;
        AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
        if (z3) {
            if (list != null) {
                throw new ClassCastException();
            }
            int i5 = this.f145b & 7;
            if (i5 == 0) {
                abstractC0541k.v();
                throw null;
            }
            if (i5 != 2) {
                throw androidx.datastore.preferences.protobuf.D.b();
            }
            abstractC0541k.v();
            abstractC0541k.v();
            throw null;
        }
        int i6 = this.f145b & 7;
        if (i6 == 0) {
            do {
                list.add(Integer.valueOf(abstractC0541k.v()));
                if (abstractC0541k.c()) {
                    return;
                } else {
                    iU = abstractC0541k.u();
                }
            } while (iU == this.f145b);
            this.f147d = iU;
            return;
        }
        if (i6 != 2) {
            throw androidx.datastore.preferences.protobuf.D.b();
        }
        int iB = abstractC0541k.b() + abstractC0541k.v();
        do {
            list.add(Integer.valueOf(abstractC0541k.v()));
        } while (abstractC0541k.b() < iB);
        z(iB);
    }

    public void y(List list) throws androidx.datastore.preferences.protobuf.D {
        int iU;
        boolean z3 = list instanceof androidx.datastore.preferences.protobuf.K;
        AbstractC0541k abstractC0541k = (AbstractC0541k) this.f148e;
        if (z3) {
            if (list != null) {
                throw new ClassCastException();
            }
            int i5 = this.f145b & 7;
            if (i5 == 0) {
                abstractC0541k.w();
                throw null;
            }
            if (i5 != 2) {
                throw androidx.datastore.preferences.protobuf.D.b();
            }
            abstractC0541k.v();
            abstractC0541k.w();
            throw null;
        }
        int i6 = this.f145b & 7;
        if (i6 == 0) {
            do {
                list.add(Long.valueOf(abstractC0541k.w()));
                if (abstractC0541k.c()) {
                    return;
                } else {
                    iU = abstractC0541k.u();
                }
            } while (iU == this.f145b);
            this.f147d = iU;
            return;
        }
        if (i6 != 2) {
            throw androidx.datastore.preferences.protobuf.D.b();
        }
        int iB = abstractC0541k.b() + abstractC0541k.v();
        do {
            list.add(Long.valueOf(abstractC0541k.w()));
        } while (abstractC0541k.b() < iB);
        z(iB);
    }

    public void z(int i5) throws androidx.datastore.preferences.protobuf.D {
        if (((AbstractC0541k) this.f148e).b() != i5) {
            throw androidx.datastore.preferences.protobuf.D.e();
        }
    }

    public C0013n(AbstractC0541k abstractC0541k) {
        this.a = 3;
        this.f147d = 0;
        Charset charset = androidx.datastore.preferences.protobuf.B.a;
        this.f148e = abstractC0541k;
        abstractC0541k.f7624b = this;
    }

    public C0013n(J.D d3) {
        this.a = 2;
        this.f148e = d3;
    }

    public C0013n(int i5, int i6, int i7, C0.I i8) {
        this.a = 0;
        this.f145b = i5;
        this.f146c = i6;
        this.f147d = i7;
        this.f148e = i8;
    }
}

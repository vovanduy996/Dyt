package A;

import n0.C1432A;

/* JADX INFO: renamed from: A.v, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0020v extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public C1432A f170o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public C3.c f171p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public /* synthetic */ Object f172q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f173r;

    @Override // M3.a
    public final Object o(Object obj) {
        this.f172q = obj;
        this.f173r |= Integer.MIN_VALUE;
        return W3.a.v(null, null, null, null, this);
    }
}

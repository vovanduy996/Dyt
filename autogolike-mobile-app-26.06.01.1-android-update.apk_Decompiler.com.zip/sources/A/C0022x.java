package A;

import kotlin.coroutines.Continuation;
import n0.C1432A;

/* JADX INFO: renamed from: A.x, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0022x extends M3.h implements T3.e {

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f177n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public /* synthetic */ Object f178o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ C3.c f179p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ C0010k f180q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ w.a0 f181r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0022x(C3.c cVar, C0010k c0010k, w.a0 a0Var, Continuation continuation) {
        super(2, continuation);
        this.f179p = cVar;
        this.f180q = c0010k;
        this.f181r = a0Var;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        return ((C0022x) m((C1432A) obj, (Continuation) obj2)).o(G3.C.a);
    }

    @Override // M3.a
    public final Continuation m(Object obj, Continuation continuation) {
        C0022x c0022x = new C0022x(this.f179p, this.f180q, this.f181r, continuation);
        c0022x.f178o = obj;
        return c0022x;
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x0074  */
    /* JADX WARN: Type inference failed for: r2v6, types: [java.lang.Object, java.util.List] */
    @Override // M3.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object o(java.lang.Object r10) {
        /*
            r9 = this;
            L3.a r0 = L3.a.f4629l
            int r1 = r9.f177n
            r2 = 1
            r3 = 3
            r4 = 2
            if (r1 == 0) goto L24
            if (r1 == r2) goto L1c
            if (r1 == r4) goto L18
            if (r1 != r3) goto L10
            goto L18
        L10:
            java.lang.IllegalStateException r10 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r10.<init>(r0)
            throw r10
        L18:
            G3.AbstractC0164a.e(r10)
            goto L81
        L1c:
            java.lang.Object r1 = r9.f178o
            n0.A r1 = (n0.C1432A) r1
            G3.AbstractC0164a.e(r10)
            goto L37
        L24:
            G3.AbstractC0164a.e(r10)
            java.lang.Object r10 = r9.f178o
            r1 = r10
            n0.A r1 = (n0.C1432A) r1
            r9.f178o = r1
            r9.f177n = r2
            java.lang.Object r10 = W3.a.p(r1, r9)
            if (r10 != r0) goto L37
            return r0
        L37:
            n0.i r10 = (n0.C1443i) r10
            boolean r2 = W3.a.H(r10)
            r5 = 0
            if (r2 == 0) goto L6e
            int r2 = r10.f11951b
            r2 = r2 & 33
            if (r2 == 0) goto L6e
            java.lang.Object r2 = r10.a
            int r6 = r2.size()
            r7 = 0
        L4d:
            if (r7 >= r6) goto L5f
            java.lang.Object r8 = r2.get(r7)
            n0.s r8 = (n0.s) r8
            boolean r8 = r8.b()
            if (r8 == 0) goto L5c
            goto L6e
        L5c:
            int r7 = r7 + 1
            goto L4d
        L5f:
            r9.f178o = r5
            r9.f177n = r4
            A.k r2 = r9.f180q
            C3.c r3 = r9.f179p
            java.lang.Object r10 = W3.a.v(r1, r3, r2, r10, r9)
            if (r10 != r0) goto L81
            return r0
        L6e:
            boolean r2 = W3.a.H(r10)
            if (r2 != 0) goto L81
            r9.f178o = r5
            r9.f177n = r3
            w.a0 r2 = r9.f181r
            java.lang.Object r10 = W3.a.w(r1, r2, r10, r9)
            if (r10 != r0) goto L81
            return r0
        L81:
            G3.C r10 = G3.C.a
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: A.C0022x.o(java.lang.Object):java.lang.Object");
    }
}

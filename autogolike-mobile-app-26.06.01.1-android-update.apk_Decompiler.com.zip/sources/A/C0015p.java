package A;

/* JADX INFO: renamed from: A.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0015p {
    public final C0014o a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C0014o f151b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f152c;

    public C0015p(C0014o c0014o, C0014o c0014o2, boolean z3) {
        this.a = c0014o;
        this.f151b = c0014o2;
        this.f152c = z3;
    }

    public static C0015p a(C0015p c0015p, C0014o c0014o, C0014o c0014o2, boolean z3, int i5) {
        if ((i5 & 1) != 0) {
            c0014o = c0015p.a;
        }
        if ((i5 & 2) != 0) {
            c0014o2 = c0015p.f151b;
        }
        c0015p.getClass();
        return new C0015p(c0014o, c0014o2, z3);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0015p)) {
            return false;
        }
        C0015p c0015p = (C0015p) obj;
        return U3.j.a(this.a, c0015p.a) && U3.j.a(this.f151b, c0015p.f151b) && this.f152c == c0015p.f152c;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f152c) + ((this.f151b.hashCode() + (this.a.hashCode() * 31)) * 31);
    }

    public final String toString() {
        return "Selection(start=" + this.a + ", end=" + this.f151b + ", handlesCrossed=" + this.f152c + ')';
    }
}

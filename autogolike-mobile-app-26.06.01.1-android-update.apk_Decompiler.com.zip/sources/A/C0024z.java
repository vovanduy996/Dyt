package A;

import n0.C1432A;

/* JADX INFO: renamed from: A.z, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0024z extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public C1432A f186o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public w.a0 f187p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public n0.s f188q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public /* synthetic */ Object f189r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f190s;

    @Override // M3.a
    public final Object o(Object obj) {
        this.f189r = obj;
        this.f190s |= Integer.MIN_VALUE;
        return W3.a.w(null, null, null, this);
    }
}

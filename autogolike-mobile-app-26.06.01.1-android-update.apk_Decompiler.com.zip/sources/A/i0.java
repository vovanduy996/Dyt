package A;

import b0.C0603v;
import com.google.android.gms.internal.measurement.AbstractC0813y0;

/* JADX INFO: loaded from: classes.dex */
public final class i0 {
    public final long a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f137b;

    public i0(long j5, long j6) {
        this.a = j5;
        this.f137b = j6;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof i0)) {
            return false;
        }
        i0 i0Var = (i0) obj;
        return C0603v.c(this.a, i0Var.a) && C0603v.c(this.f137b, i0Var.f137b);
    }

    public final int hashCode() {
        int i5 = C0603v.f7975h;
        return Long.hashCode(this.f137b) + (Long.hashCode(this.a) * 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("SelectionColors(selectionHandleColor=");
        AbstractC0813y0.s(this.a, sb, ", selectionBackgroundColor=");
        sb.append((Object) C0603v.i(this.f137b));
        sb.append(')');
        return sb.toString();
    }
}

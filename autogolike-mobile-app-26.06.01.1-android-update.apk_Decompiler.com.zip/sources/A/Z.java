package A;

/* JADX INFO: loaded from: classes.dex */
public final class Z implements InterfaceC0012m {
    public final /* synthetic */ Y a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ boolean f82b;

    public Z(Y y5, boolean z3) {
        this.a = y5;
        this.f82b = z3;
    }

    @Override // A.InterfaceC0012m
    public final long a() {
        return this.a.i(this.f82b);
    }
}

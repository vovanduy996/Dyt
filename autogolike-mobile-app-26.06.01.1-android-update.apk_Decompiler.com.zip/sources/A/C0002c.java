package A;

import I.C0234d;
import I.C0250l;
import I.C0258p;
import I.InterfaceC0255n0;
import com.google.android.gms.internal.measurement.AbstractC0813y0;
import q.AbstractC1587c;
import q.C1586b;
import t0.C1802i;
import t0.C1803j;
import t0.C1804k;
import t0.InterfaceC1805l;

/* JADX INFO: renamed from: A.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0002c extends U3.k implements T3.e {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ long f93l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ boolean f94m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ U.q f95n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0012m f96o;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0002c(long j5, boolean z3, U.q qVar, InterfaceC0012m interfaceC0012m) {
        super(2);
        this.f93l = j5;
        this.f94m = z3;
        this.f95n = qVar;
        this.f96o = interfaceC0012m;
    }

    @Override // T3.e
    public final Object i(Object obj, Object obj2) {
        C0258p c0258p = (C0258p) obj;
        if ((((Number) obj2).intValue() & 3) == 2 && c0258p.x()) {
            c0258p.L();
        } else {
            long j5 = this.f93l;
            I.W w5 = C0250l.a;
            InterfaceC0012m interfaceC0012m = this.f96o;
            boolean z3 = this.f94m;
            if (j5 != 9205357640488583168L) {
                c0258p.Q(-837727128);
                C1586b c1586b = z3 ? AbstractC1587c.f12592b : AbstractC1587c.a;
                U.q qVarH = androidx.compose.foundation.layout.c.h(this.f95n, O0.g.b(j5), O0.g.a(j5), 0.0f, 0.0f, 12);
                q.b0 b0VarB = q.a0.b(c1586b, U.b.f6116u, c0258p, 0);
                int i5 = c0258p.f3669P;
                InterfaceC0255n0 interfaceC0255n0M = c0258p.m();
                U.q qVarD = U.a.d(c0258p, qVarH);
                InterfaceC1805l.f13649k.getClass();
                C1803j c1803j = C1804k.f13641b;
                c0258p.U();
                if (c0258p.f3668O) {
                    c0258p.l(c1803j);
                } else {
                    c0258p.d0();
                }
                C0234d.R(c0258p, C1804k.f13645f, b0VarB);
                C0234d.R(c0258p, C1804k.f13644e, interfaceC0255n0M);
                C1802i c1802i = C1804k.f13646g;
                if (c0258p.f3668O || !U3.j.a(c0258p.G(), Integer.valueOf(i5))) {
                    AbstractC0813y0.r(i5, c0258p, i5, c1802i);
                }
                C0234d.R(c0258p, C1804k.f13643d, qVarD);
                U.n nVar = U.n.a;
                boolean zH = c0258p.h(interfaceC0012m);
                Object objG = c0258p.G();
                if (zH || objG == w5) {
                    objG = new C0001b(interfaceC0012m, 0);
                    c0258p.a0(objG);
                }
                E4.d.o(nVar, (T3.a) objG, z3, c0258p, 6);
                c0258p.p(true);
                c0258p.p(false);
            } else {
                c0258p.Q(-836867312);
                boolean zH2 = c0258p.h(interfaceC0012m);
                Object objG2 = c0258p.G();
                if (zH2 || objG2 == w5) {
                    objG2 = new C0001b(interfaceC0012m, 1);
                    c0258p.a0(objG2);
                }
                E4.d.o(this.f95n, (T3.a) objG2, z3, c0258p, 0);
                c0258p.p(false);
            }
        }
        return G3.C.a;
    }
}

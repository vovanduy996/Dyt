package A;

/* JADX INFO: renamed from: A.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0001b extends U3.k implements T3.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f91l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0012m f92m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0001b(InterfaceC0012m interfaceC0012m, int i5) {
        super(0);
        this.f91l = i5;
        this.f92m = interfaceC0012m;
    }

    @Override // T3.a
    public final Object b() {
        switch (this.f91l) {
        }
        return Boolean.valueOf(X2.g.P(this.f92m.a()));
    }
}

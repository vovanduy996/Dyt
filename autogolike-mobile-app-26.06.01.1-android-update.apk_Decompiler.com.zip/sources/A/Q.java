package A;

import java.util.ArrayList;
import java.util.List;
import r0.AbstractC1650O;
import r0.InterfaceC1641F;
import r0.InterfaceC1642G;
import r0.InterfaceC1643H;
import r0.InterfaceC1644I;

/* JADX INFO: loaded from: classes.dex */
public final class Q implements InterfaceC1642G {
    public static final Q a = new Q();

    @Override // r0.InterfaceC1642G
    public final InterfaceC1643H g(InterfaceC1644I interfaceC1644I, List list, long j5) {
        ArrayList arrayList = new ArrayList(list.size());
        int size = list.size();
        Integer numValueOf = 0;
        for (int i5 = 0; i5 < size; i5++) {
            arrayList.add(((InterfaceC1641F) list.get(i5)).b(j5));
        }
        int size2 = arrayList.size();
        Integer numValueOf2 = numValueOf;
        for (int i6 = 0; i6 < size2; i6++) {
            numValueOf2 = Integer.valueOf(Math.max(numValueOf2.intValue(), ((AbstractC1650O) arrayList.get(i6)).f12944l));
        }
        int iIntValue = numValueOf2.intValue();
        int size3 = arrayList.size();
        for (int i7 = 0; i7 < size3; i7++) {
            numValueOf = Integer.valueOf(Math.max(numValueOf.intValue(), ((AbstractC1650O) arrayList.get(i7)).f12945m));
        }
        return interfaceC1644I.M(iIntValue, numValueOf.intValue(), H3.x.f3465l, new P(0, arrayList));
    }
}

package A;

import n0.C1432A;

/* JADX INFO: renamed from: A.u, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0019u extends M3.c {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public C1432A f167o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public /* synthetic */ Object f168p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f169q;

    @Override // M3.a
    public final Object o(Object obj) {
        this.f168p = obj;
        this.f169q |= Integer.MIN_VALUE;
        return W3.a.p(null, this);
    }
}
